<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/mini_events.php';
$u = require_login();

const SLOT_SYMS = ['JOKER' => '🃏', 'GOLD' => '💰', 'SEVEN' => '7', 'DIAMOND' => '💎', 'BELL' => '🔔', 'CHERRY' => '🍒', 'WINE' => '🍷', 'LEMON' => '🍋'];
const SLOT_W = ['LEMON' => 20, 'WINE' => 15, 'CHERRY' => 14, 'BELL' => 12, 'DIAMOND' => 9, 'SEVEN' => 7, 'GOLD' => 3, 'JOKER' => 2];
// per-symbol tier multiplier (times count-mult 1 / 5 / 20)
const SLOT_TIER = ['SEVEN' => 1.0, 'DIAMOND' => 0.8, 'BELL' => 0.6, 'CHERRY' => 0.5, 'WINE' => 0.4, 'LEMON' => 0.3];

// 5 paylines: 3 rows + 2 diagonals, each [col,row]
function slot_paylines(): array
{
    return [
        [[0, 0], [1, 0], [2, 0], [3, 0], [4, 0]],
        [[0, 1], [1, 1], [2, 1], [3, 1], [4, 1]],
        [[0, 2], [1, 2], [2, 2], [3, 2], [4, 2]],
        [[0, 0], [1, 1], [2, 2], [3, 1], [4, 0]],
        [[0, 2], [1, 1], [2, 0], [3, 1], [4, 2]],
    ];
}

function slot_spin(): array
{
    $reels = [];
    while (count($reels) < 15) {
        $roll = mt_rand(1, array_sum(SLOT_W));
        $acc = 0;
        foreach (SLOT_W as $sym => $w) {
            $acc += $w;
            if ($roll <= $acc) {
                $reels[] = $sym;
                break;
            }
        }
    }
    return $reels;
}

/** Evaluate one payline; returns [sym, symbolsHit] or null. */
function slot_line(array $grid, array $line): ?array
{
    $first = null;
    $hit = [];
    foreach ($line as [$c, $r]) {
        $s = $grid[$r * 5 + $c];
        if ($s === 'JOKER') {
            $hit[] = $s;
            continue;
        }
        if ($first === null) {
            $first = $s;
        }
        if ($s !== $first) {
            break;
        }
        $hit[] = $s;
    }
    if (!$first) {
        // all wilds -> pays as five SEVENs
        return ['SEVEN', array_fill(0, 5, 'SEVEN')];
    }
    if (count($hit) < 3) {
        return null;
    }
    return [$first, $hit];
}

function slot_eval(array $grid): array
{
    $wins = [];
    $total = 0.0; // in stake multiples
    foreach (slot_paylines() as $li => $line) {
        $res = slot_line($grid, $line);
        if ($res) {
            [$sym, $hit] = $res;
            $n = count($hit);
            $countMult = [3 => 1, 4 => 5, 5 => 20][$n] ?? 0;
            $tier = $sym === 'SEVEN' ? 1.0 : SLOT_TIER[$sym];
            $mult = $tier * $countMult;
            $total += $mult;
            $wins[] = ['line' => $li, 'sym' => $sym, 'n' => $n, 'mult' => $mult, 'cells' => array_slice($line, 0, $n)];
        }
    }
    // scatters anywhere
    $gold = array_keys(array_filter($grid, fn($s) => $s === 'GOLD'));
    $g = count($gold);
    $bonus = false;
    if ($g >= 3) {
        $scatterMult = [3 => 5, 4 => 15, 5 => 40][$g] ?? 5;
        $total += $scatterMult;
        $wins[] = ['line' => -1, 'sym' => 'GOLD', 'n' => $g, 'mult' => $scatterMult, 'cells' => array_map(fn($i) => [$i % 5, (int) floor($i / 5)], $gold)];
        if ($g === 5) {
            $bonus = true;
        }
    }
    return ['wins' => $wins, 'total' => round($total, 1), 'goldCells' => $gold, 'bonus' => $bonus];
}

$st = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'slots']);
$st = $st ? json_decode($st['state'], true) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'spin') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('slots.php'); }
        add_money($u['id'], -$stake, 'Slots bet');
        $grid = slot_spin();
        $eval = slot_eval($grid);
        $payout = (int) floor($stake * $eval['total']);
        if ($payout > 0) {
            add_money($u['id'], $payout, 'Slots win');
            event_track('casino_won', (int) $payout);
        } else {
            // Increment progressive jackpot on losing spins
            mini_event_increment_slots_jackpot($stake);
        }
        insert('casino_bets', ['user_id' => $u['id'], 'game' => 'slots', 'stake' => $stake, 'payout' => $payout, 'detail' => count($eval['wins']) . ' wins, bonus ' . ($eval['bonus'] ? 'yes' : 'no')]);
        $pending = null;
        if ($eval['bonus']) {
            $prizes = [2, 3, 5, 8, 12];
            shuffle($prizes);
            $pending = ['stake' => $stake, 'doors' => $prizes];
        }
        $result = ['grid' => $grid, 'wins' => $eval['wins'], 'payout' => $payout, 'stake' => $stake, 'bonus' => $eval['bonus']];
        $st = ['last' => $result, 'pending' => $pending];
    } elseif ($action === 'bonus_pick' && $st && !empty($st['pending'])) {
        $pick = (int) ($_POST['door'] ?? 0);
        $doors = $st['pending']['doors'];
        $stake = (int) $st['pending']['stake'];
        $prize = $doors[$pick] ?? $doors[0];
        $payout = $stake * $prize;
        add_money($u['id'], $payout, 'Slots vault bonus');
        event_track('casino_won', (int) $payout);
        insert('casino_bets', ['user_id' => $u['id'], 'game' => 'slots', 'stake' => $stake, 'payout' => $payout, 'detail' => 'Vault bonus ' . $prize . 'x']);
        $st['bonusResult'] = ['pick' => $pick, 'prize' => $prize, 'payout' => $payout];
        $st['pending'] = null;
    }
    if ($st) {
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'slots', json_encode($st)]);
    }
    redirect('slots.php');
}

$page_title = 'Slot Machine';
require __DIR__ . '/includes/header.php';
$u = current_user();

$jackpot = mini_event_get_slots_jackpot();
$jackpotBoosted = (bool) fetch_one("SELECT 1 FROM settings WHERE k = 'mini_event_jackpot_boosted'", [], 0);

$last = $st['last'] ?? null;
$pending = $st['pending'] ?? null;
$bonusResult = $st['bonusResult'] ?? null;

function slot_cell_html(string $sym, bool $hit): string
{
    $cls = $sym === 'JOKER' ? 'joker' : ($sym === 'GOLD' ? 'gold' : '');
    return '<span class="slot-cell ' . $cls . ($hit ? ' hit' : '') . '" title="' . e($sym) . '">' . SLOT_SYMS[$sym] . '</span>';
}
?>
<style>
.slot-grid{display:grid;grid-template-columns:repeat(5,64px);gap:8px;justify-content:center;background:radial-gradient(ellipse at 50% 30%,#2a2320,#171310);border:1px solid #5c4a2e;border-radius:8px;padding:18px;margin:10px 0}
.slot-cell{display:flex;align-items:center;justify-content:center;width:64px;height:64px;background:#241d19;border:1px solid #4a3b29;border-radius:6px;font-size:1.9rem}
.slot-cell.joker{color:#d9a441}
.slot-cell.gold{color:#ffd700}
.slot-cell.hit{box-shadow:0 0 10px rgba(217,164,65,.8);border-color:#d9a441;background:#3a2f14}
.slot-door{width:110px;height:110px;background:linear-gradient(180deg,#4a4038,#2a2320);border:2px solid #8a7448;border-radius:8px;color:#d9a441;font-weight:800;font-size:2rem;cursor:pointer;transition:transform .12s}
.slot-door:hover{transform:scale(1.06)}
</style>
<div class="card">
  <div class="panel-heading">Slot Machine</div>
  <p class="muted small">Five paylines and a wild 🃏. Three 💰 anywhere pay 5×, five of them trigger the <b>Vault Bonus</b>. Wins on lines: 3/4/5 of a kind pay 1×/5×/20× scaled by symbol tier.</p>
  <?php if ($jackpot > 0): ?>
  <div class="stat" style="margin-top:8px"><span>Progressive Jackpot</span><b><?= money($jackpot) ?></b>
    <?php if ($jackpotBoosted): ?>
      <span class="tag tag-gold">🎰 Boosted!</span>
    <?php endif; ?>
  </div>
  <?php endif; ?>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<?php if ($pending): ?>
<div class="card">
  <div class="panel-heading">💰 Vault Bonus — pick a door!</div>
  <p class="muted small">The countess locked your winnings behind five vault doors. One holds 12× your bet; the rest are kinder still.</p>
  <form method="post" style="display:flex;gap:12px;flex-wrap:wrap;justify-content:center;padding:14px 0">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="bonus_pick">
    <?php foreach ($pending['doors'] as $i => $p): ?>
      <button class="slot-door" type="submit" name="door" value="<?= $i ?>"><?= $i + 1 ?></button>
    <?php endforeach; ?>
  </form>
</div>
<?php elseif ($bonusResult): ?>
<div class="card">
  <div class="panel-heading"><?= $bonusResult['prize'] ?>× Bonus — +<?= money($bonusResult['payout']) ?></div>
  <p class="muted small">You pried open the vault and took <?= money($bonusResult['payout']) ?>.</p>
</div>
<?php endif; ?>

<?php if (!$pending): ?>
<div class="card">
  <?php if (!$last): ?>
    <form method="post" style="max-width:300px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="spin">
      <label>Bet per spin (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="25" required></label>
      <button class="btn btn-gold btn-block" type="submit">Spin</button>
    </form>
  <?php else: ?>
    <?php
    $winCells = [];
    foreach ($last['wins'] as $w) {
        foreach ($w['cells'] as [$cc, $cr]) {
            $winCells[$cr * 5 + $cc] = true;
        }
    }
    ?>
    <div class="panel-heading"><?= $last['payout'] > $last['stake'] ? '<span class="text-green">WIN — +' . money($last['payout'] - $last['stake']) . '</span>' : '<span class="text-danger">NO WIN</span>' ?> · Returned <?= money($last['payout']) ?></div>
    <div class="slot-grid">
      <?php for ($i = 0; $i < 15; $i++): ?>
        <?= slot_cell_html($last['grid'][$i], isset($winCells[$i])) ?>
      <?php endfor; ?>
    </div>
    <?php foreach ($last['wins'] as $w): ?>
      <p class="muted small" style="margin:2px 0"><?= $w['line'] === -1 ? '💰 Scatter ' : 'Line ' . ($w['line'] + 1) . ' ' ?><b><?= SLOT_SYMS[$w['sym']] ?> ×<?= $w['n'] ?></b> → <?= $w['mult'] ?>× bet</p>
    <?php endforeach; ?>
    <form method="post" style="margin-top:10px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="spin">
      <input type="hidden" name="stake" value="<?= (int) $last['stake'] ?>">
      <button class="btn btn-gold" type="submit">Spin Again (<?= money((int) $last['stake']) ?>)</button>
    </form>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="card">
  <div class="panel-heading">Paytable (multiplier × bet)</div>
  <div class="table-wrap"><table>
    <tr><th>Symbol</th><th>3 of a kind</th><th>4 of a kind</th><th>5 of a kind</th></tr>
    <?php foreach (['SEVEN', 'DIAMOND', 'BELL', 'CHERRY', 'WINE', 'LEMON'] as $s): ?>
      <tr><td><?= SLOT_SYMS[$s] ?> <?= e($s) ?></td><td><?= SLOT_TIER[$s] ?>×</td><td><?= SLOT_TIER[$s] * 5 ?>×</td><td><?= SLOT_TIER[$s] * 20 ?>×</td></tr>
    <?php endforeach; ?>
  </table></div>
  <p class="muted small" style="margin-top:6px">🃏 Joker substitutes for everything. 💰 Scatter: 3 = 5×, 4 = 15×, 5 = 40× + Vault Bonus.</p>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>