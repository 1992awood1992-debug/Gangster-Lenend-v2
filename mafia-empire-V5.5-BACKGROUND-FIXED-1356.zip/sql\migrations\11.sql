-- Migration 11: Crafting system (recipes, blueprints, workbench)
-- Idempotent: CREATE TABLE IF NOT EXISTS, safe to re-run.

CREATE TABLE IF NOT EXISTS crafting_recipes (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category ENUM('weapon','armor','vehicle','drug','consumable','special') NOT NULL DEFAULT 'consumable',
    -- Output
    output_item_id INT UNSIGNED NULL,
    output_drug_id INT UNSIGNED NULL,
    output_qty INT UNSIGNED NOT NULL DEFAULT 1,
    -- Requirements
    min_level INT UNSIGNED NOT NULL DEFAULT 1,
    energy_cost INT UNSIGNED NOT NULL DEFAULT 5,
    money_cost INT UNSIGNED NOT NULL DEFAULT 0,
    -- Ingredients (JSON: [{"type":"item","id":1,"qty":2},{"type":"drug","id":3,"qty":1}])
    ingredients JSON NOT NULL,
    -- Result stats (for equipment)
    result_attack INT DEFAULT 0,
    result_defense INT DEFAULT 0,
    -- Chance
    success_chance INT UNSIGNED NOT NULL DEFAULT 100,
    fail_lose_ingredients TINYINT(1) NOT NULL DEFAULT 1,
    -- Metadata
    is_discoverable TINYINT(1) NOT NULL DEFAULT 1,
    blueprint_item_id INT UNSIGNED NULL, -- Item that teaches this recipe
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_category (category),
    KEY idx_min_level (min_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_crafting_recipes (
    user_id INT UNSIGNED NOT NULL,
    recipe_id INT UNSIGNED NOT NULL,
    discovered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, recipe_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crafting_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    recipe_id INT UNSIGNED NOT NULL,
    success TINYINT(1) NOT NULL,
    ingredients_lost TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user_date (user_id, created_at),
    KEY idx_recipe (recipe_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default recipes
INSERT INTO crafting_recipes (code, name, description, category, output_item_id, output_qty, min_level, energy_cost, money_cost, ingredients, result_attack, result_defense, success_chance, fail_lose_ingredients, is_discoverable, blueprint_item_id) VALUES
-- Weapon upgrades
('steel_bat', 'Reinforced Baseball Bat', 'Wrap a bat in steel bands for extra punch.', 'weapon', 1, 1, 5, 10, 5000,
'[{"type":"item","id":1,"qty":1},{"type":"item","id":2,"qty":1},{"type":"drug","id":3,"qty":5}]', 7, 0, 85, 1, 1, NULL),

('serrated_blade', 'Serrated Switchblade', 'Jagged edge causes bleeding wounds.', 'weapon', 2, 1, 10, 15, 15000,
'[{"type":"item","id":2,"qty":1},{"type":"item","id":3,"qty":1},{"type":"drug","id":4,"qty":10}]', 12, 1, 80, 1, 1, NULL),

('extended_mag', 'Extended Magazine 9mm', 'Double the capacity, double the trouble.', 'weapon', 3, 1, 15, 20, 30000,
'[{"type":"item","id":3,"qty":1},{"type":"item","id":1,"qty":2},{"type":"drug","id":5,"qty":5}]', 18, 2, 75, 1, 1, NULL),

('sawed_off_mod', 'Modified Sawn-Off', 'Shortened barrel, widened spread.', 'weapon', 4, 1, 20, 25, 60000,
'[{"type":"item","id":4,"qty":1},{"type":"item","id":5,"qty":1},{"type":"drug","id":6,"qty":3}]', 32, 3, 70, 1, 1, NULL),

-- Armor upgrades
('reinforced_jacket', 'Reinforced Leather Jacket', 'Metal plates sewn into the lining.', 'armor', 7, 1, 5, 10, 5000,
'[{"type":"item","id":7,"qty":1},{"type":"item","id":1,"qty":1},{"type":"drug","id":3,"qty":5}]', 0, 8, 85, 1, 1, NULL),

('kevlar_weave', 'Kevlar-Weave Vest', 'Lighter, stronger protection.', 'armor', 8, 1, 15, 20, 25000,
'[{"type":"item","id":8,"qty":1},{"type":"item","id":9,"qty":1},{"type":"drug","id":5,"qty":10}]', 1, 18, 80, 1, 1, NULL),

('ceramic_plates', 'Ceramic Plate Carrier', 'Stops rifle rounds.', 'armor', 9, 1, 25, 30, 80000,
'[{"type":"item","id":9,"qty":1},{"type":"item","id":10,"qty":1},{"type":"drug","id":6,"qty":5}]', 2, 32, 70, 1, 1, NULL),

('titanium_mesh', 'Titanium Mesh Suit', 'Near-impervious executive armor.', 'armor', 10, 1, 35, 40, 200000,
'[{"type":"item","id":10,"qty":1},{"type":"item","id":9,"qty":2},{"type":"drug","id":7,"qty":10}]', 3, 55, 60, 1, 1, NULL),

-- Vehicle upgrades
('armored_sedan', 'Armored Sedan', 'Bulletproof glass, reinforced doors.', 'vehicle', 11, 1, 10, 15, 15000,
'[{"type":"item","id":11,"qty":1},{"type":"item","id":7,"qty":2},{"type":"drug","id":4,"qty":10}]', 0, 5, 80, 1, 1, NULL),

('turbo_suv', 'Turbocharged SUV', 'Engine tuned for getaway speed.', 'vehicle', 12, 1, 20, 25, 50000,
'[{"type":"item","id":12,"qty":1},{"type":"item","id":3,"qty":2},{"type":"drug","id":6,"qty":5}]', 3, 14, 75, 1, 1, NULL),

('speedboat_armor', 'Armored Speedboat', 'Kevlar hull, mounted gun mount.', 'vehicle', 13, 1, 30, 35, 150000,
'[{"type":"item","id":13,"qty":1},{"type":"item","id":9,"qty":1},{"type":"drug","id":7,"qty":5}]', 4, 18, 70, 1, 1, NULL),

-- Drug synthesis
('super_steroid', 'Super Steroid', 'Permanent +5 Strength (one use).', 'drug', NULL, 1, 20, 30, 50000,
'[{"type":"drug","id":3,"qty":5},{"type":"drug","id":5,"qty":3},{"type":"drug","id":7,"qty":1}]', 0, 0, 60, 1, 1, NULL), -- output_drug_id will be set via drug ID lookup

('combat_stim', 'Combat Stimulant', '+10 Speed for 1 hour.', 'drug', NULL, 3, 15, 20, 25000,
'[{"type":"drug","id":4,"qty":3},{"type":"drug","id":5,"qty":2}]', 0, 0, 80, 1, 1, NULL),

('adrenaline_shot', 'Adrenaline Shot', 'Instant full heal in combat.', 'consumable', NULL, 2, 25, 25, 75000,
'[{"type":"drug","id":5,"qty":2},{"type":"drug","id":6,"qty":1},{"type":"drug","id":7,"qty":1}]', 0, 0, 70, 1, 1, NULL),

-- Consumables
('ammo_box', 'Ammo Box (250 rounds)', 'Craft your own ammunition.', 'consumable', NULL, 1, 5, 5, 5000,
'[{"type":"item","id":1,"qty":1},{"type":"drug","id":3,"qty":2}]', 0, 0, 90, 1, 1, NULL),

('medkit', 'Field Medkit', 'Heals 50 HP instantly.', 'consumable', NULL, 1, 10, 10, 10000,
'[{"type":"drug","id":4,"qty":2},{"type":"drug","id":5,"qty":1}]', 0, 0, 85, 1, 1, NULL),

-- Special
('gold_plated_ak', 'Gold-Plated AK-47', 'Status symbol with +10% intimidation.', 'special', 6, 1, 50, 50, 500000,
'[{"type":"item","id":6,"qty":1},{"type":"item","id":5,"qty":3},{"type":"drug","id":8,"qty":5}]', 50, 5, 50, 1, 1, NULL)
ON DUPLICATE KEY UPDATE
    name=VALUES(name), description=VALUES(description), category=VALUES(category),
    output_item_id=VALUES(output_item_id), output_qty=VALUES(output_qty),
    min_level=VALUES(min_level), energy_cost=VALUES(energy_cost), money_cost=VALUES(money_cost),
    ingredients=VALUES(ingredients), result_attack=VALUES(result_attack), result_defense=VALUES(result_defense),
    success_chance=VALUES(success_chance), fail_lose_ingredients=VALUES(fail_lose_ingredients),
    is_discoverable=VALUES(is_discoverable), blueprint_item_id=VALUES(blueprint_item_id);