<?php
require_once __DIR__ . '/includes/init.php';
// Public page - no login required

$page_title = 'Statistics';
require __DIR__ . '/includes/header.php';

$totalPlayers = (int) fetch_one('SELECT COUNT(*) FROM users WHERE is_banned = 0', [], 0);
$onlinePlayers = (int) fetch_one('SELECT COUNT(*) FROM users WHERE is_banned = 0 AND last_active > DATE_SUB(NOW(), INTERVAL 5 MINUTE)', [], 0);
$totalMoney = (int) fetch_one('SELECT COALESCE(SUM(money + bank),0) FROM users WHERE is_banned = 0', [], 0);
$totalBullets = (int) fetch_one('SELECT COALESCE(SUM(bullets),0) FROM users WHERE is_banned = 0', [], 0);
$totalKills = (int) fetch_one('SELECT COALESCE(SUM(kills),0) FROM users WHERE is_banned = 0', [], 0);
$totalCrews = (int) fetch_one('SELECT COUNT(*) FROM crews', [], 0);
$totalPosts = (int) fetch_one('SELECT COUNT(*) FROM forum_posts', [], 0);
$totalMissions = (int) fetch_one('SELECT COALESCE(SUM(missions_done),0) FROM users', [], 0);
$richest = fetch('SELECT username, money, bank FROM users WHERE is_banned = 0 ORDER BY (money + bank) DESC LIMIT 1');
$highestLevel = fetch('SELECT username, level FROM users WHERE is_banned = 0 ORDER BY level DESC, xp DESC LIMIT 1');
$busiestDistrict = fetch('SELECT d.name, COUNT(u.id) AS cnt FROM districts d LEFT JOIN users u ON u.district_id = d.id GROUP BY d.id ORDER BY cnt DESC LIMIT 1');
?>
<div class="card">
  <div class="panel-heading">Game Statistics</div>
  <p class="muted small">Live stats updated in real-time.</p>
</div>

<div class="grid grid-4">
  <a class="tile" href="<?= e(url('users.php')) ?>"><span class="ico">👥</span><b>Total Players</b><small><?= number_format($totalPlayers) ?></small></a>
  <a class="tile" href="<?= e(url('users.php')) ?>"><span class="ico">🟢</span><b>Online Now</b><small><?= number_format($onlinePlayers) ?></small></a>
  <a class="tile" href="#"><span class="ico">💰</span><b>Money in Circulation</b><small><?= money($totalMoney) ?></small></a>
  <a class="tile" href="#"><span class="ico">🔫</span><b>Total Bullets</b><small><?= number_format($totalBullets) ?></small></a>
</div>

<div class="grid grid-4">
  <a class="tile" href="<?= e(url('kill.php')) ?>"><span class="ico">⚔️</span><b>Total Kills</b><small><?= number_format($totalKills) ?></small></a>
  <a class="tile" href="<?= e(url('crew.php')) ?>"><span class="ico">🏢</span><b>Total Crews</b><small><?= number_format($totalCrews) ?></small></a>
  <a class="tile" href="<?= e(url('forum.php')) ?>"><span class="ico">💬</span><b>Forum Posts</b><small><?= number_format($totalPosts) ?></small></a>
  <a class="tile" href="<?= e(url('missions.php')) ?>"><span class="ico">📋</span><b>Missions Completed</b><small><?= number_format($totalMissions) ?></small></a>
</div>

<div class="grid grid-3" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Richest Player</div>
    <?php if ($richest): ?>
      <div class="stat"><span><?= e($richest['username']) ?></span><b><?= money((int) $richest['money'] + (int) $richest['bank']) ?></b></div>
    <?php else: ?>
      <p class="muted">No players yet.</p>
    <?php endif; ?>
  </div>
  <div class="card">
    <div class="panel-heading">Highest Level</div>
    <?php if ($highestLevel): ?>
      <div class="stat"><span><?= e($highestLevel['username']) ?></span><b>Level <?= (int) $highestLevel['level'] ?></b></div>
    <?php else: ?>
      <p class="muted">No players yet.</p>
    <?php endif; ?>
  </div>
  <div class="card">
    <div class="panel-heading">Busiest District</div>
    <?php if ($busiestDistrict): ?>
      <div class="stat"><span><?= e($busiestDistrict['name']) ?></span><b><?= (int) $busiestDistrict['cnt'] ?> players</b></div>
    <?php else: ?>
      <p class="muted">No data.</p>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>