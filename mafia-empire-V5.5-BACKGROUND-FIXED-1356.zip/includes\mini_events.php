<?php
/**
 * Eye Of The Mafia - Mini Events System
 * Random daily occurrences with gameplay effects, announced globally.
 */

require_once __DIR__ . '/init.php';

/**
 * Mini Event Types and their configuration
 */
const MINI_EVENT_TYPES = [
    'drug_surge' => [
        'name' => 'Drug Surge',
        'rarity' => 'common',
        'weight' => 100,
        'duration_minutes' => 10,
        'effect' => ['drug_price_multiplier' => 2.0],
        'announce' => '💊 Drug Surge in %s! Drug prices doubled for 10 minutes!',
    ],
    'bullet_restock' => [
        'name' => 'Bullet Store Restock',
        'rarity' => 'common',
        'weight' => 100,
        'duration_minutes' => 15,
        'effect' => ['bullet_production_multiplier' => 3.0],
        'announce' => '🔫 Bullet Store restocked in %s! Factory output tripled for 15 minutes!',
    ],
    'safe_deposit' => [
        'name' => 'Safe Deposit',
        'rarity' => 'common',
        'weight' => 100,
        'duration_minutes' => 20,
        'effect' => ['safe_pot_multiplier' => 2.0],
        'announce' => '💰 Safe Deposit in %s! The city safe just got a massive deposit!',
    ],
    'jackpot_boost' => [
        'name' => 'Jackpot Boost',
        'rarity' => 'rare',
        'weight' => 25,
        'duration_minutes' => 30,
        'effect' => ['slots_jackpot_boost' => 40000000],
        'announce' => '🎰 Jackpot Boost in %s! Slot Machine jackpot increased by $40,000,000 for 30 minutes!',
    ],
];

/**
 * Pick a random city (district) for the event
 */
function mini_event_pick_city(): ?int
{
    $city = fetch('SELECT id FROM districts ORDER BY RAND() LIMIT 1');
    return $city ? (int) $city['id'] : null;
}

/**
 * Get the next scheduled run time (Unix timestamp)
 */
function mini_event_get_next_run(): int
{
    return (int) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_next_run'", [], 0);
}

/**
 * Set the next scheduled run time
 */
function mini_event_set_next_run(int $timestamp): void
{
    q("INSERT INTO settings (k, v) VALUES ('mini_event_next_run', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) $timestamp]);
}

/**
 * Get scheduling window from settings
 */
function mini_event_get_window(): array
{
    $min = (int) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_min_hours'", [], 1);
    $max = (int) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_max_hours'", [], 12);
    return [$min * 3600, $max * 3600];
}

/**
 * Schedule the next mini event
 */
function mini_event_schedule_next(): int
{
    [$minSec, $maxSec] = mini_event_get_window();
    $delay = mt_rand($minSec, $maxSec);
    $nextRun = time() + $delay;
    mini_event_set_next_run($nextRun);
    return $nextRun;
}

/**
 * Check if a mini event is currently active
 */
function mini_event_is_active(): ?array
{
    $now = date('Y-m-d H:i:s');
    return fetch("
        SELECT * FROM mini_events
        WHERE is_active = 1
        AND started_at IS NOT NULL
        AND started_at <= ?
        AND ends_at IS NOT NULL
        AND ends_at > ?
        ORDER BY started_at DESC
        LIMIT 1
    ", [$now, $now]);
}

/**
 * Get all mini events (for admin UI)
 */
function mini_event_get_all(): array
{
    return fetch_all("
        SELECT me.*, d.name as city_name
        FROM mini_events me
        LEFT JOIN districts d ON d.id = me.city_id
        ORDER BY me.started_at DESC, me.id DESC
    ");
}

/**
 * Start a mini event by type (manual trigger from admin)
 */
function mini_event_start(string $type): array
{
    if (!isset(MINI_EVENT_TYPES[$type])) {
        return ['ok' => false, 'error' => 'Unknown event type'];
    }
    $config = MINI_EVENT_TYPES[$type];
    $cityId = mini_event_pick_city();
    if (!$cityId) {
        return ['ok' => false, 'error' => 'No districts found'];
    }

    $now = date('Y-m-d H:i:s');
    $endsAt = date('Y-m-d H:i:s', time() + $config['duration_minutes'] * 60);
    $instanceCode = $type . '_' . bin2hex(random_bytes(8));

    $id = insert('mini_events', [
        'instance_code' => $instanceCode,
        'type' => $type,
        'name' => $config['name'],
        'rarity' => $config['rarity'],
        'weight' => $config['weight'],
        'is_active' => 1,
        'city_id' => $cityId,
        'params' => json_encode($config['effect']),
        'started_at' => $now,
        'ends_at' => $endsAt,
    ]);

    // Apply the effect immediately
    mini_event_apply_effect($type, $config['effect'], $cityId, true);

    // Announce globally
    $cityName = fetch_one('SELECT name FROM districts WHERE id = ?', [$cityId], 'the city');
    $msg = sprintf($config['announce'], $cityName);
    mini_event_announce($msg);

    return ['ok' => true, 'id' => $id, 'ends_at' => $endsAt, 'city' => $cityName];
}

/**
 * Apply a mini event's gameplay effect
 */
function mini_event_apply_effect(string $type, array $effect, int $cityId, bool $starting): void
{
    global $settingsCache;
    $settingsCache ??= [];

    switch ($type) {
        case 'drug_surge':
            if (isset($effect['drug_price_multiplier'])) {
                $mult = (float) $effect['drug_price_multiplier'];
                $settingsCache['mini_event_drug_multiplier'] = $mult;
                $settingsCache['mini_event_drug_city'] = $cityId;
                q("INSERT INTO settings (k, v) VALUES ('mini_event_drug_multiplier', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) $mult]);
                q("INSERT INTO settings (k, v) VALUES ('mini_event_drug_city', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) $cityId]);
            }
            break;
        case 'bullet_restock':
            if (isset($effect['bullet_production_multiplier'])) {
                $mult = (float) $effect['bullet_production_multiplier'];
                $settingsCache['mini_event_bullet_multiplier'] = $mult;
                $settingsCache['mini_event_bullet_city'] = $cityId;
                q("INSERT INTO settings (k, v) VALUES ('mini_event_bullet_multiplier', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) $mult]);
                q("INSERT INTO settings (k, v) VALUES ('mini_event_bullet_city', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) $cityId]);
                // Also backdate last_collect for the factory so owners collect a windfall
                q("UPDATE bullet_factories SET last_collect = DATE_SUB(last_collect, INTERVAL 8 HOUR) WHERE district_id = ?", [$cityId]);
            }
            break;
        case 'safe_deposit':
            if (isset($effect['safe_pot_multiplier'])) {
                $mult = (float) $effect['safe_pot_multiplier'];
                $settingsCache['mini_event_safe_multiplier'] = $mult;
                // No city restriction for safe - it's global pot
                q("INSERT INTO settings (k, v) VALUES ('mini_event_safe_multiplier', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) $mult]);
            }
            break;
        case 'jackpot_boost':
            if (isset($effect['slots_jackpot_boost'])) {
                $boost = (int) $effect['slots_jackpot_boost'];
                // Increment the progressive jackpot
                $current = (int) fetch_one("SELECT v FROM settings WHERE k = 'slots_jackpot'", [], 0);
                $newPot = $current + $boost;
                q("INSERT INTO settings (k, v) VALUES ('slots_jackpot', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) $newPot]);
                q("INSERT INTO settings (k, v) VALUES ('mini_event_jackpot_boosted', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) time()]);
            }
            break;
    }
}

/**
 * Remove a mini event's gameplay effect
 */
function mini_event_remove_effect(string $type): void
{
    switch ($type) {
        case 'drug_surge':
            q("DELETE FROM settings WHERE k IN ('mini_event_drug_multiplier', 'mini_event_drug_city')");
            break;
        case 'bullet_restock':
            q("DELETE FROM settings WHERE k IN ('mini_event_bullet_multiplier', 'mini_event_bullet_city')");
            break;
        case 'safe_deposit':
            q("DELETE FROM settings WHERE k = 'mini_event_safe_multiplier'");
            break;
        case 'jackpot_boost':
            q("DELETE FROM settings WHERE k = 'mini_event_jackpot_boosted'");
            // Jackpot boost is permanent (added to the progressive pot)
            break;
    }
}

/**
 * Announce a mini event globally (city ticker + Discord + notify online users)
 */
function mini_event_announce(string $message): void
{
    // 1. Add to city ticker (shown on every page via header.php)
    $tickerKey = 'ticker:mini_event';
    $existing = cache_get($tickerKey) ?? [];
    array_unshift($existing, $message);
    if (count($existing) > 5) $existing = array_slice($existing, 0, 5);
    cache_set($tickerKey, $existing, 300); // 5 min TTL

    // 2. Discord webhook
    if (function_exists('discord_notify')) {
        try { discord_notify("🌐 **Mini Event**\n$message"); } catch (Throwable $e) {}
    }

    // 3. Notify users active in last 10 minutes (push bridge via notify())
    $users = fetch_all("SELECT id FROM users WHERE last_active > DATE_SUB(NOW(), INTERVAL 10 MINUTE)");
    foreach ($users as $u) {
        notify((int) $u['id'], $message, 'events.php');
    }
}

/**
 * Cron tick task: advance mini events schedule, start/expire events
 * Returns summary array for task_tick() logging
 */
function mini_event_cron(): array
{
    $result = ['started' => 0, 'expired' => 0, 'next_scheduled' => 0];

    $now = time();
    $nextRun = mini_event_get_next_run();

    // If it's time to start a new event
    if ($now >= $nextRun) {
        // Pick a random event type weighted by rarity
        $types = [];
        foreach (MINI_EVENT_TYPES as $type => $config) {
            $types = array_merge($types, array_fill(0, $config['weight'], $type));
        }
        $chosenType = $types[array_rand($types)];

        $started = mini_event_start($chosenType);
        if (!empty($started['ok'])) {
            $result['started'] = 1;
            $result['event_type'] = $chosenType;
            $result['city'] = $started['city'] ?? '';
        }
        // Schedule the next one
        $result['next_scheduled'] = mini_event_schedule_next();
    }

    // Expire any active events whose end time passed
    $expired = fetch_all("
        SELECT id, type FROM mini_events
        WHERE is_active = 1
        AND ends_at IS NOT NULL
        AND ends_at <= NOW()
    ");
    foreach ($expired as $ev) {
        q('UPDATE mini_events SET is_active = 0 WHERE id = ?', [(int) $ev['id']]);
        mini_event_remove_effect($ev['type']);
        $result['expired']++;
    }

    // If no event ever scheduled, schedule the first one
    if ($nextRun === 0) {
        $result['next_scheduled'] = mini_event_schedule_next();
    }

    return $result;
}

/**
 * Get current active mini event for display (header ticker, events page, etc.)
 */
function mini_event_get_active_for_display(): ?array
{
    $active = mini_event_is_active();
    if (!$active) return null;

    $cityName = fetch_one('SELECT name FROM districts WHERE id = ?', [(int) $active['city_id']], 'Unknown City');
    $config = MINI_EVENT_TYPES[$active['type']] ?? ['duration_minutes' => 0];
    $endsAt = new DateTime($active['ends_at']);
    $remaining = max(0, $endsAt->getTimestamp() - time());

    return [
        'id' => (int) $active['id'],
        'type' => $active['type'],
        'name' => $active['name'],
        'city' => $cityName,
        'city_id' => (int) $active['city_id'],
        'ends_at' => $active['ends_at'],
        'remaining_seconds' => $remaining,
        'effect' => json_decode($active['params'] ?? '{}', true),
    ];
}

/**
 * Get drug price multiplier for current mini event (if any)
 */
function mini_event_get_drug_multiplier(int $cityId): float
{
    $activeCity = (int) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_drug_city'", [], 0);
    if ($activeCity !== $cityId) return 1.0;
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_drug_multiplier'", [], 1.0);
}

/**
 * Get bullet factory production multiplier for current mini event (if any)
 */
function mini_event_get_bullet_multiplier(int $cityId): float
{
    $activeCity = (int) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_bullet_city'", [], 0);
    if ($activeCity !== $cityId) return 1.0;
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_bullet_multiplier'", [], 1.0);
}

/**
 * Get safe pot multiplier for current mini event (if any)
 */
function mini_event_get_safe_multiplier(): float
{
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_safe_multiplier'", [], 1.0);
}

/**
 * Get slots jackpot (includes any mini-event boosts)
 */
function mini_event_get_slots_jackpot(): int
{
    return (int) fetch_one("SELECT v FROM settings WHERE k = 'slots_jackpot'", [], 0);
}

/**
 * Add to slots jackpot (called on each losing spin to build progressive)
 */
function mini_event_increment_slots_jackpot(int $stake): void
{
    // 1% of each losing stake goes to progressive jackpot
    $add = max(1, (int) floor($stake * 0.01));
    $current = mini_event_get_slots_jackpot();
    q("INSERT INTO settings (k, v) VALUES ('slots_jackpot', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) ($current + $add)]);
}

/**
 * Reset a mini event type (admin action - force end)
 */
function mini_event_end(int $eventId): array
{
    $ev = fetch('SELECT * FROM mini_events WHERE id = ?', [(int) $eventId]);
    if (!$ev) return ['ok' => false, 'error' => 'Event not found'];
    if ((int) $ev['is_active'] === 0) return ['ok' => false, 'error' => 'Already ended'];

    q('UPDATE mini_events SET is_active = 0, ends_at = NOW() WHERE id = ?', [(int) $eventId]);
    mini_event_remove_effect($ev['type']);

    return ['ok' => true];
}