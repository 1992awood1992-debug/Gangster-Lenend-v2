<?php
/**
 * Mafia Empire - cron dispatcher.
 *
 * Usage:
 *   php cron/run.php tick      # every 5 minutes
 *   php cron/run.php webhooks  # every minute (deliver queued webhooks)
 *   php cron/run.php push      # every minute (deliver queued push messages)
 *   php cron/run.php daily     # once a day (e.g. 00:05)
 *   php cron/run.php weekly    # once a week (e.g. Sunday 03:00)
 *   php cron/run.php discord   # once a day (post the Discord digest)
 *   php cron/run.php all       # run every task now
 *   php cron/run.php migrate   # apply pending schema migrations
 *   php cron/run.php vapid     # generate Web Push (VAPID) keys into config/vapid.php
 *
 * A simple file lock prevents overlapping runs of the same task.
 */
require __DIR__ . '/../includes/cli.php';
require __DIR__ . '/../includes/tasks.php';

$task = $argv[1] ?? 'help';
$known = ['tick', 'webhooks', 'push', 'daily', 'weekly', 'discord', 'all', 'migrate', 'vapid'];

if (!in_array($task, $known, true)) {
    fwrite(STDOUT, "Usage: php cron/run.php <" . implode('|', $known) . ">\n");
    exit(0);
}

$lockFile = sys_get_temp_dir() . '/mafia_empire_cron_' . $task . '.lock';
$lock = fopen($lockFile, 'c');
if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
    cli_log("Task '$task' is already running; skipping this invocation.");
    exit(0);
}

$start = microtime(true);
try {
    switch ($task) {
        case 'tick':
            cli_log('tick: ' . json_encode(task_tick()));
            cli_log('webhooks: ' . json_encode(task_webhooks()));
            cli_log('push: ' . json_encode(task_push()));
            break;
        case 'webhooks':
            cli_log('webhooks: ' . json_encode(task_webhooks()));
            break;
        case 'push':
            cli_log('push: ' . json_encode(task_push()));
            break;
        case 'daily':
            cli_log('daily: ' . json_encode(task_daily()));
            cli_log('discord: ' . json_encode(task_discord_digest()));
            break;
        case 'weekly':
            cli_log('weekly: ' . json_encode(task_weekly()));
            break;
        case 'discord':
            cli_log('discord: ' . json_encode(task_discord_digest()));
            break;
        case 'all':
            cli_log('tick: '   . json_encode(task_tick()));
            cli_log('daily: '  . json_encode(task_daily()));
            cli_log('weekly: ' . json_encode(task_weekly()));
            cli_log('webhooks: ' . json_encode(task_webhooks()));
            cli_log('push: ' . json_encode(task_push()));
            cli_log('discord: ' . json_encode(task_discord_digest()));
            break;
        case 'vapid':
            $keys = push_generate_keys();
            if (!$keys) {
                cli_error('OpenSSL EC (prime256v1) is unavailable on this PHP build.');
                break;
            }
            $dir = dirname(__DIR__) . '/config';
            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }
            $php = "<?php\n// Auto-generated VAPID key pair for Web Push. Keep this file secret.\nreturn "
                . var_export(['public' => $keys['public'], 'private' => $keys['private'], 'subject' => VAPID_SUBJECT], true) . ";\n";
            if (file_put_contents($dir . '/vapid.php', $php) === false) {
                cli_error('Could not write config/vapid.php (check permissions).');
                break;
            }
            cli_log('VAPID key pair written to config/vapid.php');
            cli_log('Public key: ' . $keys['public']);
            break;
        case 'migrate':
            run_migrations();
            cli_log('migrations complete (SCHEMA_VERSION=' . SCHEMA_VERSION . ')');
            break;
    }
    cli_log(sprintf("task '%s' finished in %.3fs", $task, microtime(true) - $start));
} catch (Throwable $e) {
    cli_error($e->getMessage());
    flock($lock, LOCK_UN);
    fclose($lock);
    exit(1);
}

flock($lock, LOCK_UN);
fclose($lock);
exit(0);
