-- Phase 9: Social Features - Trading, Crew Chat, Hitlist, Bounty Board

-- Player Trading
CREATE TABLE IF NOT EXISTS trades (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sender_id INT UNSIGNED NOT NULL,
  recipient_id INT UNSIGNED NOT NULL,
  status ENUM('pending','accepted','declined','cancelled','expired') NOT NULL DEFAULT 'pending',
  sender_items JSON NOT NULL, -- [{"item_id": 1, "qty": 2}, ...]
  sender_money INT NOT NULL DEFAULT 0,
  sender_bullets INT NOT NULL DEFAULT 0,
  recipient_items JSON NOT NULL,
  recipient_money INT NOT NULL DEFAULT 0,
  recipient_bullets INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  expires_at DATETIME NOT NULL,
  completed_at DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY idx_sender (sender_id),
  KEY idx_recipient (recipient_id),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crew Chat
CREATE TABLE IF NOT EXISTS crew_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  crew_id INT UNSIGNED NOT NULL,
  sender_id INT UNSIGNED NOT NULL,
  message TEXT NOT NULL,
  message_type ENUM('text','system','trade_offer','bounty') NOT NULL DEFAULT 'text',
  related_id BIGINT UNSIGNED NULL, -- trade_id, bounty_id, etc.
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_crew (crew_id, created_at),
  KEY idx_sender (sender_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Hitlist
CREATE TABLE IF NOT EXISTS hitlist (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  target_id INT UNSIGNED NOT NULL,
  placer_id INT UNSIGNED NOT NULL,
  reward_money INT UNSIGNED NOT NULL DEFAULT 0,
  reward_points INT UNSIGNED NOT NULL DEFAULT 0,
  reward_bullets INT UNSIGNED NOT NULL DEFAULT 0,
  message VARCHAR(255) DEFAULT '',
  status ENUM('open','claimed','completed','cancelled','expired') NOT NULL DEFAULT 'open',
  claimed_by INT UNSIGNED NULL,
  claimed_at DATETIME NULL,
  completed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_target (target_id, status),
  KEY idx_placer (placer_id),
  KEY idx_claimer (claimed_by),
  KEY idx_status (status, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bounty Board (player-created bounties on other players)
CREATE TABLE IF NOT EXISTS bounties (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  target_id INT UNSIGNED NOT NULL,
  creator_id INT UNSIGNED NOT NULL,
  reward_money INT UNSIGNED NOT NULL DEFAULT 0,
  reward_points INT UNSIGNED NOT NULL DEFAULT 0,
  reward_bullets INT UNSIGNED NOT NULL DEFAULT 0,
  reason VARCHAR(255) DEFAULT '',
  status ENUM('open','claimed','completed','cancelled','expired') NOT NULL DEFAULT 'open',
  claimed_by INT UNSIGNED NULL,
  claimed_at DATETIME NULL,
  completed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_target (target_id, status),
  KEY idx_creator (creator_id),
  KEY idx_claimer (claimed_by),
  KEY idx_status (status, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Social notifications (trade requests, chat mentions, bounty claims, etc.)
CREATE TABLE IF NOT EXISTS social_notifications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  type ENUM('trade_request','trade_accepted','trade_declined','chat_mention','bounty_placed','bounty_claimed','hitlist_placed','hitlist_claimed','trade_completed') NOT NULL,
  title VARCHAR(100) NOT NULL,
  message TEXT NOT NULL,
  related_type VARCHAR(20) NULL, -- 'trade', 'bounty', 'hitlist', 'chat'
  related_id BIGINT UNSIGNED NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id, is_read, created_at),
  KEY idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crew message read tracking (for unread counts)
CREATE TABLE IF NOT EXISTS crew_message_reads (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  crew_id INT UNSIGNED NOT NULL,
  message_id BIGINT UNSIGNED NOT NULL,
  read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_user_message (user_id, message_id),
  KEY idx_user_crew (user_id, crew_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;