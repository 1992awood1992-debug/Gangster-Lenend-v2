<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

function bj_deck(): array
{
    $suits = ['♠', '♥', '♦', '♣'];
    $ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    $deck = [];
    foreach ($suits as $s) {
        foreach ($ranks as $r) {
            $deck[] = $r . $s;
        }
    }
    shuffle($deck);
    return $deck;
}

function bj_value(array $hand): int
{
    $v = 0;
    $aces = 0;
    foreach ($hand as $card) {
        [$r] = card_parts($card);
        if ($r === 'A') { $v += 11; $aces++; }
        elseif (is_numeric($r)) { $v += (int) $r; }
        else { $v += 10; }
    }
    while ($v > 21 && $aces > 0) { $v -= 10; $aces--; }
    return $v;
}

function bj_is_natural(array $hand): bool
{
    return count($hand) === 2 && bj_value($hand) === 21;
}

/** Settle one hand. Returns [label, moneyAddedPaidBack]. */
function bj_settle_hand(int $pid, int $wager, array $userHand, array $dealerHand, bool $natural): array
{
    $pv = bj_value($userHand);
    $dv = bj_value($dealerHand);
    if ($pv > 21) {
        return ['Bust', 0];
    }
    if ($natural && count($userHand) === 2 && $pv === 21) {
        if ($dv === 21) {
            return ['Push', $wager];
        }
        $pay = (int) round($wager * 1.5) + $wager;
        add_money($pid, $pay, 'Blackjack natural');
        return ['Blackjack (3:2)', $pay];
    }
    if ($dv > 21 || $pv > $dv) {
        add_money($pid, $wager * 2, 'Blackjack win');
        return ['Win', $wager * 2];
    }
    if ($pv === $dv) {
        add_money($pid, $wager, 'Blackjack push');
        return ['Push', $wager];
    }
    return ['Lose', 0];
}

$state = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'blackjack']);
$state = $state ? json_decode($state['state'], true) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'start') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('blackjack.php'); }
        add_money($u['id'], -$stake, 'Blackjack bet');
        $deck = bj_deck();
        $state = [
            'wager1' => $stake, 'wager2' => null,
            'deck' => $deck,
            'hand' => [array_pop($deck), array_pop($deck)],
            'hand2' => null,
            'dealer' => [array_pop($deck), array_pop($deck)],
            'turn' => 'h', 'phase' => 'play',
            'insurance' => 0, 'msg' => '', 'done' => false,
        ];
        if (bj_is_natural($state['hand'])) {
            if (bj_is_natural($state['dealer'])) {
                add_money($u['id'], $stake, 'Blackjack push');
                $state['phase'] = 'done'; $state['done'] = true;
                $state['msg'] = 'Both dealt Blackjack — push.';
                insert('casino_bets', ['user_id' => $u['id'], 'game' => 'blackjack', 'stake' => $stake, 'payout' => $stake, 'detail' => 'Double blackjack (push)']);
            } else {
                $pay = (int) round($stake * 1.5) + $stake;
                add_money($u['id'], $pay, 'Blackjack natural');
                event_track('casino_won', (int) $pay);
                $state['phase'] = 'done'; $state['done'] = true;
                $state['msg'] = 'Blackjack! Paid 3:2.';
                insert('casino_bets', ['user_id' => $u['id'], 'game' => 'blackjack', 'stake' => $stake, 'payout' => $pay, 'detail' => 'Blackjack (3:2)']);
            }
        } elseif (bj_is_natural($state['dealer'])) {
            $state['phase'] = 'done'; $state['done'] = true;
            $state['msg'] = 'Dealer has Blackjack.';
            insert('casino_bets', ['user_id' => $u['id'], 'game' => 'blackjack', 'stake' => $stake, 'payout' => 0, 'detail' => 'Dealer blackjack']);
        } elseif (card_parts($state['dealer'][0])[0] === 'A') {
            $state['phase'] = 'insurance';
            $state['msg'] = 'Dealer shows an Ace — take insurance?';
        }
    } elseif ($action === 'insurance_yes' && $state && $state['phase'] === 'insurance') {
        $ins = (int) floor($state['wager1'] / 2);
        if ($ins > $u['money']) { flash('Not enough cash for insurance.', 'error'); redirect('blackjack.php'); }
        add_money($u['id'], -$ins, 'Blackjack insurance');
        $state['insurance'] = $ins;
        if (bj_is_natural($state['dealer'])) {
            add_money($u['id'], $ins * 3, 'Blackjack insurance paid');
            event_track('casino_won', (int) ($ins * 3));
            $state['phase'] = 'done'; $state['done'] = true;
            $state['msg'] = 'Dealer had Blackjack — insurance pays 2:1. Main bet lost.';
            insert('casino_bets', ['user_id' => $u['id'], 'game' => 'blackjack', 'stake' => $state['wager1'] + $ins, 'payout' => $ins * 3, 'detail' => 'Dealer BJ, insurance 2:1']);
        } else {
            $state['phase'] = 'play';
            $state['msg'] = 'Insurance taken. Dealer has no blackjack.';
        }
    } elseif ($action === 'insurance_no' && $state && $state['phase'] === 'insurance') {
        $state['phase'] = 'play';
        $state['msg'] = 'No insurance.';
    } elseif ($state && $state['phase'] === 'play') {
        $handKey = $state['turn'] === 'h2' ? 'hand2' : 'hand';
        if ($action === 'hit') {
            $state[$handKey][] = array_pop($state['deck']);
            if (bj_value($state[$handKey]) > 21) {
                if ($state['hand2']) {
                    $state['turn'] = 'h2';
                    $state['msg'] = 'First hand busts. Playing second hand.';
                } else {
                    $state['phase'] = 'dealer';
                    $state['msg'] = 'Bust (' . bj_value($state[$handKey]) . '). Dealer plays.';
                }
            }
        } elseif ($action === 'stand') {
            if ($state['hand2'] && $handKey === 'hand') {
                $state['turn'] = 'h2';
                $state['msg'] = 'Stand on first hand. Playing second hand.';
            } else {
                $state['phase'] = 'dealer';
            }
        } elseif ($action === 'double') {
            if (count($state[$handKey]) !== 2) { flash('Can only double on two cards.', 'error'); redirect('blackjack.php'); }
            $extra = $handKey === 'hand' ? (int) $state['wager1'] : (int) ($state['wager2'] ?? $state['wager1']);
            if ($extra > $u['money']) { flash('Not enough cash to double.', 'error'); redirect('blackjack.php'); }
            add_money($u['id'], -$extra, 'Blackjack double');
            if ($handKey === 'hand') { $state['wager1'] += $extra; } else { $state['wager2'] += $extra; }
            $state[$handKey][] = array_pop($state['deck']);
            if ($state['hand2'] && $handKey === 'hand') {
                $state['turn'] = 'h2';
                $state['msg'] = 'Doubled first hand. Playing second.';
            } else {
                $state['phase'] = 'dealer';
            }
        } elseif ($action === 'split' && !$state['hand2']) {
            $hand = $state['hand'];
            if (count($hand) !== 2) { flash('Can only split two cards.', 'error'); redirect('blackjack.php'); }
            $e1 = card_parts($hand[0])[0]; $e2 = card_parts($hand[1])[0];
            $v1 = ($e1 === 'A') ? 11 : (is_numeric($e1) ? (int) $e1 : 10);
            $v2 = ($e2 === 'A') ? 11 : (is_numeric($e2) ? (int) $e2 : 10);
            if ($v1 !== $v2) { flash('Cards must match value to split.', 'error'); redirect('blackjack.php'); }
            if ((int) $state['wager1'] > $u['money']) { flash('Not enough cash to split.', 'error'); redirect('blackjack.php'); }
            add_money($u['id'], -(int) $state['wager1'], 'Blackjack split');
            $state['wager2'] = (int) $state['wager1'];
            $state['hand2'] = [array_pop($state['deck']), $hand[1]];
            $state['hand'] = [$hand[0], array_pop($state['deck'])];
            $state['msg'] = 'Split! Playing first hand.';
        }
        if ($state['phase'] === 'dealer') {
            $state['msg'] = '';
            bj_dealer_draw($state['dealer'], $state['deck']);
            $dealerVal = bj_value($state['dealer']);
            $payback = 0;
            $stakeTotal = (int) $state['wager1'] + (int) ($state['wager2'] ?? 0);
            [$res1, $pay1] = bj_settle_hand($u['id'], (int) $state['wager1'], $state['hand'], $state['dealer'], false);
            $payback += $pay1;
            $labels = ['Hand 1: ' . $res1];
            if ($state['hand2']) {
                [$res2, $pay2] = bj_settle_hand($u['id'], (int) $state['wager2'], $state['hand2'], $state['dealer'], false);
                $payback += $pay2;
                $labels[] = 'Hand 2: ' . $res2;
            }
            $state['phase'] = 'done'; $state['done'] = true;
            $state['msg'] = 'Dealer ' . $dealerVal . ' — ' . implode('. ', $labels) . '.';
            insert('casino_bets', ['user_id' => $u['id'], 'game' => 'blackjack', 'stake' => $stakeTotal, 'payout' => $payback, 'detail' => substr($state['msg'], 0, 190)]);
        }
    } elseif ($action === 'deal_again' && $state && $state['done']) {
        // re-deal same stake
        $stake = (int) $state['wager1'] + (int) ($state['wager2'] ?? 0);
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('blackjack.php'); }
        add_money($u['id'], -$stake, 'Blackjack bet');
        $deck = bj_deck();
        $state = [
            'wager1' => $stake, 'wager2' => null,
            'deck' => $deck,
            'hand' => [array_pop($deck), array_pop($deck)],
            'hand2' => null,
            'dealer' => [array_pop($deck), array_pop($deck)],
            'turn' => 'h', 'phase' => 'play',
            'insurance' => 0, 'msg' => '', 'done' => false,
        ];
        if (bj_is_natural($state['hand'])) {
            if (bj_is_natural($state['dealer'])) {
                add_money($u['id'], $stake, 'Blackjack push');
                $state['phase'] = 'done'; $state['done'] = true;
                $state['msg'] = 'Both dealt Blackjack — push.';
                insert('casino_bets', ['user_id' => $u['id'], 'game' => 'blackjack', 'stake' => $stake, 'payout' => $stake, 'detail' => 'Double blackjack (push)']);
            } else {
                $pay = (int) round($stake * 1.5) + $stake;
                add_money($u['id'], $pay, 'Blackjack natural');
                event_track('casino_won', (int) $pay);
                $state['phase'] = 'done'; $state['done'] = true;
                $state['msg'] = 'Blackjack! Paid 3:2.';
                insert('casino_bets', ['user_id' => $u['id'], 'game' => 'blackjack', 'stake' => $stake, 'payout' => $pay, 'detail' => 'Blackjack (3:2)']);
            }
        } elseif (bj_is_natural($state['dealer'])) {
            $state['phase'] = 'done'; $state['done'] = true;
            $state['msg'] = 'Dealer has Blackjack.';
            insert('casino_bets', ['user_id' => $u['id'], 'game' => 'blackjack', 'stake' => $stake, 'payout' => 0, 'detail' => 'Dealer blackjack']);
        } elseif (card_parts($state['dealer'][0])[0] === 'A') {
            $state['phase'] = 'insurance';
            $state['msg'] = 'Dealer shows an Ace — take insurance?';
        }
    } elseif ($action === 'end' && $state) {
        // bail out of a stuck game (refund none - only used for broken states)
        q('DELETE FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'blackjack']);
        $state = null;
    }
    if ($state) {
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'blackjack', json_encode($state)]);
    }
    redirect('blackjack.php');
}

$page_title = 'Blackjack';
require __DIR__ . '/includes/header.php';
$u = current_user();

function bj_dealer_draw(array &$hand, array &$deck): void
{
    while (bj_value($hand) < 17) {
        $hand[] = array_pop($deck);
    }
}

function bj_card(string $c): string
{
    [$r, $s] = card_parts($c);
    $red = in_array($s, ['♥', '♦'], true);
    return '<span class="bj-card"' . ($red ? ' style="color:#e0524a"' : '') . '>' . e($r) . '<small>' . e($s) . '</small></span>';
}
?>
<style>
.bj-card{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;width:52px;height:74px;background:#f5ead0;border:1px solid #8a7448;border-radius:6px;color:#2a2320;font-weight:700;font-size:1.15rem;margin:0 4px;box-shadow:0 2px 4px rgba(0,0,0,.4)}
.bj-card small{font-size:.8rem}
.bj-hand{display:flex;align-items:center;gap:2px;margin:10px 0;flex-wrap:wrap}
</style>
<div class="card">
  <div class="panel-heading">Blackjack</div>
  <p class="muted small">Beat the dealer without going over 21. Natural 21 pays 3:2. Dealer hits on soft 17. Split and double available.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<?php if (!$state): ?>
<div class="card">
  <form method="post" style="max-width:300px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="start">
    <label>Bet (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="50" required></label>
    <button class="btn btn-gold btn-block" type="submit">Deal</button>
  </form>
</div>
<?php else: ?>
<div class="card">
  <div class="panel-heading"><?= $state['done'] ? 'Hand Over' : 'In Play' ?> — Wagered: <?= money((int) $state['wager1'] + (int) ($state['wager2'] ?? 0)) ?></div>
  <?php if ($state['msg']): ?><div class="alert alert-info"><?= e($state['msg']) ?></div><?php endif; ?>

  <?php if ($state['phase'] === 'insurance'): ?>
    <p>Dealer shows <b><?= bj_card($state['dealer'][0]) ?></b>&nbsp;Take insurance (half your bet, pays 2:1 if dealer has blackjack)?</p>
    <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="insurance_yes"><button class="btn btn-gold" type="submit">Yes — <?= money((int) floor($state['wager1'] / 2)) ?></button></form>
    <form method="post" style="display:inline;margin-left:6px"><?= csrf_field() ?><input type="hidden" name="action" value="insurance_no"><button class="btn btn-sm" type="submit">No</button></form>
  <?php else: ?>
    <div class="bj-hand"><b style="min-width:120px">Dealer<?= (!$state['done'] && $state['phase'] === 'play') ? ' (showing ' . bj_value([$state['dealer'][0]]) . ')' : '' ?>:</b>
      <?php foreach ($state['dealer'] as $i => $c): ?>
        <?php if (!$state['done'] && $state['phase'] === 'play' && $i === 1): ?><span class="bj-card" style="background:#4a4038;color:#c9b27a;border-color:#2a2320">?</span>
        <?php else: ?><?= bj_card($c) ?><?php endif; ?>
      <?php endforeach; ?>
      <?php if ($state['done']): ?><b style="margin-left:10px">= <?= bj_value($state['dealer']) ?></b><?php endif; ?>
    </div>
    <?php foreach (['hand' => 'Your Hand', 'hand2' => 'Ace Hand'] as $hk => $label): ?>
      <?php if (!$state[$hk]) continue; ?>
      <div class="bj-hand"><b style="min-width:120px"><?= $label ?>:</b>
        <?php foreach ($state[$hk] as $c): ?><?= bj_card($c) ?><?php endforeach; ?>
        <b style="margin-left:10px">= <?= bj_value($state[$hk]) ?></b>
        <?php if (!$state['done'] && $state['phase'] === 'play' && $state['turn'] === ($hk === 'hand' ? 'h' : 'h2')): ?><span class="tag tag-epic">Your move</span><?php endif; ?>
        <span class="muted small" style="margin-left:6px">wager <?= money($hk === 'hand' ? (int) $state['wager1'] : (int) ($state['wager2'] ?? 0)) ?></span>
      </div>
    <?php endforeach; ?>

    <?php if ($state['phase'] === 'play'): ?>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="hit"><button class="btn btn-green" type="submit">Hit</button></form>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="stand"><button class="btn btn-gold" type="submit">Stand</button></form>
        <?php
        $curKey = $state['turn'] === 'h2' ? 'hand2' : 'hand';
        $cur = $state[$curKey];
        $curExtra = $state['turn'] === 'h' ? (int) $state['wager1'] : (int) ($state['wager2'] ?? $state['wager1']);
        ?>
        <?php if (count($cur) === 2 && (int) $u['money'] >= $curExtra): ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="double"><button class="btn btn-sm" type="submit">Double (+<?= money($curExtra) ?>)</button></form>
          <?php if (!$state['hand2'] && $state['turn'] === 'h'):
            $e1 = card_parts($cur[0])[0]; $e2 = card_parts($cur[1])[0];
            $v1 = ($e1 === 'A') ? 11 : (is_numeric($e1) ? (int) $e1 : 10);
            $v2 = ($e2 === 'A') ? 11 : (is_numeric($e2) ? (int) $e2 : 10);
          ?>
            <?php if ($v1 === $v2 && (int) $u['money'] >= (int) $state['wager1']): ?>
              <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="split"><button class="btn btn-sm" type="submit">Split (+<?= money((int) $state['wager1']) ?>)</button></form>
            <?php endif; ?>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <?php if ($state['done']): ?>
      <form method="post" style="margin-top:16px"><?= csrf_field() ?><input type="hidden" name="action" value="deal_again"><button class="btn btn-gold" type="submit">Deal Again (<?= money((int) $state['wager1'] + (int) ($state['wager2'] ?? 0)) ?>)</button></form>
    <?php endif; ?>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>