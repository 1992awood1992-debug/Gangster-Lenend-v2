<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'C:/Users/ash/Documents/Default Project/mafia-empire/config.php';
require 'C:/Users/ash/Documents/Default Project/mafia-empire/includes/db.php';

echo "Before init_secure_session:\n";
echo "Session status: " . session_status() . "\n";
echo "Session ID: " . session_id() . "\n";
echo "session.save_path: " . ini_get('session.save_path') . "\n";
echo "session.use_cookies: " . ini_get('session.use_cookies') . "\n";
echo "session.use_only_cookies: " . ini_get('session.use_only_cookies') . "\n";
echo "session.cookie_secure: " . ini_get('session.cookie_secure') . "\n";
echo "session.cookie_httponly: " . ini_get('session.cookie_httponly') . "\n";
echo "session.cookie_samesite: " . ini_get('session.cookie_samesite') . "\n";

require_once __DIR__ . '/includes/security.php';

echo "\nAfter init_secure_session:\n";
echo "Session status: " . session_status() . "\n";
echo "Session ID: " . session_id() . "\n";

if (isset($_SESSION['uid'])) {
    echo "UID in session: " . $_SESSION['uid'] . "\n";
    $u = fetch('SELECT id, username, is_admin FROM users WHERE id = ?', [$_SESSION['uid']]);
    echo "User: " . ($u ? $u['username'] . ' (admin: ' . $u['is_admin'] . ')' : 'NOT FOUND') . "\n";
} else {
    echo "No uid in session\n";
}