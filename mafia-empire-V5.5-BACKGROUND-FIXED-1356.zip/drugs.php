<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/mini_events.php';
$u = require_login();

// POST: buy, sell, use
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'buy') {
        $drugId = (int) ($_POST['drug_id'] ?? 0);
        $qty = max(1, (int) ($_POST['qty'] ?? 1));
        $drug = fetch('SELECT * FROM drugs WHERE id = ?', [$drugId]);
        if (!$drug) {
            flash('Drug not found.', 'error');
        } elseif ((int) $u['level'] < (int) $drug['min_level']) {
            flash('Level ' . (int) $drug['min_level'] . ' required.', 'error');
        } else {
            $mult = mini_event_get_drug_multiplier((int) $u['district_id']);
            $buyPrice = (int) ceil((int) $drug['buy_price'] * $mult);
            if ((int) $u['money'] < $buyPrice * $qty) {
                flash('Not enough cash.', 'error');
            } else {
                add_money($u['id'], -$buyPrice * $qty, 'Bought ' . $qty . 'x ' . $drug['name']);
                $existing = fetch('SELECT qty FROM user_drugs WHERE user_id = ? AND drug_id = ?', [$u['id'], $drugId]);
                if ($existing) {
                    q('UPDATE user_drugs SET qty = qty + ? WHERE user_id = ? AND drug_id = ?', [$qty, $u['id'], $drugId]);
                } else {
                    insert('user_drugs', ['user_id' => $u['id'], 'drug_id' => $drugId, 'qty' => $qty]);
                }
                flash('Bought ' . $qty . 'x ' . e($drug['name']) . '.', 'success');
            }
        }
    } elseif ($action === 'sell') {
        $drugId = (int) ($_POST['drug_id'] ?? 0);
        $qty = max(1, (int) ($_POST['qty'] ?? 1));
        $drug = fetch('SELECT * FROM drugs WHERE id = ?', [$drugId]);
        $owned = fetch('SELECT qty FROM user_drugs WHERE user_id = ? AND drug_id = ?', [$u['id'], $drugId]);
        if (!$drug || !$owned || (int) $owned['qty'] < $qty) {
            flash('Not enough to sell.', 'error');
        } else {
            $mult = mini_event_get_drug_multiplier((int) $u['district_id']);
            $sellPrice = (int) ceil((int) $drug['sell_price'] * $mult);
            $gain = $sellPrice * $qty;
            add_money($u['id'], $gain, 'Sold ' . $qty . 'x ' . $drug['name']);
            q('UPDATE user_drugs SET qty = qty - ? WHERE user_id = ? AND drug_id = ?', [$qty, $u['id'], $drugId]);
            q('DELETE FROM user_drugs WHERE user_id = ? AND drug_id = ? AND qty <= 0', [$u['id'], $drugId]);
            flash('Sold ' . $qty . 'x ' . e($drug['name']) . ' for ' . money($gain) . '.', 'success');
        }
    } elseif ($action === 'use') {
        $drugId = (int) ($_POST['drug_id'] ?? 0);
        $drug = fetch('SELECT * FROM drugs WHERE id = ?', [$drugId]);
        $owned = fetch('SELECT qty FROM user_drugs WHERE user_id = ? AND drug_id = ?', [$u['id'], $drugId]);
        if (!$drug || !$owned || (int) $owned['qty'] < 1) {
            flash('You don\'t have that drug.', 'error');
        } else {
            q('UPDATE user_drugs SET qty = qty - 1 WHERE user_id = ? AND drug_id = ?', [$u['id'], $drugId]);
            q('DELETE FROM user_drugs WHERE user_id = ? AND drug_id = ? AND qty <= 0', [$u['id'], $drugId]);
            $msg = 'Used ' . e($drug['name']) . '.';
            if ($drug['effect_stat'] && $drug['effect_amount'] > 0) {
                $stat = $drug['effect_stat'];
                $allowed = ['strength', 'speed', 'defense', 'iq'];
                if (in_array($stat, $allowed)) {
                    q('UPDATE users SET `' . $stat . '` = `' . $stat . '` + ? WHERE id = ?', [(int) $drug['effect_amount'], $u['id']]);
                    $msg .= ' Permanently gained ' . (int) $drug['effect_amount'] . ' ' . ucfirst($stat) . '!';
                }
            } else {
                // Heal
                q('UPDATE users SET health = health_max WHERE id = ?', [$u['id']]);
                $msg .= ' Fully healed.';
            }
            set_action_cooldown($u['id'], 'drugs');
            // OD risk
            if (mt_rand(1, 100) <= (int) $drug['od_risk']) {
                hospitalize($u['id'], 900, 'Overdose on ' . $drug['name']);
                $msg .= ' OVERDOSE! You were hospitalized.';
                flash($msg, 'error');
            } else {
                flash($msg, 'success');
            }
        }
    }
    redirect('drugs.php');
}

$page_title = 'Drugs';
require __DIR__ . '/includes/header.php';

$u = current_user();
$drugs = fetch_all('SELECT * FROM drugs ORDER BY min_level');
$myDrugs = fetch_all('SELECT ud.*, d.name, d.description, d.buy_price, d.sell_price, d.effect_stat, d.effect_amount, d.od_risk
                      FROM user_drugs ud JOIN drugs d ON d.id = ud.drug_id
                      WHERE ud.user_id = ? AND ud.qty > 0', [$u['id']]);
?>
<div class="card">
  <div class="panel-heading">Drug Market</div>
  <p class="muted small">Buy low, sell high. Use for permanent stat gains or healing—but risk overdose.</p>
</div>

<?php
$drugMult = mini_event_get_drug_multiplier((int) $u['district_id']);
$drugCity = (int) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_drug_city'", [], 0);
if ($drugMult > 1.0): ?>
<div class="card" style="border-color:var(--accent);background:var(--accent-dim)">
  <b>💊 Drug Surge Active in District <?= $drugCity ?>!</b> Prices are <b><?= (int)($drugMult * 100) ?>%</b> normal.
</div>
<?php endif; ?>

<h2>Buy Drugs</h2>
<div class="grid grid-3">
  <?php foreach ($drugs as $d): $locked = (int) $u['level'] < (int) $d['min_level'];
        $buyPrice = (int) ceil((int) $d['buy_price'] * $drugMult);
        $sellPrice = (int) ceil((int) $d['sell_price'] * $drugMult); ?>
    <div class="card tile">
      <b><?= e($d['name']) ?></b>
      <br><small class="muted"><?= e($d['description']) ?></small>
      <div class="stat"><span>Buy</span><b><?= money($buyPrice) ?></b></div>
      <div class="stat"><span>Sell</span><b><?= money($sellPrice) ?></b></div>
      <?php if ($d['effect_stat']): ?>
        <div class="stat"><span>Effect</span><b>+<?= (int) $d['effect_amount'] ?> <?= ucfirst($d['effect_stat']) ?></b></div>
      <?php else: ?>
        <div class="stat"><span>Effect</span><b>Full Heal</b></div>
      <?php endif; ?>
      <div class="stat"><span>OD Risk</span><b><?= (int) $d['od_risk'] ?>%</b></div>
      <?php if (!$locked): ?>
        <form method="post" style="margin-top:8px;display:flex;gap:6px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="buy">
          <input type="hidden" name="drug_id" value="<?= (int) $d['id'] ?>">
          <input type="number" name="qty" min="1" max="100" value="1" style="width:70px">
          <button class="btn btn-green btn-sm" type="submit">Buy</button>
        </form>
      <?php else: ?>
        <span class="tag tag-common">Lvl <?= (int) $d['min_level'] ?> req</span>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<h2 style="margin-top:24px">Your Inventory</h2>
<?php if (!$myDrugs): ?>
  <div class="card"><p class="muted">No drugs in inventory.</p></div>
<?php else: ?>
  <div class="table-wrap"><table>
    <tr><th>Drug</th><th>Qty</th><th>Buy/Sell</th><th>Effect</th><th></th></tr>
    <?php foreach ($myDrugs as $md):
        $buyPrice = (int) ceil((int) $md['buy_price'] * $drugMult);
        $sellPrice = (int) ceil((int) $md['sell_price'] * $drugMult); ?>
      <tr>
        <td><b><?= e($md['name']) ?></b></td>
        <td><?= (int) $md['qty'] ?></td>
        <td><?= money($buyPrice) ?> / <?= money($sellPrice) ?></td>
        <td><?php if ($md['effect_stat']): ?>+<?= (int) $md['effect_amount'] ?> <?= ucfirst($md['effect_stat']) ?><?php else: ?>Full Heal<?php endif; ?> (OD <?= (int) $md['od_risk'] ?>%)</td>
        <td>
          <form method="post" style="display:inline-block">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="use">
            <input type="hidden" name="drug_id" value="<?= (int) $md['drug_id'] ?>">
            <button class="btn btn-sm" type="submit">Use</button>
          </form>
          <form method="post" style="display:inline-block;margin-left:4px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="sell">
            <input type="hidden" name="drug_id" value="<?= (int) $md['drug_id'] ?>">
            <input type="number" name="qty" min="1" max="<?= (int) $md['qty'] ?>" value="1" style="width:60px">
            <button class="btn btn-gold btn-sm" type="submit">Sell</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>