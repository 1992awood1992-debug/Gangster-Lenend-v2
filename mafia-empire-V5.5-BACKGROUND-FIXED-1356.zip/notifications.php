<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/social.php';
$u = require_login();

// POST: mark read
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'mark_read') {
        $nid = (int) ($_POST['notification_id'] ?? 0);
        q('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [$nid, $u['id']]);
    } elseif ($action === 'mark_all_read') {
        q('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [$u['id']]);
    } elseif ($action === 'mark_read_social') {
        social_notification_mark_read((int) ($_POST['social_id'] ?? 0), (int) $u['id']);
    } elseif ($action === 'mark_all_social_read') {
        social_notifications_mark_all_read((int) $u['id']);
    }
    redirect('notifications.php');
}

$page_title = 'Notifications';
require __DIR__ . '/includes/header.php';

// Pagination
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 25;
$total = (int) fetch_one('SELECT COUNT(*) FROM notifications WHERE user_id = ?', [$u['id']], 0);
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$notifs = fetch_all('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?', [$u['id'], $perPage, $offset]);
?>
<div class="card" style="margin-bottom:18px">
  <div class="panel-heading">Device Notifications</div>
  <p class="muted small">Get a push alert on this device when the city needs you.</p>
  <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:10px">
    <button class="btn btn-sm" type="button" id="pushToggle" data-enabled="<?= push_available() ? '1' : '0' ?>">
      <?= push_available() ? 'Enable notifications' : 'Notifications unavailable' ?>
    </button>
    <span class="muted" id="pushStatus" style="font-size:.82rem"></span>
  </div>
</div>

<script>
(function () {
  var btn = document.getElementById('pushToggle');
  if (!btn) return;
  var status = document.getElementById('pushStatus');
  var endpoint = <?= json_encode(url('push.php')) ?>;
  var csrf = <?= json_encode(csrf_token()) ?>;

  function post(action, extra) {
    var body = new URLSearchParams(Object.assign({ action: action, csrf: csrf }, extra || {}));
    return fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
      body: body.toString(),
      credentials: 'same-origin'
    }).then(function (r) { return r.json(); });
  }
  function keyToBytes(base64) {
    var pad = '='.repeat((4 - base64.length % 4) % 4);
    var b64 = (base64 + pad).replace(/-/g, '+').replace(/_/g, '/');
    var raw = atob(b64);
    var arr = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
    return arr;
  }
  function refresh() {
    navigator.serviceWorker.getRegistration().then(function (reg) {
      if (!reg) { status.textContent = 'Service worker not ready - reload and try again.'; return; }
      reg.pushManager.getSubscription().then(function (sub) {
        if (sub) {
          btn.textContent = 'Disable notifications';
          btn.dataset.on = '1';
          status.textContent = 'Notifications are on for this device.';
        } else {
          btn.textContent = 'Enable notifications';
          btn.dataset.on = '';
          status.textContent = '';
        }
      });
    }).catch(function () {});
  }

  if (btn.getAttribute('data-enabled') !== '1') { btn.disabled = true; return; }
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
    btn.disabled = true;
    btn.textContent = 'Not supported on this device';
    return;
  }

  btn.addEventListener('click', function () {
    btn.disabled = true;
    status.textContent = 'Working...';
    navigator.serviceWorker.getRegistration().then(function (reg) {
      if (!reg) throw new Error('no sw');
      return reg.pushManager.getSubscription().then(function (existing) {
        if (existing && btn.dataset.on === '1') {
          var ep = existing.endpoint;
          return existing.unsubscribe().then(function () {
            return post('unsubscribe', { subscription: JSON.stringify({ endpoint: ep }) });
          });
        }
        return post('vapid').then(function (j) {
          if (!j.ok || !j.publicKey) throw new Error('push unavailable');
          return reg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: keyToBytes(j.publicKey)
          }).then(function (sub) {
            return post('subscribe', { subscription: JSON.stringify(sub) });
          });
        });
      });
    }).then(function () {
      refresh();
    }).catch(function () {
      status.textContent = 'Could not change notification settings.';
    }).then(function () {
      btn.disabled = false;
    });
  });

  refresh();
})();
</script>

<div class="card">
  <div class="panel-heading">Notifications</div>
  <?php if ($total > 0): ?>
    <form method="post" style="display:inline;margin-bottom:10px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="mark_all_read">
      <button class="btn btn-sm" type="submit">Mark all read</button>
    </form>
  <?php endif; ?>
  
  <?php if (!$notifs): ?>
    <div class="notif-empty">No notifications.</div>
  <?php else: ?>
    <?php foreach ($notifs as $n): ?>
      <div class="notif-item<?= $n['is_read'] ? '' : ' unread' ?>">
        <div class="notif-content">
          <div class="notif-title"><?= $n['link'] ? '<a href="' . e(url($n['link'])) . '">' . e($n['text']) . '</a>' : e($n['text']) ?></div>
          <div class="notif-desc"><small class="muted"><?= date('M j, Y H:i', strtotime($n['created_at'])) ?></small></div>
        </div>
        <div class="notif-actions">
          <?php if (!$n['is_read']): ?>
            <form method="post" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="mark_read">
              <input type="hidden" name="notification_id" value="<?= (int) $n['id'] ?>">
              <button class="btn btn-sm" type="submit">Mark read</button>
            </form>
            <span class="tag tag-legendary">new</span>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
    
    <?php if ($pages > 1): ?>
      <div class="pill-row" style="margin-top:14px;justify-content:center">
        <?php for ($p = 1; $p <= $pages; $p++): ?>
          <a class="pill<?= $p === $page ? ' on' : '' ?>" href="<?= e(url('notifications.php?page=' . $p)) ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<?php
$socialUnread = social_notifications_unread_count((int) $u['id']);
$social = fetch_all('SELECT * FROM social_notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 25', [$u['id']]);
?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Social Activity <?php if ($socialUnread): ?><span class="tag tag-gold"><?= $socialUnread ?> new</span><?php endif; ?></div>
  <?php if (empty($social)): ?>
    <p class="muted">No social activity yet. Trade offers, bounties and crew chat mentions show up here.</p>
  <?php else: ?>
    <?php if ($socialUnread): ?>
      <form method="post" style="margin-bottom:10px"><?= csrf_field() ?><input type="hidden" name="action" value="mark_all_social_read"><button class="btn btn-sm" type="submit">Mark all read</button></form>
    <?php endif; ?>
    <?php foreach ($social as $n): ?>
      <div class="social-item<?= !(int) $n['is_read'] ? ' unread' : '' ?>">
        <div class="social-content">
          <div class="social-title"><?= e($n['title']) ?></div>
          <div class="social-desc"><?= e($n['message']) ?></div>
          <a class="small" href="<?= e(url(social_notification_link($n))) ?>">Open &rarr;</a>
        </div>
        <div class="social-actions">
          <div class="social-time"><?= e($n['created_at']) ?></div>
          <?php if (!(int) $n['is_read']): ?>
            <form method="post" style="display:inline;margin-top:4px"><?= csrf_field() ?><input type="hidden" name="action" value="mark_read_social"><input type="hidden" name="social_id" value="<?= (int) $n['id'] ?>"><button class="btn btn-sm" type="submit">Mark read</button></form>
            <span class="tag tag-legendary">new</span>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // WebSocket real-time notifications
  if (typeof MafiaWebSocket !== 'undefined' && window.mafiaWS) {
    var ws = window.mafiaWS;
    var token = document.querySelector('meta[name="ws-token"]')?.content;
    var userId = <?= (int) $u['id'] ?>;

    if (token) {
      ws.auth(token);
      ws.subscribe('user_' + userId);

      ws.on('connected', function() {
        // Connection established
      });

      ws.on('notification', function(data) {
        if (!data || data.user_id !== userId) return;

        // Prepend new notification to the list
        var container = document.querySelector('.card .notif-item:first-child')?.parentElement;
        if (!container) return;

        var el = document.createElement('div');
        el.className = 'notif-item unread animate-fade-in-up';
        el.innerHTML =
          '<div class="notif-content">' +
            '<div class="notif-title">' + (data.link ? '<a href="' + data.link + '">' + data.text + '</a>' : data.text) + '</div>' +
            '<div class="notif-desc"><small class="muted">' + new Date().toLocaleString() + '</small></div>' +
          '</div>' +
          '<div class="notif-actions">' +
            '<span class="tag tag-legendary">new</span>' +
          '</div>';
        container.insertBefore(el, container.firstChild);

        // Update unread badge in header
        var badge = document.querySelector('.badge');
        if (badge) {
          var count = parseInt(badge.textContent) || 0;
          badge.textContent = count + 1;
        }
      });
    }
  }
});
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>