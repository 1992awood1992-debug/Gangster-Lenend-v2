<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Integration tests for the Property / Safehouse system.
 */
final class PropertiesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        require_once dirname(__DIR__, 2) . '/includes/properties.php';
    }

    private function cheapestType(): array
    {
        $type = fetch('SELECT * FROM property_types WHERE is_active = 1 ORDER BY base_price ASC LIMIT 1');
        $this->assertNotNull($type, 'Expected at least one seeded property type');
        return $type;
    }

    public function testBuyCreatesOwnedPropertyAndDeductsCash(): void
    {
        $u = $this->makeUser(['money' => 5_000_000, 'level' => 10]);
        $type = $this->cheapestType();

        $result = property_buy((int) $u['id'], (int) $type['id']);
        $this->assertTrue($result['ok'], $result['error'] ?? '');

        $owned = property_get_user((int) $u['id']);
        $this->assertCount(1, $owned);
        $this->assertSame((int) $type['id'], (int) $owned[0]['property_type_id']);

        $after = $this->freshUser((int) $u['id']);
        $this->assertSame(
            5_000_000 - (int) $type['base_price'],
            (int) $after['money']
        );
    }

    public function testCannotBuyBelowRequiredLevelOrTwice(): void
    {
        $type = $this->cheapestType();

        $low = $this->makeUser(['money' => 5_000_000, 'level' => 2]);
        $res = property_buy((int) $low['id'], (int) $type['id']);
        $this->assertFalse($res['ok']);
        $this->assertStringContainsString('Level', $res['error']);

        $u = $this->makeUser(['money' => 5_000_000, 'level' => 10]);
        $this->assertTrue(property_buy((int) $u['id'], (int) $type['id'])['ok']);
        $second = property_buy((int) $u['id'], (int) $type['id']);
        $this->assertFalse($second['ok']);
        $this->assertStringContainsString('Already', $second['error']);
    }

    /**
     * Regression: property_get_user_property() used `SELECT up.*, pt.*`, so the
     * duplicate `id`/`is_active` columns from property_types silently clobbered
     * the user_properties values. The returned id must be the owned row id.
     */
    public function testGetUserPropertyReturnsOwnRowIdNotTypeId(): void
    {
        $u = $this->makeUser(['money' => 5_000_000, 'level' => 10]);
        $type = $this->cheapestType();

        q(
            'INSERT INTO user_properties (id, user_id, property_type_id, level, last_collected_at) VALUES (?, ?, ?, 1, NOW())',
            [424242, (int) $u['id'], (int) $type['id']]
        );

        $prop = property_get_user_property((int) $u['id'], 424242);
        $this->assertNotNull($prop);
        $this->assertSame(424242, (int) $prop['id'], 'Property row id was clobbered by the property type id');
        $this->assertSame((int) $u['id'], (int) $prop['user_id']);
        $this->assertSame((int) $type['id'], (int) $prop['property_type_id']);
        $this->assertTrue((bool) $prop['is_active']);
        $this->assertSame((int) $type['max_level'], (int) $prop['max_level']);
    }

    public function testCollectAccruesIncomeAndCapsAt24Hours(): void
    {
        $u = $this->makeUser(['money' => 0, 'bullets' => 0, 'points' => 0, 'level' => 10]);
        $type = $this->cheapestType();

        $id = insert('user_properties', [
            'user_id' => (int) $u['id'],
            'property_type_id' => (int) $type['id'],
            'level' => 2,
            'last_collected_at' => (new \DateTime())->modify('-5 hours')->format('Y-m-d H:i:s'),
        ]);

        $res = property_collect((int) $u['id'], (int) $id);
        $this->assertSame(5, (int) $res['hours']);
        $this->assertTrue($res['ok'], $res['error'] ?? '');
        $this->assertSame((int) $type['income_money_per_hour'] * 2 * 5, (int) $res['money']);
        $this->assertSame((int) $type['income_bullets_per_hour'] * 2 * 5, (int) $res['bullets']);
        $this->assertSame((int) $type['income_points_per_hour'] * 2 * 5, (int) $res['points']);

        $refreshed = property_get_user_property((int) $u['id'], (int) $id);
        $this->assertNotNull($refreshed['last_collected_at']);

        // A second immediate collect accrues the 1-hour minimum, not zero.
        $again = property_collect((int) $u['id'], (int) $id);
        $this->assertTrue($again['ok']);
        $this->assertSame(1, (int) $again['hours']);
    }

    public function testCollectAllAggregatesAndCapsAt24h(): void
    {
        $u = $this->makeUser(['money' => 0, 'level' => 10]);
        $types = fetch_all('SELECT * FROM property_types WHERE is_active = 1 ORDER BY base_price ASC LIMIT 2');
        if (count($types) < 2) {
            $this->markTestSkipped('Need two property types for this test');
        }

        foreach ($types as $i => $type) {
            q(
                'INSERT INTO user_properties (user_id, property_type_id, level, last_collected_at)
                 VALUES (?, ?, 1, DATE_SUB(NOW(), INTERVAL 5 HOUR))',
                [(int) $u['id'], (int) $type['id']]
            );
        }

        $expectedMoney = 0;
        foreach ($types as $type) {
            $expectedMoney += (int) $type['income_money_per_hour'] * 5;
        }

        $before = (int) $this->freshUser((int) $u['id'])['money'];
        $res = property_collect_all((int) $u['id']);
        $this->assertTrue($res['ok']);
        $this->assertSame($expectedMoney, (int) $res['money']);
        $this->assertSame($before + $expectedMoney, (int) $this->freshUser((int) $u['id'])['money']);
    }

    public function testCollectCapsAccrualAt24Hours(): void
    {
        $u = $this->makeUser(['money' => 0, 'level' => 10]);
        $type = $this->cheapestType();

        q(
            'INSERT INTO user_properties (user_id, property_type_id, level, last_collected_at)
             VALUES (?, ?, 3, DATE_SUB(NOW(), INTERVAL 100 HOUR))',
            [(int) $u['id'], (int) $type['id']]
        );
        $propId = (int) fetch_one('SELECT id FROM user_properties WHERE user_id = ?', [(int) $u['id']]);

        $res = property_collect((int) $u['id'], $propId);
        $this->assertTrue($res['ok']);
        $this->assertSame(24, (int) $res['hours']);
        $this->assertSame((int) $type['income_money_per_hour'] * 3 * 24, (int) $res['money']);
    }

    public function testUpgradeIncreasesLevelAndDeductsResources(): void
    {
        $u = $this->makeUser(['money' => 50_000_000, 'bullets' => 1_000_000, 'points' => 100_000, 'level' => 10]);
        $type = $this->cheapestType();
        $buy = property_buy((int) $u['id'], (int) $type['id']);
        $this->assertTrue($buy['ok']);

        $prop = property_get_user_property((int) $u['id'], (int) $buy['property_id']);
        $cost = property_upgrade_cost($prop, 2);

        $moneyBefore = (int) $this->freshUser((int) $u['id'])['money'];
        $res = property_upgrade((int) $u['id'], (int) $buy['property_id'], 2);
        $this->assertTrue($res['ok'], $res['error'] ?? '');
        $this->assertSame(2, (int) $res['new_level']);

        $after = $this->freshUser((int) $u['id']);
        $this->assertSame($moneyBefore - (int) $cost['money'], (int) $after['money']);
        $this->assertSame(1_000_000 - (int) $cost['bullets'], (int) $after['bullets']);
        $this->assertSame(100_000 - (int) $cost['points'], (int) $after['points']);

        $refreshed = property_get_user_property((int) $u['id'], (int) $buy['property_id']);
        $this->assertSame(2, (int) $refreshed['level']);
    }

    public function testSellDeactivatesAndRefundsHalfValue(): void
    {
        $u = $this->makeUser(['money' => 50_000_000, 'level' => 10]);
        $type = $this->cheapestType();
        $buy = property_buy((int) $u['id'], (int) $type['id']);

        $before = (int) $this->freshUser((int) $u['id'])['money'];
        $res = property_sell((int) $u['id'], (int) $buy['property_id']);
        $this->assertTrue($res['ok']);
        $this->assertSame((int) floor((int) $type['base_price'] * 0.5), (int) $res['sale_price']);
        $this->assertSame($before + (int) $res['sale_price'], (int) $this->freshUser((int) $u['id'])['money']);
        $this->assertCount(0, property_get_user((int) $u['id']));
    }
}
