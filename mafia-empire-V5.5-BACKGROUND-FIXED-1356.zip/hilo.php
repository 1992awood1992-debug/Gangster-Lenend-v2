<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

function card_str(array $c): string
{
    $r = $c['rank'];
    $n = $r === 11 ? 'J' : ($r === 12 ? 'Q' : ($r === 13 ? 'K' : ($r === 14 ? 'A' : (string)$r)));
    $s = ['h'=>'♥','d'=>'♦','c'=>'♣','s'=>'♠'][$c['suit']];
    return $n . $s;
}

function draw_card(): array
{
    $deck = [];
    foreach (['h','d','c','s'] as $s) { for ($r = 2; $r <= 14; $r++) $deck[] = ['rank' => $r, 'suit' => $s]; }
    shuffle($deck);
    return $deck[0];
}

$state = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'hilo']);
$state = $state ? json_decode($state['state'], true) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'start') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('hilo.php'); }
        add_money($u['id'], -$stake, 'Hi-Lo bet');
        $state = ['stake' => $stake, 'current' => draw_card(), 'multiplier' => 1.0, 'streak' => 0];
    } elseif ($action === 'guess' && $state) {
        $guess = $_POST['guess'] ?? ''; // 'higher' or 'lower'
        $next = draw_card();
        $curRank = $state['current']['rank'];
        $nextRank = $next['rank'];
        $correct = ($guess === 'higher' && $nextRank > $curRank) || ($guess === 'lower' && $nextRank < $curRank);
        if ($correct) {
            $state['streak']++;
            $state['multiplier'] += 0.5; // increases each win
            $state['current'] = $next;
        } else {
            // Lose
            $result = "Wrong! Next was " . card_str($next) . ". You lost " . money($state['stake']);
            flash($result, 'error');
            insert('casino_bets', ['user_id' => $u['id'], 'game' => 'hilo', 'stake' => $state['stake'], 'payout' => 0, 'detail' => $result . " (streak: {$state['streak']})"]);
            q('DELETE FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'hilo']);
            $state = null;
        }
    } elseif ($action === 'cashout' && $state) {
        $payout = (int) round($state['stake'] * $state['multiplier']);
        add_money($u['id'], $payout, 'Hi-Lo cashout');
        event_track('casino_won', (int) $payout);
        $result = "Cashed out at {$state['multiplier']}x after {$state['streak']} correct guesses.";
        flash($result . " Won " . money($payout), 'success');
        insert('casino_bets', ['user_id' => $u['id'], 'game' => 'hilo', 'stake' => $state['stake'], 'payout' => $payout, 'detail' => $result]);
        q('DELETE FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'hilo']);
        $state = null;
    }
    if ($state) {
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'hilo', json_encode($state)]);
    }
    redirect('hilo.php');
}

$page_title = 'Hi-Lo';
require __DIR__ . '/includes/header.php';
$u = current_user();
?>
<div class="card">
  <div class="panel-heading">Hi-Lo</div>
  <p class="muted small">Guess if the next card is higher or lower. Ace high. Each correct guess increases the multiplier by 0.5x. Cash out anytime. Wrong guess loses your bet.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<?php if (!$state): ?>
<div class="card">
  <form method="post" style="max-width:300px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="start">
    <label>Bet (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="50" required></label>
    <button class="btn btn-gold btn-block" type="submit">Start Game</button>
  </form>
</div>
<?php else: ?>
<div class="card">
  <div class="panel-heading">Current Card</div>
  <div class="pill-row" style="justify-content:center;margin:14px 0">
    <span class="playing-card<?= in_array($state['current']['suit'], ['h','d']) ? ' red' : '' ?>" style="font-size:2.5rem;padding:20px 30px"><?= card_str($state['current']) ?></span>
  </div>
  <div class="stat"><span>Streak</span><b><?= $state['streak'] ?></b></div>
  <div class="stat"><span>Multiplier</span><b><?= number_format($state['multiplier'], 1) ?>x</b></div>
  <div class="stat"><span>Potential Payout</span><b><?= money((int) round($state['stake'] * $state['multiplier'])) ?></b></div>
  
  <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap">
    <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="guess"><input type="hidden" name="guess" value="higher"><button class="btn btn-green btn-lg" type="submit">Higher ▲</button></form>
    <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="guess"><input type="hidden" name="guess" value="lower"><button class="btn btn-danger btn-lg" type="submit">Lower ▼</button></form>
    <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="cashout"><button class="btn btn-gold" type="submit">Cash Out</button></form>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>