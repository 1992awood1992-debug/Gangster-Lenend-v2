-- Content Expansion v2 (Phase 19) -------------------------------------------
-- More missions, bosses, items, drugs, abilities, achievements, stickers

-- Districts: add 4 more (total 10)
INSERT INTO districts (name, description, unlock_level, income_bonus) VALUES
    ('Chinatown', 'Fireworks, mahjong, and opium dens.', 25, 40),
    ('The Suburbs', 'White picket fences hide dark secrets.', 30, 50),
    ('The Projects', 'Concrete towers, concrete rules.', 35, 60),
    ('The Docks Extension', 'More cargo, more opportunity.', 40, 75)
ON DUPLICATE KEY UPDATE description = VALUES(description), unlock_level = VALUES(unlock_level), income_bonus = VALUES(income_bonus);

-- Missions: add 50 more (total ~120)
INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story) VALUES
-- Chinatown (district 5)
(5, 'Extort a Herbalist', 'Traditional medicine pays well.', 6, 25, 3500, 80, 1, 40, 'Extort a Herbalist'),
(5, 'Steal Fireworks Crate', 'Light up the night with profit.', 8, 27, 4800, 110, 2, 45, 'Steal Fireworks Crate'),
(5, 'Rig a Mahjong Parlor', 'The house always wins.', 10, 29, 6200, 140, 2, 50, 'Rig a Mahjong Parlor'),
(5, 'Kidnap a Triad Elder', 'Respect has a price.', 14, 32, 8500, 190, 3, 55, 'Kidnap a Triad Elder'),
(5, 'Burn a Counterfeit Shop', 'Eliminate the competition.', 18, 35, 12000, 250, 4, 60, 'Burn a Counterfeit Shop'),
(5, 'Hijack a Tea Shipment', 'Opium in the leaves.', 22, 38, 16000, 320, 5, 65, 'Hijack a Tea Shipment'),
(5, 'Assassinate a Rival Boss', 'One less problem.', 28, 42, 25000, 500, 8, 70, 'Assassinate a Rival Boss'),
(5, 'Take Over the Dragon Gate', 'Control the district.', 35, 46, 40000, 800, 12, 75, 'Take Over the Dragon Gate'),

-- The Suburbs (district 6)
(6, 'Rob a Minivan', 'Soccer moms carry cash.', 5, 30, 2800, 65, 1, 35, 'Rob a Minivan'),
(6, 'Blackmail a PTA President', 'Secrets in the bake sale.', 7, 32, 3500, 85, 1, 40, 'Blackmail a PTA President'),
(6, 'Steal Pool Supplies', 'Chlorine and cash.', 9, 34, 4200, 100, 2, 45, 'Steal Pool Supplies'),
(6, 'Extort a Country Club', 'Old money, new debts.', 12, 36, 5800, 130, 2, 50, 'Extort a Country Club'),
(6, 'Hijack a Liquor Delivery', 'Suburban thirst.', 15, 38, 7500, 160, 3, 55, 'Hijack a Liquor Delivery'),
(6, 'Kidnap a Developer\'s Kid', 'Ransom in the suburbs.', 18, 40, 10000, 200, 4, 60, 'Kidnap a Developer\'s Kid'),
(6, 'Rig a School Board Election', 'Power starts local.', 22, 42, 14000, 280, 5, 65, 'Rig a School Board Election'),
(6, 'Take Over the HOA', 'Total suburban control.', 30, 45, 22000, 450, 8, 70, 'Take Over the HOA'),

-- The Projects (district 7)
(7, 'Shake Down a Bodega', 'Corner store, corner empire.', 4, 35, 2200, 55, 1, 35, 'Shake Down a Bodega'),
(7, 'Steal a Welfare Check', 'Desperate times.', 6, 36, 1800, 45, 0, 30, 'Steal a Welfare Check'),
(7, 'Tag a Rival Building', 'Claim the block.', 5, 35, 1500, 40, 0, 25, 'Tag a Rival Building'),
(7, 'Rob a Check-Cashing Spot', 'Fast cash, high risk.', 8, 38, 3500, 80, 1, 40, 'Rob a Check-Cashing Spot'),
(7, 'Move Product Through the Towers', 'Vertical distribution.', 10, 38, 4800, 110, 2, 45, 'Move Product Through the Towers'),
(7, 'Bribe a Building Inspector', 'Code violations disappear.', 12, 40, 6000, 130, 2, 50, 'Bribe a Building Inspector'),
(7, 'Take Over a Stairwell', 'Territory by the floor.', 15, 42, 8500, 180, 3, 55, 'Take Over a Stairwell'),
(7, 'Run the Whole Complex', 'King of the projects.', 25, 45, 18000, 400, 6, 65, 'Run the Whole Complex'),

-- Docks Extension (district 8)
(8, 'Steal a Container Manifest', 'Know what\'s coming in.', 6, 40, 3200, 75, 1, 40, 'Steal a Container Manifest'),
(8, 'Bribe a Crane Operator', 'Heavy lifting.', 8, 41, 4000, 90, 1, 45, 'Bribe a Crane Operator'),
(8, 'Hijack a Reefer Truck', 'Frozen goods, hot profit.', 12, 42, 7000, 150, 2, 50, 'Hijack a Reefer Truck'),
(8, 'Sink a Smuggler\'s Boat', 'Clean up the harbor.', 18, 44, 11000, 220, 3, 55, 'Sink a Smuggler\'s Boat'),
(8, 'Take Over the Union Hall', 'Labor is power.', 22, 46, 15000, 300, 4, 60, 'Take Over the Union Hall'),
(8, 'Rig a Customs Inspection', 'Let it pass.', 25, 48, 20000, 400, 5, 65, 'Rig a Customs Inspection'),
(8, 'Assassinate a Port Commissioner', 'Clear the way.', 30, 50, 35000, 700, 10, 75, 'Assassinate a Port Commissioner'),
(8, 'Control the Entire Waterfront', 'Emperor of the docks.', 40, 55, 60000, 1200, 15, 80, 'Control the Entire Waterfront'),

-- High-level Downtown/Wall Street missions
(1, 'Infiltrate a Crypto Exchange', 'Digital heist.', 30, 50, 50000, 1000, 20, 70, 'Infiltrate a Crypto Exchange'),
(1, 'Manipulate the Stock Ticker', 'Wall Street warfare.', 35, 52, 75000, 1500, 25, 75, 'Manipulate the Stock Ticker'),
(1, 'Blackmail a Senator', 'Power brokers.', 40, 55, 100000, 2000, 30, 80, 'Blackmail a Senator'),
(1, 'Take Over a Bank', 'The vault is yours.', 45, 58, 150000, 3000, 40, 85, 'Take Over a Bank'),
(2, 'Steal a Superyacht', 'Ocean empire.', 38, 55, 80000, 1600, 20, 75, 'Steal a Superyacht'),
(2, 'Hijack an Oil Tanker', 'Black gold.', 42, 58, 120000, 2400, 30, 80, 'Hijack an Oil Tanker'),
(3, 'Rig a Casino License', 'The house always wins.', 35, 53, 65000, 1300, 15, 70, 'Rig a Casino License'),
(4, 'Acquire a Media Empire', 'Control the narrative.', 50, 60, 200000, 4000, 50, 90, 'Acquire a Media Empire'),
(4, 'Buy a Politician', 'Democracy for sale.', 45, 58, 120000, 2500, 20, 80, 'Buy a Politician'),
(4, 'Monopolize the City', 'Total domination.', 60, 65, 500000, 10000, 100, 95, 'Monopolize the City')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Bosses: add 10 more (total ~24)
INSERT INTO bosses (district_id, name, description, hp, attack, defense, min_level, energy_cost, reward_money, reward_xp, reward_points, reward_item_id) VALUES
(5, 'Master Li', 'Ancient Triad enforcer with iron fists.', 1800, 80, 40, 28, 22, 45000, 1000, 20, NULL),
(5, 'Madame Butterfly', 'Poison expert, beautiful and deadly.', 2200, 90, 45, 35, 25, 60000, 1400, 25, NULL),
(6, 'The HOA President', 'Rules are made to be enforced.', 2500, 100, 50, 38, 28, 80000, 1800, 30, NULL),
(6, 'Suburban Sam', 'Lawn care specialist. Also breaks knees.', 3000, 110, 55, 42, 30, 100000, 2200, 35, NULL),
(7, 'Big Mama', 'Runs the projects with an iron will.', 2800, 105, 52, 40, 30, 90000, 2000, 32, NULL),
(7, 'Stairwell Steve', 'Controls every floor.', 3200, 115, 58, 44, 32, 120000, 2600, 38, NULL),
(8, 'Captain "Iron Hook" Kowalski', 'Union boss, literally.', 3500, 125, 60, 46, 35, 150000, 3000, 40, NULL),
(8, 'The Harbor Master', 'He owns the water.', 4000, 140, 70, 50, 40, 250000, 5000, 50, NULL),
(1, 'The Algorithm', 'Faceless market manipulator.', 5000, 160, 80, 55, 45, 500000, 10000, 75, NULL),
(4, 'The Puppet Master', 'Strings on every politician.', 6000, 180, 90, 60, 50, 1000000, 20000, 100, NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Items: add 30 more (total ~75)
INSERT INTO items (name, description, type, attack, defense, cost, min_level, rarity) VALUES
('Brass Knuckles', 'Simple, effective.', 'weapon', 10, 0, 1200, 2, 'common'),
('Taser', 'Non-lethal but painful.', 'weapon', 12, 1, 3500, 4, 'uncommon'),
('Revolver .38', 'Six shots, classic.', 'weapon', 18, 2, 12000, 6, 'uncommon'),
('SMG', 'Spray and pray.', 'weapon', 32, 3, 60000, 12, 'rare'),
('M4 Carbine', 'Military precision.', 'weapon', 50, 5, 150000, 20, 'epic'),
('Sniper Rifle', 'One shot, one kill.', 'weapon', 60, 4, 300000, 25, 'legendary'),
('Chainmail Shirt', 'Old school protection.', 'armor', 0, 8, 2500, 3, 'common'),
('Tactical Vest', 'Modern mobility.', 'armor', 1, 18, 15000, 8, 'uncommon'),
('Ceramic Plates', 'Stops rifle rounds.', 'armor', 2, 30, 75000, 15, 'rare'),
('Dragon Skin', 'Mythical durability.', 'armor', 3, 60, 250000, 30, 'legendary'),
('Motorcycle', 'Fast, exposed.', 'vehicle', 1, 5, 8000, 5, 'common'),
('Sports Car', 'Speed and style.', 'vehicle', 2, 10, 50000, 10, 'uncommon'),
('Armored Limo', 'Luxury tank.', 'vehicle', 3, 25, 150000, 20, 'rare'),
('Attack Helicopter', 'Air superiority.', 'vehicle', 5, 40, 500000, 35, 'epic'),
('Private Jet', 'Global reach.', 'vehicle', 4, 50, 1000000, 40, 'legendary'),
('Lucky Rabbit Foot', '+2% mission success.', 'special', 0, 0, 5000, 1, 'uncommon'),
('Four-Leaf Clover', '+5% criminal job payout.', 'special', 0, 0, 15000, 5, 'rare'),
('Gold Watch', '+10% mission money.', 'special', 0, 0, 30000, 10, 'epic'),
('Signet Ring', '+5% respect gained.', 'special', 0, 0, 50000, 15, 'legendary'),
('Cuban Cigar', 'Restores 10 nerve.', 'consumable', 0, 0, 2000, 1, 'common'),
('Aged Whiskey', 'Restores 25 energy.', 'consumable', 0, 0, 5000, 3, 'uncommon'),
('Combat Stimulant', '+10 Str for 1 hour.', 'consumable', 0, 0, 10000, 8, 'rare'),
('Focus Drug', '+10 IQ for 1 hour.', 'consumable', 0, 0, 10000, 8, 'rare'),
('Adrenaline Shot', '+15 Speed for 30 min.', 'consumable', 0, 0, 15000, 12, 'epic'),
('Bulletproof Coffee', '+20 Defense for 1 hour.', 'consumable', 0, 0, 20000, 15, 'legendary'),
('Lockpick Set', 'Open locked doors.', 'tool', 0, 0, 8000, 5, 'uncommon'),
('Hacking Deck', 'Digital access.', 'tool', 0, 0, 25000, 12, 'rare'),
('Forgery Kit', 'Fake documents.', 'tool', 0, 0, 15000, 10, 'rare'),
('Disguise Kit', 'Change appearance.', 'tool', 0, 0, 30000, 18, 'epic')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Drugs: add 15 more (total ~37)
INSERT INTO drugs (name, description, buy_price, sell_price, min_level, effect_stat, effect_amount, od_risk) VALUES
('Kratom', 'Legal-ish energy.', 300, 450, 2, 'energy', 5, 5),
('MDMA', 'Party fuel.', 1200, 1800, 8, 'speed', 2, 15),
('LSD', 'Mind expansion.', 2000, 3000, 12, 'iq', 3, 10),
('DMT', 'Breakthrough.', 5000, 7500, 18, 'iq', 5, 20),
('Ketamine', 'Dissociative anesthetic.', 1800, 2700, 10, 'defense', 2, 15),
('PCP', 'Superhuman strength.', 3000, 4500, 15, 'strength', 4, 30),
('GHB', 'Date night.', 800, 1200, 6, '', 0, 25),
('Rohypnol', 'Forget it happened.', 1500, 2200, 8, '', 0, 30),
('Steroids', 'Roid rage.', 4000, 6000, 20, 'strength', 6, 15),
('HGH', 'Growth hormone.', 8000, 12000, 28, 'health', 10, 10),
('Noopept', 'Cognitive enhancer.', 2500, 3800, 15, 'iq', 4, 8),
('Modafinil', 'Wakefulness.', 3000, 4500, 14, 'energy', 8, 10),
('Adderall', 'Focus.', 2000, 3000, 10, 'speed', 3, 15),
('Xanax', 'Chill out.', 1000, 1500, 5, 'health', 5, 20),
('Oxytocin', 'Trust me.', 6000, 9000, 22, '', 0, 10)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Abilities: add 20 more (total ~50)
INSERT INTO abilities (name, description, cost_points, min_level, effect_type, effect_value, stat) VALUES
('Third Eye', '+8 IQ permanently.', 15, 8, 'stat', 8, 'iq'),
('Iron Body', '+8 Defense permanently.', 15, 8, 'stat', 8, 'defense'),
('Lightning Reflexes', '+8 Speed permanently.', 15, 8, 'stat', 8, 'speed'),
('Crushing Blow', '+8 Strength permanently.', 15, 8, 'stat', 8, 'strength'),
('Full Restore', 'Heal to max health.', 25, 15, 'heal', 999, ''),
('Adrenaline Rush', 'Restore 50 energy.', 20, 10, 'energy', 50, ''),
('Nerve Tonic', 'Restore 25 nerve.', 18, 10, 'nerve', 25, ''),
('Ammo Crate', 'Gain 200 bullets.', 22, 12, 'bullets', 200, ''),
('Money Launderer', '+15% mission money.', 30, 18, 'money_mult', 15, ''),
('XP Booster', '+15% XP from all sources.', 35, 20, 'xp_mult', 15, ''),
('Lucky Charm', '+10% critical hit chance.', 25, 15, 'crit_chance', 10, ''),
('Dodge Master', '+10% evasion.', 25, 15, 'evasion', 10, ''),
('Intimidation', 'Enemies deal 10% less damage.', 20, 12, 'dmg_reduction', 10, ''),
('Street Doctor', 'Heal 10% per minute.', 30, 18, 'regen', 10, ''),
('Ghost', 'Invisible on find gangsters for 1 hour.', 40, 25, 'stealth', 60, ''),
('Mastermind', 'Crew mates get +5% XP.', 50, 30, 'crew_xp_bonus', 5, ''),
('Kingpin Aura', 'Crew mates deal +5% damage.', 50, 30, 'crew_dmg_bonus', 5, ''),
('Diplomat', '+20% respect gained.', 25, 15, 'respect_bonus', 20, ''),
('Black Market Access', 'Unlock exclusive items.', 40, 22, 'bm_access', 1, ''),
('Prestige Seeker', '+1 Prestige Coin per level.', 100, 50, 'prestige_coin_bonus', 1, '')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Achievements: add 50 more (total ~100)
INSERT INTO achievements (code, name, description, reward_points, target, metric) VALUES
('kills_50', 'Serial Killer', 'Kill 50 players.', 100, 50, 'kills'),
('kills_100', 'Mass Murderer', 'Kill 100 players.', 200, 100, 'kills'),
('kills_500', 'Butcher', 'Kill 500 players.', 500, 500, 'kills'),
('missions_500', 'Mission Master', 'Complete 500 missions.', 200, 500, 'missions_done'),
('missions_1000', 'Legend', 'Complete 1000 missions.', 500, 1000, 'missions_done'),
('boss_10', 'Boss Hunter', 'Defeat 10 bosses.', 100, 10, 'boss_kills'),
('boss_50', 'Boss Slayer', 'Defeat 50 bosses.', 300, 50, 'boss_kills'),
('boss_100', 'Boss Annihilator', 'Defeat 100 bosses.', 1000, 100, 'boss_kills'),
('crimes_200', 'Crime Spree', 'Complete 200 criminal jobs.', 100, 200, 'crimes_done'),
('crimes_500', 'Career Criminal', 'Complete 500 criminal jobs.', 300, 500, 'crimes_done'),
('crimes_1000', 'Public Enemy #1', 'Complete 1000 criminal jobs.', 1000, 1000, 'crimes_done'),
('millionaire', 'Millionaire', 'Hold $1,000,000 cash.', 50, 1000000, 'money'),
('billionaire', 'Billionaire', 'Hold $1,000,000,000 cash.', 500, 1000000000, 'money'),
('trillionaire', 'Trillionaire', 'Hold $1,000,000,000,000 cash.', 2000, 1000000000000, 'money'),
('level_25', 'Quarter Century', 'Reach level 25.', 30, 25, 'level'),
('level_75', 'Three Quarters', 'Reach level 75.', 150, 75, 'level'),
('level_100', 'Centurion', 'Reach level 100.', 300, 100, 'level'),
('prestige_1', 'First Prestige', 'Reach Prestige 1.', 100, 1, 'prestige_level'),
('prestige_10', 'Decade of Prestige', 'Reach Prestige 10.', 500, 10, 'prestige_level'),
('prestige_50', 'Half Century Prestige', 'Reach Prestige 50.', 2000, 50, 'prestige_level'),
('prestige_100', 'Prestige Centurion', 'Reach Prestige 100.', 5000, 100, 'prestige_level'),
('respect_100', 'Respected', 'Reach 100 net respect.', 50, 100, 'net_respect'),
('respect_500', 'Revered', 'Reach 500 net respect.', 200, 500, 'net_respect'),
('respect_1000', 'Legendary', 'Reach 1000 net respect.', 500, 1000, 'net_respect'),
('disrespect_100', 'Feared', 'Reach -100 net respect.', 50, 100, 'net_respect'),
('disrespect_500', 'Reviled', 'Reach -500 net respect.', 200, 500, 'net_respect'),
('stickers_50', 'Collector', 'Own 50 different stickers.', 100, 50, 'stickers_owned'),
('stickers_all', 'Completionist', 'Own every sticker.', 500, 100, 'stickers_owned'),
('vehicles_10', 'Fleet Commander', 'Own 10 vehicles.', 50, 10, 'vehicles_owned'),
('weapons_10', 'Arsenal', 'Own 10 weapons.', 50, 10, 'weapons_owned'),
('armor_10', 'Armory', 'Own 10 armor pieces.', 50, 10, 'armor_owned'),
('factory_owner', 'Industrialist', 'Own a bullet factory.', 30, 1, 'factory_owned'),
('factory_tycoon', 'Factory Tycoon', 'Own 5 bullet factories.', 150, 5, 'factory_owned'),
('lottery_winner', 'Lucky Strike', 'Win the lottery.', 100, 1, 'lottery_wins'),
('jackpot', 'Jackpot!', 'Hit the slots jackpot.', 200, 1, 'jackpot_hits'),
('race_wins_10', 'Speed Demon', 'Win 10 races.', 50, 10, 'race_wins'),
('race_wins_100', 'King of the Track', 'Win 100 races.', 300, 100, 'race_wins'),
('heist_master', 'Heist Master', 'Complete 20 heists.', 100, 20, 'heists_completed'),
('crew_leader', 'Leader', 'Lead a crew of 10+ members.', 50, 10, 'crew_size'),
('crew_warlord', 'Warlord', 'Win 5 crew wars.', 200, 5, 'crew_wars_won'),
('mayor', 'Mayor', 'Win a mayoral election.', 100, 1, 'mayor_wins'),
('christmas_spirit', 'Christmas Spirit', 'Claim all 25 Christmas gifts.', 200, 25, 'christmas_gifts'),
('halloween_horror', 'Halloween Horror', 'Buy the Skeleton Key.', 150, 1, 'skeleton_key_bought'),
('valentines_lover', 'Lover', 'Steal 10 Love Bugs.', 100, 10, 'love_bugs_stolen'),
('easter_bunny', 'Easter Bunny', 'Find 50 Easter Eggs.', 100, 50, 'easter_eggs_found'),
('independence_patriot', 'Patriot', 'Steal 20 Mini Flags.', 100, 20, 'mini_flags_stolen'),
('deathmatch_survivor', 'Survivor', 'Survive Deathmatch alive.', 300, 1, 'deathmatch_survived'),
('deathmatch_killer', 'Deathmatch Killer', 'Get 50 kills in one Deathmatch.', 500, 50, 'deathmatch_kills'),
('weekend_warrior', 'Weekend Warrior', 'Participate in 10 weekend events.', 100, 10, 'weekend_events_participated'),
('mini_event_junkie', 'Mini Event Junkie', 'Participate in 50 mini events.', 200, 50, 'mini_events_participated')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Stickers: add 20 more (total ~52)
INSERT INTO stickers (code, name, rarity) VALUES
('switchblade', 'Switchblade', 'common'),
('brass_knuckles', 'Brass Knuckles', 'common'),
('revolver', 'Revolver .38', 'common'),
('taser', 'Taser', 'uncommon'),
('smg', 'SMG', 'uncommon'),
('m4', 'M4 Carbine', 'rare'),
('sniper', 'Sniper Rifle', 'epic'),
('chainmail', 'Chainmail Shirt', 'common'),
('tactical_vest', 'Tactical Vest', 'uncommon'),
('ceramic_plates', 'Ceramic Plates', 'rare'),
('dragon_skin', 'Dragon Skin', 'legendary'),
('motorcycle', 'Motorcycle', 'common'),
('sports_car', 'Sports Car', 'uncommon'),
('armored_limo', 'Armored Limo', 'rare'),
('attack_heli', 'Attack Helicopter', 'epic'),
('private_jet', 'Private Jet', 'legendary'),
('rabbit_foot', 'Lucky Rabbit Foot', 'uncommon'),
('four_leaf', 'Four-Leaf Clover', 'rare'),
('gold_watch', 'Gold Watch', 'epic'),
('signet_ring', 'Signet Ring', 'legendary')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Bump schema version
UPDATE settings SET v = '20' WHERE k = 'schema_version';