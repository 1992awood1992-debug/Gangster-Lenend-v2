<?php
/**
 * Mafia Empire - core helper functions.
 * All pages should include init.php which pulls this in.
 */

/* --------------------------- Session / Current User -------------------------- */

function current_user(): ?array
{
    if (array_key_exists('__current_user', $GLOBALS)) {
        return $GLOBALS['__current_user'];
    }
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (empty($_SESSION['uid'])) {
        return null;
    }
    $u = fetch('SELECT * FROM users WHERE id = ?', [(int)$_SESSION['uid']]);
    if ($u) {
        $GLOBALS['__current_user'] = $u;
    }
    return $u;
}

function set_current_user(array $u): void
{
    $GLOBALS['__current_user'] = $u;
    if (!session_status() === PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['uid'] = (int)$u['id'];
}

function require_login(): array
{
    $u = current_user();
    if (!$u) {
        redirect('login.php');
    }
    return $u;
}

function require_admin(): array
{
    $u = require_login();
    if ((int)$u['is_admin'] !== 1) {
        http_response_code(403);
        exit('Administrator access required.');
    }
    return $u;
}

/* --------------------------- Economy / Stats -------------------------- */

function add_money(int $uid, int $amount, string $note = '', bool $bank = false): void
{
    $col = $bank ? 'bank' : 'money';
    $stmt = db()->prepare("UPDATE users SET `$col` = GREATEST(`$col` + ?, 0) WHERE id = ?");
    $stmt->execute([$amount, $uid]);
    if ($note) {
        log_event($uid, $bank ? 'bank' : 'cash', $note, $amount);
    }
}

function add_points(int $uid, int $amount): void
{
    $stmt = db()->prepare('UPDATE users SET points = GREATEST(points + ?, 0) WHERE id = ?');
    $stmt->execute([$amount, $uid]);
    if ($amount !== 0) {
        log_event($uid, 'points', 'Points change', $amount);
    }
}

function add_bullets(int $uid, int $amount): void
{
    $stmt = db()->prepare('UPDATE users SET bullets = GREATEST(bullets + ?, 0) WHERE id = ?');
    $stmt->execute([$amount, $uid]);
    if ($amount !== 0) {
        log_event($uid, 'bullets', 'Bullets change', $amount);
    }
}

function grant_xp(int $uid, int $xp): int
{
    if ($xp <= 0) {
        return 0;
    }
    $u = fetch('SELECT xp, level, energy_max, nerve_max, health_max, health FROM users WHERE id = ?', [$uid]);
    if (!$u) {
        return 0;
    }
    $oldLevel = (int)$u['level'];
    $newXp = (int)$u['xp'] + $xp;
    $newLevel = $oldLevel;
    while (xp_for_level($newLevel + 1) <= $newXp) {
        $newLevel++;
    }
    $levelsGained = $newLevel - $oldLevel;
    
    if ($levelsGained > 0) {
        $energyMax = (int)$u['energy_max'] + (5 * $levelsGained);
        $nerveMax = (int)$u['nerve_max'] + (2 * $levelsGained);
        $healthMax = (int)$u['health_max'] + (10 * $levelsGained);
        $health = (int)$u['health'] + (10 * $levelsGained);
        q('UPDATE users SET xp = ?, level = ?, energy_max = ?, nerve_max = ?, health_max = ?, health = ? WHERE id = ?', 
            [$newXp, $newLevel, $energyMax, $nerveMax, $healthMax, $health, $uid]);
        log_event($uid, 'level_up', "Reached level $newLevel", $newLevel);
        notify($uid, "Congratulations! You reached level $newLevel.", 'abilities.php');
        flash("Level Up! You reached level $newLevel!", 'gold');
        // Create a DB flash for level-up (one-time, dismissible)
        if (function_exists('db_create_flash')) {
            db_create_flash([
                'title' => "Level $newLevel Reached!",
                'message' => "Congratulations! You've reached level $newLevel. Your stats have increased and new abilities may be available.",
                'type' => 'gold',
                'target_type' => 'user',
                'target_value' => $uid,
                'dismissible' => 1,
                'show_once' => 1,
                'created_by' => null,
                'active' => 1,
                'expires_at' => date('Y-m-d H:i:s', strtotime('+1 day')),
            ]);
        }
        // Check referral milestones
        if (function_exists('referral_track_milestone')) {
            $milestones = [5, 10, 20, 50];
            foreach ($milestones as $m) {
                if ($oldLevel < $m && $newLevel >= $m) {
                    referral_track_milestone($uid, 'level_' . $m);
                }
            }
        }
    } else {
        q('UPDATE users SET xp = ? WHERE id = ?', [$newXp, $uid]);
    }
    return $levelsGained;
}

function xp_for_level(int $level): int
{
    if ($level <= 1) {
        return 0;
    }
    return 50 * ($level - 1) * $level;
}

function level_for_xp(int $xp): int
{
    $level = 1;
    while ($level < 100 && xp_for_level($level + 1) <= $xp) {
        $level++;
    }
    return $level;
}

function card_parts(string $card): array
{
    $len = strlen($card);
    if ($len === 0) {
        return ['', ''];
    }
    // A valid card has a 3-byte UTF-8 suit glyph at the end (e.g. ♠ = 0xE2 0x99 0xA0)
    // Check if last 3 bytes start with a UTF-8 lead byte 0xE0-0xEF
    if ($len >= 3 && (ord(substr($card, -3, 1)) & 0xF0) === 0xE0) {
        return [substr($card, 0, -3), substr($card, -3)];
    }
    // No valid suit glyph found - return whole card as rank
    return [$card, ''];
}

/* --------------------------- Crew Functions -------------------------- */

function crew_level(int $xp, int $xpSpent): int
{
    return max(1, (int) floor(sqrt(max(0, $xp - $xpSpent) / 100)) + 1);
}

function crew_xp_to_next(int $crewId): int
{
    $crew = fetch('SELECT xp, xp_spent FROM crews WHERE id = ?', [$crewId]);
    if (!$crew) {
        return 0;
    }
    $current = crew_level((int) $crew['xp'], (int) $crew['xp_spent']);
    $nextXp = xp_for_level($current + 1) * 100 + (int) $crew['xp_spent'];
    return max(0, $nextXp - (int) $crew['xp']);
}

function zone_income(int $level): int
{
    return max(0, (int) floor($level * 50 * 1.2));
}

function zone_claim_cost(int $level): int
{
    return max(1000, (int) floor($level * $level * 2500));
}

function money(int|float|string $amount): string
{
    $prefix = $amount < 0 ? '-' : '';
    $abs = abs((int) $amount);
    return $prefix . '$' . number_format($abs);
}

/* --------------------------- Ranks -------------------------- */

function rank_for_level(int $level): array
{
    $r = fetch('SELECT * FROM ranks WHERE level = ?', [$level]);
    return $r ?: ['id' => 0, 'name' => 'Associate', 'level' => $level];
}

/* --------------------------- Hospital -------------------------- */

function is_hospitalized(array $u): bool
{
    if (empty($u['hospital_until'])) {
        return false;
    }
    return strtotime($u['hospital_until']) > time();
}

/* --------------------------- Notifications / Events -------------------------- */

function notify(int $uid, string $text, string $link = ''): void
{
    insert('notifications', [
        'user_id'    => $uid,
        'text'       => $text,
        'link'       => $link,
        'is_read'    => 0,
        'created_at' => now(),
    ]);
    if (function_exists('push_notify')) {
        push_notify($uid, $text, $link);
    }
}

function log_event(int $uid, string $type, string $text, int $amount = 0): void
{
    insert('event_log', [
        'user_id'    => $uid,
        'type'       => $type,
        'text'       => $text,
        'amount'     => $amount,
        'created_at' => now(),
    ]);
}

/* --------------------------- Flash Messages -------------------------- */

function flash(string $msg, string $type = 'info'): void
{
    if (!session_status() === PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['flashes'][] = ['msg' => $msg, 'type' => $type];
}

function take_flashes(): array
{
    if (!session_status() === PHP_SESSION_ACTIVE) {
        session_start();
    }
    $f = $_SESSION['flashes'] ?? [];
    unset($_SESSION['flashes']);
    return $f;
}

/* --------------------------- Output Helpers -------------------------- */

function e(mixed $value, string $encoding = 'UTF-8'): string
{
    if (is_array($value) || is_object($value)) {
        return '';
    }
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, $encoding);
}

function url(string $path = ''): string
{
    $base = BASE_URL ?: (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    return $base . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    $base = defined('BASE_URL') && BASE_URL ? BASE_URL : ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST']) ? ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/') : '');
    $url = $base . '/' . ltrim($path, '/');
    // Add versioning
    if (defined('GAME_VERSION')) {
        $url .= (strpos($url, '?') === false ? '?' : '&') . 'v=' . GAME_VERSION;
    }
    return $url;
}

function redirect(string $url): void
{
    if (!headers_sent()) {
        header('Location: ' . $url);
        exit;
    }
    echo '<script>window.location.href=' . json_encode($url) . ';</script>';
    echo '<meta http-equiv="refresh" content="0;url=' . htmlspecialchars($url, ENT_QUOTES) . '">';
    exit;
}

/* --------------------------- CSRF -------------------------- */

function csrf_token(): string
{
    if (!session_status() === PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(): void
{
    if (!session_status() === PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
        http_response_code(419);
        exit('CSRF token mismatch');
    }
}

/* --------------------------- Action Timers -------------------------- */

function get_timer_setting(string $key, int $default = 0): int
{
    $v = fetch_one('SELECT v FROM settings WHERE k = ?', [$key], null);
    if ($v === null || $v === false || $v === '') {
        return $default;
    }
    return max(0, (int)$v);
}

function action_on_cooldown(int $uid, string $action): ?string
{
    $sec = get_timer_setting('timer_' . $action, 0);
    if ($sec <= 0) {
        return null;
    }
    $row = fetch('SELECT ready_at FROM user_action_cooldowns WHERE user_id = ? AND action_key = ?', [$uid, $action]);
    if (!$row) {
        return null;
    }
    $ready = strtotime($row['ready_at']);
    if ($ready > time()) {
        $diff = $ready - time();
        $m = floor($diff / 60);
        $s = $diff % 60;
        if ($m > 0) {
            return $m . 'm ' . $s . 's';
        }
        return $s . 's';
    }
    return null;
}

function set_action_cooldown(int $uid, string $action): void
{
    $sec = get_timer_setting('timer_' . $action, 0);
    if ($sec <= 0) {
        return;
    }
    $ready = date('Y-m-d H:i:s', time() + $sec);
    q('INSERT INTO user_action_cooldowns (user_id, action_key, ready_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE ready_at = VALUES(ready_at)', [$uid, $action, $ready]);
}

function is_logged_in(): bool { return current_user() !== null; }


/* --------------------------- Generic Settings -------------------------- */

function get_setting(string $key, $default = null)
{
    $v = fetch_one('SELECT v FROM settings WHERE k = ?', [$key], null);
    if ($v === null || $v === false || $v === '') {
        return $default;
    }
    // Try to return numeric if possible
    if (is_numeric($v)) {
        return (float)$v;
    }
    return $v;
}

/* --------------------------- Referral System -------------------------- */

function referral_get_referrer(int $uid): ?int
{
    $u = fetch('SELECT referrer_id, referred_by FROM users WHERE id = ?', [$uid]);
    if (!$u) return null;
    if (!empty($u['referrer_id'])) return (int)$u['referrer_id'];
    if (!empty($u['referred_by'])) return (int)$u['referred_by'];
    return null;
}

function referral_track_milestone(int $referredId, string $milestone): void
{
    $referrerId = referral_get_referrer($referredId);
    if (!$referrerId) return;
    // Avoid duplicate milestone rewards
    $exists = fetch('SELECT id FROM referral_rewards_v2 WHERE referrer_id = ? AND referred_id = ? AND milestone = ?', [$referrerId, $referredId, $milestone]);
    if ($exists) return;

    // Check if already claimed
    $existing = fetch('SELECT 1 FROM referral_rewards_v2 WHERE referrer_id = ? AND referred_id = ? AND milestone = ?', 
        [$referrerId, $referredId, $milestone]);
    if ($existing) return;

    $settings = [
        'signup' => ['type' => 'points', 'amount' => (int)get_setting('referral_signup_bonus', 50)],
        'level_5' => ['type' => 'points', 'amount' => (int)get_setting('referral_level_5_bonus', 100)],
        'level_10' => ['type' => 'points', 'amount' => (int)get_setting('referral_level_10_bonus', 250)],
        'level_20' => ['type' => 'points', 'amount' => (int)get_setting('referral_level_20_bonus', 500)],
        'level_50' => ['type' => 'points', 'amount' => (int)get_setting('referral_level_50_bonus', 1000)],
        'first_purchase' => ['type' => 'points', 'amount' => (int)get_setting('referral_first_purchase_bonus', 200)],
        'reach_rank' => ['type' => 'points', 'amount' => (int)get_setting('referral_reach_rank_bonus', 500)],
    ];

    if (!isset($settings[$milestone])) return;

    $reward = $settings[$milestone];
    insert('referral_rewards_v2', [
        'referrer_id' => $referrerId,
        'referred_id' => $referredId,
        'milestone' => $milestone,
        'reward_type' => $reward['type'],
        'reward_amount' => $reward['amount'],
        'status' => 'claimed',
        'claimed_at' => now(),
    ]);

    // Give reward
    if ($reward['type'] === 'points') {
        add_points($referrerId, $reward['amount']);
    } elseif ($reward['type'] === 'cash') {
        add_money($referrerId, $reward['amount'], 'Referral milestone: ' . $milestone);
    }

    notify($referrerId, 'Your referral reached ' . $milestone . '! Earned ' . $reward['amount'] . ' ' . $reward['type'] . '.', 'referrals.php');
}

function referral_get_pending(int $uid): array
{
    return fetch_all('SELECT * FROM referral_rewards_v2 WHERE referrer_id = ? AND status = ? ORDER BY created_at DESC', [$uid, 'pending']);
}

function referral_get_history(int $uid): array
{
    return fetch_all('SELECT * FROM referral_rewards_v2 WHERE referrer_id = ? ORDER BY created_at DESC', [$uid]);
}

function referral_get_stats(int $uid): array
{
    $referred = fetch_all('SELECT u.*, 
        (SELECT COUNT(*) FROM referral_rewards_v2 rr WHERE rr.referrer_id = u.referrer_id AND rr.referred_id = u.id) as milestones_hit
        FROM users u WHERE u.referrer_id = ?', [$uid]);
    $totalPoints = (int)fetch_one('SELECT COALESCE(SUM(reward_amount),0) FROM referral_rewards_v2 WHERE referrer_id = ? AND reward_type = ? AND status = ?', [$uid, 'points', 'claimed'], 0);
    $totalCash = (int)fetch_one('SELECT COALESCE(SUM(reward_amount),0) FROM referral_rewards_v2 WHERE referrer_id = ? AND reward_type = ? AND status = ?', [$uid, 'cash', 'claimed'], 0);
    $pending = referral_get_pending($uid);
    return [
        'total_referred' => count($referred),
        'total_points' => $totalPoints,
        'total_cash' => $totalCash,
        'pending_count' => count($pending),
        'referrals' => $referred,
    ];
}