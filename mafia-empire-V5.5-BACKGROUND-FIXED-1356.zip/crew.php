<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        if ($u['crew_id']) { flash('Already in a crew.', 'error'); redirect('crew.php'); }
        $name = trim($_POST['name'] ?? '');
        $tag = strtoupper(trim(substr($_POST['tag'] ?? '', 0, 6)));
        if ($name === '' || $tag === '') { flash('Name and tag required.', 'error'); }
        elseif (fetch('SELECT id FROM crews WHERE name = ? OR tag = ?', [$name, $tag])) { flash('Name or tag taken.', 'error'); }
        elseif ((int) $u['money'] < 50000) { flash('Need $50,000 to create a crew.', 'error'); }
        else {
            add_money($u['id'], -50000, 'Created crew: ' . $name);
            $cid = insert('crews', ['name' => $name, 'tag' => $tag, 'leader_id' => $u['id'], 'money' => 0, 'bullets' => 0, 'points' => 0, 'level' => 1]);
            q('UPDATE users SET crew_id = ?, crew_rank = ? WHERE id = ?', [$cid, 'Leader', $u['id']]);
            insert('crew_members', ['user_id' => $u['id'], 'crew_id' => $cid, 'rank' => 'Leader']);
            flash('Crew created!', 'success');
        }
    } elseif ($action === 'join') {
        if ($u['crew_id']) { flash('Already in a crew.', 'error'); redirect('crew.php'); }
        $cid = (int) ($_POST['crew_id'] ?? 0);
        $crew = fetch('SELECT * FROM crews WHERE id = ?', [$cid]);
        if (!$crew) { flash('Crew not found.', 'error'); }
        elseif ((int) fetch_one('SELECT COUNT(*) FROM crew_members WHERE crew_id = ?', [$cid], 0) >= crew_max_members($cid)) { flash('That crew is full.', 'error'); }
        else {
            q('UPDATE users SET crew_id = ?, crew_rank = ? WHERE id = ?', [$cid, 'Recruit', $u['id']]);
            insert('crew_members', ['user_id' => $u['id'], 'crew_id' => $cid, 'rank' => 'Recruit']);
            flash('Joined ' . e($crew['name']) . '!', 'success');
        }
    } elseif ($action === 'leave') {
        if (!$u['crew_id']) { flash('Not in a crew.', 'error'); }
        else {
            $cid = (int) $u['crew_id'];
            $crew = fetch('SELECT * FROM crews WHERE id = ?', [$cid]);
            if (!$crew) { flash('Crew not found.', 'error'); }
            elseif ((int) $crew['leader_id'] === $u['id']) {
                $members = fetch_all('SELECT user_id FROM crew_members WHERE crew_id = ?', [$cid]);
                if (count($members) > 1) { flash('Leader cannot leave while members remain. Disband or promote.', 'error'); }
                else {
                    purge_crew_records($cid);
                    q('DELETE FROM crews WHERE id = ?', [$cid]);
                    q('DELETE FROM crew_members WHERE crew_id = ?', [$cid]);
                    q('UPDATE users SET crew_id = NULL, crew_rank = \'\' WHERE id = ?', [$u['id']]);
                    flash('Crew disbanded. Territory and pacts released.', 'success');
                }
            } else {
                q('DELETE FROM crew_members WHERE user_id = ?', [$u['id']]);
                q('UPDATE users SET crew_id = NULL, crew_rank = \'\' WHERE id = ?', [$u['id']]);
                flash('Left crew.', 'success');
            }
        }
    } elseif ($action === 'armory_deposit') {
        if (!$u['crew_id']) { flash('Not in a crew.', 'error'); redirect('crew.php'); }
        $ui = fetch('SELECT ui.*, i.name FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.id = ? AND ui.user_id = ? AND ui.qty > 0', [(int) ($_POST['ui_id'] ?? 0), $u['id']]);
        $amt = max(1, (int) ($_POST['amount'] ?? 0));
        if (!$ui) { flash('Item not found.', 'error'); }
        elseif ($amt > (int) $ui['qty']) { flash('You don\'t have that many.', 'error'); }
        else {
            q('UPDATE user_items SET qty = qty - ? WHERE id = ?', [$amt, $ui['id']]);
            q('DELETE FROM user_items WHERE user_id = ? AND qty <= 0', [$u['id']]);
            $row = fetch('SELECT id FROM crew_armory WHERE crew_id = ? AND item_id = ?', [$u['crew_id'], $ui['item_id']]);
            if ($row) { q('UPDATE crew_armory SET qty = qty + ? WHERE id = ?', [$amt, $row['id']]); }
            else { insert('crew_armory', ['crew_id' => $u['crew_id'], 'item_id' => $ui['item_id'], 'qty' => $amt]); }
            flash('Deposited ' . $amt . 'x ' . e($ui['name']) . ' to the crew armory.', 'success');
        }
    } elseif ($action === 'armory_withdraw') {
        if (!$u['crew_id']) { flash('Not in a crew.', 'error'); redirect('crew.php'); }
        $crew = fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]);
        if (!in_array($u['crew_rank'], ['Leader', 'Underboss'], true)) { flash('Only Leader or Underboss can withdraw gear.', 'error'); }
        else {
            $a = fetch('SELECT a.*, i.name FROM crew_armory a JOIN items i ON i.id = a.item_id WHERE a.id = ? AND a.crew_id = ? AND a.qty > 0', [(int) ($_POST['armory_id'] ?? 0), $u['crew_id']]);
            $amt = max(1, (int) ($_POST['amount'] ?? 0));
            if (!$a) { flash('Item not found.', 'error'); }
            elseif ($amt > (int) $a['qty']) { flash('Not enough in the armory.', 'error'); }
            else {
                q('UPDATE crew_armory SET qty = qty - ? WHERE id = ?', [$amt, $a['id']]);
                q('DELETE FROM crew_armory WHERE qty <= 0', []);
                $mine = fetch('SELECT id FROM user_items WHERE user_id = ? AND item_id = ?', [$u['id'], $a['item_id']]);
                if ($mine) { q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [$amt, $mine['id']]); }
                else { insert('user_items', ['user_id' => $u['id'], 'item_id' => $a['item_id'], 'qty' => $amt, 'equipped' => 0]); }
                flash('Withdrew ' . $amt . 'x ' . e($a['name']) . ' from the armory.', 'success');
            }
        }
    } elseif ($action === 'bullets_deposit') {
        if (!$u['crew_id']) { flash('Not in a crew.', 'error'); redirect('crew.php'); }
        $amt = max(1, (int) ($_POST['amount'] ?? 0));
        if ($amt > (int) $u['bullets']) { flash('Not enough bullets.', 'error'); }
        else {
            add_bullets($u['id'], -$amt);
            q('UPDATE crews SET bullets = bullets + ? WHERE id = ?', [$amt, $u['crew_id']]);
            flash('Deposited ' . number_format($amt) . ' bullets to the crew vault.', 'success');
        }
    } elseif ($action === 'bullets_withdraw') {
        if (!$u['crew_id']) { flash('Not in a crew.', 'error'); redirect('crew.php'); }
        $crew = fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]);
        if (!in_array($u['crew_rank'], ['Leader', 'Underboss'], true)) { flash('Only Leader or Underboss can withdraw bullets.', 'error'); }
        else {
            $amt = max(1, (int) ($_POST['amount'] ?? 0));
            if ($amt > (int) $crew['bullets']) { flash('Not enough bullets in the vault.', 'error'); }
            else {
                q('UPDATE crews SET bullets = bullets - ? WHERE id = ?', [$amt, $crew['id']]);
                add_bullets($u['id'], $amt);
                flash('Withdrew ' . number_format($amt) . ' bullets.', 'success');
            }
        }
    } elseif ($action === 'perk_unlock') {
        if (!$u['crew_id']) { flash('Not in a crew.', 'error'); redirect('crew.php'); }
        $crew = fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]);
        if (!in_array($u['crew_rank'], ['Leader', 'Underboss'], true)) { flash('Only Leader or Underboss can unlock perks.', 'error'); }
        else {
            $perk = fetch('SELECT * FROM crew_perks WHERE code = ?', [$_POST['perk_code'] ?? '']);
            if (!$perk) { flash('Perk not found.', 'error'); }
            elseif (crew_has_perk((int) $crew['id'], (string) $perk['code'])) { flash('Perk already unlocked.', 'error'); }
            elseif ($perk['requires_code'] && !crew_has_perk((int) $crew['id'], (string) $perk['requires_code'])) { flash('Requires ' . e(fetch_one('SELECT name FROM crew_perks WHERE code = ?', [$perk['requires_code']], '?') ?? '?') . ' first.', 'error'); }
            elseif ((int) $crew['xp'] < (int) $perk['cost_xp']) { flash('Not enough crew XP.', 'error'); }
            else {
                insert('crew_unlocked_perks', ['crew_id' => $crew['id'], 'perk_code' => $perk['code']]);
                spend_crew_xp((int) $crew['id'], (int) $perk['cost_xp']);
                flash('Unlocked perk: ' . e($perk['name']) . '!', 'success');
            }
        }
    } elseif ($action === 'deposit') {
        $amt = max(1, (int) ($_POST['amount'] ?? 0));
        if ($amt > $u['money']) { flash('Not enough cash.', 'error'); }
        else {
            add_money($u['id'], -$amt, 'Crew deposit');
            q('UPDATE crews SET money = money + ? WHERE id = ?', [$amt, $u['crew_id']]);
            flash('Deposited ' . money($amt) . ' to crew bank.', 'success');
        }
    } elseif ($action === 'withdraw') {
        if (!$u['crew_id']) { flash('Not in a crew.', 'error'); redirect('crew.php'); }
        $crew = fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]);
        $isLeader = (int) $crew['leader_id'] === $u['id'];
        if (!$isLeader) { flash('Only leader can withdraw.', 'error'); }
        else {
            $amt = max(1, (int) ($_POST['amount'] ?? 0));
            if ($amt > $crew['money']) { flash('Not enough in crew bank.', 'error'); }
            else {
                q('UPDATE crews SET money = money - ? WHERE id = ?', [$amt, $crew['id']]);
                add_money($u['id'], $amt, 'Crew withdrawal');
                flash('Withdrew ' . money($amt) . ' from crew bank.', 'success');
            }
        }
    } elseif ($action === 'promote' || $action === 'demote' || $action === 'kick') {
        if (!$u['crew_id']) { flash('Not in a crew.', 'error'); redirect('crew.php'); }
        $crew = fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]);
        $isLeader = (int) $crew['leader_id'] === $u['id'];
        if (!$isLeader) { flash('Only leader can manage members.', 'error'); }
        else {
            $targetId = (int) ($_POST['target_id'] ?? 0);
            if ($targetId === $u['id']) { flash('Cannot target yourself.', 'error'); }
            else {
                $target = fetch('SELECT * FROM crew_members WHERE user_id = ? AND crew_id = ?', [$targetId, $u['crew_id']]);
                if (!$target) { flash('Not a member.', 'error'); }
                else {
                    if ($action === 'promote') {
                        $ranks = ['Recruit', 'Capo', 'Underboss', 'Leader'];
                        $idx = array_search($target['rank'], $ranks);
                        if ($idx !== false && $idx < count($ranks) - 1) {
                            $newRank = $ranks[$idx + 1];
                            q('UPDATE crew_members SET rank = ? WHERE user_id = ?', [$newRank, $targetId]);
                            q('UPDATE users SET crew_rank = ? WHERE id = ?', [$newRank, $targetId]);
                            flash('Promoted to ' . $newRank, 'success');
                        }
                    } elseif ($action === 'demote') {
                        $ranks = ['Recruit', 'Capo', 'Underboss', 'Leader'];
                        $idx = array_search($target['rank'], $ranks);
                        if ($idx !== false && $idx > 0) {
                            $newRank = $ranks[$idx - 1];
                            q('UPDATE crew_members SET rank = ? WHERE user_id = ?', [$newRank, $targetId]);
                            q('UPDATE users SET crew_rank = ? WHERE id = ?', [$newRank, $targetId]);
                            flash('Demoted to ' . $newRank, 'success');
                        }
                    } elseif ($action === 'kick') {
                        if ($target['rank'] === 'Leader') { flash('Cannot kick leader.', 'error'); }
                        else {
                            q('DELETE FROM crew_members WHERE user_id = ?', [$targetId]);
                            q('UPDATE users SET crew_id = NULL, crew_rank = \'\' WHERE id = ?', [$targetId]);
                            flash('Kicked from crew.', 'success');
                        }
                    }
                }
            }
        }
    }
    redirect('crew.php');
}

$page_title = 'Crew';
require __DIR__ . '/includes/header.php';

$hasCrew = (bool) $u['crew_id'];
$myCrew = $hasCrew ? fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]) : null;
$isLeader = $hasCrew && (int) $myCrew['leader_id'] === $u['id'];
$members = $hasCrew ? fetch_all('SELECT cm.*, u.username, u.level FROM crew_members cm JOIN users u ON u.id = cm.user_id WHERE cm.crew_id = ? ORDER BY CASE cm.rank WHEN \'Leader\' THEN 1 WHEN \'Underboss\' THEN 2 WHEN \'Capo\' THEN 3 ELSE 4 END, u.level DESC', [$u['crew_id']]) : [];
$openCrews = !$hasCrew ? fetch_all('SELECT c.*, COUNT(cm.user_id) AS members FROM crews c LEFT JOIN crew_members cm ON cm.crew_id = c.id GROUP BY c.id ORDER BY c.level DESC, c.money DESC LIMIT 15') : [];
$armory = $hasCrew ? fetch_all('SELECT ca.*, i.name, i.type, i.attack, i.defense, i.rarity FROM crew_armory ca JOIN items i ON i.id = ca.item_id WHERE ca.crew_id = ? ORDER BY i.cost DESC', [$u['crew_id']]) : [];
$perksList = fetch_all('SELECT * FROM crew_perks ORDER BY cost_xp');
$myPerks = $hasCrew ? array_column(fetch_all('SELECT perk_code FROM crew_unlocked_perks WHERE crew_id = ?', [$u['crew_id']]), 'perk_code') : [];
$myItems = $hasCrew ? fetch_all('SELECT ui.*, i.name FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.qty > 0 ORDER BY i.cost DESC', [$u['id']]) : [];
?>
<div class="card">
  <div class="panel-heading">Crew</div>
  <?php if (!$hasCrew): ?>
    <p class="muted">You are not in a crew. Create one ($50,000) or join an existing crew.</p>
    
    <h2 style="margin-top:18px">Create Crew</h2>
    <form method="post" style="max-width:400px;display:grid;gap:10px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <label>Crew Name <input name="name" maxlength="60" required></label>
      <label>Tag (max 6 chars) <input name="tag" maxlength="6" required></label>
      <button class="btn btn-gold" type="submit">Create ($50,000)</button>
    </form>
    
    <h2 style="margin-top:24px">Existing Crews</h2>
    <?php if (!$openCrews): ?>
      <p class="muted">No crews yet.</p>
    <?php else: ?>
      <div class="table-wrap"><table>
        <tr><th>Crew</th><th>Tag</th><th>Level</th><th>Members</th><th>Money</th><th></th></tr>
        <?php foreach ($openCrews as $c): ?>
          <tr>
            <td><b><?= e($c['name']) ?></b></td>
            <td>[<?= e($c['tag']) ?>]</td>
            <td><?= (int) $c['level'] ?></td>
            <td><?= (int) $c['members'] ?></td>
            <td><?= money($c['money']) ?></td>
            <td>
              <form method="post" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="join">
                <input type="hidden" name="crew_id" value="<?= (int) $c['id'] ?>">
                <button class="btn btn-green btn-sm" type="submit">Join</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </table></div>
    <?php endif; ?>
  <?php else: ?>
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px">
      <div>
        <b style="font-size:1.2rem"><?= e($myCrew['name']) ?></b> [<?= e($myCrew['tag']) ?>]
        <span class="tag tag-legendary" style="margin-left:8px"><?= e($u['crew_rank']) ?></span>
      </div>
      <div class="pill-row">
        <span class="pill">Level: <?= (int) $myCrew['level'] ?></span>
        <span class="pill">Crew XP: <?= number_format((int) $myCrew['xp']) ?></span>
        <span class="pill">Wars: <?= (int) $myCrew['wars_won'] ?>W / <?= (int) $myCrew['wars_lost'] ?>L</span>
        <span class="pill">Money: <?= money($myCrew['money']) ?></span>
        <span class="pill">Bullets: <?= number_format((int) $myCrew['bullets']) ?></span>
        <span class="pill">Points: <?= number_format((int) $myCrew['points']) ?></span>
      </div>
    </div>
    
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
      <a class="btn btn-sm" href="<?= e(url('territory.php')) ?>">🗺 Territory</a>
      <a class="btn btn-sm" href="<?= e(url('crew_wars.php')) ?>">⚔ Crew Wars</a>
      <a class="btn btn-sm" href="<?= e(url('diplomacy.php')) ?>">✒ Diplomacy</a>
    </div>
    
    <?php if ($isLeader): ?>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
      <form method="post" style="display:flex;gap:8px;align-items:center">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="deposit">
        <input type="number" name="amount" min="1" max="<?= (int) $u['money'] ?>" placeholder="Deposit" style="width:120px" required>
        <button class="btn btn-green btn-sm" type="submit">Deposit</button>
      </form>
      <form method="post" style="display:flex;gap:8px;align-items:center">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="withdraw">
        <input type="number" name="amount" min="1" max="<?= (int) $myCrew['money'] ?>" placeholder="Withdraw" style="width:120px" required>
        <button class="btn btn-gold btn-sm" type="submit">Withdraw</button>
      </form>
      </div>
    <?php else: ?>
      <div class="stat" style="margin-bottom:14px"><span>Your Rank</span><b><?= e($u['crew_rank']) ?></b></div>
    <?php endif; ?>
    
    <h2>Members</h2>
    <div class="table-wrap"><table>
      <tr><th>Player</th><th>Level</th><th>Rank</th><th>Joined</th><th><?= $isLeader ? 'Actions' : '' ?></th></tr>
      <?php foreach ($members as $m):
        $self = $m['user_id'] == $u['id'];
      ?>
        <tr>
          <td><b><?= e($m['username']) ?></b><?= $self ? ' <span class="tag tag-legendary">You</span>' : '' ?></td>
          <td><?= (int) $m['level'] ?></td>
          <td><?= e($m['rank']) ?></td>
          <td><?= date('M j, Y', strtotime($m['joined_at'])) ?></td>
          <?php if ($isLeader && !$self): ?>
            <td>
              <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="promote"><input type="hidden" name="target_id" value="<?= (int) $m['user_id'] ?>"><button class="btn btn-sm" type="submit"<?= $m['rank'] === 'Leader' ? ' disabled' : '' ?>>▲</button></form>
              <form method="post" style="display:inline;margin-left:4px"><?= csrf_field() ?><input type="hidden" name="action" value="demote"><input type="hidden" name="target_id" value="<?= (int) $m['user_id'] ?>"><button class="btn btn-sm" type="submit"<?= $m['rank'] === 'Recruit' ? ' disabled' : '' ?>>▼</button></form>
              <form method="post" style="display:inline;margin-left:4px"><?= csrf_field() ?><input type="hidden" name="action" value="kick"><input type="hidden" name="target_id" value="<?= (int) $m['user_id'] ?>"><button class="btn btn-sm" type="submit" data-confirm="Kick <?= e($m['username']) ?>?">Kick</button></form>
            </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
    </table></div>
    
    <h2 style="margin-top:22px">Vault &amp; Armory</h2>
    <div class="grid grid-3" style="margin-top:6px">
      <div class="card">
        <div class="panel-heading">Bullet Vault</div>
        <form method="post" style="display:grid;gap:6px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="bullets_deposit">
          <label>Deposit <input type="number" name="amount" min="1" max="<?= (int) $u['bullets'] ?>" placeholder="You have <?= number_format((int) $u['bullets']) ?>" required></label>
          <button class="btn btn-green btn-sm" type="submit">Deposit Bullets</button>
        </form>
        <?php if (in_array($u['crew_rank'], ['Leader', 'Underboss'], true)): ?>
        <form method="post" style="display:grid;gap:6px;margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="bullets_withdraw">
          <label>Withdraw <input type="number" name="amount" min="1" max="<?= (int) $myCrew['bullets'] ?>" placeholder="Crew has <?= number_format((int) $myCrew['bullets']) ?>" required></label>
          <button class="btn btn-gold btn-sm" type="submit">Withdraw Bullets</button>
        </form>
        <?php endif; ?>
      </div>
      <div class="card">
        <div class="panel-heading">Deposit Gear</div>
        <?php if (!$myItems): ?>
          <p class="muted small">You own no items to donate.</p>
        <?php else: ?>
        <form method="post" style="display:grid;gap:6px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="armory_deposit">
          <select name="ui_id" required>
            <?php foreach ($myItems as $it): ?>
              <option value="<?= (int) $it['id'] ?>"><?= e($it['name']) ?> (<?= (int) $it['qty'] ?>)</option>
            <?php endforeach; ?>
          </select>
          <input type="number" name="amount" min="1" value="1" required>
          <button class="btn btn-green btn-sm" type="submit">Deposit to Armory</button>
        </form>
        <?php endif; ?>
      </div>
      <div class="card">
        <div class="panel-heading">Withdraw Gear</div>
        <?php if (!$armory): ?>
          <p class="muted small">The armory is empty.</p>
        <?php elseif (!in_array($u['crew_rank'], ['Leader', 'Underboss'], true)): ?>
          <p class="muted small">Only Leader / Underboss may withdraw gear.</p>
        <?php else: ?>
        <form method="post" style="display:grid;gap:6px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="armory_withdraw">
          <select name="armory_id" required>
            <?php foreach ($armory as $a): ?>
              <option value="<?= (int) $a['id'] ?>"><?= e($a['name']) ?> (<?= (int) $a['qty'] ?>)</option>
            <?php endforeach; ?>
          </select>
          <input type="number" name="amount" min="1" value="1" required>
          <button class="btn btn-gold btn-sm" type="submit">Withdraw from Armory</button>
        </form>
        <?php endif; ?>
      </div>
    </div>
    <?php if ($armory): ?>
    <div class="table-wrap" style="margin-top:12px"><table>
      <tr><th>Item</th><th>Type</th><th>Stats</th><th>Qty</th></tr>
      <?php foreach ($armory as $a): ?>
        <tr>
          <td><b><?= e($a['name']) ?></b> <span class="tag tag-<?= e($a['rarity']) ?>"><?= e($a['rarity']) ?></span></td>
          <td><?= e($a['type']) ?></td>
          <td>ATK +<?= (int) $a['attack'] ?> DEF +<?= (int) $a['defense'] ?></td>
          <td><?= (int) $a['qty'] ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?php endif; ?>
    
    <h2 style="margin-top:22px">Crew Perks</h2>
    <p class="muted small" style="margin-bottom:10px">Crew XP is earned from wars, captures, and raids. Spend it to unlock permanent crew powers.</p>
    <div class="grid grid-3">
      <?php foreach ($perksList as $p):
        $owned = in_array($p['code'], $myPerks, true);
        $reqName = $p['requires_code'] ? fetch_one('SELECT name FROM crew_perks WHERE code = ?', [$p['requires_code']], '?') : null;
        $canBuy = $isBoss && !$owned && (!$p['requires_code'] || in_array($p['requires_code'], $myPerks, true)) && (int) $myCrew['xp'] >= (int) $p['cost_xp'];
      ?>
        <div class="card">
          <div class="panel-heading"><?= e($p['name']) ?> <?= $owned ? '<span class="tag tag-epic">Owned</span>' : '' ?></div>
          <p class="muted small" style="min-height:36px"><?= e($p['description']) ?></p>
          <div class="stat"><span>Cost</span><b><?= number_format((int) $p['cost_xp']) ?> crew XP</b></div>
          <?php if ($p['requires_code']): ?>
            <div class="stat"><span>Requires</span><b><?= e($reqName ?? '?') ?></b></div>
          <?php endif; ?>
          <?php if (!$owned && $isBoss): ?>
            <form method="post" style="margin-top:8px">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="perk_unlock">
              <input type="hidden" name="perk_code" value="<?= e($p['code']) ?>">
              <button class="btn btn-gold btn-sm" type="submit"<?= $canBuy ? '' : ' disabled' ?>><?= $canBuy ? 'Unlock' : 'Locked' ?></button>
            </form>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
    
    <form method="post" style="margin-top:18px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="leave">
      <button class="btn btn-danger" type="submit" data-confirm="Leave crew?">Leave Crew</button>
    </form>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>