<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Integration tests for the Tournament system.
 */
final class TournamentsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        require_once dirname(__DIR__, 2) . '/includes/tournaments.php';
    }

    /** Create a tournament fixture with a unique code. */
    private function makeTournament(array $overrides = []): array
    {
        $data = array_merge([
            'code'                   => 't_' . bin2hex(random_bytes(4)),
            'name'                   => 'Test Tournament',
            'description'            => 'A test event.',
            'type'                   => 'elimination',
            'game_type'              => 'pvp',
            'registration_opens_at'  => date('Y-m-d H:i:s', time() - 3600),
            'registration_closes_at' => date('Y-m-d H:i:s', time() + 3600),
            'starts_at'              => date('Y-m-d H:i:s', time() + 7200),
            'min_participants'       => 4,
            'max_participants'       => 16,
            'min_level'              => 1,
            'entry_fee_money'        => 0,
            'entry_fee_points'       => 0,
            'prize_pool_money'       => 1000,
            'prize_pool_points'      => 100,
            'prize_pool_xp'          => 1000,
            'payout_structure'       => json_encode([
                ['place' => 1, 'pct' => 50],
                ['place' => 2, 'pct' => 30],
                ['place' => 3, 'pct' => 20],
            ]),
            'status'                 => 'registration',
        ], $overrides);

        $id = insert('tournaments', $data);
        return tournament_get($id);
    }

    /** Register N players into a tournament; returns user rows keyed by id. */
    private function registerPlayers(array $tournament, int $count): array
    {
        $users = [];
        for ($i = 0; $i < $count; $i++) {
            $u = $this->makeUser(['level' => 10, 'money' => 100000, 'points' => 10000]);
            $res = tournament_register((int) $tournament['id'], (int) $u['id']);
            $this->assertTrue($res['ok'], $res['error'] ?? 'register failed');
            $users[(int) $u['id']] = $u;
        }
        return $users;
    }

    /** Resolve every pending match (participant 1 always wins) until settled. */
    private function playOut(int $tid): int
    {
        $guard = 0;
        while ($guard++ < 20) {
            $t = tournament_get($tid);
            if (!$t || (string) $t['status'] !== 'in_progress') {
                break;
            }
            $pending = array_values(array_filter(
                tournament_matches($tid),
                static fn($m) => (string) $m['status'] === 'pending'
            ));
            if (!$pending) {
                break;
            }
            foreach ($pending as $m) {
                $res = tournament_record_result((int) $m['id'], (int) $m['participant1_id'], 3, 1);
                $this->assertTrue($res['ok'], $res['error'] ?? 'result failed');
            }
        }
        return $guard;
    }

    public function testGetAllReturnsSeededTournaments(): void
    {
        $all = tournament_get_all();
        $this->assertGreaterThan(0, count($all));
        $codes = array_column($all, 'code');
        $this->assertContains('daily_pvp', $codes);
    }

    public function testCanRegisterRequiresOpenWindowAndLevel(): void
    {
        $t = $this->makeTournament(['min_level' => 5]);
        $low = $this->makeUser(['level' => 1, 'money' => 100000]);

        $check = tournament_can_register($t, $low);
        $this->assertFalse($check['ok']);
        $this->assertStringContainsString('level', strtolower($check['error']));

        $high = $this->makeUser(['level' => 10, 'money' => 100000]);
        $ok = tournament_can_register($t, $high);
        $this->assertTrue($ok['ok'], $ok['error'] ?? 'should be allowed');

        // Closed registration window
        $closed = $this->makeTournament(['registration_closes_at' => date('Y-m-d H:i:s', time() - 60)]);
        $check2 = tournament_can_register($closed, $high);
        $this->assertFalse($check2['ok']);
    }

    public function testRegisterChargesEntryFeeAndBoostsPrizePool(): void
    {
        $t = $this->makeTournament(['entry_fee_money' => 250, 'entry_fee_points' => 5]);
        $u = $this->makeUser(['level' => 10, 'money' => 1000, 'points' => 50]);

        $res = tournament_register((int) $t['id'], (int) $u['id']);
        $this->assertTrue($res['ok'], $res['error'] ?? '');

        $fresh = $this->freshUser((int) $u['id']);
        $this->assertSame(750, (int) $fresh['money']);
        $this->assertSame(45, (int) $fresh['points']);

        $updated = tournament_get((int) $t['id']);
        $this->assertSame(1250, (int) $updated['prize_pool_money']);
        $this->assertSame(105, (int) $updated['prize_pool_points']);

        // Duplicate registration is rejected
        $dup = tournament_register((int) $t['id'], (int) $u['id']);
        $this->assertFalse($dup['ok']);
    }

    public function testRegisterFailsWithInsufficientFunds(): void
    {
        $t = $this->makeTournament(['entry_fee_money' => 5000]);
        $u = $this->makeUser(['level' => 10, 'money' => 100]);

        $res = tournament_register((int) $t['id'], (int) $u['id']);
        $this->assertFalse($res['ok']);
        $this->assertStringContainsString('need', strtolower($res['error']));
    }

    public function testWithdrawRefundsEntryFee(): void
    {
        $t = $this->makeTournament(['entry_fee_money' => 300]);
        $u = $this->makeUser(['level' => 10, 'money' => 1000]);

        tournament_register((int) $t['id'], (int) $u['id']);
        $this->assertSame(700, (int) $this->freshUser((int) $u['id'])['money']);

        $res = tournament_withdraw((int) $t['id'], (int) $u['id']);
        $this->assertTrue($res['ok'], $res['error'] ?? '');
        $this->assertSame(1000, (int) $this->freshUser((int) $u['id'])['money']);

        $p = tournament_get_participant((int) $t['id'], (int) $u['id']);
        $this->assertSame('withdrawn', (string) $p['status']);
    }

    public function testStartRequiresMinimumParticipants(): void
    {
        $t = $this->makeTournament(['min_participants' => 4]);
        $this->registerPlayers($t, 2);
        $res = tournament_start((int) $t['id']);
        $this->assertFalse($res['ok']);
        $this->assertStringContainsString('enough', strtolower($res['error']));
    }

    public function testEliminationBracketAndFullPlaythrough(): void
    {
        $t = $this->makeTournament(['type' => 'elimination', 'min_participants' => 4, 'prize_pool_money' => 1000]);
        $this->registerPlayers($t, 4);

        $start = tournament_start((int) $t['id']);
        $this->assertTrue($start['ok'], $start['error'] ?? '');

        $round1 = tournament_matches((int) $t['id'], 1);
        $this->assertCount(2, $round1);
        foreach ($t['payout'] as $tier) {
            $this->assertArrayHasKey('place', $tier);
        }

        $this->playOut((int) $t['id']);

        $done = tournament_get((int) $t['id']);
        $this->assertSame('completed', (string) $done['status']);

        $standings = tournament_standings((int) $t['id']);
        $positions = array_filter(array_map(static fn($r) => (int) $r['final_position'], $standings));
        $this->assertContains(1, $positions);
        $this->assertContains(2, $positions);

        // Champion should have received a prize.
        $paid = (int) fetch_one(
            'SELECT COUNT(*) FROM tournament_rewards_log WHERE tournament_id = ?',
            [(int) $t['id']],
            0
        );
        $this->assertGreaterThan(0, $paid);
    }

    public function testEliminationBracketWithOddCountUsesBye(): void
    {
        $t = $this->makeTournament(['type' => 'elimination', 'min_participants' => 3, 'max_participants' => 8]);
        $this->registerPlayers($t, 3);

        $res = tournament_start((int) $t['id']);
        $this->assertTrue($res['ok'], $res['error'] ?? '');

        $walkovers = (int) fetch_one(
            "SELECT COUNT(*) FROM tournament_matches WHERE tournament_id = ? AND status = 'walkover'",
            [(int) $t['id']],
            0
        );
        $this->assertSame(1, $walkovers);

        $this->playOut((int) $t['id']);
        $this->assertSame('completed', (string) tournament_get((int) $t['id'])['status']);
    }

    public function testRoundRobinGeneratesEveryPairing(): void
    {
        $t = $this->makeTournament(['type' => 'round_robin', 'min_participants' => 4]);
        $this->registerPlayers($t, 4);

        $res = tournament_start((int) $t['id']);
        $this->assertTrue($res['ok'], $res['error'] ?? '');

        $count = (int) fetch_one('SELECT COUNT(*) FROM tournament_matches WHERE tournament_id = ?', [(int) $t['id']], 0);
        $this->assertSame(6, $count); // C(4,2)

        $this->playOut((int) $t['id']);
        $this->assertSame('completed', (string) tournament_get((int) $t['id'])['status']);
    }

    public function testSwissRunsConfiguredRoundsThenCompletes(): void
    {
        $t = $this->makeTournament(['type' => 'swiss', 'min_participants' => 4, 'max_rounds' => 2]);
        $this->registerPlayers($t, 4);

        $res = tournament_start((int) $t['id']);
        $this->assertTrue($res['ok'], $res['error'] ?? '');

        $this->playOut((int) $t['id']);

        $rounds = (int) fetch_one('SELECT COUNT(DISTINCT round_number) FROM tournament_matches WHERE tournament_id = ?', [(int) $t['id']], 0);
        $this->assertSame(2, $rounds);
        $this->assertSame('completed', (string) tournament_get((int) $t['id'])['status']);
    }

    public function testLadderRanksByScoreOnCompletion(): void
    {
        $t = $this->makeTournament([
            'type' => 'ladder',
            'game_type' => 'kill_race',
            'min_participants' => 2,
        ]);
        $users = $this->registerPlayers($t, 3);
        $ids = array_keys($users);

        $res = tournament_start((int) $t['id']);
        $this->assertTrue($res['ok'], $res['error'] ?? '');
        $this->assertSame('in_progress', (string) tournament_get((int) $t['id'])['status']);

        // Submit ascending scores; last player should finish first.
        $scores = [5, 12, 30];
        foreach ($ids as $i => $uid) {
            $s = tournament_submit_score((int) $t['id'], $uid, $scores[$i]);
            $this->assertTrue($s['ok'], $s['error'] ?? '');
        }

        $done = tournament_complete((int) $t['id']);
        $this->assertTrue($done['ok']);

        $standings = tournament_standings((int) $t['id']);
        $this->assertSame('completed', (string) tournament_get((int) $t['id'])['status']);
        $this->assertSame($ids[2], (int) $standings[0]['user_id']);
        $this->assertSame(1, (int) $standings[0]['final_position']);
    }

    public function testRecordResultRejectsDoubleResolution(): void
    {
        $t = $this->makeTournament(['type' => 'elimination', 'min_participants' => 2, 'max_participants' => 2]);
        $this->registerPlayers($t, 2);

        $res = tournament_start((int) $t['id']);
        $this->assertTrue($res['ok'], $res['error'] ?? '');

        $matches = tournament_matches((int) $t['id']);
        $this->assertNotEmpty($matches);
        $m = $matches[0];

        $first = tournament_record_result((int) $m['id'], (int) $m['participant1_id'], 1, 0);
        $this->assertTrue($first['ok'], $first['error'] ?? '');

        $second = tournament_record_result((int) $m['id'], (int) $m['participant2_id'], 1, 0);
        $this->assertFalse($second['ok']);
    }

    public function testSubmitScoreRejectsNonParticipant(): void
    {
        $t = $this->makeTournament(['type' => 'ladder', 'game_type' => 'kill_race', 'min_participants' => 2]);
        $this->registerPlayers($t, 2);
        tournament_start((int) $t['id']);

        $outsider = $this->makeUser(['level' => 10]);
        $res = tournament_submit_score((int) $t['id'], (int) $outsider['id'], 10);
        $this->assertFalse($res['ok']);
    }

    public function testCancelRefundsEntrantsAndIsIdempotent(): void
    {
        $t = $this->makeTournament(['entry_fee_money' => 500, 'entry_fee_points' => 3]);
        $u = $this->makeUser(['level' => 10, 'money' => 2000, 'points' => 20]);

        $this->assertTrue(tournament_register((int) $t['id'], (int) $u['id'])['ok']);
        $this->assertSame(1500, (int) $this->freshUser((int) $u['id'])['money']);
        $this->assertSame(17, (int) $this->freshUser((int) $u['id'])['points']);

        $res = tournament_cancel((int) $t['id'], 'test');
        $this->assertTrue($res['ok']);
        $this->assertSame(1, (int) $res['refunded']);
        $this->assertSame('cancelled', (string) tournament_get((int) $t['id'])['status']);

        $fresh = $this->freshUser((int) $u['id']);
        $this->assertSame(2000, (int) $fresh['money']);
        $this->assertSame(20, (int) $fresh['points']);

        // Cancelling twice must not refund twice.
        $again = tournament_cancel((int) $t['id'], 'test');
        $this->assertTrue($again['ok']);
        $this->assertSame(2000, (int) $this->freshUser((int) $u['id'])['money']);
        $this->assertSame(20, (int) $this->freshUser((int) $u['id'])['points']);
    }

    public function testAutoCreateSeedsEveryGameTypeAndIsIdempotent(): void
    {
        $createdIds = [];
        try {
            tournament_auto_create();

            // Every blueprint game type should now have at least one live event.
            foreach (tournament_blueprints() as $bp) {
                $live = fetch_one(
                    "SELECT id FROM tournaments
                     WHERE game_type = ? AND status IN ('draft','registration','in_progress') LIMIT 1",
                    [$bp['game_type']]
                );
                $this->assertNotEmpty($live, 'no live event for ' . $bp['game_type']);
            }

            // Collect the auto-created rows so the test can clean up after itself.
            foreach (tournament_get_all(null, null, 500) as $row) {
                if (preg_match(
                    '/^(weekly_slugfest|midnight_grand_prix|lucky_seven_cup|swiss_kill_race|heist_masters|speedrun_open)_/',
                    (string) $row['code']
                )) {
                    $createdIds[] = (int) $row['id'];
                }
            }

            // Idempotent: nothing new to create once every type is live.
            $this->assertSame(0, tournament_auto_create());
        } finally {
            if ($createdIds) {
                $in = implode(',', array_fill(0, count($createdIds), '?'));
                q("DELETE FROM tournaments WHERE id IN ($in)", $createdIds);
            }
        }
    }

    public function testAutoResolveWaitsForGracePeriodThenSettlesTournament(): void
    {
        $t = $this->makeTournament([
            'type' => 'elimination',
            'min_participants' => 4,
            'prize_pool_money' => 5000,
        ]);
        $this->registerPlayers($t, 4);
        $this->assertTrue(tournament_start((int) $t['id'])['ok']);

        // Freshly created matches must not be resolved within the grace period.
        tournament_auto_resolve_matches();
        $stillPending = (int) fetch_one(
            "SELECT COUNT(*) FROM tournament_matches WHERE tournament_id = ? AND status = 'pending'",
            [(int) $t['id']],
            0
        );
        $this->assertSame(2, $stillPending, 'round 1 should still be pending during the grace period');

        // Age each pending round past the grace period until the event settles.
        $guard = 0;
        while ($guard++ < 10 && (string) tournament_get((int) $t['id'])['status'] === 'in_progress') {
            q("UPDATE tournament_matches SET created_at = DATE_SUB(NOW(), INTERVAL 30 MINUTE)
               WHERE tournament_id = ? AND status = 'pending'", [(int) $t['id']]);
            tournament_auto_resolve_matches();
        }

        $this->assertSame('completed', (string) tournament_get((int) $t['id'])['status']);
        $this->assertGreaterThan(0, (int) fetch_one(
            'SELECT COUNT(*) FROM tournament_rewards_log WHERE tournament_id = ?',
            [(int) $t['id']],
            0
        ));
    }

    public function testReportMetricFeedsRunningTournamentByGameType(): void
    {
        $t = $this->makeTournament(['type' => 'ladder', 'game_type' => 'kill_race', 'min_participants' => 2]);
        $users = $this->registerPlayers($t, 2);
        $this->assertTrue(tournament_start((int) $t['id'])['ok']);
        $ids = array_keys($users);

        tournament_report_metric('kill_race', (int) $ids[0], 3);
        $p = tournament_get_participant((int) $t['id'], (int) $ids[0]);
        $this->assertSame(3, (int) $p['total_score']);
        $this->assertSame(3, (int) $p['kills']);

        // Someone who is not competing is ignored.
        $outsider = $this->makeUser(['level' => 10]);
        tournament_report_metric('kill_race', (int) $outsider['id'], 5);
        $this->assertNull(tournament_get_participant((int) $t['id'], (int) $outsider['id']));

        // A game type with no running event is a harmless no-op.
        tournament_report_metric('racing', (int) $users[array_key_first($users)]['id'], 1);
        $this->assertSame(3, (int) tournament_get_participant((int) $t['id'], array_key_first($users))['total_score']);
    }

    public function testReportMetricRecordsSpeedrunTime(): void
    {
        $t = $this->makeTournament(['type' => 'ladder', 'game_type' => 'mission_speedrun', 'min_participants' => 2]);
        $users = $this->registerPlayers($t, 2);
        tournament_start((int) $t['id']);
        $uid = (int) array_key_first($users);

        tournament_report_metric('mission_speedrun', $uid, 1, 45000);

        $p = tournament_get_participant((int) $t['id'], $uid);
        $this->assertSame(45000, (int) $p['best_time_ms']);
        $this->assertSame(1, (int) $p['total_score']);
    }
}
