# Mafia Empire — REST API (v1)

The game exposes a small, read-mostly JSON API plus outbound webhooks and a
Discord integration. Everything is plain PHP; no extra runtime dependencies.

## Base URL & routing

The API lives in `api/index.php` and can be reached three ways:

| Form | Example |
| --- | --- |
| Query route (works everywhere) | `/api/index.php?route=v1/me` |
| PATH_INFO | `/api/index.php/v1/me` |
| Pretty URL (Apache + bundled `.htaccess`) | `/api/v1/me` |

`GET /api/` returns a discovery document listing every endpoint.

> With the query-route form the route is itself a query parameter, so append
> further parameters with `&`, e.g.
> `/api/index.php?route=v1/leaderboards&board=kills`. The PATH_INFO and pretty
> forms use ordinary `?` query strings.

## Authentication

Every request **except** the public endpoints below needs an API key. Create one
on **Info & Help → API Access** (`api_access.php`). The plaintext key is shown
once; only a SHA-256 hash is stored.

Send it either as a header:

```
X-API-Key: me_1a2b3c4d.<48 hex chars>
```

or as a bearer token:

```
Authorization: Bearer me_1a2b3c4d.<48 hex chars>
```

### Scopes

| Scope | Grants |
| --- | --- |
| `read` | Your own profile and notifications |
| `write` | Trigger actions (implies `read`) |
| `admin` | Server statistics |

### Rate limiting

Each key has its own per-minute limit (60 by default, up to 600). Responses
include `X-RateLimit-Limit`, `X-RateLimit-Remaining` and `X-RateLimit-Reset`.
Exceeding the limit returns **429** with a `Retry-After` header.

## Response envelope

Success:

```json
{ "ok": true, "data": { }, "meta": { } }
```

Failure:

```json
{ "ok": false, "error": { "status": 403, "code": "insufficient_scope", "message": "…" } }
```

## Endpoints

### `GET v1/health` — public

```json
{ "ok": true, "data": { "status": "ok", "game_version": "1.0.0", "schema_version": 3, "time": "…" } }
```

### `GET v1/leaderboards` — public

Query: `board` = `level` (default) · `kills` · `cash` · `xp`; `limit` = 1–100 (default 25).

### `GET v1/market` — public

Open black-market listings, cheapest first. Query: `limit` = 1–100 (default 50).

### `GET v1/players/{id}` — public

A limited public profile (no cash/bank).

### `GET v1/me` — scope `read`

The caller's full profile: stats, vitals, resources, crew, hospital status.

### `GET v1/me/notifications` — scope `read`

Recent notifications plus an `unread` count in `meta`.

### `POST v1/webhooks/test` — scope `write`

Send a synchronous test delivery to your active webhooks (or one `id` given in
the JSON body). Returns each hook's HTTP status.

### `GET v1/admin/stats` — scope `admin`

Player/crew/kill/cash totals plus API usage counters.

## Webhooks

Register endpoints under **API Access**. We `POST` a JSON body for each
subscribed event:

| Event | Fires when |
| --- | --- |
| `kill` | you kill another player |
| `levelup` | you gain a level |
| `achievement` | you unlock an achievement |
| `purchase` | you buy something in the Points Store |

Headers on every delivery:

```
X-Mafia-Event: kill
X-Mafia-Signature: sha256=<hmac-sha256 of the raw request body, keyed by your secret>
```

Verify the signature against the **raw** body before trusting the payload.
Deliveries are queued and flushed by cron; failures retry with backoff
(1, 5, 25, 125 minutes) up to 5 attempts, then are marked failed.

```bash
php cron/run.php webhooks   # flush the delivery queue (run every minute)
```

## Discord bot

Two independent integrations, both optional:

1. **Notifications** — set `DISCORD_WEBHOOK_URL` to a channel webhook and the
   daily digest (`php cron/run.php discord`) posts activity summaries.

2. **Slash commands** — point a Discord application's *Interactions Endpoint
   URL* at `discord/interactions.php` and set `DISCORD_PUBLIC_KEY` (+
   `DISCORD_ADMIN_IDS` for the admin command). Supported commands:

    | Command | Notes |
    | --- | --- |
    | `/stats username:<player>` | Profile snapshot |
    | `/leaderboard board:<level|kills|cash>` | Top players |
    | `/serverstat` | Admin only (`DISCORD_ADMIN_IDS`) |

    Discord signs every interaction with Ed25519; the endpoint verifies the
    signature using the PHP **sodium** extension and, if it (or the public key)
    is missing, refuses the request rather than trusting it.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `DISCORD_PUBLIC_KEY` | Ed25519 public key for interaction verification |
| `DISCORD_APP_ID` | Discord application id |
| `DISCORD_WEBHOOK_URL` | Channel webhook for outbound notifications |
| `DISCORD_ADMIN_IDS` | Comma-separated Discord user ids allowed `/serverstat` |

## Maintenance

- `api_requests` logs every call (pruned after 30 days by the weekly task).
- Revoking a key takes effect immediately.
- CORS is permissive (`Access-Control-Allow-Origin: *`); keys travel in headers,
  never cookies, so this does not enable CSRF.

---

## Web Push (VAPID)

The server supports Web Push notifications per RFC 8291/8292. Keys are generated with `php cron/run.php vapid` and stored in `config/vapid.php` (or via env `VAPID_PUBLIC_KEY` / `VAPID_PRIVATE_KEY` / `VAPID_SUBJECT`).

### `GET /push.php?action=vapid` — scope `read` (or no auth if only checking availability)

Returns the application server public key and whether push is configured:

```json
{ "ok": true, "enabled": true, "publicKey": "BASE64URL_PUBLIC_KEY" }
```

If push is not configured, `enabled: false` and `publicKey` is empty.

### `POST /push.php?action=subscribe` — scope `write`

Register a browser PushSubscription:

```json
{ "ok": true, "count": 1 }
```

Body: `action=subscribe&csrf=...&subscription={endpoint,keys:{p256dh,auth}}`

### `POST /push.php?action=unsubscribe` — scope `write`

Remove a subscription:

```json
{ "ok": true, "count": 0 }
```

Body: `action=unsubscribe&csrf=...&subscription={endpoint,keys:{p256dh,auth}}` or `action=unsubscribe&csrf=...&endpoint=...`

### `POST /push.php?action=status` — scope `read`

```json
{ "ok": true, "enabled": true, "count": 3 }
```

---

## Events System

Daily, weekly, and seasonal events with challenge tracking and rewards.

### `GET /events.php` — UI page

Server-rendered dashboard showing active events, challenges, progress, and claim buttons.

### Event Types

| Type | Frequency | Example |
|------|-----------|---------|
| `daily` | Every 24h | Complete 1 mission, win a fight |
| `weekly` | Every 7 days | Win 3 fights, complete 5 missions |
| `seasonal` | Seasonal dates | Halloween, Christmas, New Year, etc. |

### Challenge Metrics

| Metric | Description |
|--------|-------------|
| `missions_done` | Missions completed |
| `crimes_done` | Criminal jobs completed |
| `kills` | Players killed |
| `boss_kills` | Bosses defeated |
| `casino_won` | Casino winnings (cash) |

### `GET /events.php` (UI)

Server-rendered dashboard with challenge progress, rewards, and claim buttons.

### `POST /events.php?action=claim` — scope `write`

Claim completed challenge rewards:

```json
{ "ok": true, "rewards": { "xp": 500, "money": 5000, "points": 10 } }
```

Body: `action=claim&csrf=...&challenge_id=123`