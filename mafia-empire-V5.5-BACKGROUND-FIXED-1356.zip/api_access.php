<?php
/**
 * Mafia Empire - API Access: manage REST API keys and outbound webhooks.
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/api.php';
$u = require_login();

$scopesAvailable = ['read' => 'Read (view your data)', 'write' => 'Write (trigger actions)', 'admin' => 'Admin (server stats)'];
$rateOptions = [60, 120, 300, 600];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'create_key') {
        $name   = trim((string) ($_POST['name'] ?? ''));
        $scopes = array_keys(array_intersect_key($scopesAvailable, array_flip((array) ($_POST['scopes'] ?? []))));
        $rate   = (int) ($_POST['rate_limit'] ?? API_DEFAULT_RATE_LIMIT);
        if ($scopes === []) {
            $scopes = ['read'];
        }
        $created = api_key_create((int) $u['id'], $name, $scopes, $rate);
        $_SESSION['new_api_key'] = $created['plain'];
        flash('API key "' . e($created['prefix']) . '…" created.', 'success');
        redirect('api_access.php');
    }

    if ($action === 'revoke_key') {
        $id = (int) ($_POST['id'] ?? 0);
        $row = fetch('SELECT * FROM api_keys WHERE id = ? AND user_id = ?', [$id, (int) $u['id']]);
        if ($row && $row['revoked_at'] === null) {
            update_row('api_keys', ['revoked_at' => now()], 'id = ?', [$id]);
            q('DELETE FROM api_rate WHERE key_id = ?', [$id]);
            flash('API key revoked.', 'success');
        } else {
            flash('Key not found or already revoked.', 'error');
        }
        redirect('api_access.php');
    }

    if ($action === 'create_webhook') {
        $url = trim((string) ($_POST['url'] ?? ''));
        if (!preg_match('#^https?://#i', $url)) {
            flash('Webhook URL must start with http:// or https://.', 'error');
            redirect('api_access.php');
        }
        $events = (array) ($_POST['events'] ?? []);
        if (in_array('*', $events, true) || $events === []) {
            $eventsCsv = '*';
        } else {
            $eventsCsv = implode(',', webhook_valid_events(implode(',', $events))) ?: '*';
        }
        insert('webhooks', [
            'user_id'    => (int) $u['id'],
            'url'        => mb_substr($url, 0, 500),
            'secret'     => bin2hex(random_bytes(16)),
            'events'     => $eventsCsv,
            'active'     => 1,
            'created_at' => now(),
        ]);
        flash('Webhook added. Sign each request with your secret (see below).', 'success');
        redirect('api_access.php');
    }

    if ($action === 'toggle_webhook') {
        $id = (int) ($_POST['id'] ?? 0);
        $row = fetch('SELECT * FROM webhooks WHERE id = ? AND user_id = ?', [$id, (int) $u['id']]);
        if ($row) {
            update_row('webhooks', ['active' => (int) $row['active'] === 1 ? 0 : 1], 'id = ?', [$id]);
            flash('Webhook ' . ((int) $row['active'] === 1 ? 'disabled' : 'enabled') . '.', 'success');
        }
        redirect('api_access.php');
    }

    if ($action === 'delete_webhook') {
        $id = (int) ($_POST['id'] ?? 0);
        $row = fetch('SELECT * FROM webhooks WHERE id = ? AND user_id = ?', [$id, (int) $u['id']]);
        if ($row) {
            q('DELETE FROM webhook_deliveries WHERE webhook_id = ?', [$id]);
            q('DELETE FROM webhooks WHERE id = ?', [$id]);
            flash('Webhook deleted.', 'success');
        }
        redirect('api_access.php');
    }

    if ($action === 'test_webhook') {
        $id = (int) ($_POST['id'] ?? 0);
        $row = fetch('SELECT * FROM webhooks WHERE id = ? AND user_id = ?', [$id, (int) $u['id']]);
        if ($row) {
            [$ok, $code, $err] = webhook_send_test($row);
            update_row('webhooks', ['last_status' => $code, 'last_called_at' => now()], 'id = ?', [$id]);
            flash($ok ? 'Test delivered (HTTP ' . $code . ').' : 'Test failed: ' . ($err ?: 'HTTP ' . $code), $ok ? 'success' : 'error');
        } else {
            flash('Webhook not found.', 'error');
        }
        redirect('api_access.php');
    }

    redirect('api_access.php');
}

$newKey = $_SESSION['new_api_key'] ?? null;
unset($_SESSION['new_api_key']);

$keys = fetch_all('SELECT * FROM api_keys WHERE user_id = ? ORDER BY id DESC', [(int) $u['id']]);
$hooks = fetch_all('SELECT * FROM webhooks WHERE user_id = ? ORDER BY id DESC', [(int) $u['id']]);
$events = webhook_events();
$endpoint = url('api/index.php');

$page_title = 'API Access';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <div class="panel-heading">API Access</div>
  <p class="muted">Build integrations on top of <?= e(SITE_NAME) ?>. Authenticate with a key in the
    <code>X-API-Key</code> header (or <code>Authorization: Bearer &lt;key&gt;</code>). The full endpoint list lives in
    <code>docs/API.md</code>.</p>
  <div class="stat"><span>Base endpoint</span><b><code><?= e($endpoint) ?></code></b></div>
  <div class="stat"><span>Directory</span><b><code><?= e($endpoint) ?>?route=v1</code></b></div>
</div>

<?php if ($newKey): ?>
<div class="card" style="border-color:#d9a441">
  <div class="panel-heading">&#128273; Your new API key</div>
  <p>Copy it now — it is shown <b>only once</b> and stored hashed.</p>
  <p><input id="newKey" class="input" style="width:100%" readonly value="<?= e($newKey) ?>" onclick="this.select()"></p>
  <button class="btn btn-gold btn-sm" type="button" onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById('newKey').value)">Copy to clipboard</button>
</div>
<?php endif; ?>

<div class="card">
  <div class="panel-heading">Create a key</div>
  <form method="post" class="form">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create_key">
    <label>Label
      <input class="input" type="text" name="name" maxlength="60" placeholder="My dashboard" value="API key">
    </label>
    <fieldset style="border:0;padding:6px 0">
      <legend class="muted">Scopes</legend>
      <?php foreach ($scopesAvailable as $code => $label): ?>
        <label style="display:inline-block;margin-right:14px">
          <input type="checkbox" name="scopes[]" value="<?= e($code) ?>" <?= $code === 'read' ? 'checked' : '' ?>> <?= e($label) ?>
        </label>
      <?php endforeach; ?>
    </fieldset>
    <label>Rate limit (requests / minute)
      <select class="input" name="rate_limit">
        <?php foreach ($rateOptions as $r): ?>
          <option value="<?= (int) $r ?>" <?= $r === API_DEFAULT_RATE_LIMIT ? 'selected' : '' ?>><?= (int) $r ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <button class="btn btn-gold" type="submit">Generate key</button>
  </form>
</div>

<div class="card">
  <div class="panel-heading">Your keys</div>
  <?php if (!$keys): ?>
    <p class="muted">No API keys yet.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Label</th><th>Prefix</th><th>Scopes</th><th>Limit</th><th>Requests</th><th>Last used</th><th>Status</th><th></th></tr>
      <?php foreach ($keys as $k): ?>
        <tr>
          <td><?= e($k['name']) ?></td>
          <td><code><?= e($k['prefix']) ?>…</code></td>
          <td><?= e($k['scopes']) ?></td>
          <td><?= (int) $k['rate_limit'] ?>/min</td>
          <td><?= number_format((int) $k['request_count']) ?></td>
          <td><?= $k['last_used_at'] ? e($k['last_used_at']) : '<span class="muted">never</span>' ?></td>
          <td><?= $k['revoked_at'] ? '<span class="tag tag-fail">Revoked</span>' : '<span class="tag tag-legendary">Active</span>' ?></td>
          <td>
            <?php if (!$k['revoked_at']): ?>
            <form method="post" onsubmit="return confirm('Revoke this key? Integrations using it will stop working.')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="revoke_key">
              <input type="hidden" name="id" value="<?= (int) $k['id'] ?>">
              <button class="btn btn-sm btn-danger" type="submit">Revoke</button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="panel-heading">Add a webhook</div>
  <p class="muted">We POST a JSON body for each subscribed event to your URL, signed with
    <code>X-Mafia-Signature: sha256=&lt;hmac&gt;</code> (HMAC-SHA256 of the raw body using your secret).
    Deliveries retry with backoff and are sent by cron (<code>php cron/run.php webhooks</code>).</p>
  <form method="post" class="form">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create_webhook">
    <label>Endpoint URL
      <input class="input" type="url" name="url" placeholder="https://example.com/mafia-hook" required>
    </label>
    <fieldset style="border:0;padding:6px 0">
      <legend class="muted">Events (leave all unchecked for everything)</legend>
      <label style="display:block"><input type="checkbox" name="events[]" value="*"> All events (*)</label>
      <?php foreach ($events as $code => $desc): ?>
        <label style="display:block"><input type="checkbox" name="events[]" value="<?= e($code) ?>"> <code><?= e($code) ?></code> — <?= e($desc) ?></label>
      <?php endforeach; ?>
    </fieldset>
    <button class="btn btn-gold" type="submit">Add webhook</button>
  </form>
</div>

<div class="card">
  <div class="panel-heading">Your webhooks</div>
  <?php if (!$hooks): ?>
    <p class="muted">No webhooks yet.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>URL</th><th>Events</th><th>Active</th><th>Last status</th><th>Secret</th><th>Actions</th></tr>
      <?php foreach ($hooks as $h): ?>
        <tr>
          <td><code><?= e($h['url']) ?></code></td>
          <td><?= $h['events'] === '*' ? '<span class="tag tag-legendary">all</span>' : e($h['events']) ?></td>
          <td><?= (int) $h['active'] === 1 ? '<span class="tag tag-legendary">on</span>' : '<span class="tag tag-fail">off</span>' ?></td>
          <td><?= $h['last_status'] !== null ? 'HTTP ' . (int) $h['last_status'] . ($h['failures'] ? ' (' . (int) $h['failures'] . ' fails)' : '') : '<span class="muted">—</span>' ?></td>
          <td><code title="HMAC signing secret"><?= e($h['secret']) ?></code></td>
          <td style="white-space:nowrap">
            <form method="post" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="test_webhook">
              <input type="hidden" name="id" value="<?= (int) $h['id'] ?>">
              <button class="btn btn-sm" type="submit">Test</button>
            </form>
            <form method="post" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle_webhook">
              <input type="hidden" name="id" value="<?= (int) $h['id'] ?>">
              <button class="btn btn-sm" type="submit"><?= (int) $h['active'] === 1 ? 'Disable' : 'Enable' ?></button>
            </form>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete this webhook and its history?')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete_webhook">
              <input type="hidden" name="id" value="<?= (int) $h['id'] ?>">
              <button class="btn btn-sm btn-danger" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
