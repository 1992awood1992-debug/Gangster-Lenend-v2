-- Migration 12: Heist missions (crew co-op content)
-- Idempotent: CREATE TABLE IF NOT EXISTS, safe to re-run.

CREATE TABLE IF NOT EXISTS heists (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    min_crew_level INT UNSIGNED NOT NULL DEFAULT 1,
    min_members INT UNSIGNED NOT NULL DEFAULT 2,
    max_members INT UNSIGNED NOT NULL DEFAULT 6,
    -- Phases (JSON: [{"name":"Recon","description":"...","requirements":{"items":[...],"stats":{"strength":50}},"xp":100,"money":5000}])
    phases JSON NOT NULL,
    -- Rewards (split among participants)
    reward_money BIGINT NOT NULL DEFAULT 0,
    reward_xp BIGINT NOT NULL DEFAULT 0,
    reward_points INT UNSIGNED NOT NULL DEFAULT 0,
    reward_items JSON, -- [{"item_id":1,"qty":1,"chance":0.5}]
    -- Cooldown
    cooldown_hours INT UNSIGNED NOT NULL DEFAULT 24,
    -- Requirements
    required_items JSON, -- [{"item_id":1,"qty":1}]
    required_stats JSON, -- {"strength":50,"speed":30}
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_active (is_active),
    KEY idx_crew_level (min_crew_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS heist_instances (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    heist_id INT UNSIGNED NOT NULL,
    crew_id INT UNSIGNED NOT NULL,
    leader_id INT UNSIGNED NOT NULL,
    status ENUM('planning','active','completed','failed','abandoned') NOT NULL DEFAULT 'planning',
    current_phase INT UNSIGNED NOT NULL DEFAULT 0,
    phase_started_at DATETIME NULL,
    -- Participants (JSON: [{"user_id":1,"role":"leader","joined_at":"...","ready":false}])
    participants JSON NOT NULL,
    -- Phase progress (JSON: {"0":{"completed":true,"completed_by":1,"completed_at":"..."}})
    phase_progress JSON,
    -- Rewards earned
    total_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    total_xp BIGINT UNSIGNED NOT NULL DEFAULT 0,
    total_points INT UNSIGNED NOT NULL DEFAULT 0,
    items_awarded JSON,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_crew_status (crew_id, status),
    KEY idx_leader (leader_id),
    KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS heist_participants (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    instance_id BIGINT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    role ENUM('leader','member') NOT NULL DEFAULT 'member',
    joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ready TINYINT(1) NOT NULL DEFAULT 0,
    -- Rewards received
    money_received BIGINT UNSIGNED NOT NULL DEFAULT 0,
    xp_received BIGINT UNSIGNED NOT NULL DEFAULT 0,
    points_received INT UNSIGNED NOT NULL DEFAULT 0,
    items_received JSON,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_instance_user (instance_id, user_id),
    KEY idx_instance (instance_id),
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default heists
INSERT INTO heists (code, name, description, min_crew_level, min_members, max_members, phases, reward_money, reward_xp, reward_points, reward_items, cooldown_hours, required_items, required_stats, is_active, sort_order) VALUES
('bank_job', 'First National Bank Heist', 'The classic score. Vault, guards, getaway driver needed.', 5, 3, 5,
'[{"name": "Recon", "description": "Case the joint. Identify guard rotations and vault location.", "requirements": {"items": [{"item_id": 2, "qty": 1}], "stats": {"iq": 30}}, "xp": 500, "money": 10000}, {"name": "The Grab", "description": "Hit the vault. Speed and strength decide the haul.", "requirements": {"items": [{"item_id": 3, "qty": 2}], "stats": {"strength": 50, "speed": 40}}, "xp": 2000, "money": 50000}, {"name": "The Getaway", "description": "Escape clean. Driver skill and crew coordination critical.", "requirements": {"items": [{"item_id": 11, "qty": 1}], "stats": {"speed": 60, "defense": 30}}, "xp": 1500, "money": 20000}]',
500000, 5000, 200,
'[{"item_id": 6, "qty": 1, "chance": 0.1}, {"item_id": 9, "qty": 1, "chance": 0.05}]',
24, '[{"item_id": 1, "qty": 1}]', '{"strength": 30, "speed": 25, "iq": 20}', 1, 1),

('art_heist', 'Museum Art Heist', 'Steal priceless artifacts. Stealth over force.', 10, 2, 4,
'[{"name": "Infiltration", "description": "Bypass security systems. High IQ and stealth gear required.", "requirements": {"items": [{"item_id": 2, "qty": 2}], "stats": {"iq": 50, "speed": 40}}, "xp": 1000, "money": 20000}, {"name": "Extraction", "description": "Remove the art without triggering sensors.", "requirements": {"items": [{"item_id": 2, "qty": 1}], "stats": {"iq": 60, "defense": 20}}, "xp": 3000, "money": 100000}, {"name": "Fence", "description": "Move the goods through underground channels.", "requirements": {"items": [], "stats": {"iq": 40}}, "xp": 500, "money": 50000}]',
1000000, 8000, 500,
'[{"item_id": 10, "qty": 1, "chance": 0.15}, {"item_id": 6, "qty": 1, "chance": 0.1}]',
48, '[{"item_id": 2, "qty": 2}]', '{"iq": 40, "speed": 35}', 1, 2),

('armored_car', 'Armored Car Ambush', 'Hit a moving target. Heavy firepower needed.', 8, 3, 6,
'[{"name": "Surveillance", "description": "Track the route and timing.", "requirements": {"items": [{"item_id": 1, "qty": 1}], "stats": {"iq": 25}}, "xp": 300, "money": 5000}, {"name": "The Stop", "description": "Force the vehicle to halt. Firepower and armor critical.", "requirements": {"items": [{"item_id": 4, "qty": 2}, {"item_id": 8, "qty": 1}], "stats": {"strength": 60, "defense": 50}}, "xp": 3000, "money": 200000}, {"name": "The Haul", "description": "Load up and vanish before backup arrives.", "requirements": {"items": [{"item_id": 12, "qty": 1}], "stats": {"speed": 50}}, "xp": 1000, "money": 50000}]',
300000, 6000, 300,
'[{"item_id": 5, "qty": 1, "chance": 0.2}, {"item_id": 4, "qty": 1, "chance": 0.1}]',
36, '[{"item_id": 4, "qty": 1}, {"item_id": 8, "qty": 1}]', '{"strength": 40, "defense": 35}', 1, 3),

('casino_vault', 'Casino Vault Raid', 'Ocean\'s Eleven style. High risk, legendary reward.', 20, 4, 6,
'[{"name": "Inside Man", "description": "Plant a crew member on staff.", "requirements": {"items": [], "stats": {"iq": 80, "speed": 30}}, "xp": 2000, "money": 50000}, {"name": "Systems Override", "description": "Hack the vault timer and cameras.", "requirements": {"items": [{"item_id": 3, "qty": 1}], "stats": {"iq": 90}}, "xp": 5000, "money": 250000}, {"name": "The Score", "description": "Empty the high-roller vault.", "requirements": {"items": [], "stats": {"strength": 70, "speed": 60}}, "xp": 8000, "money": 1000000}, {"name": "Vanish", "description": "Disappear into the night with millions.", "requirements": {"items": [{"item_id": 13, "qty": 1}], "stats": {"speed": 80, "defense": 40}}, "xp": 5000, "money": 500000}]',
5000000, 25000, 2000,
'[{"item_id": 6, "qty": 1, "chance": 0.3}, {"item_id": 10, "qty": 1, "chance": 0.2}, {"item_id": 5, "qty": 1, "chance": 0.1}]',
168, '[{"item_id": 3, "qty": 1}, {"item_id": 9, "qty": 1}]', '{"iq": 70, "strength": 50, "speed": 50}', 1, 4),

('drug_lab_raid', 'Cartel Lab Seizure', 'Take over a production facility. Territory control.', 15, 3, 6,
'[{"name": "Intel", "description": "Locate the hidden lab.", "requirements": {"items": [], "stats": {"iq": 40}}, "xp": 500, "money": 10000}, {"name": "Assault", "description": "Breach and clear. Heavy resistance expected.", "requirements": {"items": [{"item_id": 5, "qty": 2}, {"item_id": 9, "qty": 2}], "stats": {"strength": 80, "defense": 60}}, "xp": 4000, "money": 300000}, {"name": "Secure", "description": "Hold the location until extraction.", "requirements": {"items": [{"item_id": 12, "qty": 1}], "stats": {"defense": 50, "speed": 40}}, "xp": 2000, "money": 100000}, {"name": "Transport", "description": "Move product to safehouse.", "requirements": {"items": [{"item_id": 13, "qty": 1}], "stats": {"speed": 60}}, "xp": 1500, "money": 50000}]',
500000, 10000, 500,
'[{"item_id": 7, "qty": 3, "chance": 0.5}, {"item_id": 8, "qty": 1, "chance": 0.2}, {"item_id": 4, "qty": 1, "chance": 0.1}]',
72, '[{"item_id": 5, "qty": 1}]', '{"strength": 50, "defense": 40, "iq": 30}', 1, 5)

ON DUPLICATE KEY UPDATE
    name=VALUES(name), description=VALUES(description), min_crew_level=VALUES(min_crew_level),
    min_members=VALUES(min_members), max_members=VALUES(max_members), phases=VALUES(phases),
    reward_money=VALUES(reward_money), reward_xp=VALUES(reward_xp), reward_points=VALUES(reward_points),
    reward_items=VALUES(reward_items), cooldown_hours=VALUES(cooldown_hours),
    required_items=VALUES(required_items), required_stats=VALUES(required_stats),
    is_active=VALUES(is_active), sort_order=VALUES(sort_order);