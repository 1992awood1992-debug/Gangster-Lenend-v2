<?php
/**
 * Eye Of The Mafia - Tournaments
 * Scheduled competitive events: elimination, round robin, swiss, ladder.
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/tournaments.php';

$u = require_login();

tournament_sweep();

// POST handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    $tid = (int) ($_POST['tournament_id'] ?? 0);

    if ($action === 'register') {
        $result = tournament_register($tid, (int) $u['id']);
        if (!empty($result['ok'])) {
            flash('You are registered. Good luck!', 'success');
        } else {
            flash($result['error'] ?? 'Could not register.', 'error');
        }
        redirect('tournaments.php?view=' . $tid);
    } elseif ($action === 'withdraw') {
        $result = tournament_withdraw($tid, (int) $u['id']);
        if (!empty($result['ok'])) {
            flash('You have withdrawn from the tournament.', 'info');
        } else {
            flash($result['error'] ?? 'Could not withdraw.', 'error');
        }
        redirect('tournaments.php?view=' . $tid);
    }

    redirect('tournaments.php');
}

$viewId = (int) ($_GET['view'] ?? 0);
$page_title = $viewId > 0 ? 'Tournament' : 'Tournaments';

require __DIR__ . '/includes/header.php';

$statusTag = static function (string $s): string {
    $map = [
        'registration' => 'gold',
        'in_progress'  => 'legendary',
        'completed'    => 'rare',
        'cancelled'    => 'common',
        'draft'        => 'common',
    ];
    return $map[$s] ?? 'common';
};

?>
<div class="card">
  <div class="panel-heading">Tournaments <span class="muted small">(Scheduled Competition)</span></div>
  <p class="muted small">Enter scheduled tournaments to test your mettle against the city's best. Formats include single elimination, round robin, swiss and open ladders. Pay an entry fee, climb the bracket and claim the prize pool.</p>
</div>

<?php if ($viewId > 0):
    $t = tournament_get($viewId);
    if (!$t): ?>
      <div class="card" style="margin-top:16px"><p class="muted">That tournament could not be found.</p>
        <a class="btn btn-sm" href="<?= e(url('tournaments.php')) ?>">Back to all tournaments</a></div>
    <?php else:
        $participants = tournament_standings((int) $t['id']);
        $mine = tournament_get_participant((int) $t['id'], (int) $u['id']);
        $count = tournament_participant_count((int) $t['id']);
        $canReg = tournament_can_register($t, $u);
        $matchesByRound = tournament_matches_by_round((int) $t['id']);
        ?>
  <p style="margin-top:12px"><a class="btn btn-sm" href="<?= e(url('tournaments.php')) ?>">&larr; All tournaments</a></p>

  <div class="card" style="margin-top:8px; border-left:4px solid var(--gold);">
    <div class="panel-heading">
      <span><?= e($t['name']) ?></span>
      <span class="tag tag-<?= $statusTag((string) $t['status']) ?>"><?= e(tournament_status_label((string) $t['status'])) ?></span>
    </div>
    <p class="muted"><?= e($t['description']) ?></p>

    <div class="grid grid-3" style="margin:12px 0">
      <div class="stat"><span>Format</span><b><?= e(tournament_type_label((string) $t['type'])) ?></b></div>
      <div class="stat"><span>Game</span><b><?= e(tournament_game_label((string) $t['game_type'])) ?></b></div>
      <div class="stat"><span>Entrants</span><b><?= $count ?> / <?= (int) $t['max_participants'] ?></b></div>
      <div class="stat"><span>Level</span><b><?= (int) $t['min_level'] ?><?= !empty($t['max_level']) ? '-' . (int) $t['max_level'] : '+' ?></b></div>
      <div class="stat"><span>Entry</span><b><?= (int) $t['entry_fee_money'] > 0 ? money((int) $t['entry_fee_money']) : 'Free' ?><?= (int) $t['entry_fee_points'] > 0 ? ' + ' . number_format((int) $t['entry_fee_points']) . ' pts' : '' ?></b></div>
      <div class="stat"><span>Starts</span><b><?= $t['starts_at'] ? date('M j, g:ia', strtotime($t['starts_at'])) : 'TBD' ?></b></div>
    </div>

    <div class="muted small" style="margin-bottom:8px">
      <b>Prize Pool:</b> <?= money((int) $t['prize_pool_money']) ?> | <?= number_format((int) $t['prize_pool_points']) ?> Pts | <?= number_format((int) $t['prize_pool_xp']) ?> XP
    </div>
    <?php if (!empty($t['payout'])): ?>
    <div class="muted small" style="margin-bottom:8px">
      <b>Payouts:</b>
      <?php foreach ($t['payout'] as $tier): ?>
        <span class="tag tag-common">#<?= (int) $tier['place'] ?> &mdash; <?= (float) $tier['pct'] ?>%</span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if ($mine && in_array((string) $mine['status'], ['registered', 'confirmed'], true)): ?>
      <div class="stat" style="margin:8px 0">
        <span>Your status</span>
        <b><?= e(ucfirst((string) $mine['status'])) ?><?= $mine['seed'] ? ' &middot; seed #' . (int) $mine['seed'] : '' ?></b>
      </div>
      <?php if (in_array((string) $t['status'], ['draft', 'registration'], true)): ?>
        <form method="post" style="margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="withdraw">
          <input type="hidden" name="tournament_id" value="<?= (int) $t['id'] ?>">
          <button class="btn btn-sm" type="submit">Withdraw (refund entry)</button>
        </form>
      <?php endif; ?>
    <?php elseif ((string) $t['status'] === 'registration'): ?>
      <?php if (!empty($canReg['ok'])): ?>
        <form method="post" style="margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="register">
          <input type="hidden" name="tournament_id" value="<?= (int) $t['id'] ?>">
          <button class="btn btn-gold btn-block" type="submit">Register Now</button>
        </form>
      <?php else: ?>
        <div class="muted small" style="margin-top:8px">Cannot register: <?= e($canReg['error'] ?? 'Unavailable') ?></div>
      <?php endif; ?>
    <?php endif; ?>
  </div>

  <?php if ($matchesByRound): ?>
  <div class="card" style="margin-top:16px">
    <div class="panel-heading">Bracket &amp; Matches</div>
    <?php foreach ($matchesByRound as $round => $matches): ?>
      <div style="margin-top:12px">
        <div class="muted small" style="font-weight:700; margin-bottom:6px;">Round <?= (int) $round ?></div>
        <div class="table-wrap"><table>
          <tr><th>#</th><th>Matchup</th><th>Score</th><th>Winner</th><th>Status</th></tr>
          <?php foreach ($matches as $m): ?>
          <tr>
            <td><?= (int) $m['match_number'] ?></td>
            <td>
              <?= e($m['p1_name'] ?? 'BYE') ?>
              <span class="muted small">vs</span>
              <?= e($m['p2_name'] ?? 'BYE') ?>
            </td>
            <td><?= (int) $m['score1'] ?> - <?= (int) $m['score2'] ?></td>
            <td><?= $m['winner_id'] ? e($m['winner_name'] ?? '—') : '<span class="muted">—</span>' ?></td>
            <td><span class="tag tag-<?= $m['status'] === 'completed' ? 'rare' : ($m['status'] === 'walkover' ? 'common' : 'gold') ?>"><?= e(ucfirst((string) $m['status'])) ?></span></td>
          </tr>
          <?php endforeach; ?>
        </table></div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if ($participants): ?>
  <div class="card" style="margin-top:16px">
    <div class="panel-heading">Standings</div>
    <div class="table-wrap"><table>
      <tr><th>#</th><th>Player</th><th>W</th><th>L</th><th>D</th><th>Pts</th><th>Score</th><th>Prize</th></tr>
      <?php foreach ($participants as $i => $p): ?>
      <tr<?= ((int) $p['user_id'] === (int) $u['id']) ? ' style="background:rgba(255,215,0,0.08)"' : '' ?>>
        <td><?= $p['final_position'] ? (int) $p['final_position'] : ($i + 1) ?></td>
        <td><?= e($p['username'] ?? 'Unknown') ?> <span class="muted small">(Lv <?= (int) ($p['level'] ?? 1) ?>)</span></td>
        <td><?= (int) $p['wins'] ?></td>
        <td><?= (int) $p['losses'] ?></td>
        <td><?= (int) $p['draws'] ?></td>
        <td><?= (int) $p['points'] ?></td>
        <td><?= (int) $p['total_score'] ?><?= $p['best_time_ms'] ? ' (' . number_format((int) $p['best_time_ms']) . 'ms)' : '' ?></td>
        <td><?= (int) $p['prize_money'] > 0 ? money((int) $p['prize_money']) : '&mdash;' ?></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
  <?php endif; ?>

    <?php endif; ?>
<?php else:
    $all = tournament_get_all();
    $open = array_values(array_filter($all, static fn($t) => (string) $t['status'] === 'registration'));
    $running = array_values(array_filter($all, static fn($t) => (string) $t['status'] === 'in_progress'));
    $past = array_values(array_filter($all, static fn($t) => (string) $t['status'] === 'completed'));
    $render = static function (array $list, $u) use ($statusTag): void {
        foreach ($list as $t):
            $count = tournament_participant_count((int) $t['id']);
            $mine = tournament_get_participant((int) $t['id'], (int) $u['id']);
            $canReg = tournament_can_register($t, $u); ?>
      <div class="card" style="margin-top:16px">
        <div class="panel-heading">
          <span><?= e($t['name']) ?></span>
          <span class="tag tag-<?= $statusTag((string) $t['status']) ?>"><?= e(tournament_status_label((string) $t['status'])) ?></span>
        </div>
        <p class="muted"><?= e($t['description']) ?></p>
        <div class="grid grid-3" style="margin:12px 0">
          <div class="stat"><span>Format</span><b><?= e(tournament_type_label((string) $t['type'])) ?></b></div>
          <div class="stat"><span>Game</span><b><?= e(tournament_game_label((string) $t['game_type'])) ?></b></div>
          <div class="stat"><span>Entrants</span><b><?= $count ?> / <?= (int) $t['max_participants'] ?></b></div>
        </div>
        <div class="muted small" style="margin-bottom:8px">
          <b>Prize Pool:</b> <?= money((int) $t['prize_pool_money']) ?> | <?= number_format((int) $t['prize_pool_points']) ?> Pts | <?= number_format((int) $t['prize_pool_xp']) ?> XP
          &middot; <b>Entry:</b> <?= (int) $t['entry_fee_money'] > 0 ? money((int) $t['entry_fee_money']) : 'Free' ?>
        </div>
        <a class="btn btn-sm" href="<?= e(url('tournaments.php?view=' . (int) $t['id'])) ?>">View details</a>
        <?php if ((string) $t['status'] === 'registration' && !empty($canReg['ok'])): ?>
          <form method="post" style="display:inline; margin-left:6px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="register">
            <input type="hidden" name="tournament_id" value="<?= (int) $t['id'] ?>">
            <button class="btn btn-gold btn-sm" type="submit">Register</button>
          </form>
        <?php elseif ($mine && in_array((string) $mine['status'], ['registered', 'confirmed'], true)): ?>
          <span class="tag tag-gold" style="margin-left:6px">Registered</span>
        <?php endif; ?>
      </div>
    <?php endforeach;
    };
    ?>

    <?php if (!$all): ?>
      <div class="card" style="margin-top:16px"><p class="muted">No tournaments are scheduled right now. Check back soon.</p></div>
    <?php endif; ?>

    <?php if ($running): ?>
      <h2 style="margin-top:24px">In Progress</h2>
      <?php $render($running, $u); ?>
    <?php endif; ?>

    <?php if ($open): ?>
      <h2 style="margin-top:24px">Open for Registration</h2>
      <?php $render($open, $u); ?>
    <?php endif; ?>

    <?php if ($past): ?>
      <h2 style="margin-top:24px">Completed</h2>
      <?php $render($past, $u); ?>
    <?php endif; ?>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
