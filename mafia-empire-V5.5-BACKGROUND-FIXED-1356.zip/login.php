<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/security.php';
require_once __DIR__ . '/includes/twofa.php';
if (is_logged_in()) {
    redirect('play.php');
}

$error = '';
$stage = 'password'; // 'password' or '2fa'
$pendingUid = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($action ?? '') === 'verify_2fa') {
        // Stage 2: Verify 2FA code
        $pendingUid = (int) ($_POST['pending_uid'] ?? 0);
        $code = trim($_POST['code'] ?? '');

        if ($pendingUid && $code) {
            $verify = twofa_verify($pendingUid, $code);
            if ($verify['ok']) {
                session_regenerate_id(true);
                $_SESSION['uid'] = $pendingUid;
                auth_rate_limit_reset('login');
                analytics_track('login', $pendingUid, ['via' => 'password_2fa', '2fa_method' => $verify['method']]);
                redirect('play.php');
            } else {
                $error = $verify['error'] ?? 'Invalid 2FA code.';
            }
        } else {
            $error = 'Invalid 2FA submission.';
        }
    } else {
        // Stage 1: Username/password
        auth_rate_limit('login', 5, 15);
        csrf_verify();
        $username = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        $row = fetch('SELECT * FROM users WHERE username = ? OR email = ?', [$username, $username]);

        if ($row && password_verify($pass, $row['password_hash'])) {
            if ((int) $row['is_banned'] === 1) {
                $error = 'This account has been banned.';
            } else {
                if ((int) $row['twofa_enabled'] === 1) {
                    // 2FA enabled - require second factor
                    $stage = '2fa';
                    $pendingUid = (int) $row['id'];
                } else {
                    // No 2FA - log in directly
                    session_regenerate_id(true);
                    $_SESSION['uid'] = (int) $row['id'];
                    auth_rate_limit_reset('login');
                    analytics_track('login', (int) $row['id'], ['via' => 'password']);
                    redirect('play.php');
                }
            }
        } else {
            $error = 'Invalid username or password.';
        }
    }
}
$page_title = 'Log In';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-page">
  <div class="auth-container">
    <div class="auth-header">
      <div class="auth-logo" aria-hidden="true">&#9671;</div>
      <h1 class="auth-title"><?= $stage === '2fa' ? 'Two-Factor Auth' : 'Welcome Back' ?></h1>
      <?php if ($stage === 'password'): ?>
      <p class="auth-subtitle">Sign in to your empire</p>
      <?php else: ?>
      <p class="auth-subtitle">Enter your 2FA code to continue</p>
      <?php endif; ?>
    </div>

    <div class="auth-card">
      <?php if ($error): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
      <?php endif; ?>

      <?php if ($stage === '2fa'): ?>
      <!-- 2FA Verification Stage -->
      <form method="post" class="auth-form">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="verify_2fa">
        <input type="hidden" name="pending_uid" value="<?= e($pendingUid) ?>">

        <div class="auth-2fa-icon" aria-hidden="true">&#9671;</div>
        <h2 class="auth-2fa-title">Two-Factor Authentication</h2>
        <p class="auth-2fa-desc">Enter the 6-digit code from your authenticator app or use a backup code.</p>

        <div class="form-group">
          <label>2FA Code
            <input type="text" name="code" maxlength="6" pattern="[0-9]{6}" 
                   placeholder="123456" required autofocus 
                    class="auth-2fa-input"
                    autocomplete="one-time-code">
          </label>
        </div>

        <button class="btn btn-gold" type="submit">Verify & Log In</button>

        <div class="auth-links">
          <a href="<?= e(url('login.php')) ?>">Back to password</a>
        </div>
      </form>

      <?php else: ?>
      <!-- Password Stage -->
      <form method="post" class="auth-form">
        <?= csrf_field() ?>

        <div class="form-group">
          <label>Username or Email
            <input type="text" name="username" required autofocus 
                   placeholder="Enter username or email">
          </label>
        </div>

        <div class="form-group">
          <label>Password
            <div class="input-with-toggle">
              <input type="password" name="password" required placeholder="Enter password">
              <button type="button" class="input-toggle" aria-label="Toggle password visibility">
                <span id="pwdToggle" aria-hidden="true">&#128065;</span>
              </button>
            </div>
          </label>
        </div>

        <button class="btn btn-gold" type="submit">Log In</button>
      </form>

      <div class="auth-links">
        <a href="<?= e(url('register.php')) ?>">Join the Family</a>
        <a href="<?= e(url('twofa_setup.php')) ?>">Manage 2FA</a>
      </div>
      <?php endif; ?>
    </div>

    <p class="auth-footer">&copy; <?= date('Y') ?> <?= e(SITE_NAME) ?>. All rights reserved.</p>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Password toggle
  const toggle = document.getElementById('pwdToggle');
  const pwdInput = document.querySelector('input[name="password"]');
  if (toggle && pwdInput) {
    toggle.addEventListener('click', function() {
      if (pwdInput.type === 'password') {
        pwdInput.type = 'text';
        this.textContent = '&#128064;';
      } else {
        pwdInput.type = 'password';
        this.textContent = '&#128065;';
      }
    });
  }

  // Auto-format 2FA input
  const twofaInput = document.querySelector('input[name="code"]');
  if (twofaInput) {
    twofaInput.addEventListener('input', function() {
      this.value = this.value.replace(/[^0-9]/g, '').slice(0, 6);
    });
  }
});
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>