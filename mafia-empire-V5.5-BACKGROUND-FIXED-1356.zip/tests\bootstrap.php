<?php

declare(strict_types=1);

/**
 * Mafia Empire - PHPUnit bootstrap.
 *
 * Builds a disposable database (name must end in "_test"), loads the schema and
 * the content seed, then exposes the application's global helper functions to
 * the test classes. The live/dev database is never touched: the bootstrap
 * refuses to run against any database whose name does not end in "_test".
 */

$dbName = getenv('DB_NAME') ?: 'mafia_empire_test';
if (!str_ends_with($dbName, '_test')) {
    fwrite(STDERR, "\n[test bootstrap] Refusing to run against database \"{$dbName}\".\n"
        . "Set DB_NAME to a database whose name ends in \"_test\" (e.g. mafia_empire_test).\n\n");
    exit(1);
}

putenv('DB_NAME=' . $dbName);
putenv('DB_HOST=' . (getenv('DB_HOST') ?: '127.0.0.1'));
putenv('DB_PORT=' . (getenv('DB_PORT') ?: '3306'));
putenv('DB_USER=' . (getenv('DB_USER') ?: 'root'));
putenv('DB_PASS=' . (getenv('DB_PASS') ?: ''));

$root = dirname(__DIR__);

// Fallback PSR-4 autoloader for the test namespace. Composer provides this in
// CI, but registering it here lets the suite run from a bare checkout / phar.
spl_autoload_register(static function (string $class): void {
    $prefix = 'MafiaEmpire\\Tests\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = __DIR__ . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require_once $root . '/includes/db.php';
require_once $root . '/includes/functions.php';
require_once $root . '/includes/game.php';
require_once $root . '/includes/migrate.php';
require_once $root . '/includes/webhooks.php';
require_once $root . '/includes/discord.php';
require_once $root . '/includes/push.php';
require_once $root . '/includes/tasks.php';
require_once $root . '/includes/api.php';
require_once $root . '/includes/seed.php';

// --- Build a clean database for a deterministic run ---------------------
$server = new PDO(
    'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4',
    DB_USER,
    DB_PASS,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);
$server->exec('DROP DATABASE IF EXISTS `' . $dbName . '`');
$server->exec('CREATE DATABASE `' . $dbName . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci');

run_schema();

$adminId = create_admin('admin', 'admin@mafia-empire.test', 'mafia123');
seed($adminId ?: (int) fetch_one('SELECT id FROM users WHERE is_admin = 1 LIMIT 1', [], 1));
run_migrations();
