<?php
/**
 * Eye Of The Mafia - Heists Dashboard
 * Crew co-op multi-phase missions with shared rewards.
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/heists.php';

$u = require_login();

// POST handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'start') {
        if (!$u['crew_id']) {
            flash('You must be in a crew to start a heist.', 'error');
        } else {
            $result = heist_start($u['crew_id'], (int) ($_POST['heist_id'] ?? 0), $u['id']);
            if (!empty($result['ok'])) {
                flash('Heist started! Gather your crew in the planning phase.', 'success');
            } else {
                flash($result['error'] ?? 'Could not start heist.', 'error');
            }
        }
        redirect('heists.php');
    } elseif ($action === 'ready') {
        $result = heist_ready((int) ($_POST['instance_id'] ?? 0), $u['id']);
        if (!empty($result['ok'])) {
            flash('Ready! Waiting for crew...', 'success');
        } else {
            flash($result['error'] ?? 'Could not ready up.', 'error');
        }
        redirect('heists.php');
    } elseif ($action === 'unready') {
        heist_unready((int) ($_POST['instance_id'] ?? 0), $u['id']);
        flash('Unreadied.', 'info');
        redirect('heists.php');
    } elseif ($action === 'abandon') {
        $result = heist_abandon((int) ($_POST['instance_id'] ?? 0), $u['id']);
        if (!empty($result['ok'])) {
            flash('Heist abandoned.', 'info');
        } else {
            flash($result['error'] ?? 'Could not abandon.', 'error');
        }
        redirect('heists.php');
    } elseif ($action === 'complete_phase') {
        $result = heist_complete_phase((int) ($_POST['instance_id'] ?? 0), $u['id'], (int) ($_POST['phase'] ?? 0));
        if (!empty($result['ok'])) {
            if (isset($result['next_phase'])) {
                flash("Phase complete! Phase " . ($result['next_phase'] + 1) . " started.", 'success');
            } else {
                flash('Heist complete! Rewards distributed.', 'success');
            }
        } else {
            flash($result['error'] ?? 'Could not complete phase.', 'error');
        }
        redirect('heists.php');
    } elseif ($action === 'fail') {
        $result = heist_fail((int) ($_POST['instance_id'] ?? 0), $u['id']);
        if (!empty($result['ok'])) {
            flash('Heist marked as failed.', 'error');
        } else {
            flash($result['error'] ?? 'Could not fail heist.', 'error');
        }
        redirect('heists.php');
    }
}

$page_title = 'Heists';
require __DIR__ . '/includes/header.php';

$heists = heist_get_all();
$activeInstance = heist_get_user_active($u['id']);
$history = heist_get_user_history($u['id'], 10);

?>

<div class="card">
  <div class="panel-heading">Heists <span class="muted small">(Crew Co-op Missions)</span></div>
  <p class="muted small">Assemble your crew, plan the job, and split the take. Each heist has multiple phases requiring coordination.</p>
</div>

<?php if ($activeInstance): ?>
<div class="card" style="margin-top:16px; border-left:4px solid var(--gold);">
  <div class="panel-heading">Active Heist: <?= e($activeInstance['heist']['name']) ?></div>
  <div class="muted small">Status: <span class="tag tag-<?= $activeInstance['status'] === 'planning' ? 'gold' : 'legendary' ?>"><?= ucfirst($activeInstance['status']) ?></span></div>
  
  <?php if ($activeInstance['status'] === 'planning'): ?>
    <div style="margin-top:12px">
      <p class="muted small">Planning phase - all crew members must ready up to begin.</p>
      <?php
      $parts = fetch_all('SELECT hp.*, u.username FROM heist_participants hp JOIN users u ON u.id = hp.user_id WHERE hp.instance_id = ?', [$activeInstance['id']]);
      $allReady = true;
      foreach ($parts as $p): 
        if (!$p['ready']) $allReady = false;
      ?>
        <div class="stat" style="margin:4px 0">
          <span><?= e($p['username']) ?> (<?= e($p['role']) ?>)</span>
          <b><?= $p['ready'] ? '✓ Ready' : '<span class="muted">Waiting...</span>' ?></b>
        </div>
      <?php endforeach; ?>
      
      <?php if ($allReady && (int) $activeInstance['leader_id'] === $u['id']): ?>
        <form method="post" style="display:inline; margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="start">
          <input type="hidden" name="instance_id" value="<?= (int) $activeInstance['id'] ?>">
          <button class="btn btn-gold btn-sm" type="submit">Start Heist (All Ready)</button>
        </form>
      <?php endif; ?>
      
      <form method="post" style="display:inline; margin-top:8px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $activeInstance['leader_id'] === $u['id'] ? 'abandon' : 'unready' ?>">
        <input type="hidden" name="instance_id" value="<?= (int) $activeInstance['id'] ?>">
        <button class="btn btn-sm" type="submit"><?= $activeInstance['leader_id'] === $u['id'] ? 'Abandon' : 'Unready' ?></button>
      </form>
      
      <?php if ($activeInstance['leader_id'] !== $u['id']): ?>
        <form method="post" style="display:inline; margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="ready">
          <input type="hidden" name="instance_id" value="<?= (int) $activeInstance['id'] ?>">
          <button class="btn btn-green btn-sm" type="submit">✓ Ready Up</button>
        </form>
      <?php endif; ?>
    </div>
  
  <?php elseif ($activeInstance['status'] === 'active'): ?>
    <div style="margin-top:12px">
      <?php
      $heistData = $activeInstance['heist'];
      $phases = heist_get_phases($heistData);
      $progress = json_decode($activeInstance['phase_progress'] ?? '[]', true);
      $currentPhase = (int) $activeInstance['current_phase'] - 1;
      ?>
      <p class="muted small">Phase <?= $currentPhase + 1 ?> of <?= count($phases) ?>: <b><?= e($phases[$currentPhase]['name']) ?></b></p>
      <p class="muted small"><?= e($phases[$currentPhase]['description']) ?></p>
      
      <?php foreach ($phases as $i => $phase): ?>
        <div class="stat" style="margin:4px 0">
          <span><?= e($phase['name']) ?></span>
          <b>
            <?php if ($i < $currentPhase): ?>
              ✓ Complete
            <?php elseif ($i === $currentPhase): ?>
              <span class="tag tag-legendary">IN PROGRESS</span>
            <?php else: ?>
              <span class="muted">Locked</span>
            <?php endif; ?>
          </b>
        </div>
      <?php endforeach; ?>
      
      <?php if ($currentPhase >= 0 && $currentPhase < count($phases)): ?>
        <form method="post" style="margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="complete_phase">
          <input type="hidden" name="instance_id" value="<?= (int) $activeInstance['id'] ?>">
          <input type="hidden" name="phase" value="<?= $currentPhase ?>">
          <button class="btn btn-gold btn-sm" type="submit">Complete Phase</button>
        </form>
      <?php endif; ?>
      
      <?php if ($activeInstance['leader_id'] === $u['id']): ?>
        <form method="post" style="display:inline; margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="fail">
          <input type="hidden" name="instance_id" value="<?= (int) $activeInstance['id'] ?>">
          <button class="btn btn-sm" type="submit">Fail Heist</button>
        </form>
      <?php endif; ?>
    </div>
  
  <?php elseif ($activeInstance['status'] === 'completed'): ?>
    <div style="margin-top:12px; padding:12px; background:rgba(0,128,0,0.1); border-left:4px solid var(--green);">
      <b>Heist Completed!</b>
      <p class="muted small">Check your rewards in the history below.</p>
    </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<h2>Available Heists</h2>
<?php foreach ($heists as $h): 
  $phases = heist_get_phases($h);
  $canStart = false;
  $canStartReason = '';
  if ($u['crew_id']) {
    $check = heist_can_start($u['crew_id'], (int) $h['id']);
    $canStart = $check['ok'];
    $canStartReason = $check['error'] ?? '';
  } else {
    $canStartReason = 'Join a crew first';
  }
?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">
    <span><?= e($h['name']) ?></span>
    <span class="tag tag-<?= $h['min_crew_level'] >= 15 ? 'legendary' : ($h['min_crew_level'] >= 10 ? 'rare' : 'gold') ?>">
      Crew Lv <?= (int) $h['min_crew_level'] ?>+
    </span>
  </div>
  <p class="muted"><?= e($h['description']) ?></p>
  
  <div class="grid grid-3" style="margin:12px 0">
    <div class="stat"><span>Crew</span><b><?= (int) $h['min_members'] ?>-<?= (int) $h['max_members'] ?> members</b></div>
    <div class="stat"><span>Phases</span><b><?= count($phases) ?></b></div>
    <div class="stat"><span>Cooldown</span><b><?= (int) $h['cooldown_hours'] ?>h</b></div>
  </div>
  
  <div class="muted small" style="margin-bottom:8px">
    <b>Rewards (per member):</b> <?= money($h['reward_money']) ?> | <?= number_format($h['reward_xp']) ?> XP | <?= number_format($h['reward_points']) ?> Pts
  </div>
  
  <details style="margin-top:8px">
    <summary class="muted small">Phase Details</summary>
    <ul class="muted small" style="margin-top:8px; line-height:1.8">
      <?php foreach ($phases as $i => $p): ?>
        <li><b>Phase <?= $i + 1 ?>: <?= e($p['name']) ?></b> - <?= e($p['description']) ?>
          <br>Rewards: <?= money($p['money']) ?> | <?= number_format($p['xp']) ?> XP
          <?php if (!empty($p['requirements']['items'])): ?>
            <br>Requires: <?php foreach ($p['requirements']['items'] as $req) { $it = fetch('SELECT name FROM items WHERE id = ?', [(int) $req['item_id']]); echo (int) $req['qty'] . 'x ' . ($it['name'] ?? 'Item') . ' '; } ?>
          <?php endif; ?>
          <?php if (!empty($p['requirements']['stats'])): ?>
            <br>Stats: <?php foreach ($p['requirements']['stats'] as $s => $v) echo ucfirst($s) . ' ' . $v . ' '; ?>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </details>
  
  <?php if ($canStart): ?>
    <form method="post" style="margin-top:12px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="start">
      <input type="hidden" name="heist_id" value="<?= (int) $h['id'] ?>">
      <button class="btn btn-gold btn-block" type="submit">Start Heist</button>
    </form>
  <?php else: ?>
    <div class="muted small" style="margin-top:12px">Cannot start: <?= e($canStartReason) ?></div>
  <?php endif; ?>
</div>
<?php endforeach; ?>

<?php if ($history): ?>
<div class="card" style="margin-top:24px">
  <div class="panel-heading">Your Heist History</div>
  <div class="table-wrap"><table>
    <tr><th>Heist</th><th>Status</th><th>Date</th><th>Your Share</th></tr>
    <?php foreach ($history as $row): ?>
    <tr>
      <td><b><?= e($row['name']) ?></b></td>
      <td><span class="tag tag-<?= $row['status'] === 'completed' ? 'legendary' : ($row['status'] === 'failed' ? 'common' : 'gold') ?>"><?= ucfirst($row['status']) ?></span></td>
      <td><?= date('M j, Y', strtotime($row['created_at'])) ?></td>
      <td><?= money($row['money_received']) ?> | <?= number_format($row['xp_received']) ?> XP | <?= number_format($row['points_received']) ?> Pts</td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>