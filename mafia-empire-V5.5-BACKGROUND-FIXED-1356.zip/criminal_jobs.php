<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: do job
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $jobId = (int) ($_POST['job_id'] ?? 0);
    $job = fetch('SELECT * FROM criminal_jobs WHERE id = ?', [$jobId]);
    if (!$job) {
        flash('Job not found.', 'error');
    } elseif ((int) $u['level'] < (int) $job['min_level']) {
        flash('Level ' . (int) $job['min_level'] . ' required.', 'error');
    } elseif ((int) $u['nerve'] < (int) $job['nerve_cost']) {
        flash('Not enough nerve.', 'error');
    } elseif (is_hospitalized($u)) {
        flash('You are hospitalized.', 'error');
    } elseif (action_on_cooldown($u['id'], 'criminal_jobs')) {
        $cd = action_on_cooldown($u['id'], 'criminal_jobs');
        flash('Criminal jobs on cooldown. Try again in ' . $cd . '.', 'error');
    } else {
        $cd = fetch('SELECT ready_at FROM user_job_cooldowns WHERE user_id = ? AND job_id = ?', [$u['id'], $jobId]);
        if ($cd && strtotime($cd['ready_at']) > time()) {
            flash('On cooldown.', 'error');
        } else {
            q('UPDATE users SET nerve = nerve - ? WHERE id = ?', [(int) $job['nerve_cost'], $u['id']]);
            $chance = 100 - (int) $job['fail_risk'];
            // Police Funding (crime_rate < 1.0) makes criminal jobs harder city-wide.
            if (function_exists('politics_apply_policy_effect')) {
                $chance = (int) round($chance * politics_apply_policy_effect('crime_rate', 1.0));
            }
            $success = mt_rand(1, 100) <= $chance;
            if ($success) {
                $payout = mt_rand((int) $job['payout_min'], (int) $job['payout_max']);
                $xp = (int) $job['xp'];
                // Mayor policies: Tax Cut boosts income, Education boosts XP.
                if (function_exists('politics_apply_policy_effect')) {
                    $payout = (int) round($payout * politics_apply_policy_effect('money_multiplier', 1.0));
                    $xp = (int) round($xp * politics_apply_policy_effect('xp_multiplier', 1.0));
                }
                add_money($u['id'], $payout, 'Criminal Job: ' . $job['name']);
                if ($xp > 0) grant_xp($u['id'], $xp);
                q('UPDATE users SET crimes_done = crimes_done + 1 WHERE id = ?', [$u['id']]);
                analytics_track('crime_complete', $u['id'], ['job_id' => $jobId, 'payout' => $payout]);
                set_action_cooldown($u['id'], 'criminal_jobs');
                if (function_exists('heat_add')) { heat_add($u['id'], 1, 'crime'); }
                flash('Job success! Earned ' . money($payout) . ' and ' . $xp . ' XP.', 'success');
            } else {
                $hpLoss = mt_rand(5, 20);
                q('UPDATE users SET health = GREATEST(health - ?, 0) WHERE id = ?', [$hpLoss, $u['id']]);
                analytics_track('crime_fail', $u['id'], ['job_id' => $jobId]);
                if (function_exists('heat_add')) { heat_add($u['id'], 1, 'crime'); }
                flash('Job failed. Lost ' . $hpLoss . ' health.', 'error');
            }
            if ((int) $job['cooldown'] > 0) {
                q('INSERT INTO user_job_cooldowns (user_id, job_id, ready_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE ready_at = VALUES(ready_at)',
                    [$u['id'], $jobId, date('Y-m-d H:i:s', time() + (int) $job['cooldown'])]);
            }
        }
    }
    event_track('crimes_done');
    redirect('criminal_jobs.php');
}

$page_title = 'Criminal Jobs';
require __DIR__ . '/includes/header.php';

$u = current_user();
$jobs = fetch_all('SELECT * FROM criminal_jobs ORDER BY min_level');
$cooldowns = fetch_all('SELECT job_id, ready_at FROM user_job_cooldowns WHERE user_id = ?', [$u['id']]);
$cdMap = [];
foreach ($cooldowns as $cd) { $cdMap[$cd['job_id']] = $cd['ready_at']; }
?>
<div class="card">
  <div class="panel-heading">Criminal Jobs</div>
  <p class="muted small">Spend nerve for quick cash. Each job has a cooldown and fail risk.</p>
  <div class="stat"><span>Nerve</span><b><?= (int) $u['nerve'] ?> / <?= (int) $u['nerve_max'] ?></b></div>
</div>

<div class="grid grid-2">
  <?php foreach ($jobs as $j):
    $locked = (int) $u['level'] < (int) $j['min_level'];
    $cd = $cdMap[$j['id']] ?? null;
    $onCd = $cd && strtotime($cd) > time();
    $remaining = $onCd ? strtotime($cd) - time() : 0;
  ?>
    <div class="card">
      <b><?= e($j['name']) ?></b>
      <br><small class="muted"><?= e($j['description']) ?></small>
      <div class="pill-row" style="margin:8px 0">
        <span class="pill">Nerve: <?= (int) $j['nerve_cost'] ?></span>
        <span class="pill">Lvl: <?= (int) $j['min_level'] ?></span>
        <span class="pill">Payout: <?= money($j['payout_min']) ?>-<?= money($j['payout_max']) ?></span>
        <span class="pill">XP: +<?= (int) $j['xp'] ?></span>
        <span class="pill">Fail: <?= (int) $j['fail_risk'] ?>%</span>
        <?php if ((int) $j['cooldown'] > 0): ?><span class="pill">CD: <?= (int) $j['cooldown'] ?>s</span><?php endif; ?>
      </div>
      <?php if ($onCd): ?>
        <div class="small muted">Ready in <span data-until="<?= e($cd) ?>"></span></div>
      <?php endif; ?>
      <?php if (!$locked && !$onCd): ?>
        <form method="post" data-offline-queue data-offline-label="Criminal Job" style="margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="job_id" value="<?= (int) $j['id'] ?>">
          <button class="btn btn-green btn-block btn-sm" type="submit">Do Job</button>
        </form>
      <?php elseif ($locked): ?>
        <span class="tag tag-common">Locked (Lvl <?= (int) $j['min_level'] ?>)</span>
      <?php else: ?>
        <span class="tag tag-common">On Cooldown</span>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>