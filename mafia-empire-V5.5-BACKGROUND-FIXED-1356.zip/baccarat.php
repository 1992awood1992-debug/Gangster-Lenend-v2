<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

function bacc_deck(): array
{
    $suits = ['♠', '♥', '♦', '♣'];
    $ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    $deck = [];
    foreach ($suits as $s) {
        foreach ($ranks as $r) {
            $deck[] = $r . $s;
        }
    }
    shuffle($deck);
    return $deck;
}

function bacc_points(array $hand): int
{
    $total = 0;
    foreach ($hand as $card) {
        [$r] = card_parts($card);
        if ($r === 'A') { $total += 1; }
        elseif (is_numeric($r)) { $total += (int) $r; }
    }
    return $total % 10;
}

$result = null; // ['player' => [...], 'banker' => [...], 'bet' => ..., 'stake' => ..., 'payout' => ..., 'outcome' => ..., 'tally' => ...]

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'play') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        $bet = ($_POST['bet'] ?? 'player');
        if (!in_array($bet, ['player', 'banker', 'tie'], true)) { $bet = 'player'; }
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('baccarat.php'); }
        add_money($u['id'], -$stake, 'Baccarat bet');
        $deck = bacc_deck();
        $player = [array_pop($deck), array_pop($deck)];
        $banker = [array_pop($deck), array_pop($deck)];
        // Official drawing rules
        $pp = bacc_points($player);
        $bp = bacc_points($banker);
        if (!($pp >= 8 || $bp >= 8)) {
            if ($pp <= 5) {
                $player[] = array_pop($deck);
                [$r] = card_parts($player[2]);
                $thirdVal = $r === 'A' ? 1 : (is_numeric($r) ? (int) $r : 0);
                if ($bp <= 2) {
                    $banker[] = array_pop($deck);
                } elseif ($bp === 3) {
                    if ($thirdVal !== 8) { $banker[] = array_pop($deck); }
                } elseif ($bp === 4) {
                    if (!in_array($thirdVal, [0, 1, 8, 9], true)) { $banker[] = array_pop($deck); }
                } elseif ($bp === 5) {
                    if (!in_array($thirdVal, [0, 1, 2, 3, 8, 9], true)) { $banker[] = array_pop($deck); }
                } elseif ($bp === 6) {
                    if (in_array($thirdVal, [6, 7], true)) { $banker[] = array_pop($deck); }
                }
            } else {
                if ($bp <= 5) { $banker[] = array_pop($deck); }
            }
        }
        $pp = bacc_points($player);
        $bp = bacc_points($banker);
        $payout = 0;
        $outcome = '';
        if ($pp === $bp) {
            if ($bet === 'tie') {
                $payout = $stake * 9;
                add_money($u['id'], $payout, 'Baccarat win (Tie)');
                event_track('casino_won', (int) $payout);
                $outcome = 'Tie — paid 8:1';
            } else {
                $payout = $stake; // push returns stake for player/banker bets
                add_money($u['id'], $stake, 'Baccarat push');
                $outcome = 'Tie — push';
            }
        } elseif ($pp > $bp) {
            if ($bet === 'player') {
                $payout = $stake * 2;
                add_money($u['id'], $payout, 'Baccarat win (Player)');
                event_track('casino_won', (int) $payout);
                $outcome = 'Player wins — paid 1:1';
            } elseif ($bet === 'tie') {
                $outcome = 'Player wins — tie bet lost';
            } else {
                $outcome = 'Player wins — banker bet lost';
            }
        } else {
            if ($bet === 'banker') {
                $payout = $stake + (int) round($stake * 0.95);
                add_money($u['id'], $payout, 'Baccarat win (Banker)');
                event_track('casino_won', (int) $payout);
                $outcome = 'Banker wins — paid 0.95:1';
            } elseif ($bet === 'tie') {
                $outcome = 'Banker wins — tie bet lost';
            } else {
                $outcome = 'Banker wins — player bet lost';
            }
        }
        insert('casino_bets', ['user_id' => $u['id'], 'game' => 'baccarat', 'stake' => $stake, 'payout' => $payout, 'detail' => ucfirst($bet) . ' ' . $outcome]);
        $result = ['player' => $player, 'banker' => $banker, 'bet' => $bet, 'stake' => $stake, 'payout' => $payout, 'outcome' => $outcome];
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'baccarat', json_encode(['last' => $result])]);
    }
    redirect('baccarat.php');
}

$saved = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'baccarat']);
$saved = $saved ? json_decode($saved['state'], true) : null;
$result = $saved['last'] ?? null;

$page_title = 'Baccarat';
require __DIR__ . '/includes/header.php';
$u = current_user();

function bacc_card(string $c): string
{
    [$r, $s] = card_parts($c);
    $red = in_array($s, ['♥', '♦'], true);
    return '<span class="bj-card"' . ($red ? ' style="color:#e0524a"' : '') . '>' . e($r) . '<small>' . e($s) . '</small></span>';
}
?>
<style>
.bj-card{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;width:48px;height:68px;background:#f5ead0;border:1px solid #8a7448;border-radius:6px;color:#2a2320;font-weight:700;font-size:1.05rem;margin:0 3px;box-shadow:0 2px 4px rgba(0,0,0,.4)}
.bj-card small{font-size:.8rem}
.bj-hand{display:flex;align-items:center;gap:2px;margin:10px 0;flex-wrap:wrap}
</style>
<div class="card">
  <div class="panel-heading">Baccarat</div>
  <p class="muted small">Highest hand wins; 9 is the best. Player pays 1:1, Banker 0.95:1 (5% commission), Tie pays 8:1. Official drawing rules apply.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<div class="card">
  <form method="post" style="max-width:420px;display:grid;gap:10px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="play">
    <div>
      <label>Bet on</label>
      <select name="bet" class="full">
        <option value="player">Player — pays 1:1</option>
        <option value="banker">Banker — pays 0.95:1</option>
        <option value="tie">Tie — pays 8:1</option>
      </select>
    </div>
    <label>Wager (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="50" required></label>
    <button class="btn btn-gold" type="submit">Deal</button>
  </form>
</div>

<?php if ($result): ?>
<div class="card">
  <div class="panel-heading"><?= e($result['outcome']) ?></div>
  <div class="bj-hand"><b style="min-width:110px">Player (<?= bacc_points($result['player']) ?>):</b>
    <?php foreach ($result['player'] as $c): ?><?= bacc_card($c) ?><?php endforeach; ?>
  </div>
  <div class="bj-hand"><b style="min-width:110px">Banker (<?= bacc_points($result['banker']) ?>):</b>
    <?php foreach ($result['banker'] as $c): ?><?= bacc_card($c) ?><?php endforeach; ?>
  </div>
  <div class="stat"><span>Your Bet</span><b><?= e(ucfirst($result['bet'])) ?> · <?= money($result['stake']) ?></b></div>
  <div class="stat"><span>Returned</span><b><?= money($result['payout']) ?></b></div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>