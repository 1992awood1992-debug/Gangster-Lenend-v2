<?php
/**
 * Mafia Empire - page header + navigation.
 * Expects optional $page_title. Uses $user from init.
 */
if (!defined('MAFIA_EMPIRE')) {
    define('MAFIA_EMPIRE', true);
}
require_once __DIR__ . '/init.php';
$u = current_user();
$active = basename($_SERVER['SCRIPT_NAME'] ?? '');

/**
 * Navigation groups: [label, file, icon]
 * Icons are mono unicode glyphs - era-appropriate, no external assets.
 */
$nav = [
    'Play' => [
        ['Play', 'play.php', '&#9654;'],
        ['Home', 'index.php', '&#8962;'],
    ],
    'The Empire' => [
        ['Missions',       'missions.php',       '&#9670;'],
        ['The Gym',        'gym.php',            '&#9650;'],
        ['Bosses',         'bosses.php',         '&#9760;'],
        ['Criminal Jobs',  'criminal_jobs.php',  '&#9875;'],
        ['Kill',           'kill.php',           '&#9876;'],
        ['The Empire',     'empire.php',         '&#9819;'],
        ['Abilities',      'abilities.php',      '&#10022;'],
        ['Drugs',          'drugs.php',          '&#10027;'],
        ['Hospital',       'hospital.php',       '&#10010;'],
        ['Districts',      'districts.php',      '&#9672;'],
        ['Workbench',      'crafting.php',       '&#9881;'],
        ['Heists',         'heists.php',         '&#128184;'],
        ['Tournaments',    'tournaments.php',    '&#127942;'],
    ],
    'Money' => [
        ['Money',          'money.php',          '&#36;'],
        ['Bank',           'bank.php',           '&#9635;'],
        ['Businesses',     'businesses.php',     '&#127969;'],
        ['Daily Bonus',    'daily.php',          '&#128176;'],
        ['Garage',         'garage.php',         '&#128663;'],
        ['Flash Center',   'flash_center.php',   '&#128222;'],
        ['Events',         'events.php',         '&#128203;'],
        ['Black Market',   'black-market.php',   '&#9878;'],
        ['Escrow',         'escrow.php',         '&#9753;'],
        ['Equipment',      'equipment.php',      '&#10026;'],
        ['Bullet Factory', 'bullet_factory.php', '&#8226;'],
        ['Points Store',   'points_store.php',   '&#9733;'],
        ['Daily Rewards',  'daily_rewards.php',  '&#128197;'],
        ['Properties',     'properties.php',     '&#127969;'],
        ['Racing',         'racing.php',         '&#128663;'],
        ['Marketplace',    'market.php',         '&#128722;'],
        ['Stock Market',   'stock_market.php',   '&#128184;'],
        ['Pawn Shop',      'pawn_shop.php',      '&#128748;'],
        ['Prestige Shop',  'prestige_shop.php',  '&#128293;'],
        ['City Hall',      'politics.php',       '&#127980;'],
    ],
    'Casino' => [
        ['Casino',       'casino.php',       '&#9824;'],
        ['Lottery',      'lottery.php',      '&#10054;'],
        ['Poker',        'poker.php',        '&#9827;'],
        ['Roulette',     'roulette.php',     '&#9679;'],
        ['Video Poker',  'video_poker.php',  '&#9830;'],
        ['Hi-Lo',        'hilo.php',         '&#8661;'],
        ['Mines',        'mines.php',        '&#9746;'],
        ['Blackjack',    'blackjack.php',    '&#9824;'],
        ['Baccarat',     'baccarat.php',     '&#9829;'],
        ['Keno',         'keno.php',         '&#10021;'],
        ['Crash',        'crash.php',        '&#9889;'],
        ['Dice',         'dice.php',         '&#10026;'],
        ['Slots',        'slots.php',        '&#10027;'],
        ['Sports Betting','sports_betting.php','&#9917;'],
    ],
    'People' => [
        ['People',       'people.php',       '&#9673;'],
        ['Crew',         'crew.php',         '&#9873;'],
        ['Territory',    'territory.php',    '&#128506;'],
        ['Crew Wars',    'crew_wars.php',    '&#9876;'],
        ['Diplomacy',    'diplomacy.php',    '&#9996;'],
        ['Forum',        'forum.php',        '&#9993;'],
        ['Users',        'users.php',        '&#9681;'],
        ['Leaderboards', 'leaderboards.php', '&#9812;'],
        ['Rewards',      'rewards.php',      '&#10050;'],
        ['Achievements', 'achievements.php', '&#10027;'],
        ['Scratch Cards','scratch_cards.php','&#9839;'],
        ['Sticker Book', 'sticker_book.php', '&#9640;'],
        ['Referrals',    'referrals.php',    '&#8644;'],
    ],
    'Info & Help' => [
        ['Info',        'info.php',       '&#9675;'],
        ['Updates',     'updates.php',    '&#10223;'],
        ['Votes',       'votes.php',      '&#11021;'],
        ['Statistics',  'statistics.php', '&#9644;'],
        ['API Access',  'api_access.php', '&#128273;'],
        ['Help',        'help.php',       '?'],
        ['Support',     'support.php',    '&#9991;'],
        ['Suggestions', 'suggestions.php','&#9998;'],
        ['Events',      'events.php',     '&#128197;'],
        ['Trades',      'trades.php',     '&#8644;'],
        ['Crew Chat',   'crew_chat.php',  '&#9993;'],
        ['Hitlist',     'hitlist.php',    '&#9876;'],
        ['Bounties',    'bounties.php',   '&#9670;'],
    ],
];

/* --- City news ticker: cheap, failure-tolerant, era flavour --- */
$ticker = [date('l, F j, Y')];
try {
    $pot = cache_remember('ticker:pot', 300, function () {
        return fetch_one('SELECT pot FROM lottery_draws WHERE status = ? ORDER BY draw_date DESC LIMIT 1', ['open']);
    });
    if ($pot) {
        $ticker[] = 'Lottery jackpot sits at ' . money((int) $pot);
    }
    $headline = cache_remember('ticker:headline', 300, function () {
        return fetch_one('SELECT title FROM updates ORDER BY id DESC LIMIT 1');
    });
    if ($headline) {
        $ticker[] = 'City desk: ' . $headline;
    }
    $made = (int) cache_remember('ticker:players', 300, function () {
        return fetch_one('SELECT COUNT(*) FROM users', [], 0);
    });
    $ticker[] = $made . ' made men on the streets';
} catch (Throwable $e) {
    // The ticker must never break a page.
}
$ticker[] = 'Prohibition in effect — stay armed';
$ticker[] = 'Whiskey is for drinking; turf is for taking';
// Rotating city events
foreach (get_city_events() as $ev) {
    $ticker[] = $ev[0];
}

?><!doctype html>
<html lang="<?= e(i18n_get_locale()) ?>" dir="<?= e(i18n_get_dir(i18n_get_locale())) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#140f0a">
<title><?= e(($page_title ?? 'The City') . ' - ' . SITE_NAME) ?></title>
<?php if (defined('CDN_PRELOAD_CRITICAL') && CDN_PRELOAD_CRITICAL && function_exists('asset_preload')): ?>
<?php
$preloadPaths = ['assets/style.css', 'assets/app.js', 'assets/websocket.js', 'assets/img/icon-192.png'];
$preloadHeader = '';
if (defined('CDN_BASE') && CDN_BASE) {
    $preloadHeader = asset_preload($preloadPaths, CDN_BASE);
} else {
    $preloadHeader = asset_preload($preloadPaths);
}
if ($preloadHeader) {
    echo '<link rel="preload" href="' . e(asset('assets/style.css?v=' . GAME_VERSION)) . '" as="style">' . PHP_EOL;
    echo '<link rel="preload" href="' . e(asset('assets/app.js')) . '" as="script">' . PHP_EOL;
    echo '<link rel="preload" href="' . e(asset('assets/websocket.js')) . '" as="script">' . PHP_EOL;
    echo '<link rel="preload" href="' . e(asset('assets/img/icon-192.png')) . '" as="image">' . PHP_EOL;
}
?>
<?php endif; ?>
<link rel="stylesheet" href="<?= e(asset('assets/style.css?v=' . GAME_VERSION)) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/css-theme.css')) ?>">
<link rel="manifest" href="<?= e(url('manifest.webmanifest')) ?>">
<?php if ($u): ?>
<meta name="ws-token" content="<?= e(hash('sha256', $u['id'] . $u['username'] . SECRET_KEY)) ?>">
<meta name="csrf" content="<?= e(csrf_token()) ?>">
<?php endif; ?>
<link rel="icon" href="<?= e(url('assets/img/avatar-default.svg')) ?>">
<link rel="apple-touch-icon" href="<?= e(url('assets/img/icon-192.png')) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/flash.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/flash-ext.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/v47.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/sound.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/loading.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/layout_fix4.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/flash_center.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/v48.css')) ?>">
<meta name="application-name" content="<?= e(SITE_NAME) ?>">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="<?= e(SITE_NAME) ?>">
<script src="<?= e(asset('assets/websocket.js')) ?>" defer></script>
<script src="<?= e(asset('assets/flash.js')) ?>" defer></script>
<script src="<?= e(asset('assets/flash-ext.js')) ?>" defer></script>
<script src="<?= e(asset('assets/sound.js')) ?>" defer></script>
<script>try{if(localStorage.getItem('me-theme')==='sepia')document.documentElement.classList.add('theme-sepia');}catch(e){}</script>
</head>
<body data-sw="<?= e(asset('sw.js')) ?>" data-offline-url="<?= e(url('offline.html')) ?>">
<div id="fw-loading" style="display:none;">
  <div class="fw-loader"></div>
  <div class="fw-text">Rising through the ranks&#8230;</div>
</div>
<a href="#main-content" class="skip-link"><?= e(__('header.skip_to_main', [], 'en')) ?></a>
<div class="scroll-progress" id="scrollProgress" aria-hidden="true"></div>
<div class="news-ticker" role="region" aria-label="City news">
  <span class="ticker-tag">&#9733; The City</span>
  <div class="ticker-track">
    <div class="ticker-items">
      <?php foreach ($ticker as $t): ?><span class="ticker-item"><?= e($t) ?></span><span class="ticker-sep">&#9670;</span><?php endforeach; ?>
      <?php foreach ($ticker as $t): ?><span class="ticker-item" aria-hidden="true"><?= e($t) ?></span><span class="ticker-sep" aria-hidden="true">&#9670;</span><?php endforeach; ?>
    </div>
  </div>
</div>
<header class="topbar">
  <?php if ($u): ?>
  <button class="menu-toggle" id="menuToggle" type="button" aria-label="Toggle menu" aria-expanded="false">&#9776;</button>
  <?php endif; ?>
  <a class="brand" href="<?= e(url('index.php')) ?>">
    <span class="brand-mark">&#9671;</span>
    <span class="brand-text">
      <span class="brand-name"><?= e(SITE_NAME) ?></span>
      <span class="brand-sub">v<?= GAME_VERSION ?> &middot; Anno <?= GAME_YEAR ?> &middot; <?= e(__('brand.watchful_eye', [], 'en')) ?></span>
    </span>
  </a>
  <?php if ($u): ?>
  <div class="vitals">
    <a class="vital" href="<?= e(url('money.php')) ?>" title="Cash on hand"><b><span class="v-ico">&#36;</span><?= money($u['money']) ?></b><span>Cash</span></a>
    <a class="vital" href="<?= e(url('bank.php')) ?>" title="Money in the bank"><b><span class="v-ico">&#9635;</span><?= money($u['bank']) ?></b><span>Bank</span></a>
    <a class="vital" href="<?= e(url('points_store.php')) ?>" title="Points"><b><span class="v-ico">&#9733;</span><span data-count="<?= (int) $u['points'] ?>"><?= number_format((int) $u['points']) ?></span></b><span>Points</span></a>
    <a class="vital" href="<?= e(url('bullet_factory.php')) ?>" title="Bullets"><b><span class="v-ico">&#9679;</span><span data-count="<?= (int) $u['bullets'] ?>"><?= number_format((int) $u['bullets']) ?></span></b><span>Bullets</span></a>
  </div>
  <div class="bars">
    <?php
    $bars = [
        ['Energy', (int) $u['energy'], (int) $u['energy_max'], 'bar-energy'],
        ['Nerve', (int) $u['nerve'], (int) $u['nerve_max'], 'bar-nerve'],
        ['Health', (int) $u['health'], (int) $u['health_max'], 'bar-health'],
        ['XP', (int) $u['xp'], (int) xp_for_level((int) $u['level'] + 1), 'bar-xp'],
    ];
    foreach ($bars as $b):
        $pct = $b[2] > 0 ? min(100, round($b[1] / $b[2] * 100)) : 0;
    ?>
      <div class="bar-wrap" title="<?= e($b[0]) ?>: <?= $b[1] ?>/<?= $b[2] ?>">
        <span class="bar-label"><?= e($b[0]) ?></span>
        <span class="bar <?= $b[3] ?>"><i style="width:<?= $pct ?>%"></i></span>
        <span class="bar-num"><?= $b[1] ?>/<?= $b[2] ?></span>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="userbox">
    <a class="user-link" href="<?= e(url('profile.php')) ?>">
      <img src="<?= e($u['avatar']) ?>" alt="avatar" onerror="this.src='<?= e(url('assets/img/avatar-default.svg')) ?>'">
      <span><b><?= e($u['username']) ?></b><small>Lv <?= (int) $u['level'] ?> &middot; <?= e(rank_for_level((int) $u['level'])['name']) ?></small></span>
    </a>
    <button class="icon-link theme-toggle" id="themeToggle" type="button" title="Toggle ledger (sepia) mode" aria-label="Toggle ledger mode">&#9788;</button>
    <a class="icon-link" href="<?= e(url('notifications.php')) ?>" title="Notifications">&#128276;<?php $nn = unread_notifications(); if ($nn): ?><span class="badge"><?= $nn ?></span><?php endif; ?></a>
    <?php if (!empty($u['is_admin'])): ?>
    <a class="icon-link" href="<?= e(url('admin.php')) ?>" title="Admin Panel">&#9881;</a>
    <?php endif; ?>
    <a class="icon-link" href="<?= e(url('logout.php')) ?>" title="Log out">&#9099;</a>
    <button class="icon-link sound-toggle" id="soundToggle" type="button" title="Toggle sound" aria-label="Toggle sound">&#127930;</button>
  </div>
  <?php else: ?>
  <div class="guest-links">
    <button class="icon-link theme-toggle" id="themeToggle" type="button" title="Toggle ledger (sepia) mode" aria-label="Toggle ledger mode">&#9788;</button>
    <a class="btn btn-ghost" href="<?= e(url('login.php')) ?>">Log in</a>
    <a class="btn btn-gold" href="<?= e(url('register.php')) ?>">Join the Family</a>
  </div>
  <?php endif; ?>
</header>

<div class="layout<?= $u ? '' : ' no-sidebar' ?>">
  <div class="sidebar-backdrop" id="sidebarBackdrop" aria-hidden="true"></div>
  <?php if ($u): ?>
  <aside class="sidebar" id="mainSidebar">
    <nav>
      <?php $gi = 0; foreach ($nav as $group => $links): $gi++; $gid = 'ng' . $gi; ?>
        <div class="nav-group<?= $active && in_array($active, array_column($links, 1), true) ? ' has-active' : '' ?>" id="<?= e($gid) ?>" data-collapsible>
          <button class="nav-group-title" type="button" aria-expanded="true"><?= e($group) ?></button>
          <div class="nav-links">
            <?php foreach ($links as $link): [$label, $file, $ico] = $link; ?>
              <a class="nav-link<?= $active === $file ? ' active' : '' ?>" href="<?= e(url($file)) ?>">
                <span class="n-ico"><?= $ico ?></span><span class="n-name"><?= e($label) ?></span>
                <?php if ($file === 'crew_chat.php'): $chatUnread = crew_messages_unread_count((int) $u['id']); if ($chatUnread > 0): ?><span class="badge"><?= $chatUnread ?></span><?php endif; endif; ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
      <span class="muted small">&#9671; Eye Of The Mafia v<?= GAME_VERSION ?></span>
    </div>
  </aside>
  <?php endif; ?>
  <nav class="mobile-nav" id="mobileNav">
    <a class="mn-link<?= $active === 'index.php' ? ' active' : '' ?>" href="<?= e(url('index.php')) ?>"><span class="mn-ico">&#8962;</span><span>Home</span></a>
    <a class="mn-link<?= $active === 'play.php' ? ' active' : '' ?>" href="<?= e(url('play.php')) ?>"><span class="mn-ico">&#9654;</span><span>Play</span></a>
    <a class="mn-link<?= $active === 'kill.php' ? ' active' : '' ?>" href="<?= e(url('kill.php')) ?>"><span class="mn-ico">&#128299;</span><span>Kill</span></a>
    <a class="mn-link<?= $active === 'businesses.php' ? ' active' : '' ?>" href="<?= e(url('businesses.php')) ?>"><span class="mn-ico">&#127969;</span><span>Biz</span></a>
    <a class="mn-link<?= $active === 'daily.php' ? ' active' : '' ?>" href="<?= e(url('daily.php')) ?>"><span class="mn-ico">&#128176;</span><span>Daily</span></a>
    <a class="mn-link<?= $active === 'notifications.php' ? ' active' : '' ?>" href="<?= e(url('notifications.php')) ?>"><span class="mn-ico">&#128276;</span><span>Notif</span></a>
    <?php if (!empty($u['is_admin'])): ?>
    <a class="mn-link<?= $active === 'admin.php' ? ' active' : '' ?>" href="<?= e(url('admin.php')) ?>"><span class="mn-ico">&#9881;</span><span>Admin</span></a>
    <?php endif; ?>
    <a class="mn-link" href="<?= e(url('profile.php')) ?>"><span class="mn-ico">&#128100;</span><span>Profile</span></a>
    <a class="mn-link" href="<?= e(url('logout.php')) ?>"><span class="mn-ico">&#9099;</span><span>Out</span></a>
  </nav>

<main class="content page-enter" id="main-content">
    <?php
    $flashes = take_flashes();
    $showPage = in_array(basename($_SERVER['SCRIPT_NAME'] ?? ''), ['index.php', 'play.php']);
    $dbFlashes = [];
    if (is_logged_in() && $showPage) {
        $uid = (int) $_SESSION['uid'];
        $dbFlashes = db_get_flashes($uid);
        // Session-based: don't re-show flashes already displayed this session
        $shownKey = 'db_flashes_shown';
        $shown = (array)($_SESSION[$shownKey] ?? []);
        $dbFlashes = array_values(array_filter($dbFlashes, function ($f) use (&$shown) {
            if (in_array((int)$f['id'], $shown)) return false;
            $shown[] = (int)$f['id'];
            return true;
        }));
        $_SESSION[$shownKey] = $shown;
    }
    $toastIcons = ['success' => '&#10003;', 'error' => '&#10007;', 'warning' => '&#9888;', 'info' => '&#8505;', 'gold' => '&#128176;'];
    $allFlashes = array_merge(
        array_map(fn($f) => ['msg' => $f['msg'], 'type' => $f['type'], 'id' => null, 'dismissible' => true], $flashes),
        array_map(fn($f) => ['msg' => $f['message'], 'type' => $f['type'], 'id' => (int) $f['id'], 'title' => $f['title'], 'dismissible' => (bool) $f['dismissible']], $dbFlashes)
    );
    if ($allFlashes): ?>
    <div class="toasts" id="toasts" role="status" aria-live="polite">
      <?php foreach ($allFlashes as $f): $t = in_array($f['type'], ['success', 'error', 'warning', 'gold'], true) ? $f['type'] : 'info'; ?>
      <div class="toast toast-<?= e($t) ?>" data-toast data-flash-id="<?= $f['id'] ?? '' ?>" data-dismissible="<?= $f['dismissible'] ? '1' : '0' ?>">
        <?php if (!empty($f['title'])): ?><div class="toast-title"><?= e($f['title']) ?></div><?php endif; ?>
        <span class="toast-ico"><?= $toastIcons[$t] ?? '&#8505;' ?></span>
        <span class="toast-msg"><?= e($f['msg']) ?></span>
        <?php if ($f['dismissible']): ?><button class="toast-close toast-dismiss" type="button" aria-label="Dismiss" data-flash-id="<?= $f['id'] ?? '' ?>">&#10005;</button><?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif;