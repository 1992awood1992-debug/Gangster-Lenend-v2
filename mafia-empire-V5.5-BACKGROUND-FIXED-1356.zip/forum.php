<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$catId = isset($_GET['cat']) ? (int) $_GET['cat'] : null;
$threadId = isset($_GET['thread']) ? (int) $_GET['thread'] : null;

// POST: new thread, reply, lock
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'new_thread' && $catId) {
        $title = trim($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');
        if ($title === '' || $body === '') { flash('Title and body required.', 'error'); }
        else {
            $tid = insert('forum_threads', ['category_id' => $catId, 'user_id' => $u['id'], 'title' => $title, 'created_at' => now(), 'last_post' => now()]);
            insert('forum_posts', ['thread_id' => $tid, 'user_id' => $u['id'], 'body' => $body, 'created_at' => now()]);
            flash('Thread created.', 'success');
            redirect('forum.php?thread=' . $tid);
        }
    } elseif ($action === 'reply' && $threadId) {
        $thread = fetch('SELECT * FROM forum_threads WHERE id = ?', [$threadId]);
        if (!$thread) { flash('Thread not found.', 'error'); }
        elseif ((int) $thread['locked'] === 1) { flash('Thread is locked.', 'error'); }
        else {
            $body = trim($_POST['body'] ?? '');
            if ($body === '') { flash('Reply cannot be empty.', 'error'); }
            else {
                insert('forum_posts', ['thread_id' => $threadId, 'user_id' => $u['id'], 'body' => $body, 'created_at' => now()]);
                q('UPDATE forum_threads SET last_post = ? WHERE id = ?', [now(), $threadId]);
                flash('Reply posted.', 'success');
            }
        }
    } elseif ($action === 'lock' && $threadId && (int) $u['is_admin'] === 1) {
        $thread = fetch('SELECT * FROM forum_threads WHERE id = ?', [$threadId]);
        if ($thread) {
            q('UPDATE forum_threads SET locked = 1 - locked WHERE id = ?', [$threadId]);
            flash('Thread ' . ((int) $thread['locked'] ? 'unlocked' : 'locked') . '.', 'success');
        }
    }
    redirect('forum.php' . ($catId ? '?cat=' . $catId : '') . ($threadId ? ($catId ? '&' : '?') . 'thread=' . $threadId : ''));
}

$page_title = 'Forum';
require __DIR__ . '/includes/header.php';

if ($threadId) {
    // View thread
    $thread = fetch('SELECT ft.*, u.username, u.avatar FROM forum_threads ft JOIN users u ON u.id = ft.user_id WHERE ft.id = ?', [$threadId]);
    if (!$thread) { echo '<div class="card"><p class="muted">Thread not found.</p></div>'; require __DIR__ . '/includes/footer.php'; exit; }
    
    // Increment views once per session
    $viewKey = 'thread_view_' . $threadId;
    if (!isset($_SESSION[$viewKey])) {
        q('UPDATE forum_threads SET views = views + 1 WHERE id = ?', [$threadId]);
        $_SESSION[$viewKey] = true;
    }
    
    $posts = fetch_all('SELECT fp.*, u.username, u.avatar FROM forum_posts fp JOIN users u ON u.id = fp.user_id WHERE fp.thread_id = ? ORDER BY fp.created_at', [$threadId]);
    
?>
<div class="card" style="margin-bottom:18px">
  <a class="btn btn-sm" href="<?= e(url('forum.php')) ?>">&larr; Back to categories</a>
  <?php if ($catId): ?><a class="btn btn-sm" href="<?= e(url('forum.php?cat=' . $catId)) ?>">&larr; Back to <?= e(fetch('SELECT name FROM forum_categories WHERE id = ?', [$catId])['name'] ?? 'Category') ?></a><?php endif; ?>
  <?php if ((int) $u['is_admin'] === 1): ?>
    <form method="post" style="display:inline;margin-left:10px"><?= csrf_field() ?><input type="hidden" name="action" value="lock"><button class="btn btn-sm" type="submit"><?= (int) $thread['locked'] ? 'Unlock' : 'Lock' ?></button></form>
  <?php endif; ?>
</div>

<div class="card">
  <div class="panel-heading"><?= e($thread['title']) ?> <span class="tag tag-<?= (int) $thread['locked'] ? 'common' : 'uncommon' ?>"><?= (int) $thread['locked'] ? 'Locked' : 'Open' ?></span></div>
  <div class="small muted">by <a href="<?= e(url('profile.php?id=' . (int) $thread['user_id'])) ?>"><?= e($thread['username']) ?></a> · <?= date('M j, Y H:i', strtotime($thread['created_at'])) ?> · Views: <?= (int) $thread['views'] ?></div>
</div>

<?php foreach ($posts as $i => $p): ?>
<div class="card" style="margin-top:10px">
  <div style="display:flex;gap:12px;align-items:flex-start">
    <img src="<?= e($p['avatar']) ?>" alt="" class="avatar" onerror="this.src='<?= e(url('assets/img/avatar-default.svg')) ?>'">
    <div style="flex:1">
      <b><a href="<?= e(url('profile.php?id=' . (int) $p['user_id'])) ?>"><?= e($p['username']) ?></a></b>
      <span class="muted small"> · #<?= $i + 1 ?> · <?= date('M j, Y H:i', strtotime($p['created_at'])) ?></span>
      <div style="margin-top:8px;white-space:pre-wrap"><?= e($p['body']) ?></div>
    </div>
  </div>
</div>
<?php endforeach; ?>

<?php if (!(int) $thread['locked']): ?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Reply</div>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="reply">
    <label>Message <textarea name="body" required></textarea></label>
    <button class="btn btn-gold" type="submit">Post Reply</button>
  </form>
</div>
<?php endif; ?>

<?php
} elseif ($catId) {
    // View category
    $cat = fetch('SELECT * FROM forum_categories WHERE id = ?', [$catId]);
    if (!$cat) { echo '<div class="card"><p class="muted">Category not found.</p></div>'; require __DIR__ . '/includes/footer.php'; exit; }
    
    $threads = fetch_all('SELECT ft.*, u.username FROM forum_threads ft JOIN users u ON u.id = ft.user_id WHERE ft.category_id = ? ORDER BY ft.last_post DESC', [$catId]);
?>
<div class="card" style="margin-bottom:18px">
  <a class="btn btn-sm" href="<?= e(url('forum.php')) ?>">&larr; Back to categories</a>
</div>

<div class="card">
  <div class="panel-heading"><?= e($cat['name']) ?></div>
  <form method="post" style="margin-bottom:18px;display:grid;gap:10px;max-width:600px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="new_thread">
    <label>Title <input name="title" maxlength="190" required></label>
    <label>Message <textarea name="body" required></textarea></label>
    <button class="btn btn-gold" type="submit">Create Thread</button>
  </form>
  
  <?php if (!$threads): ?>
    <p class="muted">No threads yet. Start the conversation!</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Thread</th><th>Author</th><th>Replies</th><th>Views</th><th>Last Post</th></tr>
      <?php foreach ($threads as $t):
        $replyCount = (int) fetch_one('SELECT COUNT(*) - 1 FROM forum_posts WHERE thread_id = ?', [$t['id']], 0);
      ?>
        <tr>
          <td><a href="<?= e(url('forum.php?thread=' . (int) $t['id'] . '&cat=' . $catId)) ?>"><b><?= e($t['title']) ?></b></a><?= (int) $t['locked'] ? ' <span class="tag tag-common">🔒</span>' : '' ?></td>
          <td><?= e($t['username']) ?></td>
          <td><?= $replyCount ?></td>
          <td><?= (int) $t['views'] ?></td>
          <td><?= date('M j, H:i', strtotime($t['last_post'])) ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php
} else {
    // List categories
    $cats = fetch_all('SELECT fc.*, COUNT(ft.id) AS threads, COUNT(fp.id) AS posts FROM forum_categories fc LEFT JOIN forum_threads ft ON ft.category_id = fc.id LEFT JOIN forum_posts fp ON fp.thread_id = ft.id GROUP BY fc.id ORDER BY fc.sort_order');
?>
<div class="grid grid-2">
  <?php foreach ($cats as $c): ?>
    <a class="tile" href="<?= e(url('forum.php?cat=' . (int) $c['id'])) ?>">
      <b><?= e($c['name']) ?></b>
      <small><?= e($c['description']) ?></small>
      <div style="margin-top:8px" class="stat"><span>Threads</span><b><?= (int) $c['threads'] ?></b></div>
      <div class="stat"><span>Posts</span><b><?= (int) $c['posts'] ?></b></div>
    </a>
  <?php endforeach; ?>
</div>
<?php
}
require __DIR__ . '/includes/footer.php';