<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'Money';
require __DIR__ . '/includes/header.php';

$u = current_user();
$netWorth = (int) $u['money'] + (int) $u['bank'] + (int) $u['points'] * 100;
$transactions = fetch_all('SELECT * FROM bank_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20', [$u['id']]);
?>
<div class="card">
  <div class="panel-heading">Financial Overview</div>
  <div class="grid grid-4">
    <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
    <div class="stat"><span>Bank</span><b><?= money($u['bank']) ?></b></div>
    <div class="stat"><span>Bullets</span><b><?= number_format((int) $u['bullets']) ?></b></div>
    <div class="stat"><span>Points</span><b><?= number_format((int) $u['points']) ?></b></div>
  </div>
  <div style="margin-top:14px">
    <div class="stat"><span>Net Worth (est.)</span><b><?= money($netWorth) ?></b></div>
  </div>
</div>

<div class="grid grid-4" style="margin-top:18px">
  <a class="tile" href="<?= e(url('bank.php')) ?>"><span class="ico">&#127974;</span><b>Bank</b><small>Deposit, withdraw, transfer</small></a>
  <a class="tile" href="<?= e(url('black-market.php')) ?>"><span class="ico">&#127982;</span><b>Black Market</b><small>Player marketplace</small></a>
  <a class="tile" href="<?= e(url('points_store.php')) ?>"><span class="ico">&#128077;</span><b>Points Store</b><small>Spend points</small></a>
  <a class="tile" href="<?= e(url('bullet_factory.php')) ?>"><span class="ico">&#128299;</span><b>Bullet Factory</b><small>Own & collect</small></a>
  <a class="tile" href="<?= e(url('casino.php')) ?>"><span class="ico">&#127920;</span><b>Casino</b><small>Gamble your cash</small></a>
  <a class="tile" href="<?= e(url('equipment.php')) ?>"><span class="ico">&#9876;</span><b>Equipment</b><small>Buy & equip gear</small></a>
  <a class="tile" href="<?= e(url('escrow.php')) ?>"><span class="ico">&#128274;</span><b>Escrow</b><small>Safe trades</small></a>
  <a class="tile" href="<?= e(url('lottery.php')) ?>"><span class="ico">&#127922;</span><b>Lottery</b><small>Daily draw</small></a>
</div>

<div class="card">
  <div class="panel-heading">Recent Transactions</div>
  <div class="table-wrap"><table>
    <tr><th>+/-</th><th>Amount</th><th>Reason</th><th>Date</th></tr>
    <?php if (!$transactions): ?>
      <tr><td colspan="4" class="muted">No transactions yet.</td></tr>
    <?php else: foreach ($transactions as $t): ?>
      <tr>
        <td><?= (int) $t['amount'] >= 0 ? '<span style="color:var(--green)">+</span>' : '<span style="color:var(--red)">-</span>' ?></td>
        <td><?= money(abs((int) $t['amount'])) ?></td>
        <td><?= e($t['reason']) ?></td>
        <td><?= date('M j, H:i', strtotime($t['created_at'])) ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </table></div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>