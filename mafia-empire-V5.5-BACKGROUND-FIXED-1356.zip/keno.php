<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// Payout multipliers for matches, indexed by spots picked -> matches -> multiplier
$paytable = [
    1 => [1 => 2.4],
    2 => [2 => 12, 1 => 0],
    3 => [3 => 44, 2 => 2],
    4 => [4 => 110, 3 => 5, 2 => 1],
    5 => [5 => 400, 4 => 15, 3 => 2, 2 => 0],
    6 => [6 => 1200, 5 => 50, 4 => 6, 3 => 1],
    7 => [7 => 5000, 6 => 150, 5 => 20, 4 => 3, 3 => 0],
    8 => [8 => 10000, 7 => 500, 6 => 45, 5 => 10, 4 => 2],
    9 => [9 => 15000, 8 => 800, 7 => 80, 6 => 15, 5 => 4],
    10 => [10 => 20000, 9 => 1200, 8 => 150, 7 => 30, 6 => 8, 5 => 2],
];

$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (($_POST['action'] ?? '') === 'play') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        $picks = [];
        for ($i = 1; $i <= 80; $i++) {
            $v = (int) ($_POST["n$i"] ?? 0);
            if ($v >= 1 && $v <= 80) { $picks[] = $v; }
        }
        $picks = array_values(array_unique($picks));
        if (count($picks) < 1 || count($picks) > 10) {
            flash('Pick 1 to 10 numbers (1-80).', 'error');
            redirect('keno.php');
        }
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('keno.php'); }
        add_money($u['id'], -$stake, 'Keno bet');
        $balls = range(1, 80);
        shuffle($balls);
        $drawn = array_slice($balls, 0, 20);
        $matches = array_intersect($picks, $drawn);
        $n = count($matches);
        $mult = $paytable[count($picks)][$n] ?? 0;
        $payout = (int) floor($stake * $mult);
        if ($payout > 0) { add_money($u['id'], $payout, 'Keno win'); event_track('casino_won', (int) $payout); }
        insert('casino_bets', ['user_id' => $u['id'], 'game' => 'keno', 'stake' => $stake, 'payout' => $payout, 'detail' => count($picks) . ' spots, ' . $n . ' matched']);
        $result = ['picks' => $picks, 'drawn' => $drawn, 'matches' => $matches, 'stake' => $stake, 'payout' => $payout, 'n' => $n];
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'keno', json_encode(['last' => $result])]);
    }
    redirect('keno.php');
}

$saved = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'keno']);
$saved = $saved ? json_decode($saved['state'], true) : null;
$result = $saved['last'] ?? null;

$page_title = 'Keno';
require __DIR__ . '/includes/header.php';
$u = current_user();
?>
<div class="card">
  <div class="panel-heading">Keno</div>
  <p class="muted small">Pick up to 10 numbers (1–80). The house draws 20 balls. Match enough to win up to 20,000× your bet.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<div class="card">
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="play">
    <div class="keno-grid" style="max-width:100%;overflow-x:auto">
      <?php for ($i = 1; $i <= 80; $i++): ?>
        <label class="keno-cell" title="Number <?= $i ?>">
          <input type="checkbox" name="n<?= $i ?>" value="<?= $i ?>" class="keno-cb">
          <span><?= $i ?></span>
        </label>
      <?php endfor; ?>
    </div>
    <div style="max-width:360px;margin-top:12px">
      <label>Wager (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="25" required></label>
      <button class="btn btn-gold btn-block" type="submit">Draw 20 Balls</button>
    </div>
  </form>
</div>

<?php if ($result): ?>
<div class="card">
  <div class="panel-heading"><?= $result['n'] ?> match<?= $result['n'] === 1 ? '' : 'es' ?> — Returned <?= money($result['payout']) ?></div>
  <p class="muted small">Your picks:</p>
  <div class="keno-grid">
    <?php for ($i = 1; $i <= 80; $i++): $isPick = in_array($i, $result['picks'], true); ?>
      <span class="keno-tile <?= $isPick && in_array($i, $result['matches'], true) ? 'hit' : ($isPick ? 'pick' : '') ?>"><?= $i ?></span>
    <?php endfor; ?>
  </div>
  <p class="muted small" style="margin-top:8px">Drawn: <?= implode(' ', array_map(fn($b) => '<b>' . $b . '</b>', $result['drawn'])) ?></p>
</div>
<?php endif; ?>

<div class="card">
  <div class="panel-heading">Payouts</div>
  <div class="table-wrap" style="overflow-x:auto"><table>
    <tr><th>Spots</th><th colspan="10">Matches (multiplier × bet)</th></tr>
    <?php foreach ($paytable as $spots => $row): ?>
      <tr><td><b><?= $spots ?></b></td>
        <?php for ($m = $spots; $m >= max(1, $spots - 4); $m--): ?>
          <td><?= $m ?> → <?= $row[$m] ?? 0 ?>×</td>
        <?php endfor; ?>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<style>
.keno-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(44px,1fr));gap:5px;max-width:940px}
.keno-cell{position:relative;text-align:center}
.keno-cb{position:absolute;opacity:0;width:100%;height:100%;cursor:pointer;z-index:2}
.keno-cell span,.keno-tile{display:flex;align-items:center;justify-content:center;height:38px;background:#241d19;border:1px solid #4a3b29;border-radius:4px;color:#c9b27a;font-size:.85rem}
.keno-cb:checked + span,.keno-tile.pick{background:#3a2f14;border-color:#d9a441;color:#ffd98a;font-weight:700}
.keno-tile.hit{background:#2c4a2c;border-color:#5fae5f;color:#a8e0a8;font-weight:700;box-shadow:0 0 8px rgba(95,174,95,.6)}
</style>
<?php require __DIR__ . '/includes/footer.php'; ?>