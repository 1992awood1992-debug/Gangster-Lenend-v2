#!/usr/bin/env bash
#
# Mafia Empire - database backup.
#
# Creates a gzipped mysqldump in ./backups and prunes backups older than
# RETENTION_DAYS. Safe for cron / docker exec.
#
#   ./scripts/backup.sh
#
# Override any of the DB_*/BACKUP_DIR/RETENTION_DAYS vars via the environment.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-3306}"
DB_NAME="${DB_NAME:-mafia_empire}"
DB_USER="${DB_USER:-root}"
DB_PASS="${DB_PASS:-}"
BACKUP_DIR="${BACKUP_DIR:-$ROOT_DIR/backups}"
RETENTION_DAYS="${RETENTION_DAYS:-14}"
MYSQLDUMP="${MYSQLDUMP:-mysqldump}"

mkdir -p "$BACKUP_DIR"
STAMP="$(date +%Y%m%d_%H%M%S)"
OUT="$BACKUP_DIR/${DB_NAME}_${STAMP}.sql.gz"

export MYSQL_PWD="$DB_PASS"
"$MYSQLDUMP" \
    --host="$DB_HOST" --port="$DB_PORT" --user="$DB_USER" \
    --single-transaction --quick --routines --triggers --events \
    --default-character-set=utf8mb4 \
    "$DB_NAME" | gzip -9 > "$OUT"
unset MYSQL_PWD

# Prune old backups.
find "$BACKUP_DIR" -type f -name "${DB_NAME}_*.sql.gz" -mtime +"$RETENTION_DAYS" -delete

SIZE="$(du -h "$OUT" | cut -f1)"
echo "Backup written: $OUT ($SIZE)"
