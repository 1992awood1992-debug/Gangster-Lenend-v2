<?php
/**
 * Eye Of The Mafia - Property / Safehouse System
 * Buy, upgrade, and collect income from properties.
 */

require_once __DIR__ . '/init.php';

/**
 * Get all available property types
 */
function property_get_types(): array
{
    return fetch_all("
        SELECT * FROM property_types 
        WHERE is_active = 1 
        ORDER BY base_price
    ");
}

/**
 * Get user's properties
 */
function property_get_user(int $userId): array
{
    return fetch_all("
        SELECT up.*, pt.name, pt.code, pt.description, 
               pt.income_money_per_hour, pt.income_bullets_per_hour, pt.income_points_per_hour,
               pt.storage_items, pt.storage_drugs, pt.storage_bullets,
               pt.upgrade_money_base, pt.upgrade_bullets_base, pt.upgrade_points_base
        FROM user_properties up
        JOIN property_types pt ON pt.id = up.property_type_id
        WHERE up.user_id = ? AND up.is_active = 1
        ORDER BY pt.base_price
    ", [$userId]);
}

/**
 * Get a specific user property
 */
function property_get_user_property(int $userId, int $propertyId): ?array
{
    return fetch("
        SELECT up.*, pt.name, pt.code, pt.description, pt.base_price, pt.max_level,
               pt.income_money_per_hour, pt.income_bullets_per_hour, pt.income_points_per_hour,
               pt.storage_items, pt.storage_drugs, pt.storage_bullets,
               pt.upgrade_money_base, pt.upgrade_bullets_base, pt.upgrade_points_base
        FROM user_properties up
        JOIN property_types pt ON pt.id = up.property_type_id
        WHERE up.id = ? AND up.user_id = ? AND up.is_active = 1
    ", [$propertyId, $userId]);
}

/**
 * Check if user can afford a property
 */
function property_can_buy(int $userId, int $propertyTypeId): array
{
    $user = fetch('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$user) return ['ok' => false, 'error' => 'User not found'];

    $type = fetch('SELECT * FROM property_types WHERE id = ? AND is_active = 1', [$propertyTypeId]);
    if (!$type) return ['ok' => false, 'error' => 'Property type not found'];

    // Check if already owned
    $existing = fetch('SELECT id FROM user_properties WHERE user_id = ? AND property_type_id = ? AND is_active = 1', [$userId, $propertyTypeId]);
    if ($existing) return ['ok' => false, 'error' => 'Already owned'];

    if ((int) $user['money'] < (int) $type['base_price']) {
        return ['ok' => false, 'error' => 'Not enough cash'];
    }

    if ((int) $user['level'] < 5) { // Minimum level to own property
        return ['ok' => false, 'error' => 'Level 5 required to own property'];
    }

    return ['ok' => true, 'type' => $type, 'user' => $user];
}

/**
 * Buy a property
 */
function property_buy(int $userId, int $propertyTypeId): array
{
    $check = property_can_buy($userId, $propertyTypeId);
    if (!$check['ok']) return $check;

    $type = $check['type'];

    // Deduct money
    add_money($userId, -(int) $type['base_price'], 'Property purchase: ' . $type['name']);

    // Create property
    $propertyId = insert('user_properties', [
        'user_id' => $userId,
        'property_type_id' => $propertyTypeId,
        'level' => 1,
        'last_collected_at' => date('Y-m-d H:i:s'),
    ]);

    analytics_track('property_buy', $userId, [
        'property_type' => (int) $propertyTypeId,
        'cost' => (int) $type['base_price'],
    ]);

    return ['ok' => true, 'property_id' => $propertyId];
}

/**
 * Calculate upgrade cost for a property
 */
function property_upgrade_cost(array $property, int $targetLevel = null): array
{
    $type = $property;
    $currentLevel = (int) $property['level'];
    $targetLevel = $targetLevel ?? ($currentLevel + 1);

    if ($targetLevel > (int) $type['max_level']) {
        return ['ok' => false, 'error' => 'Max level reached'];
    }

    $money = 0;
    $bullets = 0;
    $points = 0;

    for ($lvl = $currentLevel + 1; $lvl <= $targetLevel; $lvl++) {
        $money += (int) floor((int) $type['upgrade_money_base'] * pow($lvl, 1.5));
        $bullets += (int) floor((int) $type['upgrade_bullets_base'] * pow($lvl, 1.5));
        $points += (int) floor((int) $type['upgrade_points_base'] * pow($lvl, 1.3));
    }

    return ['ok' => true, 'money' => $money, 'bullets' => $bullets, 'points' => $points];
}

/**
 * Upgrade a property
 */
function property_upgrade(int $userId, int $propertyId, int $targetLevel = null): array
{
    $prop = property_get_user_property($userId, $propertyId);
    if (!$prop) return ['ok' => false, 'error' => 'Property not found'];

    $cost = property_upgrade_cost($prop, $targetLevel);
    if (!$cost['ok']) return $cost;

    // Check resources
    $user = fetch('SELECT money, bullets, points FROM users WHERE id = ?', [$userId]);
    if ((int) $user['money'] < $cost['money']) return ['ok' => false, 'error' => 'Not enough cash'];
    if ((int) $user['bullets'] < $cost['bullets']) return ['ok' => false, 'error' => 'Not enough bullets'];
    if ((int) $user['points'] < $cost['points']) return ['ok' => false, 'error' => 'Not enough points'];

    // Deduct resources
    add_money($userId, -$cost['money'], 'Property upgrade');
    q('UPDATE users SET bullets = bullets - ?, points = points - ? WHERE id = ?', [$cost['bullets'], $cost['points'], $userId]);

    // Upgrade
    $newLevel = $targetLevel ?? ((int) $prop['level'] + 1);
    q('UPDATE user_properties SET level = ?, upgraded_at = NOW() WHERE id = ?', [$newLevel, $propertyId]);

    analytics_track('property_upgrade', $userId, [
        'property_id' => $propertyId,
        'new_level' => $newLevel,
        'cost_money' => $cost['money'],
        'cost_bullets' => $cost['bullets'],
        'cost_points' => $cost['points'],
    ]);

    return ['ok' => true, 'new_level' => $newLevel];
}

/**
 * Collect income from a property
 */
function property_collect(int $userId, int $propertyId): array
{
    $prop = property_get_user_property($userId, $propertyId);
    if (!$prop) return ['ok' => false, 'error' => 'Property not found'];

    $now = new DateTime();
    $last = $prop['last_collected_at'] ? new DateTime($prop['last_collected_at']) : $now;
    $hours = max(1, floor(($now->getTimestamp() - $last->getTimestamp()) / 3600));

    // Cap at 24 hours of accumulation
    $hours = min($hours, 24);

    $level = (int) $prop['level'];
    $money = (int) $prop['income_money_per_hour'] * $hours * $level;
    $bullets = (int) $prop['income_bullets_per_hour'] * $hours * $level;
    $points = (int) $prop['income_points_per_hour'] * $hours * $level;

    if ($money <= 0 && $bullets <= 0 && $points <= 0) {
        return ['ok' => false, 'error' => 'No income to collect'];
    }

    // Grant rewards
    if ($money > 0) add_money($userId, $money, 'Property income: ' . $prop['name']);
    if ($bullets > 0) q('UPDATE users SET bullets = bullets + ? WHERE id = ?', [$bullets, $userId]);
    if ($points > 0) add_points($userId, $points);

    // Update last collected
    q('UPDATE user_properties SET last_collected_at = NOW() WHERE id = ?', [$propertyId]);

    // Log
    insert('property_income_log', [
        'user_id' => $userId,
        'property_id' => $propertyId,
        'money' => $money,
        'bullets' => $bullets,
        'points' => $points,
    ]);

    analytics_track('property_collect', $userId, [
        'property_id' => $propertyId,
        'hours' => $hours,
        'money' => $money,
        'bullets' => $bullets,
        'points' => $points,
    ]);

    return ['ok' => true, 'money' => $money, 'bullets' => $bullets, 'points' => $points, 'hours' => $hours];
}

/**
 * Collect from all properties (cron or manual)
 */
function property_collect_all(int $userId): array
{
    $props = property_get_user($userId);
    $total = ['money' => 0, 'bullets' => 0, 'points' => 0];

    foreach ($props as $prop) {
        $result = property_collect($userId, (int) $prop['id']);
        if ($result['ok']) {
            $total['money'] += $result['money'];
            $total['bullets'] += $result['bullets'];
            $total['points'] += $result['points'];
        }
    }

    return ['ok' => true, ...$total];
}

/**
 * Rename a property
 */
function property_rename(int $userId, int $propertyId, string $nickname): array
{
    $prop = property_get_user_property($userId, $propertyId);
    if (!$prop) return ['ok' => false, 'error' => 'Property not found'];

    $nickname = trim($nickname);
    if (strlen($nickname) > 100) return ['ok' => false, 'error' => 'Nickname too long'];

    q('UPDATE user_properties SET nickname = ? WHERE id = ?', [$nickname ?: null, $propertyId]);

    return ['ok' => true];
}

/**
 * Sell a property (50% of current value)
 */
function property_sell(int $userId, int $propertyId): array
{
    $prop = property_get_user_property($userId, $propertyId);
    if (!$prop) return ['ok' => false, 'error' => 'Property not found'];

    $type = $prop;
    $currentValue = (int) $type['base_price'];
    for ($lvl = 2; $lvl <= (int) $prop['level']; $lvl++) {
        $currentValue += (int) floor((int) $type['upgrade_money_base'] * pow($lvl, 1.5));
    }
    $salePrice = (int) floor($currentValue * 0.5);

    // Deactivate
    q('UPDATE user_properties SET is_active = 0 WHERE id = ?', [$propertyId]);

    // Refund
    add_money($userId, $salePrice, 'Property sale: ' . $prop['name']);

    analytics_track('property_sell', $userId, [
        'property_id' => $propertyId,
        'sale_price' => $salePrice,
    ]);

    return ['ok' => true, 'sale_price' => $salePrice];
}

/**
 * Get property income preview (for UI)
 */
function property_get_income_preview(array $property): array
{
    $level = (int) $property['level'];
    return [
        'per_hour' => [
            'money' => (int) $property['income_money_per_hour'] * $level,
            'bullets' => (int) $property['income_bullets_per_hour'] * $level,
            'points' => (int) $property['income_points_per_hour'] * $level,
        ],
        'per_day' => [
            'money' => (int) $property['income_money_per_hour'] * $level * 24,
            'bullets' => (int) $property['income_bullets_per_hour'] * $level * 24,
            'points' => (int) $property['income_points_per_hour'] * $level * 24,
        ],
    ];
}

/**
 * Properties 2.0: Crew Bases
 * Shared properties owned by crews with defense, storage, and buffs
 */

/**
 * Get crew base property types
 */
function property_get_crew_base_types(): array
{
    return fetch_all("
        SELECT * FROM property_types 
        WHERE is_crew_base = 1 AND is_active = 1 
        ORDER BY base_price
    ");
}

/**
 * Get a crew's base (if any)
 */
function property_get_crew_base(int $crewId): ?array
{
    $base = fetch("
        SELECT up.*, pt.name, pt.code, pt.description, pt.base_price, pt.max_level,
               pt.income_money_per_hour, pt.income_bullets_per_hour, pt.income_points_per_hour,
               pt.storage_items, pt.storage_drugs, pt.storage_bullets,
               pt.defense_bonus, pt.raid_protection, pt.crew_xp_bonus,
               pt.upgrade_money_base, pt.upgrade_bullets_base, pt.upgrade_points_base
        FROM user_properties up
        JOIN property_types pt ON pt.id = up.property_type_id
        WHERE up.crew_id = ? AND up.is_active = 1 AND pt.is_crew_base = 1
        LIMIT 1
    ", [$crewId]);
    
    if ($base) {
        $base['level'] = (int) $base['level'];
        $base['income_preview'] = property_get_income_preview($base);
    }
    return $base;
}

/**
 * Check if crew can buy a base
 */
function property_crew_can_buy(int $crewId, int $propertyTypeId): array
{
    $crew = fetch('SELECT * FROM crews WHERE id = ?', [$crewId]);
    if (!$crew) return ['ok' => false, 'error' => 'Crew not found'];

    $type = fetch('SELECT * FROM property_types WHERE id = ? AND is_active = 1 AND is_crew_base = 1', [$propertyTypeId]);
    if (!$type) return ['ok' => false, 'error' => 'Crew base type not found'];

    // Check if crew already has a base
    $existing = fetch('SELECT id FROM user_properties WHERE crew_id = ? AND is_active = 1 AND property_type_id IN (SELECT id FROM property_types WHERE is_crew_base = 1)', [$crewId]);
    if ($existing) return ['ok' => false, 'error' => 'Crew already has a base'];

    // Check crew vault funds
    if ((int) $crew['vault_money'] < (int) $type['base_price']) {
        return ['ok' => false, 'error' => 'Crew vault has insufficient funds'];
    }

    // Check if crew leader or officer is initiating
    // This will be checked at the calling page level

    return ['ok' => true, 'type' => $type, 'crew' => $crew];
}

/**
 * Buy a crew base
 */
function property_crew_buy(int $crewId, int $userId, int $propertyTypeId): array
{
    $check = property_crew_can_buy($crewId, $propertyTypeId);
    if (!$check['ok']) return $check;

    $type = $check['type'];
    $crew = $check['crew'];

    // Deduct from crew vault
    q('UPDATE crews SET vault_money = vault_money - ? WHERE id = ?', [(int) $type['base_price'], $crewId]);

    // Create property owned by crew
    $propertyId = insert('user_properties', [
        'user_id' => $userId,
        'crew_id' => $crewId,
        'property_type_id' => $propertyTypeId,
        'level' => 1,
        'last_collected_at' => date('Y-m-d H:i:s'),
    ]);

    // Log
    insert('crew_logs', [
        'crew_id' => $crewId,
        'user_id' => $userId,
        'action' => 'buy_base',
        'details' => "Purchased crew base: {$type['name']} for " . money((int) $type['base_price']),
        'created_at' => date('Y-m-d H:i:s'),
    ]);

    return ['ok' => true, 'property_id' => $propertyId];
}

/**
 * Upgrade a crew base
 */
function property_crew_upgrade(int $crewId, int $userId, int $propertyId, int $targetLevel = null): array
{
    $base = property_get_crew_base($crewId);
    if (!$base || (int) $base['id'] !== $propertyId) {
        return ['ok' => false, 'error' => 'Crew base not found'];
    }

    // Check permissions (leader/officer)
    $member = fetch('SELECT rank FROM crew_members WHERE crew_id = ? AND user_id = ?', [$crewId, $userId]);
    if (!$member || !in_array($member['rank'], ['Leader', 'Officer'])) {
        return ['ok' => false, 'error' => 'Only Leaders and Officers can upgrade the base'];
    }

    $cost = property_upgrade_cost($base, $targetLevel);
    if (!$cost['ok']) return $cost;

    // Check crew vault
    if ((int) $base['vault_money'] < $cost['money']) {
        return ['ok' => false, 'error' => 'Crew vault has insufficient funds'];
    }

    // Deduct from crew vault (money only for crew bases)
    q('UPDATE crews SET vault_money = vault_money - ? WHERE id = ?', [$cost['money'], $crewId]);

    $newLevel = $targetLevel ?? ((int) $base['level'] + 1);
    q('UPDATE user_properties SET level = ?, upgraded_at = NOW() WHERE id = ?', [$newLevel, $propertyId]);

    insert('crew_logs', [
        'crew_id' => $crewId,
        'user_id' => $userId,
        'action' => 'upgrade_base',
        'details' => "Upgraded crew base to level {$newLevel} for " . money($cost['money']),
        'created_at' => date('Y-m-d H:i:s'),
    ]);

    return ['ok' => true, 'new_level' => $newLevel];
}

/**
 * Collect income from crew base (goes to crew vault)
 */
function property_crew_collect(int $crewId, int $userId, int $propertyId): array
{
    $base = property_get_crew_base($crewId);
    if (!$base || (int) $base['id'] !== $propertyId) {
        return ['ok' => false, 'error' => 'Crew base not found'];
    }

    $now = new DateTime();
    $last = $base['last_collected_at'] ? new DateTime($base['last_collected_at']) : $now;
    $hours = max(1, floor(($now->getTimestamp() - $last->getTimestamp()) / 3600));
    $hours = min($hours, 24);

    $level = (int) $base['level'];
    $money = (int) $base['income_money_per_hour'] * $hours * $level;
    $bullets = (int) $base['income_bullets_per_hour'] * $hours * $level;
    $points = (int) $base['income_points_per_hour'] * $hours * $level;
    $crewXp = (int) ($base['crew_xp_bonus'] ?? 0) * $hours * $level;

    if ($money <= 0 && $bullets <= 0 && $points <= 0 && $crewXp <= 0) {
        return ['ok' => false, 'error' => 'No income to collect'];
    }

    // Add to crew vault
    if ($money > 0) q('UPDATE crews SET vault_money = vault_money + ? WHERE id = ?', [$money, $crewId]);
    if ($bullets > 0) q('UPDATE crews SET vault_bullets = vault_bullets + ? WHERE id = ?', [$bullets, $crewId]);
    if ($points > 0) q('UPDATE crews SET vault_points = vault_points + ? WHERE id = ?', [$points, $crewId]);
    if ($crewXp > 0) q('UPDATE crews SET xp = xp + ? WHERE id = ?', [$crewXp, $crewId]);

    q('UPDATE user_properties SET last_collected_at = NOW() WHERE id = ?', [$propertyId]);

    insert('crew_logs', [
        'crew_id' => $crewId,
        'user_id' => $userId,
        'action' => 'collect_base',
        'details' => "Collected base income: " . money($money) . ", {$bullets} bullets, {$points} pts, {$crewXp} crew XP",
        'created_at' => date('Y-m-d H:i:s'),
    ]);

    return ['ok' => true, 'money' => $money, 'bullets' => $bullets, 'points' => $points, 'crew_xp' => $crewXp, 'hours' => $hours];
}

/**
 * Get safehouse defense stats (for raid protection)
 */
function property_get_safehouse_defense(int $userId): array
{
    $props = property_get_user($userId);
    $totalDefense = 0;
    $totalStorage = ['items' => 0, 'drugs' => 0, 'bullets' => 0];
    
    foreach ($props as $p) {
        $level = (int) $p['level'];
        $totalDefense += (int) ($p['defense_bonus'] ?? 0) * $level;
        $totalStorage['items'] += (int) ($p['storage_items'] ?? 0) * $level;
        $totalStorage['drugs'] += (int) ($p['storage_drugs'] ?? 0) * $level;
        $totalStorage['bullets'] += (int) ($p['storage_bullets'] ?? 0) * $level;
    }
    
    // Crew base defense bonus
    $crewBase = property_get_crew_base((int) ($p['crew_id'] ?? 0) ?? 0);
    if ($crewBase) {
        $totalDefense += (int) ($crewBase['defense_bonus'] ?? 0) * (int) $crewBase['level'];
    }

    return [
        'defense' => $totalDefense,
        'storage' => $totalStorage,
        'raid_protection' => min(100, $totalDefense), // % chance to defend raid
    ];
}

/**
 * Apply safehouse defense during a raid
 */
function property_apply_raid_defense(int $attackerId, int $defenderId): array
{
    $defense = property_get_safehouse_defense($defenderId);
    $protection = $defense['raid_protection'];
    
    // Roll for defense
    $roll = mt_rand(1, 100);
    $defended = $roll <= $protection;
    
    return [
        'defended' => $defended,
        'roll' => $roll,
        'protection_chance' => $protection,
        'defense_rating' => $defense['defense'],
        'storage' => $defense['storage'],
    ];
}