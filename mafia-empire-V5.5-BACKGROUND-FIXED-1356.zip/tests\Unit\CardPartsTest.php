<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

/**
 * card_parts() must split multi-byte suit glyphs correctly.
 *
 * Regression guard: the original games used substr($card, 0, -1), which
 * truncated one *byte* and mangled the 3-byte suit symbols, causing every
 * blackjack hand to be valued incorrectly.
 */
final class CardPartsTest extends TestCase
{
    /** @return array<string, array{string, string, string}> */
    public static function cards(): array
    {
        return [
            'ace of spades'   => ['A♠', 'A', '♠'],
            'ten of hearts'   => ['10♥', '10', '♥'],
            'king of diamonds' => ['K♦', 'K', '♦'],
            'queen of clubs'  => ['Q♣', 'Q', '♣'],
            'two of spades'   => ['2♠', '2', '♠'],
            'jack of hearts'  => ['J♥', 'J', '♥'],
        ];
    }

    #[DataProvider('cards')]
    public function testSplitsRankAndSuit(string $card, string $rank, string $suit): void
    {
        $this->assertSame([$rank, $suit], card_parts($card));
    }

    public function testTenKeepsBothDigits(): void
    {
        [$rank, $suit] = card_parts('10♦');
        $this->assertSame('10', $rank);
        $this->assertSame('♦', $suit);
    }

    public function testSuitGlyphIsThreeUtf8Bytes(): void
    {
        [, $suit] = card_parts('A♠');
        $this->assertSame(3, strlen($suit));
        $this->assertSame(1, mb_strlen($suit));
    }

    public function testUnknownSuitReturnsWholeCard(): void
    {
        $this->assertSame(['7', ''], card_parts('7'));
        $this->assertSame(['', ''], card_parts(''));
    }
}
