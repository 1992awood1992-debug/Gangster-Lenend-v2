<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

define('CRASH_RATE', 0.12); // multiplier gain per second

function crash_point(): float
{
    $r = mt_rand(1, 10000) / 10000;
    // r^2 skews low: most rounds crash under 2x, rare high wins
    return round(1 + ($r * $r * 8), 2);
}

function crash_current(array $st): array
{
    // Returns [mult, crashed]
    $el = microtime(true) - (float) $st['started'];
    $mult = 1 + $el * CRASH_RATE;
    $crashed = $mult >= (float) $st['crash'];
    return [$crashed ? (float) $st['crash'] : round($mult, 2), $crashed];
}

$st = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'crash']);
$st = $st ? json_decode($st['state'], true) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'start') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('crash.php'); }
        add_money($u['id'], -$stake, 'Crash bet');
        $st = ['stake' => $stake, 'crash' => crash_point(), 'started' => microtime(true) - 0.02, 'settled' => false, 'payout' => 0];
    } elseif ($action === 'cashout' && $st && !$st['settled']) {
        [$mult, $crashed] = crash_current($st);
        if ($crashed) {
            $st['settled'] = true;
            $st['payout'] = 0;
            $st['msg'] = 'CRASHED at ' . $mult . '× — bet lost.';
            insert('casino_bets', ['user_id' => $u['id'], 'game' => 'crash', 'stake' => $st['stake'], 'payout' => 0, 'detail' => 'Crashed at ' . $mult . 'x']);
        } else {
            $payout = (int) floor($st['stake'] * $mult);
            add_money($u['id'], $payout, 'Crash cashout');
            event_track('casino_won', (int) $payout);
            $st['settled'] = true;
            $st['payout'] = $payout;
            $st['msg'] = 'Cashed out at ' . $mult . '× for ' . money($payout) . '!';
            insert('casino_bets', ['user_id' => $u['id'], 'game' => 'crash', 'stake' => $st['stake'], 'payout' => $payout, 'detail' => 'Cashed out ' . $mult . 'x']);
        }
    } elseif ($action === 'new' && $st && $st['settled']) {
        $st = null;
        q('DELETE FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'crash']);
        redirect('crash.php');
    }
    if ($st) {
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'crash', json_encode($st)]);
    }
    redirect('crash.php');
}

// Auto-settle if the round crashed while the player was away
if ($st && !$st['settled']) {
    [$mult, $crashed] = crash_current($st);
    if ($crashed) {
        $st['settled'] = true;
        $st['payout'] = 0;
        $st['msg'] = 'CRASHED at ' . $mult . '× — bet lost.';
        insert('casino_bets', ['user_id' => $u['id'], 'game' => 'crash', 'stake' => $st['stake'], 'payout' => 0, 'detail' => 'Crashed at ' . $mult . 'x']);
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'crash', json_encode($st)]);
    }
}
$curMult = $st && !$st['settled'] ? crash_current($st)[0] : ($st['crash'] ?? 1.0);

$page_title = 'Crash';
require __DIR__ . '/includes/header.php';
$u = current_user();
?>
<style>
.crash-box{font-size:4.5rem;font-weight:800;text-align:center;padding:30px 0;color:#d9a441;text-shadow:0 0 22px rgba(217,164,65,.45);letter-spacing:2px;min-height:120px}
.crash-box.bust{color:#e0524a;text-shadow:0 0 22px rgba(224,82,74,.5)}
.crash-box.win{color:#5fae5f;text-shadow:0 0 22px rgba(95,174,95,.5)}
</style>
<div class="card">
  <div class="panel-heading">Crash</div>
  <p class="muted small">The multiplier climbs... cash out before it crashes. Every second the multiplier rises by 0.12×. Too slow, and it's gone.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<?php if (!$st): ?>
<div class="card">
  <form method="post" style="max-width:300px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="start">
    <label>Bet (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="50" required></label>
    <button class="btn btn-gold btn-block" type="submit">Start Round</button>
  </form>
</div>
<?php else: ?>
<div class="card">
  <div class="panel-heading"><?= $st['settled'] ? 'Round Over — Bet: ' . money($st['stake']) : 'Round Live — Bet: ' . money($st['stake']) ?></div>
  <?php if (!empty($st['msg'])): ?><div class="alert alert-<?= $st['payout'] > 0 ? 'success' : 'error' ?>"><?= e($st['msg']) ?></div><?php endif; ?>
  <div class="crash-box <?= $st['settled'] ? ($st['payout'] > 0 ? 'win' : 'bust') : '' ?>" id="multBox"><?= number_format($curMult, 2) ?>×</div>
  <?php if ($st['settled']): ?>
    <div class="stat"><span>Returned</span><b><?= money($st['payout']) ?></b></div>
    <form method="post" style="margin-top:12px"><?= csrf_field() ?><input type="hidden" name="action" value="new"><button class="btn btn-gold" type="submit">New Round</button></form>
  <?php else: ?>
    <form method="post" style="margin-top:12px"><?= csrf_field() ?><input type="hidden" name="action" value="cashout"><button class="btn btn-green btn-lg" type="submit">Cash Out</button></form>
    <meta http-equiv="refresh" content="1">
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if ($st && !$st['settled']): ?>
<script>
// Smooth client-side ticker; the server remains authoritative on cashout.
(function(){
  var start = <?= (float) $st['started'] ?> * 1000;
  var rate = <?= CRASH_RATE ?>;
  var box = document.getElementById('multBox');
  function tick(){
    var el = (Date.now() - start) / 1000;
    var m = 1 + el * rate;
    box.textContent = m.toFixed(2) + '\u00D7';
  }
  setInterval(tick, 100);
})();
</script>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>