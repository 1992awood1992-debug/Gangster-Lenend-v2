# Mafia Empire - Developer Spec (for page modules)

Project: `C:\Users\ash\Documents\Default Project\mafia-empire`
Stack: PHP 8.2, MySQL/MariaDB (PDO). PHP binary: `C:\xampp\php\php.exe`
Local URL: http://localhost/mafia-empire/

## Required reading before writing a page
`includes/functions.php`, `includes/game.php`, `includes/db.php`, `includes/header.php`,
`includes/footer.php`, `sql/schema.sql`, `play.php` (example), `assets/style.css`.

## Page skeleton (follow exactly)
```php
<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();              // omit for public pages

// 1) Handle POST mutations BEFORE any output (Post/Redirect/Get)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    // validate, mutate, then:
    flash('Done.', 'success');
    redirect('this_page.php');
}

$page_title = 'Page Name';
require __DIR__ . '/includes/header.php';   // includes init + prints layout/nav
// 2) echo the page body inside <div class="card"> panels
require __DIR__ . '/includes/footer.php';
```

For GET actions that mutate (e.g. `?buy=1`), prefer POST forms. If you must use GET, still
call `csrf_verify()` only on POST and validate ownership server-side.

## Database helpers (prepared statements only)
`q($sql,$params)` -> PDOStatement; `fetch($sql,$params)`; `fetch_all(...)`; `fetch_one($sql,$params,$default)`;
`insert($table, $assocArray)` -> id; `update_row($table, $assocArray, $where, $params)`; `now()`.

## Game / utility helpers
`redirect($path)`, `url($path)`, `e($s)`, `money($n)`, `flash($msg,$type)`, notify($uid,$text,$link)`,
`log_event($uid,$type,$text,$amount)`, `add_money($uid,$delta,$reason`,`$bank=false)`, `add_bullets($uid,$delta)`,
`add_points($uid,$delta)`, `grant_xp($uid,$xp)`, `rank_for_level($lvl)`, `is_hospitalized($u)`, `xp_for_level($lvl)`,
`combat_power($uid)`, `resolve_fight($aRow,$bRow)`, `award_kill($aRow,$vRow)`, `hospitalize($uid,$sec,$reason,$victimRow)`.

The logged-in user row is `$u` (energy/nerve/health already regenerated this request). Re-fetch after mutations:
`$fresh = fetch('SELECT * FROM users WHERE id = ?', [$u['id']]);`

## Security & correctness
- Never trust client values. Cast ints: `(int) $_POST['x']`. Reject non-positive amounts.
- Guard: sufficient cash/points/energy/nerve/bullets/health, level requirements, ownership.
- Always `<?= e($row['col']) ?>` escape output. `<?= csrf_field() ?>` inside every form.
- Use `?>` carefully; prefer echoing HTML.

## Styling (from assets/style.css)
`.card`, `.panel-heading`, `.grid .grid-2/.grid-3/.grid-4`, `.btn .btn-gold/.btn-green/.btn-danger/.btn-sm/.btn-block`,
`.table-wrap table`, `.stat` (flex row label/value), `.tag .tag-common/.tag-uncommon/.tag-rare/.tag-epic/.tag-legendary`,
`.progress > i`, `.tile`, `.big`, `.muted`, `.small`, `.center`, `.right`, `.alert .alert-success/.alert-error/.alert-info/.alert-gold`,
`.pill`, `.pill.on`, `.avatar`, `.playing-card`.

## Tables (columns in sql/schema.sql)
users, ranks, districts, settings, notifications, event_log, bank_transactions, missions, user_missions,
gyms, bosses, boss_fights, criminal_jobs, user_job_cooldowns, abilities, user_abilities, drugs, user_drugs,
items, user_items, market_listings, escrow, bullet_factories, points_store, lottery_draws, lottery_tickets,
casino_bets, casino_state, crews, crew_members, crew_invites, forum_categories, forum_threads, forum_posts,
achievements, user_achievements, stickers, user_stickers, scratch_cards, referral_rewards, updates,
update_votes, update_comments, suggestions, suggestion_votes, suggestion_comments, support_tickets,
support_replies, faqs, kill_log.

## Definition of done
1. Every assigned file exists and contains complete, working PHP.
2. Lint clean: `& "C:\xampp\php\php.exe" -l <file>` for each file (fix until clean).
3. No edits to shared includes or schema.
4. Return a concise summary: files created, key mechanics, assumptions.
