-- Migration 16: Performance indexes and optimization
-- Idempotent: safe to re-run.

-- Users table indexes
CREATE INDEX IF NOT EXISTS idx_users_crew_level ON users (crew_id, level);
CREATE INDEX IF NOT EXISTS idx_users_level_xp ON users (level, xp);
CREATE INDEX IF NOT EXISTS idx_users_money ON users (money);
CREATE INDEX IF NOT EXISTS idx_users_kills ON users (kills);
CREATE INDEX IF NOT EXISTS idx_users_last_active ON users (last_active);
CREATE INDEX IF NOT EXISTS idx_users_referred_by ON users (referred_by);
CREATE INDEX IF NOT EXISTS idx_users_daily_streak ON users (daily_streak);

-- Notifications indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_read_created ON notifications (user_id, is_read, created_at);

-- Event log indexes
CREATE INDEX IF NOT EXISTS idx_event_log_user_type_created ON event_log (user_id, type, created_at);

-- User items indexes
CREATE INDEX IF NOT EXISTS idx_user_items_user_equipped ON user_items (user_id, equipped);
CREATE INDEX IF NOT EXISTS idx_user_items_user_item ON user_items (user_id, item_id);

-- User drugs indexes
CREATE INDEX IF NOT EXISTS idx_user_drugs_user ON user_drugs (user_id);

-- Missions indexes
CREATE INDEX IF NOT EXISTS idx_missions_district_level ON missions (district_id, min_level);

-- User missions indexes
CREATE INDEX IF NOT EXISTS idx_user_missions_user_status ON user_missions (user_id, status);

-- Crews indexes
CREATE INDEX IF NOT EXISTS idx_crews_level_money ON crews (level, money);
CREATE INDEX IF NOT EXISTS idx_crews_tag ON crews (tag);

-- Crew members indexes
CREATE INDEX IF NOT EXISTS idx_crew_members_user ON crew_members (user_id);
CREATE INDEX IF NOT EXISTS idx_crew_members_crew ON crew_members (crew_id);

-- Crew wars indexes
CREATE INDEX IF NOT EXISTS idx_crew_wars_status_dates ON crew_wars (status, start_time, end_time);

-- Zone control indexes
CREATE INDEX IF NOT EXISTS idx_zone_control_zone ON zone_control (zone_id);
CREATE INDEX IF NOT EXISTS idx_zone_control_crew ON zone_control (crew_id);

-- Market listings indexes
CREATE INDEX IF NOT EXISTS idx_market_listings_type_status ON market_listings (item_type, status);
CREATE INDEX IF NOT EXISTS idx_market_listings_seller_status ON market_listings (seller_id, status);
CREATE INDEX IF NOT EXISTS idx_market_listings_end ON market_listings (auction_end);

-- Market bids indexes
CREATE INDEX IF NOT EXISTS idx_market_bids_listing_status ON market_bids (listing_id, status);
CREATE INDEX IF NOT EXISTS idx_market_bids_bidder_status ON market_bids (bidder_id, status);

-- Heist instances indexes
CREATE INDEX IF NOT EXISTS idx_heist_instances_crew_status ON heist_instances (crew_id, status);
CREATE INDEX IF NOT EXISTS idx_heist_instances_leader ON heist_instances (leader_id);

-- Heist participants indexes
CREATE INDEX IF NOT EXISTS idx_heist_participants_user ON heist_participants (user_id);

-- Race events indexes
CREATE INDEX IF NOT EXISTS idx_race_events_status ON race_events (status);
CREATE INDEX IF NOT EXISTS idx_race_events_track ON race_events (track_id);

-- Race participants indexes
CREATE INDEX IF NOT EXISTS idx_race_participants_race ON race_participants (race_id);
CREATE INDEX IF NOT EXISTS idx_race_participants_user ON race_participants (user_id);

-- Properties indexes
CREATE INDEX IF NOT EXISTS idx_user_properties_user ON user_properties (user_id);
CREATE INDEX IF NOT EXISTS idx_user_properties_type ON user_properties (property_type_id);

-- Politics indexes
CREATE INDEX IF NOT EXISTS idx_mayor_elections_status ON mayor_elections (status);
CREATE INDEX IF NOT EXISTS idx_mayor_candidates_election ON mayor_candidates (election_id);
CREATE INDEX IF NOT EXISTS idx_mayor_votes_election ON mayor_votes (election_id);
CREATE INDEX IF NOT EXISTS idx_city_policies_active ON city_policies (is_active);

-- Analytics indexes
CREATE INDEX IF NOT EXISTS idx_analytics_events_type_created ON analytics_events (type, created_at);
CREATE INDEX IF NOT EXISTS idx_analytics_events_user_created ON analytics_events (user_id, created_at);

-- Race events indexes
CREATE INDEX IF NOT EXISTS idx_race_participants_race_position ON race_participants (race_id, position);

-- Add composite indexes for common queries
CREATE INDEX IF NOT EXISTS idx_users_leaderboard ON users (level, xp, money);
CREATE INDEX IF NOT EXISTS idx_crew_members_crew_rank ON crew_members (crew_id, rank);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications (user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_user_missions_user_mission ON user_missions (user_id, mission_id);
CREATE INDEX IF NOT EXISTS idx_market_listings_search ON market_listings (item_type, status, created_at);

-- Full-text search indexes (if MySQL 5.6+)
ALTER TABLE items ADD FULLTEXT INDEX IF NOT EXISTS ft_items_name_desc (name, description);
ALTER TABLE missions ADD FULLTEXT INDEX IF NOT EXISTS ft_missions_name_desc (name, description);
ALTER TABLE drugs ADD FULLTEXT INDEX IF NOT EXISTS ft_drugs_name_desc (name, description);
ALTER TABLE abilities ADD FULLTEXT INDEX IF NOT EXISTS ft_abilities_name_desc (name, description);
ALTER TABLE achievements ADD FULLTEXT INDEX IF NOT EXISTS ft_achievements_name_desc (name, description);