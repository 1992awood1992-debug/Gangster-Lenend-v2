<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

/** Reuse eval_hand from poker - copy here for independence */
function eval_hand(array $cards): array
{
    $ranks = array_count_values(array_column($cards, 'rank'));
    $suits = array_count_values(array_column($cards, 'suit'));
    rsort($ranks);
    $isFlush = max($suits) === 5;
    $rankKeys = array_keys(array_column($cards, 'rank'));
    sort($rankKeys);
    $isStraight = ($rankKeys[4] - $rankKeys[0] === 4 && count($ranks) === 5) || $rankKeys === [2,3,4,5,14];
    $high = max($rankKeys);
    if ($isFlush && $isStraight) return ['rank' => 9, 'name' => 'Royal Flush', 'high' => $high, 'mult' => 250];
    if ($ranks[0] === 4) return ['rank' => 8, 'name' => 'Four of a Kind', 'high' => max(array_keys($ranks, 4)), 'mult' => 50];
    if ($ranks[0] === 3 && $ranks[1] === 2) return ['rank' => 7, 'name' => 'Full House', 'high' => max(array_keys($ranks, 3)), 'mult' => 9];
    if ($isFlush) return ['rank' => 6, 'name' => 'Flush', 'high' => $high, 'mult' => 6];
    if ($isStraight) return ['rank' => 5, 'name' => 'Straight', 'high' => $high, 'mult' => 4];
    if ($ranks[0] === 3) return ['rank' => 4, 'name' => 'Three of a Kind', 'high' => max(array_keys($ranks, 3)), 'mult' => 3];
    if ($ranks[0] === 2 && $ranks[1] === 2) return ['rank' => 3, 'name' => 'Two Pair', 'high' => max(array_keys($ranks, 2)), 'mult' => 2];
    if ($ranks[0] === 2) {
        $pairRank = max(array_keys($ranks, 2));
        return ['rank' => 2, 'name' => 'Pair', 'high' => $pairRank, 'mult' => ($pairRank >= 11 ? 1 : 0)];
    }
    return ['rank' => 1, 'name' => 'High Card', 'high' => $high, 'mult' => 0];
}

function draw_cards(int $n): array
{
    $deck = [];
    foreach (['h','d','c','s'] as $s) { for ($r = 2; $r <= 14; $r++) $deck[] = ['rank' => $r, 'suit' => $s]; }
    shuffle($deck);
    return array_slice($deck, 0, $n);
}

function card_str(array $c): string
{
    $r = $c['rank'];
    $n = $r === 11 ? 'J' : ($r === 12 ? 'Q' : ($r === 13 ? 'K' : ($r === 14 ? 'A' : (string)$r)));
    $s = ['h'=>'♥','d'=>'♦','c'=>'♣','s'=>'♠'][$c['suit']];
    return $n . $s;
}

$state = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'video_poker']);
$state = $state ? json_decode($state['state'], true) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'deal') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('video_poker.php'); }
        add_money($u['id'], -$stake, 'Video Poker bet');
        $player = draw_cards(5);
        $state = ['phase' => 'draw', 'stake' => $stake, 'player' => $player];
    } elseif ($action === 'draw' && $state && $state['phase'] === 'draw') {
        $hold = isset($_POST['hold']) ? array_map('intval', $_POST['hold']) : [];
        $newCards = draw_cards(5 - count($hold));
        $newHand = [];
        $nc = 0;
        for ($i = 0; $i < 5; $i++) {
            if (in_array($i, $hold)) $newHand[] = $state['player'][$i];
            else $newHand[] = $newCards[$nc++];
        }
        $state = ['phase' => 'showdown', 'stake' => $state['stake'], 'player' => $newHand];
    }
    if ($state) {
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'video_poker', json_encode($state)]);
    }
    redirect('video_poker.php');
}

$showdown = false;
if ($state && $state['phase'] === 'showdown') {
    $eval = eval_hand($state['player']);
    $payout = $state['stake'] * max(1, $eval['mult']);
    if ($payout > 0) {
        add_money($u['id'], $payout, 'Video Poker win');
        event_track('casino_won', (int) $payout);
        flash("{$eval['name']}! Won " . money($payout), 'success');
    } else {
        flash("{$eval['name']}. No win.", 'error');
    }
    insert('casino_bets', ['user_id' => $u['id'], 'game' => 'video_poker', 'stake' => $state['stake'], 'payout' => $payout, 'detail' => $eval['name']]);
    q('DELETE FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'video_poker']);
    $state = null;
    $showdown = true;
}

$page_title = 'Video Poker';
require __DIR__ . '/includes/header.php';
$u = current_user();
?>
<div class="card">
  <div class="panel-heading">Video Poker — Jacks or Better</div>
  <p class="muted small">Bet, hold cards, draw. Paytable: J+ 1x, Two Pair 2x, Trips 3x, Straight 4x, Flush 6x, Full House 9x, Quads 25x, Straight Flush 50x, Royal Flush 250x.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<?php if (!$state): ?>
<div class="card">
  <form method="post" style="max-width:300px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="deal">
    <label>Bet (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="50" required></label>
    <button class="btn btn-gold btn-block" type="submit">Deal</button>
  </form>
</div>
<?php else: ?>
<div class="card">
  <div class="panel-heading"><?= $state['phase'] === 'draw' ? 'Choose Cards to Hold' : 'Result' ?></div>
  <div style="margin-bottom:14px">
    <b>Your Hand:</b>
    <div class="pill-row" style="margin-top:8px">
      <?php foreach ($state['player'] as $i => $c): ?>
        <label style="display:flex;flex-direction:column;align-items:center;gap:4px;cursor:pointer;border:2px solid var(--line);border-radius:8px;padding:8px;background:var(--panel)">
          <span class="playing-card<?= in_array($c['suit'], ['h','d']) ? ' red' : '' ?>"><?= card_str($c) ?></span>
          <?php if ($state['phase'] === 'draw'): ?>
            <input type="checkbox" name="hold[]" value="<?= $i ?>" <?= isset($_POST['hold']) && in_array($i, array_map('intval', $_POST['hold'])) ? 'checked' : '' ?>> Hold
          <?php endif; ?>
        </label>
      <?php endforeach; ?>
    </div>
  </div>
  <?php if ($state['phase'] === 'draw'): ?>
    <form method="post" style="display:inline">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="draw">
      <button class="btn btn-green" type="submit">Draw</button>
    </form>
  <?php elseif ($showdown): ?>
    <?php $eval = eval_hand($state['player']); ?>
    <p style="margin-top:10px"><b><?= $eval['name'] ?></b> — <?= $eval['mult'] > 0 ? 'Won ' . money($state['stake'] * $eval['mult']) : 'No win' ?></p>
    <p><a class="btn btn-gold" href="<?= e(url('video_poker.php')) ?>">Play Again</a></p>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>