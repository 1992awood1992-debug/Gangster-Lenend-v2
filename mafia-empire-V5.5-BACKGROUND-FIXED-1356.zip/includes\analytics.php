<?php
/**
 * Eye Of The Mafia - Analytics & telemetry
 *
 * Lightweight event tracking for funnel/retention/engagement metrics.
 * Raw rows are pruned by the daily cron task (see task_analytics in
 * cron/tasks.php); aggregated views live in the admin reports.
 */

require_once __DIR__ . '/functions.php';

/**
 * Record a single analytics event. Never throws; failures are swallowed so
 * tracking can't break gameplay.
 */
function analytics_track(string $eventType, ?int $userId = null, array $meta = []): void
{
    try {
        insert('analytics_events', [
            'event_type' => substr($eventType, 0, 64),
            'user_id'    => $userId,
            'meta'       => json_encode($meta),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    } catch (Throwable $e) {
        // tracking is best-effort
    }
}

/**
 * Count events of a type since a cutoff (default: last 24h).
 */
function analytics_count_since(string $eventType, int $hours = 24): int
{
    try {
        return (int) fetch_one(
            'SELECT COUNT(*) FROM analytics_events WHERE event_type = ? AND created_at >= ?',
            [$eventType, date('Y-m-d H:i:s', time() - $hours * 3600)],
            0
        );
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Unique users for an event type since a cutoff.
 */
function analytics_unique_users_since(string $eventType, int $hours = 24): int
{
    try {
        return (int) fetch_one(
            'SELECT COUNT(DISTINCT user_id) FROM analytics_events WHERE event_type = ? AND user_id IS NOT NULL AND created_at >= ?',
            [$eventType, date('Y-m-d H:i:s', time() - $hours * 3600)],
            0
        );
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Per-day counts for an event type over the last N days (oldest first).
 * Returns [ ['date' => 'Y-m-d', 'count' => int], ... ]
 */
function analytics_daily(string $eventType, int $days = 14): array
{
    $out = [];
    $from = date('Y-m-d', time() - ($days - 1) * 86400);
    try {
        $rows = fetch_all(
            "SELECT DATE(created_at) AS d, COUNT(*) AS c
             FROM analytics_events
             WHERE event_type = ? AND created_at >= ?
             GROUP BY DATE(created_at)
             ORDER BY d ASC",
            [$eventType, $from . ' 00:00:00']
        );
        $byDate = [];
        foreach ($rows as $r) {
            $byDate[$r['d']] = (int) $r['c'];
        }
    } catch (Throwable $e) {
        $byDate = [];
    }
    for ($i = $days - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', time() - $i * 86400);
        $out[] = ['date' => $d, 'count' => $byDate[$d] ?? 0];
    }
    return $out;
}

/**
 * Active users (distinct users performing any tracked action) per day.
 */
function analytics_active_users_daily(int $days = 14): array
{
    $out = [];
    $from = date('Y-m-d', time() - ($days - 1) * 86400);
    try {
        $rows = fetch_all(
            "SELECT DATE(created_at) AS d, COUNT(DISTINCT user_id) AS c
             FROM analytics_events
             WHERE user_id IS NOT NULL AND created_at >= ?
             GROUP BY DATE(created_at)
             ORDER BY d ASC",
            [$from . ' 00:00:00']
        );
        $byDate = [];
        foreach ($rows as $r) {
            $byDate[$r['d']] = (int) $r['c'];
        }
    } catch (Throwable $e) {
        $byDate = [];
    }
    for ($i = $days - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', time() - $i * 86400);
        $out[] = ['date' => $d, 'count' => $byDate[$d] ?? 0];
    }
    return $out;
}

/**
 * Prune raw analytics rows older than $days (called by daily cron).
 */
function analytics_prune(int $days = 30): int
{
    $cutoff = date('Y-m-d H:i:s', time() - $days * 86400);
    $stmt = q('DELETE FROM analytics_events WHERE created_at < ?', [$cutoff]);
    return (int) $stmt->rowCount();
}

/**
 * Total events in a time window.
 */
function analytics_total_since(string $eventType, int $hours = 24): int
{
    try {
        return (int) fetch_one(
            'SELECT COUNT(*) FROM analytics_events WHERE event_type = ? AND created_at >= ?',
            [$eventType, date('Y-m-d H:i:s', time() - $hours * 3600)],
            0
        );
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Get top event types in a time window.
 */
function analytics_top_events(int $hours = 24, int $limit = 10): array
{
    try {
        return fetch_all(
            'SELECT event_type, COUNT(*) AS cnt, COUNT(DISTINCT user_id) AS uniq
             FROM analytics_events
             WHERE created_at >= ?
             GROUP BY event_type
             ORDER BY cnt DESC
             LIMIT ' . (int) $limit,
            [date('Y-m-d H:i:s', time() - $hours * 3600)]
        ) ?: [];
    } catch (Throwable $e) {
        return [];
    }
}

/**
 * Hourly distribution for an event over last N hours.
 */
function analytics_hourly(string $eventType, int $hours = 24): array
{
    $out = [];
    try {
        $rows = fetch_all(
            "SELECT HOUR(created_at) AS h, COUNT(*) AS c
             FROM analytics_events
             WHERE event_type = ? AND created_at >= ?
             GROUP BY HOUR(created_at)",
            [$eventType, date('Y-m-d H:i:s', time() - $hours * 3600)]
        );
        $byH = [];
        foreach ($rows as $r) {
            $byH[(int) $r['h']] = (int) $r['c'];
        }
    } catch (Throwable $e) {
        $byH = [];
    }
    for ($i = $hours - 1; $i >= 0; $i--) {
        $ts = time() - $i * 3600;
        $h = (int) date('G', $ts);
        $label = date('H:00', $ts);
        $out[] = ['hour' => $h, 'label' => $label, 'count' => $byH[$h] ?? 0];
    }
    return $out;
}

/**
 * Cohort retention: % of users who registered N days ago and were active again.
 */
function analytics_cohorts(int $days = 7): array
{
    $cohorts = [];
    try {
        for ($d = $days; $d >= 1; $d--) {
            $start = date('Y-m-d 00:00:00', time() - $d * 86400);
            $end = date('Y-m-d 23:59:59', time() - $d * 86400);
            $nextStart = date('Y-m-d 00:00:00', time() - ($d - 1) * 86400);
            $cohortUsers = fetch_all(
                'SELECT id FROM users WHERE created_at BETWEEN ? AND ?',
                [$start, $end]
            );
            $cohortSize = count($cohortUsers);
            if ($cohortSize === 0) {
                $cohorts[] = ['label' => $d . 'd ago', 'size' => 0, 'retained' => 0, 'pct' => 0];
                continue;
            }
            $ids = array_map(function ($u) { return (int) $u['id']; }, $cohortUsers);
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $retained = (int) fetch_one(
                "SELECT COUNT(DISTINCT user_id) FROM analytics_events WHERE user_id IN ($placeholders) AND created_at >= ? AND event_type IN ('login','mission_complete','crime_complete','kill','fight')",
                array_merge($ids, [$nextStart]),
                0
            );
            $cohorts[] = [
                'label' => $d . 'd ago',
                'size' => $cohortSize,
                'retained' => $retained,
                'pct' => $cohortSize > 0 ? (int) round(($retained / $cohortSize) * 100) : 0,
            ];
        }
    } catch (Throwable $e) {
        // ignore
    }
    return $cohorts;
}

/**
 * Live activity: last N events.
 */
function analytics_live(int $limit = 20): array
{
    try {
        return fetch_all(
            'SELECT ae.event_type, ae.user_id, ae.meta, ae.created_at, u.username
             FROM analytics_events ae
             LEFT JOIN users u ON u.id = ae.user_id
             ORDER BY ae.created_at DESC
             LIMIT ' . (int) $limit
        ) ?: [];
    } catch (Throwable $e) {
        return [];
    }
}