<?php
/**
 * Eye Of The Mafia - Events System
 * Daily/weekly challenges, seasonal events, progress tracking
 */

require_once __DIR__ . '/init.php';

/**
 * Check if an event is currently active
 */
function event_is_active(string $code): bool
{
    $event = fetch('SELECT * FROM events WHERE code = ? AND is_active = 1', [$code]);
    if (!$event) return false;
    
    $now = new DateTime();
    if ($event['start_date'] && new DateTime($event['start_date']) > new DateTime()) return false;
    if ($event['end_date'] && new DateTime($event['end_date']) < new DateTime()) return false;
    
    return true;
}

/**
 * Get all active events
 */
function event_get_active(): array
{
    return fetch_all("
        SELECT * FROM events 
        WHERE is_active = 1 
        AND (start_date IS NULL OR start_date <= NOW())
        AND (end_date IS NULL OR end_date >= NOW())
        ORDER BY type, name
    ");
}

/**
 * Roll expired daily/weekly windows forward and reset their per-user progress,
 * so recurring challenges stay available without a scheduled task.
 */
function event_refresh_recurring(): void
{
    foreach ([['daily', 1], ['weekly', 7]] as $spec) {
        $type = $spec[0];
        $days = (int) $spec[1];
        $expired = fetch_all(
            "SELECT id FROM events WHERE type = ? AND is_active = 1 AND (end_date IS NULL OR end_date < NOW())",
            [$type]
        );
        foreach ($expired as $ev) {
            q("UPDATE events SET start_date = NOW(), end_date = DATE_ADD(NOW(), INTERVAL {$days} DAY) WHERE id = ?", [(int) $ev['id']]);
            q('DELETE FROM user_event_progress WHERE event_id = ?', [(int) $ev['id']]);
        }
    }
}

/**
 * Track event progress for a metric.
 * Called after actions that should count towards event challenges.
 */
function event_track_metric(int $userId, string $metric, int $increment = 1): void
{
    $activeEvents = event_get_active();
    foreach ($activeEvents as $event) {
        $challenges = event_get_challenges((int) $event['id']);
        foreach ($challenges as $challenge) {
            if ($challenge['metric'] !== $metric) continue;
            
            $progress = fetch('
                SELECT * FROM user_event_progress 
                WHERE user_id = ? AND event_id = ? AND challenge_id = ?
            ', [$userId, $event['id'], $challenge['id']]);
            
            if (!$progress) {
                $justCompleted = $increment >= (int) $challenge['target_value'] ? 1 : 0;
                insert('user_event_progress', [
                    'user_id' => $userId,
                    'event_id' => $event['id'],
                    'challenge_id' => $challenge['id'],
                    'current_value' => $increment,
                    'completed' => $justCompleted,
                    'completed_at' => $justCompleted ? now() : null,
                ]);
                continue;
            }
            
            if ((int) $progress['completed'] === 1) continue;
            
            $newValue = (int) $progress['current_value'] + $increment;
            $completed = $newValue >= (int) $challenge['target_value'] ? 1 : 0;
            
            q('UPDATE user_event_progress SET current_value = ?, completed = ? WHERE id = ?', 
                [$newValue, $completed, $progress['id']]);
            
            if ($completed && !(int) $progress['completed']) {
                // Challenge just completed - could trigger notification
            }
        }
    }
}

/**
 * Get active challenges for an event
 */
function event_get_challenges(int $eventId): array
{
    return fetch_all("
        SELECT * FROM event_challenges 
        WHERE event_id = ? AND is_active = 1 
        ORDER BY sort_order
    ", [$eventId]);
}

/**
 * Get user's progress on event challenges
 */
function event_get_user_progress(int $userId, int $eventId): array
{
    return fetch_all("
        SELECT uep.*, ec.code, ec.name, ec.description, ec.target_value, ec.metric,
               ec.reward_xp, ec.reward_money, ec.reward_points, ec.reward_items
        FROM user_event_progress uep
        JOIN event_challenges ec ON ec.id = uep.challenge_id
        WHERE uep.user_id = ? AND uep.event_id = ?
    ", [$userId, $eventId]);
}

/**
 * Update user's progress on a challenge metric
 */
function event_update_progress(int $userId, string $metric, int $increment = 1): void
{
    if (!is_logged_in()) return;
    
    $activeEvents = event_get_active();
    foreach ($activeEvents as $event) {
        $challenges = event_get_challenges((int) $event['id']);
        foreach ($challenges as $challenge) {
            if ($challenge['metric'] !== $metric) continue;
            
            $progress = fetch('
                SELECT * FROM user_event_progress 
                WHERE user_id = ? AND event_id = ? AND challenge_id = ?
            ', [$userId, $event['id'], $challenge['id']]);
            
            if (!$progress) {
                $justCompleted = $increment >= (int) $challenge['target_value'] ? 1 : 0;
                insert('user_event_progress', [
                    'user_id' => $userId,
                    'event_id' => $event['id'],
                    'challenge_id' => $challenge['id'],
                    'current_value' => $increment,
                    'completed' => $justCompleted,
                    'completed_at' => $justCompleted ? now() : null,
                ]);
                continue;
            }
            
            if ((int) $progress['completed'] === 1) continue;
            
            $newValue = (int) $progress['current_value'] + $increment;
            $completed = $newValue >= (int) $challenge['target_value'] ? 1 : 0;
            
            q('UPDATE user_event_progress SET current_value = ?, completed = ?, completed_at = COALESCE(completed_at, NOW()) WHERE id = ?',
                [$newValue, $completed, $progress['id']]);
            
            if ($completed && !(int) $progress['completed']) {
                // Challenge just completed - could trigger notification
            }
        }
    }
}

/**
 * Claim challenge rewards
 */
function event_claim_reward(int $challengeId): array
{
    $u = current_user();
    $progress = fetch('
        SELECT uep.*, ec.reward_xp, ec.reward_money, ec.reward_points, ec.reward_items
        FROM user_event_progress uep
        JOIN event_challenges ec ON ec.id = uep.challenge_id
        WHERE uep.challenge_id = ? AND uep.user_id = ?
    ', [$challengeId, $u['id']]);
    
    if (!$progress) return ['ok' => false, 'error' => 'Progress not found'];
    if (!(int) $progress['completed']) return ['ok' => false, 'error' => 'Challenge not completed'];
    if ((int) $progress['claimed']) return ['ok' => false, 'error' => 'Already claimed'];
    
    // Grant rewards
    $xp = (int) $progress['reward_xp'];
    $money = (int) $progress['reward_money'];
    $points = (int) $progress['reward_points'];
    
    if ($xp > 0) grant_xp($u['id'], $xp);
    if ($money > 0) add_money($u['id'], $money, 'Event reward');
    if ($points > 0) add_points($u['id'], $points);
    
    // Handle item rewards: [{"item_id":1,"qty":1,"chance":0.5}]
    $items = $progress['reward_items'] ? json_decode($progress['reward_items'], true) : [];
    $itemsGranted = [];
    if (is_array($items)) {
        foreach ($items as $item) {
            if (!is_array($item)) continue;
            $itemId = (int) ($item['item_id'] ?? 0);
            $qty = (int) ($item['qty'] ?? 1);
            $chance = isset($item['chance']) ? (float) $item['chance'] : 1.0;
            if ($itemId <= 0 || $qty <= 0) continue;
            if ($chance < 1.0 && mt_rand(1, 100) > (int) round($chance * 100)) continue;

            $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [(int) $u['id'], $itemId]);
            if ($existing) {
                q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [$qty, (int) $existing['id']]);
            } else {
                insert('user_items', ['user_id' => (int) $u['id'], 'item_id' => $itemId, 'qty' => $qty, 'equipped' => 0]);
            }
            $itemsGranted[] = ['item_id' => $itemId, 'qty' => $qty];
        }
    }
    
    q('UPDATE user_event_progress SET claimed = 1, claimed_at = NOW() WHERE id = ?', [$progress['id']]);

    // Log reward
    insert('event_rewards_log', [
        'user_id' => $u['id'],
        'event_id' => (int) $progress['event_id'],
        'challenge_id' => (int) $progress['challenge_id'],
        'reward_type' => 'xp',
        'reward_value' => (string) $xp,
    ]);
    if ($money > 0) {
        insert('event_rewards_log', [
            'user_id' => $u['id'],
            'event_id' => (int) $progress['event_id'],
            'challenge_id' => (int) $progress['challenge_id'],
            'reward_type' => 'money',
            'reward_value' => (string) $money,
        ]);
    }
    if ($points > 0) {
        insert('event_rewards_log', [
            'user_id' => $u['id'],
            'event_id' => (int) $progress['event_id'],
            'challenge_id' => (int) $progress['challenge_id'],
            'reward_type' => 'points',
            'reward_value' => (string) $points,
        ]);
    }
    
    return ['ok' => true, 'rewards' => ['xp' => $xp, 'money' => $money, 'points' => $points, 'items' => $itemsGranted]];
}

/**
 * Initialize user's progress for active events
 */
function event_init_user_progress(int $userId): void
{
    $activeEvents = event_get_active();
    foreach ($activeEvents as $event) {
        $challenges = event_get_challenges((int) $event['id']);
        foreach ($challenges as $challenge) {
            $exists = fetch_one('SELECT 1 FROM user_event_progress WHERE user_id = ? AND challenge_id = ?', [$userId, $challenge['id']]);
            if (!$exists) {
                insert('user_event_progress', [
                    'user_id' => $userId,
                    'event_id' => $event['id'],
                    'challenge_id' => $challenge['id'],
                    'current_value' => 0,
                    'completed' => 0,
                ]);
            }
        }
    }
}

/**
 * Get active seasonal event for display
 */
function event_get_seasonal(): ?array
{
    $now = new DateTime();
    $events = fetch_all("
        SELECT * FROM events 
        WHERE type = 'seasonal' AND is_active = 1
        AND start_date <= NOW() AND end_date >= NOW()
        ORDER BY start_date
    ");
    return $events[0] ?? null;
}

/**
 * Get user's event dashboard data
 */
function event_get_dashboard(int $userId): array
{
    $activeEvents = event_get_active();
    $data = [
        'seasonal' => null,
        'daily' => null,
        'weekly' => null,
        'progress' => [],
    ];
    
    foreach ($activeEvents as $event) {
        $challenges = event_get_challenges((int) $event['id']);
        $progress = event_get_user_progress($userId, (int) $event['id']);
        
        $eventData = [
            'event' => $event,
            'challenges' => [],
            'completed_count' => 0,
            'total_count' => count($challenges),
        ];
        
        foreach ($challenges as $challenge) {
            $prog = null;
            foreach ($progress as $p) {
                if ($p['challenge_id'] == $challenge['id']) {
                    $prog = $p;
                    break;
                }
            }
            
            $completed = $prog ? (int) $prog['completed'] : 0;
            $claimed = $prog ? (int) $prog['claimed'] : 0;
            $current = $prog ? (int) $prog['current_value'] : 0;
            
            if ($completed) $eventData['completed_count']++;
            
            $eventData['challenges'][] = [
                'id' => $challenge['id'],
                'code' => $challenge['code'],
                'name' => $challenge['name'],
                'description' => $challenge['description'],
                'target' => $challenge['target_value'],
                'current' => $current,
                'completed' => $completed,
                'claimed' => $claimed,
                'rewards' => [
                    'xp' => $challenge['reward_xp'],
                    'money' => $challenge['reward_money'],
                    'points' => $challenge['reward_points'],
                ],
            ];
        }
        
        if ($event['type'] === 'seasonal') $data['seasonal'] = $eventData;
        elseif ($event['type'] === 'daily') $data['daily'] = $eventData;
        elseif ($event['type'] === 'weekly') $data['weekly'] = $eventData;
    }
    
    return $data;
}