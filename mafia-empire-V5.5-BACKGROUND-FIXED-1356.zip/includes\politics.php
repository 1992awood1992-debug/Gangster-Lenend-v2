<?php
/**
 * Eye Of The Mafia - Politics / Mayor System
 * Player elections, city policies, city-wide buffs.
 */

require_once __DIR__ . '/init.php';

/**
 * Get current election
 */
function politics_get_current_election(): ?array
{
    return fetch("
        SELECT * FROM mayor_elections 
        WHERE status IN ('nominations','voting') 
        ORDER BY election_number DESC LIMIT 1
    ");
}

/**
 * Get election by ID
 */
function politics_get_election(int $electionId): ?array
{
    return fetch('SELECT * FROM mayor_elections WHERE id = ?', [$electionId]);
}

/**
 * Get current mayor
 */
function politics_get_mayor(): ?array
{
    return fetch("
        SELECT me.*, u.username, u.level, u.avatar
        FROM mayor_elections me
        JOIN users u ON u.id = me.mayor_id
        WHERE me.status = 'finished' AND me.mayor_id IS NOT NULL
        ORDER BY me.election_number DESC LIMIT 1
    ");
}

/**
 * Get active policies
 */
function politics_get_active_policies(): array
{
    return fetch_all("
        SELECT cp.*, u.username as enacted_by_name
        FROM city_policies cp
        LEFT JOIN users u ON u.id = cp.enacted_by
        WHERE cp.is_active = 1 AND (cp.expires_at IS NULL OR cp.expires_at > NOW())
        ORDER BY cp.category, cp.name
    ");
}

/**
 * Get election candidates
 */
function politics_get_candidates(int $electionId): array
{
    return fetch_all("
        SELECT mc.*, u.username, u.level, u.avatar, u.kills, u.money
        FROM mayor_candidates mc
        JOIN users u ON u.id = mc.user_id
        WHERE mc.election_id = ? AND mc.is_nominated = 1
        ORDER BY mc.votes DESC
    ", [$electionId]);
}

/**
 * Check if user can nominate themselves
 */
function politics_can_nominate(int $userId, int $electionId): array
{
    $election = politics_get_election($electionId);
    if (!$election) return ['ok' => false, 'error' => 'Election not found'];
    if ($election['status'] !== 'nominations') return ['ok' => false, 'error' => 'Nominations closed'];

    $user = fetch('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$user) return ['ok' => false, 'error' => 'User not found'];
    if ((int) $user['level'] < 20) return ['ok' => false, 'error' => 'Level 20 required to run for mayor'];

    $existing = fetch_one('SELECT 1 FROM mayor_candidates WHERE election_id = ? AND user_id = ?', [$electionId, $userId]);
    if ($existing) return ['ok' => false, 'error' => 'Already nominated'];

    return ['ok' => true];
}

/**
 * Nominate self for mayor
 */
function politics_nominate(int $userId, int $electionId, string $platform = ''): array
{
    $check = politics_can_nominate($userId, $electionId);
    if (!$check['ok']) return $check;

    insert('mayor_candidates', [
        'election_id' => $electionId,
        'user_id' => $userId,
        'platform' => $platform,
    ]);

    analytics_track('mayor_nominate', $userId, ['election_id' => $electionId]);
    return ['ok' => true];
}

/**
 * Vote for a candidate
 */
function politics_vote(int $voterId, int $electionId, int $candidateId): array
{
    $election = politics_get_election($electionId);
    if (!$election) return ['ok' => false, 'error' => 'Election not found'];
    if ($election['status'] !== 'voting') return ['ok' => false, 'error' => 'Voting not open'];

    $voter = fetch('SELECT * FROM users WHERE id = ?', [$voterId]);
    if (!$voter) return ['ok' => false, 'error' => 'User not found'];
    if ((int) $voter['level'] < 5) return ['ok' => false, 'error' => 'Level 5 required to vote'];

    $candidate = fetch('SELECT * FROM mayor_candidates WHERE id = ? AND election_id = ? AND is_nominated = 1', [$candidateId, $electionId]);
    if (!$candidate) return ['ok' => false, 'error' => 'Invalid candidate'];

    $alreadyVoted = fetch_one('SELECT 1 FROM mayor_votes WHERE election_id = ? AND voter_id = ?', [$electionId, $voterId]);
    if ($alreadyVoted) return ['ok' => false, 'error' => 'Already voted'];

    insert('mayor_votes', [
        'election_id' => $electionId,
        'voter_id' => $voterId,
        'candidate_id' => $candidateId,
    ]);

    q('UPDATE mayor_candidates SET votes = votes + 1 WHERE id = ?', [$candidateId]);
    q('UPDATE mayor_elections SET total_votes = total_votes + 1 WHERE id = ?', [$electionId]);

    analytics_track('mayor_vote', $voterId, [
        'election_id' => $electionId,
        'candidate_id' => $candidateId,
    ]);

    return ['ok' => true];
}

/**
 * Get user's vote status
 */
function politics_get_user_vote(int $userId, int $electionId): ?array
{
    return fetch("
        SELECT mv.*, mc.user_id as candidate_user_id, u.username as candidate_name
        FROM mayor_votes mv
        JOIN mayor_candidates mc ON mc.id = mv.candidate_id
        JOIN users u ON u.id = mc.user_id
        WHERE mv.election_id = ? AND mv.voter_id = ?
    ", [$electionId, $userId]);
}

/**
 * Enact a city policy (mayor only)
 */
function politics_enact_policy(int $mayorId, int $policyId): array
{
    $mayor = politics_get_mayor();
    if (!$mayor || (int) $mayor['mayor_id'] !== $mayorId) {
        return ['ok' => false, 'error' => 'Only the current mayor can enact policies'];
    }

    $policy = fetch('SELECT * FROM city_policies WHERE id = ?', [$policyId]);
    if (!$policy) return ['ok' => false, 'error' => 'Policy not found'];
    if ((int) $policy['is_active'] === 1) return ['ok' => false, 'error' => 'Policy already active'];

    // Check city treasury (simplified - use mayor's money as proxy)
    $mayorUser = fetch('SELECT money FROM users WHERE id = ?', [$mayorId]);
    if ((int) $mayorUser['money'] < (int) $policy['cost_per_day'] * 7) {
        return ['ok' => false, 'error' => 'Insufficient funds for 7-day upkeep'];
    }

    add_money($mayorId, -(int) $policy['cost_per_day'] * 7, 'Policy enactment: ' . $policy['name']);

    $expiresAt = date('Y-m-d H:i:s', time() + 7 * 86400); // 7 days
    q('UPDATE city_policies SET is_active = 1, enacted_by = ?, enacted_at = NOW(), expires_at = ? WHERE id = ?', [$mayorId, $expiresAt, $policyId]);

    analytics_track('policy_enact', $mayorId, ['policy_id' => $policyId]);
    notify($mayorId, 'Policy enacted: ' . $policy['name'] . ' (expires in 7 days)', 'politics.php');

    // Notify all online users (simplified)
    $users = fetch_all('SELECT id FROM users WHERE last_active > DATE_SUB(NOW(), INTERVAL 1 HOUR)');
    foreach ($users as $u) {
        if ((int) $u['id'] !== $mayorId) {
            notify((int) $u['id'], 'New city policy enacted: ' . $policy['name'] . ' - ' . $policy['description'], 'politics.php');
        }
    }

    return ['ok' => true];
}

/**
 * Revoke a policy (mayor only)
 */
function politics_revoke_policy(int $mayorId, int $policyId): array
{
    $mayor = politics_get_mayor();
    if (!$mayor || (int) $mayor['mayor_id'] !== $mayorId) {
        return ['ok' => false, 'error' => 'Only the current mayor can revoke policies'];
    }

    $policy = fetch('SELECT * FROM city_policies WHERE id = ?', [$policyId]);
    if (!$policy) return ['ok' => false, 'error' => 'Policy not found'];
    if ((int) $policy['is_active'] === 0) return ['ok' => false, 'error' => 'Policy not active'];

    q('UPDATE city_policies SET is_active = 0, expires_at = NOW() WHERE id = ?', [$policyId]);
    analytics_track('policy_revoke', $mayorId, ['policy_id' => $policyId]);

    return ['ok' => true];
}

/**
 * Apply active policy effects to a value
 */
function politics_apply_policy_effect(string $effectType, float $value): float
{
    $policies = politics_get_active_policies();
    foreach ($policies as $policy) {
        if ($policy['effect_type'] === $effectType) {
            if (strpos($effectType, 'multiplier') !== false) {
                $value *= (float) $policy['effect_value'];
            } elseif (strpos($effectType, 'rate') !== false) {
                $value *= (float) $policy['effect_value'];
            }
        }
    }
    return $value;
}

/**
 * Get politics page data
 */
function politics_get_dashboard(int $userId): array
{
    $currentElection = politics_get_current_election();
    $mayor = politics_get_mayor();
    $policies = politics_get_active_policies();
    $candidates = $currentElection ? politics_get_candidates((int) $currentElection['id']) : [];
    $userVote = $currentElection ? politics_get_user_vote($userId, (int) $currentElection['id']) : null;
    $userCandidate = $currentElection ? fetch('SELECT * FROM mayor_candidates WHERE election_id = ? AND user_id = ?', [(int) $currentElection['id'], $userId]) : null;
    $canNominate = $currentElection ? politics_can_nominate($userId, (int) $currentElection['id']) : ['ok' => false];

    return [
        'current_election' => $currentElection,
        'mayor' => $mayor,
        'policies' => $policies,
        'candidates' => $candidates,
        'user_vote' => $userVote,
        'user_candidate' => $userCandidate,
        'can_nominate' => $canNominate['ok'],
    ];
}

/**
 * Auto-advance election phases (cron job)
 */
function politics_advance_elections(): array
{
    $toVoting = 0;
    $finished = 0;
    $started = 0;
    
    // Move nominations -> voting
    $nominations = fetch_all("
        SELECT * FROM mayor_elections 
        WHERE status = 'nominations' 
        AND DATE_SUB(NOW(), INTERVAL 3 DAY) > created_at
    ");
    foreach ($nominations as $election) {
        $candidateCount = (int) fetch_one('SELECT COUNT(*) FROM mayor_candidates WHERE election_id = ?', [(int) $election['id']], 0);
        if ($candidateCount < 2) {
            q('UPDATE mayor_elections SET status = \'finished\' WHERE id = ?', [(int) $election['id']]);
            continue;
        }
        q('UPDATE mayor_elections SET status = \'voting\' WHERE id = ?', [(int) $election['id']]);
        $toVoting++;
    }

    // Move voting -> finished
    $voting = fetch_all("
        SELECT * FROM mayor_elections 
        WHERE status = 'voting' 
        AND DATE_SUB(NOW(), INTERVAL 3 DAY) > created_at
    ");
    foreach ($voting as $election) {
        $winner = fetch('
            SELECT user_id FROM mayor_candidates 
            WHERE election_id = ? 
            ORDER BY votes DESC LIMIT 1
        ', [(int) $election['id']]);
        
        q('UPDATE mayor_elections SET status = \'finished\', finished_at = NOW(), mayor_id = ? WHERE id = ?', 
            [$winner ? (int) $winner['user_id'] : null, (int) $election['id']]);
        $finished++;
        
        if ($winner) {
            $winnerId = (int) $winner['user_id'];
            $winnerUser = fetch('SELECT username FROM users WHERE id = ?', [$winnerId]);
            $electionNum = (int) $election['election_number'];
            
            // Notify winner
            notify($winnerId, "You won Election #{$electionNum}! You are now the Mayor.", 'politics.php');
            
            // Notify all
            $users = fetch_all('SELECT id FROM users WHERE id != ?', [(int) $winnerId]);
            foreach ($users as $u) {
                notify((int) $u['id'], "{$winnerUser['username']} won Election #{$electionNum} and is now the Mayor!", 'politics.php');
            }
        }
    }

    // Create new election if none pending
    $active = fetch_one('SELECT 1 FROM mayor_elections WHERE status IN (\'nominations\',\'voting\')', [], 0);
    if (!$active) {
        $lastNum = (int) fetch_one('SELECT MAX(election_number) FROM mayor_elections', [], 0);
        $newNum = $lastNum + 1;
        $start = date('Y-m-d');
        $end = date('Y-m-d', strtotime('+7 days'));
        
        insert('mayor_elections', [
            'election_number' => $newNum,
            'status' => 'nominations',
            'term_start' => $start,
            'term_end' => $end,
        ]);
        $started = 1;
        
        $users = fetch_all('SELECT id FROM users WHERE level >= 20');
        foreach ($users as $u) {
            notify((int) $u['id'], "Election #{$newNum} nominations open! Level 20+ can run for Mayor.", 'politics.php');
        }
    }

    return ['to_voting' => $toVoting, 'finished' => $finished, 'started' => $started];
}