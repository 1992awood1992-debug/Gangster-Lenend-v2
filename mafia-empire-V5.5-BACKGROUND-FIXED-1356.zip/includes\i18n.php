<?php
/**
 * Eye Of The Mafia - Internationalization (i18n)
 * Multi-language support with locale switching
 */

declare(strict_types=1);

/**
 * Supported languages
 */
const I18N_LANGUAGES = [
    'en' => ['name' => 'English', 'native' => 'English', 'flag' => '🇺🇸'],
    'es' => ['name' => 'Spanish', 'native' => 'Español', 'flag' => '🇪🇸'],
    'fr' => ['name' => 'French', 'native' => 'Français', 'flag' => '🇫🇷'],
    'de' => ['name' => 'German', 'native' => 'Deutsch', 'flag' => '🇩🇪'],
    'it' => ['name' => 'Italian', 'native' => 'Italiano', 'flag' => '🇮🇹'],
    'pt' => ['name' => 'Portuguese', 'native' => 'Português', 'flag' => '🇵🇹'],
    'ru' => ['name' => 'Russian', 'native' => 'Русский', 'flag' => '🇷🇺'],
    'pl' => ['name' => 'Polish', 'native' => 'Polski', 'flag' => '🇵🇱'],
    'tr' => ['name' => 'Turkish', 'native' => 'Türkçe', 'flag' => '🇹🇷'],
    'zh' => ['name' => 'Chinese', 'native' => '中文', 'flag' => '🇨🇳'],
    'ja' => ['name' => 'Japanese', 'native' => '日本語', 'flag' => '🇯🇵'],
    'ko' => ['name' => 'Korean', 'native' => '한국어', 'flag' => '🇰🇷'],
];

/**
 * Get current user's locale
 */
function i18n_get_locale(): string
{
    $u = current_user();
    if ($u && !empty($u['locale'])) {
        return $u['locale'];
    }
    
    // Check session
    if (isset($_SESSION['locale'])) {
        return $_SESSION['locale'];
    }
    
    // Check cookie
    if (isset($_COOKIE['locale'])) {
        return $_COOKIE['locale'];
    }
    
    // Check Accept-Language header
    if (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
        $langs = [];
        foreach (explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']) as $part) {
            $part = trim($part);
            $q = 1.0;
            if (preg_match('/;q=([0-9.]+)/', $part, $m)) {
                $q = (float)$m[1];
                $part = substr($part, 0, strpos($part, ';'));
            }
            $lang = strtolower(substr($part, 0, 2));
            if (isset(I18N_LANGUAGES[$lang])) {
                $langs[$lang] = $q;
            }
        }
        arsort($langs);
        return key($langs) ?? 'en';
    }
    
    return 'en';
}

/**
 * Set user's locale
 */
function i18n_set_locale(string $locale): bool
{
    if (!isset(I18N_LANGUAGES[$locale])) {
        return false;
    }
    
    $_SESSION['locale'] = $locale;
    
    // Set cookie for 1 year
    setcookie('locale', $locale, [
        'expires' => time() + 31536000,
        'path' => '/',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    
    // Update user preference if logged in
    $u = current_user();
    if ($u) {
        q('UPDATE users SET locale = ? WHERE id = ?', [$locale, $u['id']]);
    }
    
    return true;
}

/**
 * Get translation for a key
 */
function __($key, array $params = [], string $locale = ''): string
{
    $locale = $locale ?: i18n_get_locale();
    
    static $translations = [];
    $cacheKey = $locale . ':' . $key;
    
    if (!isset($translations[$cacheKey])) {
        // Try to load from cache
        $translations[$cacheKey] = cache_get("i18n:{$locale}:{$key}");
        
        if ($translations[$cacheKey] === null) {
            // Fallback to database
            $row = fetch('SELECT translation FROM i18n_translations WHERE locale = ? AND `key` = ?', [$locale, $key]);
            if ($row) {
                $translations[$cacheKey] = $row['translation'];
                cache_set("i18n:{$locale}:{$key}", $row['translation'], 3600);
            } else {
                // Fallback to English
                if ($locale !== 'en') {
                    $enRow = fetch('SELECT translation FROM i18n_translations WHERE locale = ? AND `key` = ?', ['en', $key]);
                    if ($enRow) {
                        $translations[$cacheKey] = $enRow['translation'];
                    } else {
                        $translations[$cacheKey] = $key; // Return key as fallback
                    }
                } else {
                    $translations[$cacheKey] = $key;
                }
            }
        }
    }
    
    $text = $translations[$cacheKey];
    
    // Replace params
    if (!empty($params)) {
        $text = preg_replace_callback('/\{(\w+)\}/', function($m) use ($params) {
            return $params[$m[1]] ?? $m[0];
        }, $text);
    }
    
    return $text;
}

/**
 * Get pluralized translation
 */
function __n($key, int $count, array $params = [], string $locale = ''): string
{
    $locale = $locale ?: i18n_get_locale();
    $pluralKey = $key . '_plural';
    
    $text = __($count === 1 ? $key : $pluralKey, array_merge($params, ['count' => $count]), $locale);
    
    // If plural key doesn't exist, use singular with count
    if ($text === $pluralKey && $count !== 1) {
        $text = __($key, array_merge($params, ['count' => $count]), $locale);
    }
    
    return str_replace('{count}', number_format($count), $text);
}

/**
 * Get language name
 */
function i18n_language_name(string $locale, bool $native = true): string
{
    return I18N_LANGUAGES[$locale][$native ? 'native' : 'name'] ?? $locale;
}

/**
 * Get language flag
 */
function i18n_language_flag(string $locale): string
{
    return I18N_LANGUAGES[$locale]['flag'] ?? '🏳️';
}

/**
 * Get all available languages
 */
function i18n_get_languages(): array
{
    return I18N_LANGUAGES;
}

/**
 * Check if locale is RTL
 */
function i18n_is_rtl(string $locale): bool
{
    return in_array($locale, ['ar', 'he', 'fa', 'ur'], true);
}

/**
 * Get direction for locale
 */
function i18n_get_dir(string $locale): string
{
    return i18n_is_rtl($locale) ? 'rtl' : 'ltr';
}

/**
 * Format number according to locale
 */
function i18n_format_number(float $number, int $decimals = 0, string $locale = ''): string
{
    $locale = $locale ?: i18n_get_locale();
    
    $formatter = new NumberFormatter($locale, NumberFormatter::DECIMAL);
    $formatter->setAttribute(NumberFormatter::MIN_FRACTION_DIGITS, $decimals);
    $formatter->setAttribute(NumberFormatter::MAX_FRACTION_DIGITS, $decimals);
    
    return $formatter->format($number);
}

/**
 * Format currency according to locale
 */
function i18n_format_currency(float $amount, string $currency = 'USD', string $locale = ''): string
{
    $locale = $locale ?: i18n_get_locale();
    
    $formatter = new NumberFormatter($locale, NumberFormatter::CURRENCY);
    return $formatter->formatCurrency($amount, $currency);
}

/**
 * Format date according to locale
 */
function i18n_format_date(int $timestamp, string $format = 'medium', string $locale = ''): string
{
    $locale = $locale ?: i18n_get_locale();
    
    $formatter = new IntlDateFormatter(
        $locale,
        IntlDateFormatter::NONE,
        IntlDateFormatter::NONE
    );
    
    switch ($format) {
        case 'short':
            $formatter->setPattern('dd/MM/yyyy');
            break;
        case 'medium':
            $formatter->setPattern('dd MMM yyyy');
            break;
        case 'long':
            $formatter->setPattern('dd MMMM yyyy');
            break;
        case 'full':
            $formatter->setPattern('EEEE, dd MMMM yyyy');
            break;
        case 'time':
            $formatter->setPattern('HH:mm');
            break;
        case 'datetime':
            $formatter->setPattern('dd MMM yyyy HH:mm');
            break;
        default:
            $formatter->setPattern('dd/MM/yyyy');
    }
    
    return $formatter->format($timestamp);
}

/**
 * Format relative time (e.g., "2 hours ago")
 */
function i18n_format_relative_time(int $timestamp, string $locale = ''): string
{
    $locale = $locale ?: i18n_get_locale();
    $diff = time() - $timestamp;
    
    if ($diff < 60) {
        return __('just_now', [], $locale);
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return __n('minute_ago', $minutes, ['count' => $minutes], $locale);
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return __n('hour_ago', $hours, ['count' => $hours], $locale);
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return __n('day_ago', $days, ['count' => $days], $locale);
    } elseif ($diff < 2592000) {
        $weeks = floor($diff / 604800);
        return __n('week_ago', $weeks, ['count' => $weeks], $locale);
    } elseif ($diff < 31536000) {
        $months = floor($diff / 2592000);
        return __n('month_ago', $months, ['count' => $months], $locale);
    } else {
        $years = floor($diff / 31536000);
        return __n('year_ago', $years, ['count' => $years], $locale);
    }
}