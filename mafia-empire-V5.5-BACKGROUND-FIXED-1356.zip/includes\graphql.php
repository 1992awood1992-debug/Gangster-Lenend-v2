<?php
/**
 * Eye Of The Mafia - GraphQL API
 * Flexible query API with complexity analysis and rate limiting.
 */

require_once __DIR__ . '/init.php';

/**
 * GraphQL schema definition (simplified)
 */
const GRAPHQL_SCHEMA = '
type User {
    id: ID!
    username: String!
    level: Int!
    money: Int!
    bank: Int!
    bullets: Int!
    energy: Int!
    energy_max: Int!
    nerve: Int!
    nerve_max: Int!
    health: Int!
    health_max: Int!
    xp: Int!
    crew: Crew
    items: [UserItem!]!
    stats: UserStats!
}

type UserStats {
    strength: Int!
    speed: Int!
    defense: Int!
    iq: Int!
    kills: Int!
    deaths: Int!
}

type Crew {
    id: ID!
    name: String!
    tag: String!
    level: Int!
    members: Int!
}

type UserItem {
    id: ID!
    name: String!
    type: String!
    attack: Int!
    defense: Int!
    qty: Int!
    equipped: Boolean!
}

type Item {
    id: ID!
    name: String!
    description: String!
    type: String!
    attack: Int!
    defense: Int!
    cost: Int!
    min_level: Int!
    rarity: String!
}

type Mission {
    id: ID!
    name: String!
    description: String!
    energy_cost: Int!
    min_level: Int!
    reward_money: Int!
    reward_xp: Int!
    reward_points: Int!
    risk: Int!
    district: District!
}

type District {
    id: ID!
    name: String!
    description: String!
    unlock_level: Int!
    income_bonus: Int!
}

type Heist {
    id: ID!
    name: String!
    description: String!
    min_crew_level: Int!
    min_members: Int!
    max_members: Int!
    phases: [HeistPhase!]!
    reward_money: Int!
    reward_xp: Int!
    reward_points: Int!
}

type HeistPhase {
    name: String!
    description: String!
    requirements: PhaseRequirements!
    reward_money: Int!
    reward_xp: Int!
}

type PhaseRequirements {
    items: [PhaseItem!]!
    stats: PhaseStats!
}

type PhaseItem {
    item_id: Int!
    qty: Int!
}

type PhaseStats {
    strength: Int!
    speed: Int!
    iq: Int!
    defense: Int!
}

type Query {
    me: User
    user(id: ID!): User
    item(id: ID!): Item
    items(type: String): [Item!]!
    mission(id: ID!): Mission
    missions(district_id: Int): [Mission!]!
    district(id: ID!): District
    districts: [District!]!
    heist(id: ID!): Heist
    heists: [Heist!]!
    heistInstance(id: ID!): HeistInstance
    myHeistInstances: [HeistInstance!]!
    marketListings(type: String, search: String, max_price: Int): [MarketListing!]!
    myMarketListings: [MarketListing!]!
    myMarketBids: [MarketBid!]!
    crew: Crew
    crewMembers: [CrewMember!]!
    leaderboard(type: String!, limit: Int): [LeaderboardEntry!]!
    properties: [UserProperty!]!
    dailyRewards: DailyRewardInfo!
    craftingRecipes: [CraftingRecipe!]!
    heists: [Heist!]!
    raceTracks: [RaceTrack!]!
    activeRaces: [RaceEvent!]!
    myVehicles: [UserVehicle!]!
    raceHistory: [RaceResult!]!
    politics: PoliticsDashboard!
}

type HeistInstance {
    id: ID!
    heist: Heist!
    status: String!
    current_phase: Int!
    participants: [HeistParticipant!]!
    started_at: String
    completed_at: String
}

type HeistParticipant {
    user_id: Int!
    username: String!
    role: String!
    ready: Boolean!
}

type MarketListing {
    id: ID!
    item_type: String!
    item_name: String!
    qty: Int!
    bid_price: Int!
    buyout_price: Int
    min_bid: Int!
    auction_end: String
    seller_name: String!
    attack: Int
    defense: Int
}

type MarketBid {
    id: ID!
    listing: MarketListing!
    amount: Int!
    status: String!
    placed_at: String!
}

type CrewMember {
    user_id: Int!
    username: String!
    level: Int!
    rank: String!
}

type LeaderboardEntry {
    rank: Int!
    user_id: Int!
    username: String!
    value: Int!
}

type UserProperty {
    id: ID!
    name: String!
    level: Int!
    max_level: Int!
    hourly_income: PropertyIncome!
    can_collect: Boolean!
    hours_ready: Int!
}

type PropertyIncome {
    money: Int!
    bullets: Int!
    points: Int!
}

type DailyRewardInfo {
    current_streak: Int!
    longest_streak: Int!
    total_logins: Int!
    reward_day: Int!
    today_reward: DailyReward
    can_claim_today: Boolean!
    upcoming_rewards: [DailyReward!]!
}

type DailyReward {
    day: Int!
    type: String!
    value: Int!
    is_milestone: Boolean!
    milestone_label: String
}

type CraftingRecipe {
    id: ID!
    name: String!
    description: String!
    category: String!
    output_item: Item!
    output_qty: Int!
    energy_cost: Int!
    money_cost: Int!
    ingredients: [CraftingIngredient!]!
    success_chance: Int!
    known: Boolean!
}

type CraftingIngredient {
    item_type: String!
    item_id: Int!
    item_name: String!
    qty: Int!
}

type RaceTrack {
    id: ID!
    name: String!
    description: String!
    min_vehicle_level: Int!
    distance_km: Float!
    entry_fee_money: Int!
    entry_fee_bullets: Int!
    base_reward_money: Int!
    base_reward_xp: Int!
}

type RaceEvent {
    id: ID!
    track: RaceTrack!
    status: String!
    max_racers: Int!
    entry_fee_money: Int!
    entry_fee_bullets: Int!
    prize_pool_money: Int!
    racers: Int!
    participants: [RaceParticipant!]!
}

type RaceParticipant {
    user_id: Int!
    username: String!
    vehicle_name: String!
    position: Int
    finish_time_ms: Int
}

type UserVehicle {
    id: ID!
    name: String!
    attack: Int!
    defense: Int!
    qty: Int!
}

type RaceResult {
    id: ID!
    track_name: String!
    vehicle_name: String!
    position: Int!
    finish_time_ms: Int!
    payout_money: Int!
    payout_xp: Int!
    payout_points: Int!
}

type PoliticsDashboard {
    current_election: Election
    mayor: Mayor
    policies: [CityPolicy!]!
    candidates: [Candidate!]!
    user_vote: Vote
    can_nominate: Boolean!
}

type Election {
    id: ID!
    number: Int!
    status: String!
    term_start: String!
    term_end: String!
    total_votes: Int!
}

type Mayor {
    id: ID!
    username: String!
    election_number: Int!
    term_end: String!
}

type CityPolicy {
    id: ID!
    name: String!
    description: String!
    category: String!
    effect_type: String!
    effect_value: Float!
    cost_per_day: Int!
    is_active: Boolean!
    expires_at: String
}

type Candidate {
    id: ID!
    username: String!
    level: Int!
    platform: String
    votes: Int!
}

type Vote {
    candidate_id: Int!
    candidate_name: String!
}

type Mutation {
    login(username: String!, password: String!): AuthPayload!
    register(username: String!, email: String!, password: String!): AuthPayload!
    startMission(mission_id: ID!): MissionResult!
    doJob(job_id: ID!): JobResult!
    gymTrain(stat: String!): GymResult!
    buyItem(item_id: ID!): BuyResult!
    equipItem(user_item_id: ID!): EquipResult!
    startHeist(heist_id: ID!): HeistStartResult!
    readyHeist(instance_id: ID!): ReadyResult!
    completeHeistPhase(instance_id: ID!, phase: Int!): PhaseResult!
    buyProperty(property_type_id: ID!): PropertyResult!
    upgradeProperty(property_id: ID!, target_level: Int): PropertyResult!
    collectProperty(property_id: ID!): CollectResult!
    joinRace(race_id: ID!, vehicle_id: ID!): RaceJoinResult!
    placeBet(race_id: ID!, target_id: ID!, amount_money: Int!, amount_bullets: Int): BetResult!
    createMarketListing(item_type: String!, item_id: ID!, qty: Int!, buyout_price: Int, bid_price: Int, min_bid: Int, duration_hours: Int): MarketResult!
    placeBid(listing_id: ID!, amount: Int!): BidResult!
    buyoutListing(listing_id: ID!): MarketResult!
    cancelListing(listing_id: ID!): MarketResult!
    nominateForMayor(platform: String): NominationResult!
    voteForMayor(candidate_id: ID!): VoteResult!
    enactPolicy(policy_id: ID!): PolicyResult!
    revokePolicy(policy_id: ID!): PolicyResult!
    claimDailyReward: DailyRewardResult!
    craftItem(recipe_id: ID!): CraftResult!
    startHeist(heist_id: ID!): HeistStartResult!
    joinRace(race_id: ID!, vehicle_id: ID!): RaceJoinResult!
}

type AuthPayload {
    success: Boolean!
    token: String
    user: User
    errors: [String!]
}

type MissionResult {
    success: Boolean!
    message: String!
    rewards: MissionRewards
}

type MissionRewards {
    money: Int!
    xp: Int!
    points: Int!
}

type JobResult {
    success: Boolean!
    message: String!
    payout: Int!
    xp: Int!
}

type GymResult {
    success: Boolean!
    message: String!
    stat: String!
    gain: Int!
}

type BuyResult {
    success: Boolean!
    message: String!
    item: UserItem
}

type EquipResult {
    success: Boolean!
    message: String!
}

type HeistStartResult {
    success: Boolean!
    message: String!
    instance_id: ID
}

type ReadyResult {
    success: Boolean!
    message: String!
    all_ready: Boolean!
}

type PhaseResult {
    success: Boolean!
    message: String!
    next_phase: Int
    completed: Boolean!
}

type PropertyResult {
    success: Boolean!
    message: String!
    property_id: ID
}

type CollectResult {
    success: Boolean!
    message: String!
    money: Int!
    bullets: Int!
    points: Int!
    hours: Int!
}

type RaceJoinResult {
    success: Boolean!
    message: String!
}

type BetResult {
    success: Boolean!
    message: String!
}

type MarketResult {
    success: Boolean!
    message: String!
    listing_id: ID
}

type BidResult {
    success: Boolean!
    message: String!
}

type NominationResult {
    success: Boolean!
    message: String!
}

type VoteResult {
    success: Boolean!
    message: String!
}

type PolicyResult {
    success: Boolean!
    message: String!
}

type DailyRewardResult {
    success: Boolean!
    message: String!
    rewards: [String!]!
    streak: Int!
}

type CraftResult {
    success: Boolean!
    message: String!
    output: [String!]!
}

type HeistStartResult {
    success: Boolean!
    message: String!
    instance_id: ID
}

type RaceJoinResult {
    success: Boolean!
    message: String!
}
';

/**
 * GraphQL complexity analyzer
 */
function graphql_analyze_complexity(string $query): array
{
    // Simplified complexity analysis
    $fieldCount = substr_count($query, '{') - substr_count($query, '}');
    $depth = 0;
    $maxDepth = 0;
    for ($i = 0; $i < strlen($query); $i++) {
        if ($query[$i] === '{') {
            $depth++;
            $maxDepth = max($maxDepth, $depth);
        } elseif ($query[$i] === '}') {
            $depth--;
        }
    }
    
    // Estimate field count
    $fieldCount = substr_count($query, ':') + substr_count($query, '(');
    
    return [
        'complexity' => $fieldCount * $maxDepth,
        'depth' => $maxDepth,
        'field_count' => $fieldCount,
    ];
}

/**
 * Execute GraphQL query
 */
function graphql_execute(string $query, array $variables = [], ?string $operationName = null, int $userId = 0): array
{
    $startTime = microtime(true);
    
    // Analyze complexity
    $complexity = graphql_analyze_complexity($query);
    
    // Rate limit check
    if ($userId) {
        $recentComplexity = (int) fetch_one("
            SELECT COALESCE(SUM(complexity),0) FROM api_graphql_complexity 
            WHERE api_key_id = (SELECT id FROM api_keys WHERE user_id = ?) 
            AND executed_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)
        ", [$userId], 0);
        
        if ($recentComplexity + $complexity['complexity'] > 1000) {
            return [
                'errors' => [['message' => 'GraphQL complexity limit exceeded']],
                'data' => null,
            ];
        }
    }
    
    // For now, return schema introspection or mock data
    // In production, use a real GraphQL engine like webonyx/graphql-php
    
    if (strpos($query, '__schema') !== false || strpos($query, '__type') !== false) {
        return [
            'data' => ['__schema' => ['types' => []]],
        ];
    }
    
    // Mock response for demo
    $duration = (int) ((microtime(true) - $startTime) * 1000);
    
    // Log complexity
    if ($userId) {
        $apiKey = fetch('SELECT id FROM api_keys WHERE user_id = ? AND revoked = 0 LIMIT 1', [$userId]);
        if ($apiKey) {
            insert('api_graphql_complexity', [
                'api_key_id' => (int) $apiKey['id'],
                'query_hash' => hash('sha256', $query),
                'complexity' => $complexity['complexity'],
                'depth' => $complexity['depth'],
                'fields_count' => $complexity['field_count'],
                'duration_ms' => $duration,
                'status' => 'success',
            ]);
        }
    }
    
    return [
        'data' => ['message' => 'GraphQL endpoint ready. Implement with webonyx/graphql-php for full support.'],
        'extensions' => [
            'complexity' => $complexity,
            'duration_ms' => $duration,
        ],
    ];
}

/**
 * GraphQL HTTP endpoint
 */
function graphql_handle_request(): void
{
    header('Content-Type: application/json');
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['errors' => [['message' => 'Method not allowed']]]);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        echo json_encode(['errors' => [['message' => 'Invalid JSON']]]);
        return;
    }
    
    $query = $input['query'] ?? '';
    $variables = $input['variables'] ?? [];
    $operationName = $input['operationName'] ?? null;
    
    if (!$query) {
        echo json_encode(['errors' => [['message' => 'No query provided']]]);
        return;
    }
    
    $userId = 0;
    if (is_logged_in()) {
        $u = current_user();
        $userId = $u['id'];
    }
    
    $result = graphql_execute($query, $input['variables'] ?? [], $input['operationName'] ?? null, $userId);
    echo json_encode($result);
}

/**
 * GraphQL Playground (for development)
 */
function graphql_playground(): void
{
    if (!defined('GRAPHQL_PLAYGROUND') || !GRAPHQL_PLAYGROUND) {
        http_response_code(404);
        exit;
    }
    ?>
<!DOCTYPE html>
<html>
<head>
    <title>GraphQL Playground</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/graphql-playground-react/build/static/css/index.css" />
    <script src="https://cdn.jsdelivr.net/npm/graphql-playground-react/build/static/js/middleware.js"></script>
</head>
<body>
    <div id="root"></div>
    <script>
        window.addEventListener('load', function (event) {
            GraphQLPlayground.init(document.getElementById('root'), {
                endpoint: '/api/graphql.php',
                settings: {
                    'editor.theme': 'dark',
                    'editor.fontSize': 14,
                    'editor.reuseHeaders': true,
                },
            });
        });
    </script>
</body>
</html>
    <?php
}