<?php
/**
 * Eye Of The Mafia - Quality of Life Helpers
 * Bulk actions, keyboard shortcuts, accessibility utilities
 */

declare(strict_types=1);

require_once __DIR__ . '/init.php';

/**
 * Generate bulk action form for list pages
 * 
 * @param array $items Items with 'id' and 'label' keys
 * @param array $actions Available actions: ['action_key' => 'Action Label']
 * @param string $formId Form ID for JS targeting
 * @return string HTML form
 */
function qol_bulk_action_form(array $items, array $actions, string $formId = 'bulk-action-form'): string
{
    if (empty($items)) return '';
    
    $html = '<form method="post" id="' . e($formId) . '" class="bulk-action-form">';
    $html .= csrf_field();
    $html .= '<input type="hidden" name="bulk_action" value="1">';
    
    // Select all checkbox
    $html .= '<div class="bulk-header" style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--line);margin-bottom:8px">';
    $html .= '<label style="display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" id="bulk-select-all"> <span class="muted">Select all ' . count($items) . '</span></label>';
    $html .= '<div style="flex:1"></div>';
    $html .= '<select name="action" class="bulk-action-select" style="padding:6px 10px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)" required disabled>';
    $html .= '<option value="">— Choose action —</option>';
    foreach ($actions as $key => $label) {
        $html .= '<option value="' . e($key) . '">' . e($label) . '</option>';
    }
    $html .= '</select>';
    $html .= '<button type="submit" class="btn btn-gold btn-sm" disabled>Apply</button>';
    $html .= '</div>';
    
    // Items table with checkboxes
    $html .= '<div class="table-wrap"><table><thead><tr>';
    $html .= '<th style="width:40px"><input type="checkbox" class="bulk-item-check" data-target="all"></th>';
    $html .= '<th>Item</th><th>Actions</th></tr></thead><tbody>';
    
    foreach ($items as $item) {
        $html .= '<tr>';
        $html .= '<td><input type="checkbox" name="ids[]" value="' . e($item['id']) . '" class="bulk-item-check"></td>';
        $html .= '<td>' . e($item['label']) . '</td>';
        $html .= '<td><span class="muted">—</span></td>';
        $html .= '</tr>';
    }
    
    $html .= '</tbody></table></div></form>';
    return $html;
}

/**
 * Render keyboard shortcut help modal
 */
function qol_keyboard_shortcuts(): string
{
    $shortcuts = [
        ['G', 'D', 'Go to Dashboard'],
        ['G', 'M', 'Go to Missions'],
        ['G', 'K', 'Go to Kill'],
        ['G', 'C', 'Go to Casino'],
        ['G', 'B', 'Go to Bank'],
        ['G', 'P', 'Go to Profile'],
        ['G', 'S', 'Go to Settings'],
        ['/', '—', 'Focus Search'],
        ['?', '—', 'Show This Help'],
        ['Esc', '—', 'Close Modal / Close Drawer'],
        ['Alt', 'N', 'New Message (Crew Chat)'],
        ['Ctrl', 'Enter', 'Submit Form'],
    ];
    
    $html = '<div class="keyboard-shortcuts-modal" id="kb-shortcuts" style="display:none;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:24px;max-width:500px;width:90%;z-index:1000;box-shadow:0 20px 60px rgba(0,0,0,.5)">';
    $html .= '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px"><h3 style="margin:0">Keyboard Shortcuts</h3><button class="modal-close" style="background:none;border:none;color:var(--muted);font-size:1.5rem;cursor:pointer" aria-label="Close">&times;</button></div>';
    $html .= '<div class="shortcuts-list" style="display:grid;grid-template-columns:auto auto 1fr;gap:8px 16px;font-size:.85rem">';
    
    foreach ($shortcuts as $s) {
        $html .= '<kbd style="background:var(--bg);border:1px solid var(--line);border-radius:3px;padding:2px 6px;font-family:monospace;font-size:.75rem">' . e($s[0]) . '</kbd>';
        if ($s[1] !== '—') {
            $html .= '<kbd style="background:var(--bg);border:1px solid var(--line);border-radius:3px;padding:2px 6px;font-family:monospace;font-size:.75rem">+</kbd>';
            $html .= '<kbd style="background:var(--bg);border:1px solid var(--line);border-radius:3px;padding:2px 6px;font-family:monospace;font-size:.75rem">' . e($s[1]) . '</kbd>';
        } else {
            $html .= '<span style="color:var(--muted);width:24px">+</span>';
            $html .= '<span style="color:var(--muted)"></span>';
        }
        $html .= '<span style="color:var(--text)">' . e($s[2]) . '</span>';
    }
    
    $html .= '</div></div>';
    return $html;
}

/**
 * Add accessibility attributes to form elements
 */
function qol_accessible_input(array $attrs = []): string
{
    $defaults = [
        'type' => 'text',
        'name' => '',
        'id' => '',
        'label' => '',
        'placeholder' => '',
        'required' => false,
        'aria_describedby' => '',
        'aria_required' => false,
        'autocomplete' => 'off',
    ];
    $a = array_merge($defaults, $attrs);
    
    $id = $a['id'] ?: 'input_' . uniqid();
    $labelId = $id . '_label';
    $descId = $id . '_desc';
    
    $html = '<div class="form-field">';
    if ($a['label']) {
        $html .= '<label id="' . e($labelId) . '" for="' . e($id) . '">' . e($a['label']) . ($a['required'] ? ' <span class="required" aria-hidden="true">*</span>' : '') . '</label>';
    }
    $html .= '<input type="' . e($a['type']) . '" id="' . e($id) . '" name="' . e($a['name']) . '"';
    if ($a['placeholder']) $html .= ' placeholder="' . e($a['placeholder']) . '"';
    if ($a['required']) $html .= ' required aria-required="true"';
    if ($a['aria_describedby']) $html .= ' aria-describedby="' . e($a['aria_describedby']) . '"';
    elseif (!empty($a['placeholder'])) $html .= ' aria-describedby="' . e($descId) . '"';
    $html .= ' autocomplete="' . e($a['autocomplete']) . '">';
    
    if ($a['placeholder']) {
        $html .= '<span id="' . e($descId) . '" class="form-hint" style="font-size:.75rem;color:var(--muted);margin-top:4px;display:block">' . e($a['placeholder']) . '</span>';
    }
    
    return $html;
}

/**
 * Generate skip link for main content
 */
function qol_skip_link(): string
{
    return '<a href="#main-content" class="skip-link" style="position:absolute;top:-100%;left:50%;transform:translateX(-50%);padding:10px 18px;border-radius:3px;background:linear-gradient(180deg,var(--gold),var(--accent));color:var(--ink);font-weight:700;font-size:.82rem;border:1px solid var(--accent-2);box-shadow:0 4px 16px rgba(0,0,0,.5);z-index:1000;white-space:nowrap">Skip to main content</a>';
}

/**
 * Announce message to screen readers (live region)
 */
function qol_announce(string $message, string $politeness = 'polite'): string
{
    return '<div aria-live="' . e($politeness) . '" aria-atomic="true" class="sr-only" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden">' . e($message) . '</div>';
}

/**
 * Focus trap for modals/drawers
 */
function qol_focus_trap_js(): string
{
    return <<<'JS'
(function () {
  function trapFocus(element) {
    var focusable = element.querySelectorAll('a[href], button, input, textarea, select, [tabindex]:not([tabindex="-1"])');
    if (!focusable.length) return;
    var first = focusable[0];
    var last = focusable[focusable.length - 1];
    
    function handleTab(e) {
      if (e.key !== 'Tab') return;
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault(); last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault(); first.focus();
      }
    }
    element.addEventListener('keydown', handleTab);
    first.focus();
    return function() { element.removeEventListener('keydown', handleTab); };
  }
  
  // Export for global use
  window.trapFocus = trapFocus;
})();
JS;
}

/**
 * Bulk action handler for admin list pages
 * 
 * @param string $action Action key
 * @param array $ids Array of IDs
 * @param callable $handler Function(action, ids) -> array ['ok' => bool, 'message' => string]
 * @return array Result
 */
function qol_handle_bulk_action(string $action, array $ids, callable $handler): array
{
    if (empty($ids)) {
        return ['ok' => false, 'message' => 'No items selected'];
    }
    if ($action === '') {
        return ['ok' => false, 'message' => 'No action selected'];
    }
    return $handler($action, $ids);
}

/**
 * Render sortable table header
 */
function qol_sortable_header(string $column, string $label, string $currentSort, string $currentDir, array $params = []): string
{
    $isActive = $currentSort === $column;
    $nextDir = ($isActive && $currentDir === 'asc') ? 'desc' : 'asc';
    $icon = $isActive ? ($currentDir === 'asc' ? '↑' : '↓') : '↕';
    
    $newParams = array_merge($params, ['sort' => $column, 'dir' => $nextDir]);
    $url = '?' . http_build_query($newParams);
    
    return '<a href="' . e($url) . '" class="sortable-header" style="display:flex;align-items:center;gap:4px;color:inherit;text-decoration:none"><span>' . e($label) . '</span><span class="sort-icon" aria-hidden="true">' . $icon . '</span></a>';
}

/**
 * Live region for dynamic updates
 */
function qol_live_region(string $id = 'live-region', string $politeness = 'polite'): string
{
    return '<div id="' . e($id) . '" aria-live="' . e($politeness) . '" aria-atomic="true" class="sr-only" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden"></div>';
}