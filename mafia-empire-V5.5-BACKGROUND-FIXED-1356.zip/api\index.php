<?php
/**
 * Mafia Empire - REST API front controller (v1).
 *
 * Route it one of three ways:
 *   GET /api/v1/me                     (Apache rewrite / built-in-server router)
 *   GET /api/index.php/v1/me           (PATH_INFO)
 *   GET /api/index.php?route=v1/me     (works everywhere, incl. php -S without a router)
 *
 * See docs/API.md for the full contract.
 */
require_once __DIR__ . '/../includes/api.php';
require_once __DIR__ . '/../includes/migrate.php';

// Preflight + CORS.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    api_cors();
    http_response_code(204);
    header('Content-Length: 0');
    exit;
}
api_cors();
api_register_logging();

if (!db_installed()) {
    api_fail(503, 'The game database is not installed yet.', 'not_installed');
}
run_migrations();

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$seg    = api_segments();
$version = $seg[0] ?? '';

// Root: discovery document.
if ($version === '') {
    api_ok([
        'name'      => SITE_NAME,
        'version'   => GAME_VERSION,
        'api'       => 'v1',
        'docs'      => 'docs/API.md',
        'endpoints' => [
            'GET  v1/health',
            'GET  v1/leaderboards?board=level|kills|cash&limit=25',
            'GET  v1/market',
            'GET  v1/players/{id}',
            'GET  v1/me',
            'GET  v1/me/notifications',
            'POST v1/webhooks/test',
            'GET  v1/admin/stats',
        ],
    ]);
}

if ($version !== 'v1') {
    api_fail(404, 'Unknown API version. Only v1 is available.', 'not_found');
}
array_shift($seg);

$resource = $seg[0] ?? '';
$sub      = $seg[1] ?? '';
$param    = $seg[1] ?? '';

/* ------------------------- Public: health ------------------------- */
if ($resource === 'health') {
    if ($method !== 'GET') {
        api_fail(405, 'Use GET for this endpoint.', 'method_not_allowed');
    }
    api_ok([
        'status'         => 'ok',
        'game_version'   => GAME_VERSION,
        'schema_version' => (int) fetch_one('SELECT v FROM settings WHERE k = ?', ['schema_version'], 0),
        'time'           => now(),
    ]);
}

/* ------------------------- Public: leaderboards ------------------------- */
if ($resource === 'leaderboards') {
    if ($method !== 'GET') {
        api_fail(405, 'Use GET for this endpoint.', 'method_not_allowed');
    }
    $boards = [
        'level' => 'level DESC, xp DESC',
        'kills' => 'kills DESC',
        'cash'  => '(money + bank) DESC',
        'xp'    => 'xp DESC',
    ];
    $board = (string) ($_GET['board'] ?? 'level');
    $order = $boards[$board] ?? null;
    if ($order === null) {
        api_fail(400, 'Unknown board. Choose one of: ' . implode(', ', array_keys($boards)) . '.', 'bad_request');
    }
    $limit = min(100, max(1, (int) ($_GET['limit'] ?? 25)));
    $rows  = fetch_all("SELECT * FROM users WHERE is_banned = 0 ORDER BY $order LIMIT $limit");
    $out   = [];
    $rank  = 1;
    foreach ($rows as $r) {
        $out[] = api_public_player_payload($r) + [
            'rank'  => $rank++,
            'cash'  => (int) $r['money'] + (int) $r['bank'],
            'xp'    => (int) $r['xp'],
        ];
    }
    api_ok($out, ['board' => $board, 'count' => count($out)]);
}

/* ------------------------- Public: market ------------------------- */
if ($resource === 'market') {
    if ($method !== 'GET') {
        api_fail(405, 'Use GET for this endpoint.', 'method_not_allowed');
    }
    $limit = min(100, max(1, (int) ($_GET['limit'] ?? 50)));
    $rows  = fetch_all(
        "SELECT l.id, l.seller_id, l.item_id, l.qty, l.price, l.created_at, i.name AS item_name, i.type AS item_type,
                u.username AS seller
           FROM market_listings l
           JOIN items i ON i.id = l.item_id
           JOIN users u ON u.id = l.seller_id
          WHERE l.status = 'open'
          ORDER BY l.price ASC
          LIMIT $limit"
    );
    $out = array_map(fn($r) => [
        'id'         => (int) $r['id'],
        'item_id'    => (int) $r['item_id'],
        'item'       => (string) $r['item_name'],
        'type'       => (string) $r['item_type'],
        'qty'        => (int) $r['qty'],
        'price'      => (int) $r['price'],
        'seller'     => (string) $r['seller'],
        'created_at' => (string) $r['created_at'],
    ], $rows);
    api_ok($out, ['count' => count($out)]);
}

/* ------------------------- Public: players/{id} ------------------------- */
if ($resource === 'players' && $param !== '') {
    if ($method !== 'GET') {
        api_fail(405, 'Use GET for this endpoint.', 'method_not_allowed');
    }
    $p = fetch('SELECT * FROM users WHERE id = ?', [(int) $param]);
    if (!$p) {
        api_fail(404, 'No such player.', 'not_found');
    }
    api_ok(api_public_player_payload($p));
}

/* ------------------------- Authenticated: /me ------------------------- */
if ($resource === 'me') {
    $key = api_authenticate();
    api_require_scope($key, 'read');
    api_rate_limit($key);
    api_touch_key($key);
    $u = api_key_user($key);

    if ($sub === '') {
        if ($method !== 'GET') {
            api_fail(405, 'Use GET for this endpoint.', 'method_not_allowed');
        }
        api_ok(api_player_payload($u));
    }
    if ($sub === 'notifications') {
        if ($method !== 'GET') {
            api_fail(405, 'Use GET for this endpoint.', 'method_not_allowed');
        }
        $limit = min(50, max(1, (int) ($_GET['limit'] ?? 25)));
        $rows  = fetch_all('SELECT id, text, link, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT ' . $limit, [(int) $u['id']]);
        $unread = (int) fetch_one('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [(int) $u['id']], 0);
        $out = array_map(fn($n) => [
            'id'         => (int) $n['id'],
            'text'       => (string) $n['text'],
            'link'       => (string) $n['link'],
            'read'       => (bool) $n['is_read'],
            'created_at' => (string) $n['created_at'],
        ], $rows);
        api_ok($out, ['unread' => $unread, 'count' => count($out)]);
    }
    api_fail(404, 'Unknown endpoint.', 'not_found');
}

/* ------------------------- Authenticated: webhook test ------------------------- */
if ($resource === 'webhooks' && $sub === 'test') {
    if ($method !== 'POST') {
        api_fail(405, 'Use POST for this endpoint.', 'method_not_allowed');
    }
    $key = api_authenticate();
    api_require_scope($key, 'write');
    api_rate_limit($key);
    api_touch_key($key);
    $u = api_key_user($key);

    $id    = (int) (api_input()['id'] ?? 0);
    $hooks = $id > 0
        ? fetch_all('SELECT * FROM webhooks WHERE id = ? AND user_id = ?', [$id, (int) $u['id']])
        : fetch_all('SELECT * FROM webhooks WHERE user_id = ? AND active = 1', [(int) $u['id']]);
    if (!$hooks) {
        api_fail(404, 'No matching webhook found.', 'not_found');
    }
    $results = [];
    foreach ($hooks as $h) {
        [$ok, $code, $err] = webhook_send_test($h);
        $results[] = ['id' => (int) $h['id'], 'url' => (string) $h['url'], 'ok' => $ok, 'status' => $code, 'error' => $err];
    }
    api_ok($results);
}

/* ------------------------- Authenticated: admin stats ------------------------- */
if ($resource === 'admin' && $sub === 'stats') {
    if ($method !== 'GET') {
        api_fail(405, 'Use GET for this endpoint.', 'method_not_allowed');
    }
    $key = api_authenticate();
    api_require_scope($key, 'admin');
    api_rate_limit($key);
    api_touch_key($key);
    api_key_user($key);

    api_ok([
        'players'      => (int) fetch_one('SELECT COUNT(*) FROM users', [], 0),
        'banned'       => (int) fetch_one('SELECT COUNT(*) FROM users WHERE is_banned = 1', [], 0),
        'crews'        => (int) fetch_one('SELECT COUNT(*) FROM crews', [], 0),
        'kills'        => (int) fetch_one('SELECT COUNT(*) FROM kill_log', [], 0),
        'money_total'  => (int) fetch_one('SELECT COALESCE(SUM(money + bank), 0) FROM users', [], 0),
        'active_keys'  => (int) fetch_one('SELECT COUNT(*) FROM api_keys WHERE revoked_at IS NULL', [], 0),
        'requests_24h' => (int) fetch_one('SELECT COUNT(*) FROM api_requests WHERE created_at >= (NOW() - INTERVAL 1 DAY)', [], 0),
        'webhooks'     => (int) fetch_one('SELECT COUNT(*) FROM webhooks WHERE active = 1', [], 0),
    ]);
}

api_fail(404, 'Unknown endpoint. See GET /api/v1 for the directory.', 'not_found');
