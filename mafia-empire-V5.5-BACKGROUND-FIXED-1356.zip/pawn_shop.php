<?php
/**
 * Eye Of The Mafia - Pawn Shop
 * Quick cash for items, redeem later with interest. Or buy forfeited items cheap.
 */

require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'Pawn Shop';
require __DIR__ . '/includes/header.php';

$pawned = fetch_all("
    SELECT pi.*, i.name, i.type, i.attack, i.defense, i.rarity
    FROM pawned_items pi
    JOIN items i ON i.id = pi.item_id
    WHERE pi.user_id = ? AND pi.status = 'pawned'
    ORDER BY pi.pawned_at DESC
", [$u['id']]);

$forfeited = fetch_all("
    SELECT pi.*, i.name, i.type, i.attack, i.defense, i.rarity
    FROM pawned_items pi
    JOIN items i ON i.id = pi.item_id
    WHERE pi.status = 'forfeited' AND pi.buyout_price > 0
    ORDER BY pi.forfeited_at DESC
    LIMIT 50
");

$redeemed = fetch_all("
    SELECT pr.*, i.name, i.type
    FROM pawn_redeem_log pr
    JOIN items i ON i.id = pr.item_id
    WHERE pr.user_id = ?
    ORDER BY pr.redeemed_at DESC
    LIMIT 20
", [$u['id']]);

?>
<div class="card">
  <div class="panel-heading">Pawn Shop</div>
  <p class="muted small">Pawn items for instant cash. Redeem within 7 days with 20% interest, or they're forfeited and sold. Buy forfeited items at a discount.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
  <div class="stat"><span>Items Pawned</span><b><?= count($pawned) ?></b></div>
  <div class="stat"><span>Items at Risk</span><b><?= count(array_filter($pawned, fn($p) => strtotime($p['due_at']) < time() + 86400)) ?></b></div>
</div>

<div class="grid grid-2" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Pawn an Item</div>
    <p class="muted small">Receive 50% of item value. 7 days to redeem with 20% interest.</p>
    <form method="post" style="max-width:500px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="pawn">
      <div style="margin-bottom:12px">
        <label class="muted small">Item</label>
        <select name="item_id" required style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
          <optgroup label="Weapons">
            <?php $weapons = fetch_all("SELECT ui.id as user_item_id, ui.qty, i.name, i.type, i.attack, i.rarity, i.cost FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.equipped = 0 AND i.type = 'weapon' AND ui.qty > 0", [$u['id']]); foreach ($weapons as $w): ?>
              <option value="<?= (int) $w['user_item_id'] ?>" data-type="weapon" data-value="<?= (int) $w['cost'] ?>"><?= e($w['name']) ?> (ATK +<?= (int) $w['attack'] ?>) [<?= e($w['rarity']) ?>]</option>
            <?php endforeach; ?>
          </optgroup>
          <optgroup label="Armor">
            <?php $armor = fetch_all("SELECT ui.id as user_item_id, ui.qty, i.name, i.type, i.defense, i.rarity, i.cost FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.equipped = 0 AND i.type = 'armor' AND ui.qty > 0", [$u['id']]); foreach ($armor as $a): ?>
              <option value="<?= (int) $a['user_item_id'] ?>" data-type="armor" data-value="<?= (int) $a['cost'] ?>"><?= e($a['name']) ?> (DEF +<?= (int) $a['defense'] ?>) [<?= e($a['rarity']) ?>]</option>
            <?php endforeach; ?>
          </optgroup>
          <optgroup label="Vehicles">
            <?php $vehicles = fetch_all("SELECT ui.id as user_item_id, ui.qty, i.name, i.type, i.rarity, i.cost FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.equipped = 0 AND i.type = 'vehicle' AND ui.qty > 0", [$u['id']]); foreach ($vehicles as $v): ?>
              <option value="<?= (int) $v['user_item_id'] ?>" data-type="vehicle" data-value="<?= (int) $v['cost'] ?>"><?= e($v['name']) ?> [<?= e($v['rarity']) ?>]</option>
            <?php endforeach; ?>
          </optgroup>
          <optgroup label="Consumables/Tools">
            <?php $tools = fetch_all("SELECT ui.id as user_item_id, ui.qty, i.name, i.type, i.rarity, i.cost FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.equipped = 0 AND i.type IN ('consumable','tool','special') AND ui.qty > 0", [$u['id']]); foreach ($tools as $t): ?>
              <option value="<?= (int) $t['user_item_id'] ?>" data-type="<?= e($t['type']) ?>" data-value="<?= (int) $t['cost'] ?>"><?= e($t['name']) ?> [<?= e($t['rarity']) ?>]</option>
            <?php endforeach; ?>
          </optgroup>
        </select>
      </div>
      <div style="margin-bottom:12px">
        <label class="muted small">Loan Amount (50% of value)</label>
        <input type="text" id="pawnAmount" readonly style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
      </div>
      <button class="btn btn-gold btn-block" type="submit">Pawn Item</button>
    </form>
  </div>

  <div class="card">
    <div class="panel-heading">Your Pawned Items</div>
    <?php if (!$pawned): ?>
      <p class="muted">No items currently pawned.</p>
    <?php else: ?>
      <div class="table-wrap"><table>
        <tr><th>Item</th><th>Pawned</th><th>Due</th><th>Redeem Cost</th><th>Status</th><th></th></tr>
        <?php foreach ($pawned as $p):
          $due = new DateTime($p['due_at']);
          $now = new DateTime();
          $hoursLeft = max(0, floor(($due->getTimestamp() - $now->getTimestamp()) / 3600));
          $redeemCost = (int) ceil((int) $p['loan_amount'] * 1.2);
          $isOverdue = $hoursLeft <= 0;
        ?>
        <tr class="<?= $isOverdue ? 'error' : '' ?>">
          <td><b><?= e($p['name']) ?></b> <span class="tag tag-<?= $p['rarity'] ?>"><?= ucfirst($p['type']) ?></span></td>
          <td><?= date('M j H:i', strtotime($p['pawned_at'])) ?></td>
          <td class="<?= $isOverdue ? 'text-red' : ($hoursLeft <= 24 ? 'text-gold' : '') ?>">
            <?= $isOverdue ? 'OVERDUE' : date('M j H:i', strtotime($p['due_at'])) ?>
            <?php if (!$isOverdue): ?><br><small><?= $hoursLeft ?>h left</small><?php endif; ?>
          </td>
          <td><?= money($redeemCost) ?></td>
          <td><span class="tag tag-<?= $isOverdue ? 'error' : 'legendary' ?>"><?= $isOverdue ? 'Forfeited' : 'Active' ?></span></td>
          <td>
            <?php if (!$isOverdue): ?>
            <form method="post" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="redeem">
              <input type="hidden" name="pawn_id" value="<?= (int) $p['id'] ?>">
              <button class="btn btn-gold btn-sm" type="submit">Redeem (<?= money($redeemCost) ?>)</button>
            </form>
            <?php else: ?>
            <span class="tag tag-error">Forfeited</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </table></div>
    <?php endif; ?>
  </div>
</div>

<div class="grid grid-2" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Forfeited Items (Buy Cheap)</div>
    <p class="muted small">Items previous owners couldn't redeem. Buy at 75% of pawn value.</p>
    <?php if (!$forfeited): ?>
      <p class="muted">No forfeited items available.</p>
    <?php else: ?>
      <div class="table-wrap"><table>
        <tr><th>Item</th><th>Type</th><th>Buyout</th><th>Original Loan</th><th></th></tr>
        <?php foreach ($forfeited as $f): ?>
        <tr>
          <td><b><?= e($f['name']) ?></b> <span class="tag tag-<?= $f['rarity'] ?>"><?= ucfirst($f['type']) ?></span></td>
          <td><?= ucfirst($f['type']) ?></td>
          <td><?= money($f['buyout_price']) ?></td>
          <td class="muted">Was pawned for <?= money($f['loan_amount']) ?></td>
          <td>
            <form method="post" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="buy_forfeited">
              <input type="hidden" name="pawn_id" value="<?= (int) $f['id'] ?>">
              <button class="btn btn-gold btn-sm" type="submit">Buy (<?= money($f['buyout_price']) ?>)</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </table></div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="panel-heading">Redemption History</div>
    <?php if (!$redeemed): ?>
      <p class="muted">No redemptions yet.</p>
    <?php else: ?>
      <div class="table-wrap"><table>
        <tr><th>Date</th><th>Item</th><th>Paid</th></tr>
        <?php foreach ($redeemed as $r): ?>
        <tr>
          <td><?= date('M j H:i', strtotime($r['redeemed_at'])) ?></td>
          <td><b><?= e($r['name']) ?></b></td>
          <td><?= money($r['amount_paid']) ?></td>
        </tr>
        <?php endforeach; ?>
      </table></div>
    <?php endif; ?>
  </div>
</div>

<script>
document.querySelector('select[name="item_id"]').addEventListener('change', function() {
  const opt = this.options[this.selectedIndex];
  const val = opt.dataset.value;
  if (val) {
    document.getElementById('pawnAmount').value = '₵' + (val * 0.5).toLocaleString();
  } else {
    document.getElementById('pawnAmount').value = '';
  }
});
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>