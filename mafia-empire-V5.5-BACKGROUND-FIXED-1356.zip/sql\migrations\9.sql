-- Migration 9: Events subsystem tables (daily/weekly/seasonal challenges).
-- Idempotent: CREATE TABLE IF NOT EXISTS, safe to re-run.
-- Schema mirrors includes/event_seed.php, which owns the same DDL so the
-- installer can seed events before automatic migrations run.

CREATE TABLE IF NOT EXISTS events (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    type ENUM('daily','weekly','seasonal','special') NOT NULL DEFAULT 'special',
    start_date DATETIME NULL,
    end_date DATETIME NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    config JSON,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_active_dates (is_active, start_date, end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS event_challenges (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    event_id INT UNSIGNED NOT NULL,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    target_value INT NOT NULL DEFAULT 1,
    metric VARCHAR(50) NOT NULL,
    reward_xp INT NOT NULL DEFAULT 0,
    reward_money INT NOT NULL DEFAULT 0,
    reward_points INT NOT NULL DEFAULT 0,
    reward_items JSON,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_event (event_id),
    UNIQUE KEY uniq_event_code (event_id, code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_event_progress (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    event_id INT UNSIGNED NOT NULL,
    challenge_id INT UNSIGNED NOT NULL,
    current_value INT NOT NULL DEFAULT 0,
    completed TINYINT(1) NOT NULL DEFAULT 0,
    claimed TINYINT(1) NOT NULL DEFAULT 0,
    completed_at DATETIME NULL,
    claimed_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_user_event (user_id, event_id),
    UNIQUE KEY uniq_user_challenge (user_id, challenge_id),
    KEY idx_completed (completed, claimed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS event_rewards_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    event_id INT UNSIGNED NOT NULL,
    challenge_id INT UNSIGNED NULL,
    reward_type VARCHAR(20) NOT NULL,
    reward_value VARCHAR(255) NOT NULL,
    claimed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user_event (user_id, event_id),
    KEY idx_claimed (claimed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
