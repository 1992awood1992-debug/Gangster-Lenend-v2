<?php
ob_start();
require_once __DIR__ . '/includes/init.php';
require_admin();

$page_title = 'Admin Panel';
require __DIR__ . '/includes/header.php';

$u = current_user();
$action = $_GET['a'] ?? 'dashboard';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $postAction = $_POST['admin_action'] ?? '';

    // User actions
    if ($postAction === 'user_ban') {
        $targetId = (int)($_POST['user_id'] ?? 0);
        if ($targetId !== $u['id']) {
            q('UPDATE users SET is_banned = 1 WHERE id = ?', [$targetId]);
            flash('User banned.', 'success');
        }
    } elseif ($postAction === 'user_unban') {
        $targetId = (int)($_POST['user_id'] ?? 0);
        q('UPDATE users SET is_banned = 0 WHERE id = ?', [$targetId]);
        flash('User unbanned.', 'success');
    } elseif ($postAction === 'user_delete') {
        $targetId = (int)($_POST['user_id'] ?? 0);
        if ($targetId !== $u['id']) {
            q('DELETE FROM users WHERE id = ?', [$targetId]);
            flash('User deleted.', 'success');
        }
    } elseif ($postAction === 'user_edit') {
        $targetId = (int)($_POST['user_id'] ?? 0);
        $field = $_POST['field'] ?? '';
        $value = $_POST['value'] ?? '';
        $allowed = ['money','bank','points','bullets','energy','nerve','health','level','xp','strength','speed','defense','iq','district_id'];
        if (in_array($field, $allowed)) {
            q("UPDATE users SET `$field` = ? WHERE id = ?", [$value, $targetId]);
            flash('User updated.', 'success');
        }
    } elseif ($postAction === 'user_give_money') {
        $targetId = (int)($_POST['user_id'] ?? 0);
        $amount = (int)($_POST['amount'] ?? 0);
        $type = $_POST['type'] ?? 'cash';
        if ($amount > 0) {
            if ($type === 'cash') add_money($targetId, $amount, 'Admin gift');
            else add_money($targetId, $amount, 'Admin gift', true);
            flash('Money granted.', 'success');
        }
    } elseif ($postAction === 'user_give_points') {
        $targetId = (int)($_POST['user_id'] ?? 0);
        $amount = (int)($_POST['amount'] ?? 0);
        if ($amount > 0) { add_points($targetId, $amount); flash('Points granted.', 'success'); }
    } elseif ($postAction === 'user_give_bullets') {
        $targetId = (int)($_POST['user_id'] ?? 0);
        $amount = (int)($_POST['amount'] ?? 0);
        if ($amount > 0) { add_bullets($targetId, $amount); flash('Bullets granted.', 'success'); }
    } elseif ($postAction === 'impersonate') {
        $targetId = (int)($_POST['user_id'] ?? 0);
        if ($targetId !== $u['id']) {
            $_SESSION['uid'] = $targetId;
            flash('Now impersonating user #' . $targetId, 'info');
            redirect('play.php');
        }
    }

    // Settings
    elseif ($postAction === 'save_settings') {
        $settings = [
            'energy_tick' => (int)($_POST['energy_tick'] ?? 300),
            'nerve_tick' => (int)($_POST['nerve_tick'] ?? 600),
            'health_tick' => (int)($_POST['health_tick'] ?? 600),
            'max_energy' => (int)($_POST['max_energy'] ?? 100),
            'max_nerve' => (int)($_POST['max_nerve'] ?? 50),
            'max_health' => (int)($_POST['max_health'] ?? 100),
            'start_money' => (int)($_POST['start_money'] ?? 2500),
            'start_bullets' => (int)($_POST['start_bullets'] ?? 50),
            'start_points' => (int)($_POST['start_points'] ?? 10),
            'hospital_penalty' => (float)($_POST['hospital_penalty'] ?? 0.10),
            'referral_signup_bonus' => (int)($_POST['referral_signup_bonus'] ?? 50),
            'referral_level_5_bonus' => (int)($_POST['referral_level_5_bonus'] ?? 100),
            'referral_level_10_bonus' => (int)($_POST['referral_level_10_bonus'] ?? 250),
            'referral_level_20_bonus' => (int)($_POST['referral_level_20_bonus'] ?? 500),
            'referral_level_50_bonus' => (int)($_POST['referral_level_50_bonus'] ?? 1000),
            'referral_first_purchase_bonus' => (int)($_POST['referral_first_purchase_bonus'] ?? 200),
            'referral_reach_rank_bonus' => (int)($_POST['referral_reach_rank_bonus'] ?? 500),
            'referral_commission_pct' => (int)($_POST['referral_commission_pct'] ?? 5),
            'referral_commission_cap' => (int)($_POST['referral_commission_cap'] ?? 100000),
        ];
        foreach ($settings as $k => $v) {
            q('INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = ?', [$k, (string)$v, (string)$v]);
        }
        flash('Settings saved. Some changes require server restart.', 'success');
    }
    elseif ($postAction === 'save_timers') {
        // All timer keys
        $timerKeys = [
            'timer_missions','timer_gym','timer_bosses','timer_criminal_jobs','timer_kill',
            'timer_empire','timer_abilities','timer_drugs','timer_hospital','timer_districts',
            'timer_workbench','timer_heists','timer_tournaments',
            'timer_money','timer_bank','timer_black_market','timer_escrow','timer_equipment',
            'timer_bullet_factory','timer_points_store','timer_daily_rewards','timer_properties',
            'timer_racing','timer_marketplace','timer_stock_market','timer_pawn_shop',
            'timer_prestige_shop','timer_city_hall',
            'timer_casino','timer_lottery','timer_poker','timer_roulette','timer_video_poker',
            'timer_hilo','timer_mines','timer_blackjack','timer_baccarat','timer_keno',
            'timer_crash','timer_dice','timer_slots','timer_sports_betting',
            'timer_people','timer_crew','timer_territory','timer_crew_wars','timer_diplomacy',
            'timer_forum','timer_users','timer_leaderboards','timer_rewards','timer_achievements',
            'timer_scratch_cards','timer_sticker_book','timer_referrals',
            'timer_info','timer_updates','timer_votes','timer_statistics','timer_api_access',
            'timer_help','timer_support','timer_suggestions','timer_events','timer_trades',
            'timer_crew_chat','timer_hitlist','timer_bounties',
        ];
        foreach ($timerKeys as $tk) {
            $v = (int)($_POST[$tk] ?? 0);
            q('INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = ?', [$tk, (string)$v, (string)$v]);
        }
        flash('Action timers saved.', 'success');
    }
    elseif ($postAction === 'load_timer_presets') {
        // Sensible default presets (in seconds)
        $presets = [
            // The Empire - core gameplay
            'timer_missions' => 180,       // 3 min
            'timer_gym' => 300,            // 5 min
            'timer_bosses' => 600,         // 10 min
            'timer_criminal_jobs' => 120,  // 2 min (per job cooldown handled separately)
            'timer_kill' => 30,            // 30 sec
            'timer_empire' => 60,          // 1 min
            'timer_abilities' => 0,        // passive, no cooldown
            'timer_drugs' => 300,          // 5 min
            'timer_hospital' => 3600,      // 1 hour
            'timer_districts' => 0,        // no cooldown
            'timer_workbench' => 180,      // 3 min
            'timer_heists' => 86400,       // 24 hours (handled by heist cooldown)
            'timer_tournaments' => 0,      // scheduled
            // Money - instant
            'timer_money' => 0,
            'timer_bank' => 0,
            'timer_black_market' => 60,
            'timer_escrow' => 0,
            'timer_equipment' => 0,
            'timer_bullet_factory' => 0,
            'timer_points_store' => 0,
            'timer_daily_rewards' => 86400,
            'timer_properties' => 0,
            'timer_racing' => 300,
            'timer_marketplace' => 0,
            'timer_stock_market' => 60,
            'timer_pawn_shop' => 0,
            'timer_prestige_shop' => 0,
            'timer_city_hall' => 0,
            // Casino
            'timer_casino' => 0,
            'timer_lottery' => 0,
            'timer_poker' => 30,
            'timer_roulette' => 10,
            'timer_video_poker' => 15,
            'timer_hilo' => 10,
            'timer_mines' => 10,
            'timer_blackjack' => 15,
            'timer_baccarat' => 15,
            'timer_keno' => 30,
            'timer_crash' => 5,
            'timer_dice' => 10,
            'timer_slots' => 10,
            'timer_sports_betting' => 0,
            // People
            'timer_people' => 0,
            'timer_crew' => 0,
            'timer_territory' => 0,
            'timer_crew_wars' => 3600,
            'timer_diplomacy' => 0,
            'timer_forum' => 0,
            'timer_users' => 0,
            'timer_leaderboards' => 0,
            'timer_rewards' => 86400,
            'timer_achievements' => 0,
            'timer_scratch_cards' => 300,
            'timer_sticker_book' => 0,
            'timer_referrals' => 0,
            // Info & Help
            'timer_info' => 0,
            'timer_updates' => 0,
            'timer_votes' => 86400,
            'timer_statistics' => 0,
            'timer_api_access' => 0,
            'timer_help' => 0,
            'timer_support' => 0,
            'timer_suggestions' => 0,
            'timer_events' => 0,
            'timer_trades' => 60,
            'timer_crew_chat' => 0,
            'timer_hitlist' => 300,
            'timer_bounties' => 600,
        ];
        foreach ($presets as $tk => $v) {
            q('INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = ?', [$tk, (string)$v, (string)$v]);
        }
        flash('Timer presets loaded (sensible defaults applied).', 'success');
    }

    // Content: Missions
    elseif ($postAction === 'mission_add') {
        insert('missions', [
            'district_id' => (int)($_POST['district_id'] ?? 1),
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'energy_cost' => (int)($_POST['energy_cost'] ?? 5),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'reward_money' => (int)($_POST['reward_money'] ?? 0),
            'reward_xp' => (int)($_POST['reward_xp'] ?? 0),
            'reward_points' => (int)($_POST['reward_points'] ?? 0),
            'risk' => (int)($_POST['risk'] ?? 20),
            'story' => trim($_POST['story'] ?? ''),
        ]);
        flash('Mission added.', 'success');
    } elseif ($postAction === 'mission_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('missions', [
            'district_id' => (int)($_POST['district_id'] ?? 1),
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'energy_cost' => (int)($_POST['energy_cost'] ?? 5),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'reward_money' => (int)($_POST['reward_money'] ?? 0),
            'reward_xp' => (int)($_POST['reward_xp'] ?? 0),
            'reward_points' => (int)($_POST['reward_points'] ?? 0),
            'risk' => (int)($_POST['risk'] ?? 20),
            'story' => trim($_POST['story'] ?? ''),
        ], 'id = ?', [$id]);
        flash('Mission updated.', 'success');
    } elseif ($postAction === 'mission_delete') {
        q('DELETE FROM missions WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Mission deleted.', 'success');
    }

    // Content: Items
    elseif ($postAction === 'item_add') {
        insert('items', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'type' => $_POST['type'] ?? 'misc',
            'attack' => (int)($_POST['attack'] ?? 0),
            'defense' => (int)($_POST['defense'] ?? 0),
            'cost' => (int)($_POST['cost'] ?? 0),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'rarity' => $_POST['rarity'] ?? 'common',
        ]);
        flash('Item added.', 'success');
    } elseif ($postAction === 'item_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('items', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'type' => $_POST['type'] ?? 'misc',
            'attack' => (int)($_POST['attack'] ?? 0),
            'defense' => (int)($_POST['defense'] ?? 0),
            'cost' => (int)($_POST['cost'] ?? 0),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'rarity' => $_POST['rarity'] ?? 'common',
        ], 'id = ?', [$id]);
        flash('Item updated.', 'success');
    } elseif ($postAction === 'item_delete') {
        q('DELETE FROM items WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Item deleted.', 'success');
    }

    // Content: Bosses
    elseif ($postAction === 'boss_add') {
        insert('bosses', [
            'district_id' => (int)($_POST['district_id'] ?? 1),
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'hp' => (int)($_POST['hp'] ?? 100),
            'attack' => (int)($_POST['attack'] ?? 10),
            'defense' => (int)($_POST['defense'] ?? 5),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'energy_cost' => (int)($_POST['energy_cost'] ?? 20),
            'reward_money' => (int)($_POST['reward_money'] ?? 0),
            'reward_xp' => (int)($_POST['reward_xp'] ?? 0),
            'reward_points' => (int)($_POST['reward_points'] ?? 0),
            'reward_item_id' => $_POST['reward_item_id'] ? (int)$_POST['reward_item_id'] : null,
        ]);
        flash('Boss added.', 'success');
    } elseif ($postAction === 'boss_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('bosses', [
            'district_id' => (int)($_POST['district_id'] ?? 1),
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'hp' => (int)($_POST['hp'] ?? 100),
            'attack' => (int)($_POST['attack'] ?? 10),
            'defense' => (int)($_POST['defense'] ?? 5),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'energy_cost' => (int)($_POST['energy_cost'] ?? 20),
            'reward_money' => (int)($_POST['reward_money'] ?? 0),
            'reward_xp' => (int)($_POST['reward_xp'] ?? 0),
            'reward_points' => (int)($_POST['reward_points'] ?? 0),
            'reward_item_id' => $_POST['reward_item_id'] ? (int)$_POST['reward_item_id'] : null,
        ], 'id = ?', [$id]);
        flash('Boss updated.', 'success');
    } elseif ($postAction === 'boss_delete') {
        q('DELETE FROM bosses WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Boss deleted.', 'success');
    }

    // Content: Criminal Jobs
    elseif ($postAction === 'job_add') {
        insert('criminal_jobs', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'nerve_cost' => (int)($_POST['nerve_cost'] ?? 2),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'payout_min' => (int)($_POST['payout_min'] ?? 50),
            'payout_max' => (int)($_POST['payout_max'] ?? 150),
            'xp' => (int)($_POST['xp'] ?? 5),
            'fail_risk' => (int)($_POST['fail_risk'] ?? 20),
            'cooldown' => (int)($_POST['cooldown'] ?? 0),
        ]);
        flash('Job added.', 'success');
    } elseif ($postAction === 'job_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('criminal_jobs', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'nerve_cost' => (int)($_POST['nerve_cost'] ?? 2),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'payout_min' => (int)($_POST['payout_min'] ?? 50),
            'payout_max' => (int)($_POST['payout_max'] ?? 150),
            'xp' => (int)($_POST['xp'] ?? 5),
            'fail_risk' => (int)($_POST['fail_risk'] ?? 20),
            'cooldown' => (int)($_POST['cooldown'] ?? 0),
        ], 'id = ?', [$id]);
        flash('Job updated.', 'success');
    } elseif ($postAction === 'job_delete') {
        q('DELETE FROM criminal_jobs WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Job deleted.', 'success');
    }

    // Content: Drugs
    elseif ($postAction === 'drug_add') {
        insert('drugs', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'buy_price' => (int)($_POST['buy_price'] ?? 100),
            'sell_price' => (int)($_POST['sell_price'] ?? 150),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'effect_stat' => $_POST['effect_stat'] ?? '',
            'effect_amount' => (int)($_POST['effect_amount'] ?? 0),
            'od_risk' => (int)($_POST['od_risk'] ?? 10),
        ]);
        flash('Drug added.', 'success');
    } elseif ($postAction === 'drug_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('drugs', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'buy_price' => (int)($_POST['buy_price'] ?? 100),
            'sell_price' => (int)($_POST['sell_price'] ?? 150),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'effect_stat' => $_POST['effect_stat'] ?? '',
            'effect_amount' => (int)($_POST['effect_amount'] ?? 0),
            'od_risk' => (int)($_POST['od_risk'] ?? 10),
        ], 'id = ?', [$id]);
        flash('Drug updated.', 'success');
    } elseif ($postAction === 'drug_delete') {
        q('DELETE FROM drugs WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Drug deleted.', 'success');
    }

    // Content: Abilities
    elseif ($postAction === 'ability_add') {
        insert('abilities', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'cost_points' => (int)($_POST['cost_points'] ?? 5),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'effect_type' => $_POST['effect_type'] ?? 'passive',
            'effect_value' => (int)($_POST['effect_value'] ?? 0),
            'stat' => $_POST['stat'] ?? '',
        ]);
        flash('Ability added.', 'success');
    } elseif ($postAction === 'ability_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('abilities', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'cost_points' => (int)($_POST['cost_points'] ?? 5),
            'min_level' => (int)($_POST['min_level'] ?? 1),
            'effect_type' => $_POST['effect_type'] ?? 'passive',
            'effect_value' => (int)($_POST['effect_value'] ?? 0),
            'stat' => $_POST['stat'] ?? '',
        ], 'id = ?', [$id]);
        flash('Ability updated.', 'success');
    } elseif ($postAction === 'ability_delete') {
        q('DELETE FROM abilities WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Ability deleted.', 'success');
    }

    // Content: Gyms
    elseif ($postAction === 'gym_add') {
        insert('gyms', [
            'name' => trim($_POST['name'] ?? ''),
            'stat' => $_POST['stat'] ?? 'strength',
            'cost' => (int)($_POST['cost'] ?? 100),
            'gain' => (int)($_POST['gain'] ?? 1),
            'energy_cost' => (int)($_POST['energy_cost'] ?? 5),
            'min_level' => (int)($_POST['min_level'] ?? 1),
        ]);
        flash('Gym added.', 'success');
    } elseif ($postAction === 'gym_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('gyms', [
            'name' => trim($_POST['name'] ?? ''),
            'stat' => $_POST['stat'] ?? 'strength',
            'cost' => (int)($_POST['cost'] ?? 100),
            'gain' => (int)($_POST['gain'] ?? 1),
            'energy_cost' => (int)($_POST['energy_cost'] ?? 5),
            'min_level' => (int)($_POST['min_level'] ?? 1),
        ], 'id = ?', [$id]);
        flash('Gym updated.', 'success');
    } elseif ($postAction === 'gym_delete') {
        q('DELETE FROM gyms WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Gym deleted.', 'success');
    }

    // Content: Districts
    elseif ($postAction === 'district_add') {
        insert('districts', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'unlock_level' => (int)($_POST['unlock_level'] ?? 1),
            'income_bonus' => (int)($_POST['income_bonus'] ?? 0),
        ]);
        flash('District added.', 'success');
    } elseif ($postAction === 'district_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('districts', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'unlock_level' => (int)($_POST['unlock_level'] ?? 1),
            'income_bonus' => (int)($_POST['income_bonus'] ?? 0),
        ], 'id = ?', [$id]);
        flash('District updated.', 'success');
    } elseif ($postAction === 'district_delete') {
        q('DELETE FROM districts WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('District deleted.', 'success');
    }

    // Content: Points Store
    elseif ($postAction === 'points_store_add') {
        insert('points_store', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'cost_points' => (int)($_POST['cost_points'] ?? 1),
            'kind' => $_POST['kind'] ?? 'money',
            'amount' => (int)($_POST['amount'] ?? 0),
            'item_id' => $_POST['item_id'] ? (int)$_POST['item_id'] : null,
        ]);
        flash('Points store item added.', 'success');
    } elseif ($postAction === 'points_store_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('points_store', [
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'cost_points' => (int)($_POST['cost_points'] ?? 1),
            'kind' => $_POST['kind'] ?? 'money',
            'amount' => (int)($_POST['amount'] ?? 0),
            'item_id' => $_POST['item_id'] ? (int)$_POST['item_id'] : null,
        ], 'id = ?', [$id]);
        flash('Points store item updated.', 'success');
    } elseif ($postAction === 'points_store_delete') {
        q('DELETE FROM points_store WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Points store item deleted.', 'success');
    }

    // Content: Achievements
    elseif ($postAction === 'achievement_add') {
        insert('achievements', [
            'code' => trim($_POST['code'] ?? ''),
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'reward_points' => (int)($_POST['reward_points'] ?? 5),
            'target' => (int)($_POST['target'] ?? 1),
            'metric' => $_POST['metric'] ?? 'kills',
        ]);
        flash('Achievement added.', 'success');
    } elseif ($postAction === 'achievement_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('achievements', [
            'code' => trim($_POST['code'] ?? ''),
            'name' => trim($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'reward_points' => (int)($_POST['reward_points'] ?? 5),
            'target' => (int)($_POST['target'] ?? 1),
            'metric' => $_POST['metric'] ?? 'kills',
        ], 'id = ?', [$id]);
        flash('Achievement updated.', 'success');
    } elseif ($postAction === 'achievement_delete') {
        q('DELETE FROM achievements WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Achievement deleted.', 'success');
    }

    // Content: Stickers
    elseif ($postAction === 'sticker_add') {
        insert('stickers', [
            'code' => trim($_POST['code'] ?? ''),
            'name' => trim($_POST['name'] ?? ''),
            'rarity' => $_POST['rarity'] ?? 'common',
        ]);
        flash('Sticker added.', 'success');
    } elseif ($postAction === 'sticker_edit') {
        $id = (int)($_POST['id'] ?? 0);
        update_row('stickers', [
            'code' => trim($_POST['code'] ?? ''),
            'name' => trim($_POST['name'] ?? ''),
            'rarity' => $_POST['rarity'] ?? 'common',
        ], 'id = ?', [$id]);
        flash('Sticker updated.', 'success');
    } elseif ($postAction === 'sticker_delete') {
        q('DELETE FROM stickers WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        flash('Sticker deleted.', 'success');
    }

    // Bullet Factories
    elseif ($postAction === 'factory_edit') {
        $did = (int)($_POST['district_id'] ?? 0);
        update_row('bullet_factories', [
            'price' => (int)($_POST['price'] ?? 5000000),
            'production' => (int)($_POST['production'] ?? 25),
        ], 'district_id = ?', [$did]);
        flash('Factory updated.', 'success');
    }

    // Lottery
    elseif ($postAction === 'lottery_draw') {
        $draw = fetch('SELECT * FROM lottery_draws WHERE status = ? ORDER BY draw_date DESC LIMIT 1', ['open']);
        if ($draw) {
            $winning = mt_rand(0, 999);
            q('UPDATE lottery_draws SET winning_number = ?, status = ? WHERE id = ?', [$winning, 'drawn', $draw['id']]);
            $winners = fetch_all('SELECT * FROM lottery_tickets WHERE draw_id = ? AND number = ?', [$draw['id'], $winning]);
            if ($winners) {
                $split = (int)floor((int)$draw['pot'] / count($winners));
                foreach ($winners as $w) {
                    add_money($w['user_id'], $split, 'Lottery win');
                    notify($w['user_id'], 'Your lottery ticket matched! You won ' . money($split) . '.', 'lottery.php');
                }
            }
            flash('Lottery drawn! Winning number: ' . str_pad($winning, 3, '0', STR_PAD_LEFT), 'success');
        } else {
            flash('No open draw to draw.', 'error');
        }
    } elseif ($postAction === 'lottery_create') {
        insert('lottery_draws', ['draw_date' => date('Y-m-d', strtotime('+1 day')), 'pot' => 25000, 'status' => 'open']);
        flash('New lottery draw created for tomorrow.', 'success');
    }

    // Economy: Mass operations
    elseif ($postAction === 'mass_money') {
        $amount = (int)($_POST['amount'] ?? 0);
        $type = $_POST['type'] ?? 'cash';
        $target = $_POST['target'] ?? 'all';
        if ($amount !== 0) {
            if ($target === 'all') {
                q("UPDATE users SET `$type` = GREATEST(`$type` + ?, 0) WHERE is_banned = 0", [$amount]);
            } elseif ($target === 'online') {
                q("UPDATE users SET `$type` = GREATEST(`$type` + ?, 0) WHERE is_banned = 0 AND last_active > DATE_SUB(NOW(), INTERVAL 5 MINUTE)", [$amount]);
            } elseif ($target === 'level') {
                $minL = (int)($_POST['min_level'] ?? 1);
                $maxL = (int)($_POST['max_level'] ?? 100);
                q("UPDATE users SET `$type` = GREATEST(`$type` + ?, 0) WHERE is_banned = 0 AND level BETWEEN ? AND ?", [$amount, $minL, $maxL]);
            }
            insert('event_log', ['user_id' => 0, 'type' => 'admin_mass', 'text' => "Mass $type adjustment: $amount to $target", 'amount' => $amount]);
            flash("Mass $type adjustment applied.", 'success');
        }
    }

    // Support tickets
    elseif ($postAction === 'ticket_toggle') {
        $tid = (int)($_POST['ticket_id'] ?? 0);
        $tk = fetch('SELECT * FROM support_tickets WHERE id = ?', [$tid]);
        if ($tk) {
            q('UPDATE support_tickets SET status = ? WHERE id = ?', [$tk['status'] === 'open' ? 'closed' : 'open', $tid]);
            flash('Ticket status updated.', 'success');
        }
    } elseif ($postAction === 'ticket_delete') {
        q('DELETE FROM support_tickets WHERE id = ?', [(int)($_POST['ticket_id'] ?? 0)]);
        flash('Ticket deleted.', 'success');
    }

    // Suggestions
    elseif ($postAction === 'suggestion_status') {
        $sid = (int)($_POST['suggestion_id'] ?? 0);
        $status = $_POST['status'] ?? '';
        $allowed = ['new', 'open', 'locked', 'implemented', 'rejected'];
        if (in_array($status, $allowed, true)) {
            q('UPDATE suggestions SET status = ? WHERE id = ?', [$status, $sid]);
            flash('Suggestion status updated.', 'success');
        }
    } elseif ($postAction === 'suggestion_delete') {
        q('DELETE FROM suggestions WHERE id = ?', [(int)($_POST['suggestion_id'] ?? 0)]);
        flash('Suggestion deleted.', 'success');
    }

    // Tournaments
    elseif ($postAction === 'tournament_start') {
        $tid = (int)($_POST['tournament_id'] ?? 0);
        $res = tournament_start($tid);
        if (!empty($res['ok'])) {
            flash('Tournament started.', 'success');
        } else {
            flash($res['error'] ?? 'Could not start tournament.', 'error');
        }
    } elseif ($postAction === 'tournament_cancel') {
        $tid = (int)($_POST['tournament_id'] ?? 0);
        $res = tournament_cancel($tid, 'Cancelled by admin');
        if (!empty($res['ok'])) {
            flash('Tournament cancelled. ' . (int)($res['refunded'] ?? 0) . ' entrant(s) refunded.', 'success');
        } else {
            flash($res['error'] ?? 'Could not cancel tournament.', 'error');
        }
    } elseif ($postAction === 'tournament_delete') {
        $tid = (int)($_POST['tournament_id'] ?? 0);
        $t = tournament_get($tid);
        if ($t && in_array((string)$t['status'], ['completed', 'cancelled'], true)) {
            q('DELETE FROM tournament_matches WHERE tournament_id = ?', [$tid]);
            q('DELETE FROM tournament_rewards_log WHERE tournament_id = ?', [$tid]);
            q('DELETE FROM tournament_participants WHERE tournament_id = ?', [$tid]);
            q('DELETE FROM tournaments WHERE id = ?', [$tid]);
            flash('Tournament and its history deleted.', 'success');
        } else {
            flash('Only completed or cancelled tournaments can be deleted.', 'error');
        }
    } elseif ($postAction === 'tournament_sweep') {
        $res = tournament_sweep_run();
        flash(
            'Sweep complete — started ' . (int)($res['started'] ?? 0)
            . ', resolved ' . (int)($res['resolved'] ?? 0)
            . ', completed ' . (int)($res['completed'] ?? 0)
            . ', cancelled ' . (int)($res['cancelled'] ?? 0)
            . ', created ' . (int)($res['created'] ?? 0) . '.',
            'success'
        );
    }

    // Racing
    elseif ($postAction === 'race_start') {
        require_once __DIR__ . '/includes/racing.php';
        $res = race_start((int)($_POST['race_id'] ?? 0));
        flash(!empty($res['ok']) ? 'Race started.' : ($res['error'] ?? 'Could not start race.'), !empty($res['ok']) ? 'success' : 'error');
    } elseif ($postAction === 'race_finish') {
        require_once __DIR__ . '/includes/racing.php';
        $res = race_finish((int)($_POST['race_id'] ?? 0));
        flash(!empty($res['ok']) ? 'Race finished and prizes paid.' : ($res['error'] ?? 'Could not finish race.'), !empty($res['ok']) ? 'success' : 'error');
    }

    redirect('admin.php?a=' . $action);
}

// Fetch data for display
$totalUsers = (int)fetch_one('SELECT COUNT(*) FROM users', [], 0);
$onlineUsers = (int)fetch_one('SELECT COUNT(*) FROM users WHERE last_active > DATE_SUB(NOW(), INTERVAL 5 MINUTE) AND is_banned = 0', [], 0);
$bannedUsers = (int)fetch_one('SELECT COUNT(*) FROM users WHERE is_banned = 1', [], 0);
$totalMoney = (int)fetch_one('SELECT COALESCE(SUM(money + bank), 0) FROM users WHERE is_banned = 0', [], 0);
$totalBullets = (int)fetch_one('SELECT COALESCE(SUM(bullets), 0) FROM users WHERE is_banned = 0', [], 0);
$totalPoints = (int)fetch_one('SELECT COALESCE(SUM(points), 0) FROM users WHERE is_banned = 0', [], 0);
$totalKills = (int)fetch_one('SELECT COALESCE(SUM(kills), 0) FROM users WHERE is_banned = 0', [], 0);
$totalCrews = (int)fetch_one('SELECT COUNT(*) FROM crews', [], 0);
$openTickets = (int)fetch_one('SELECT COUNT(*) FROM support_tickets WHERE status = ?', ['open'], 0);
$pendingSuggestions = (int)fetch_one('SELECT COUNT(*) FROM suggestions WHERE status = ?', ['new'], 0);
$recentUsers = fetch_all('SELECT * FROM users ORDER BY created_at DESC LIMIT 10');
$recentKills = fetch_all('SELECT kl.*, ua.username AS attacker, uv.username AS victim FROM kill_log kl JOIN users ua ON ua.id = kl.attacker_id JOIN users uv ON uv.id = kl.victim_id ORDER BY kl.created_at DESC LIMIT 10');
$settings = fetch_all('SELECT * FROM settings');

// Sections data
$missions = fetch_all('SELECT m.*, d.name AS district_name FROM missions m JOIN districts d ON d.id = m.district_id ORDER BY m.district_id, m.min_level');
$items = fetch_all('SELECT * FROM items ORDER BY type, cost');
$bosses = fetch_all('SELECT b.*, d.name AS district_name FROM bosses b JOIN districts d ON d.id = b.district_id ORDER BY b.min_level');
$jobs = fetch_all('SELECT * FROM criminal_jobs ORDER BY min_level');
$drugs = fetch_all('SELECT * FROM drugs ORDER BY min_level');
$abilities = fetch_all('SELECT * FROM abilities ORDER BY min_level');
$gyms = fetch_all('SELECT * FROM gyms ORDER BY min_level');
$districts = fetch_all('SELECT * FROM districts ORDER BY unlock_level');
$pointsStore = fetch_all('SELECT ps.*, i.name AS item_name FROM points_store ps LEFT JOIN items i ON i.id = ps.item_id ORDER BY ps.cost_points');
$achievements = fetch_all('SELECT * FROM achievements ORDER BY id');
$stickers = fetch_all('SELECT * FROM stickers ORDER BY FIELD(rarity,\'common\',\'uncommon\',\'rare\',\'epic\',\'legendary\'), id');
$factories = fetch_all('SELECT bf.*, d.name AS district_name FROM bullet_factories bf JOIN districts d ON d.id = bf.district_id ORDER BY d.id');
$lotteryDraw = fetch('SELECT * FROM lottery_draws WHERE status = ? ORDER BY draw_date DESC LIMIT 1', ['open']);

// Additional section data
$userSearch = trim($_GET['search'] ?? '');
if ($userSearch !== '') {
    $users = fetch_all('SELECT * FROM users WHERE username LIKE ? OR email LIKE ? ORDER BY last_active DESC LIMIT 100', ["%$userSearch%", "%$userSearch%"]);
} else {
    $users = fetch_all('SELECT * FROM users ORDER BY last_active DESC LIMIT 50');
}
$tickets = fetch_all('SELECT t.*, u.username FROM support_tickets t JOIN users u ON u.id = t.user_id ORDER BY t.created_at DESC LIMIT 50');
$suggestions = fetch_all('SELECT s.*, u.username, (SELECT COUNT(*) FROM suggestion_votes v WHERE v.suggestion_id = s.id) AS votes FROM suggestions s JOIN users u ON u.id = s.user_id ORDER BY s.created_at DESC LIMIT 50');
$logs = fetch_all('SELECT * FROM event_log ORDER BY id DESC LIMIT 60');
$casinoBets = fetch_all('SELECT cb.*, u.username FROM casino_bets cb JOIN users u ON u.id = cb.user_id ORDER BY cb.id DESC LIMIT 30');
$bankTx = fetch_all('SELECT bt.*, u.username FROM bank_transactions bt JOIN users u ON u.id = bt.user_id ORDER BY bt.id DESC LIMIT 30');

// Select option maps
$districtMap = [];
foreach ($districts as $d) { $districtMap[$d['id']] = $d['name']; }
$itemMap = [];
foreach ($items as $it) { $itemMap[$it['id']] = $it['name']; }
$settingsMap = [];
foreach ($settings as $s2) { $settingsMap[$s2['k']] = $s2['v']; }

/**
 * Render a section card with title, actions, table, and optional add form
 */
function admin_section(string $title, string $action, array $fields, array $data, array $columns, array $addFields = [], array $editFields = []): void
{
    $isEditing = isset($_GET['edit']) && $_GET['edit'] !== '';
    $editId = $isEditing ? (int)$_GET['edit'] : null;
    $editRow = $editId ? fetch("SELECT * FROM $action WHERE id = ?", [$editId]) : null;
    if ($isEditing && !$editRow) { $isEditing = false; $editId = null; }

    echo '<div class="card" style="margin-top:18px">';
    echo '<div class="panel-heading">' . e($title) . '</div>';

    if ($isEditing && $editRow):
        echo '<form method="post" style="display:grid;gap:10px;max-width:700px;margin-bottom:16px">';
        echo csrf_field();
        echo '<input type="hidden" name="admin_action" value="' . e($action) . '_edit">';
        echo '<input type="hidden" name="id" value="' . e($editId) . '">';
        foreach ($editFields ?: $addFields as $field):
            $fname = $field[0];
            $label = $field[1];
            $type = $field[2] ?? 'text';
            $options = $field[3] ?? [];
            $val = $editRow[$fname] ?? '';
            echo '<label>' . e($label);
            if ($type === 'select'):
                $isList = array_is_list($options);
                echo '<select name="' . e($fname) . '">';
                foreach ($options as $optVal => $optLabel):
                    $v = $isList ? $optLabel : $optVal;
                    echo '<option value="' . e((string)$v) . '"' . ((string)$val === (string)$v ? ' selected' : '') . '>' . e($optLabel) . '</option>';
                endforeach;
                echo '</select>';
            elseif ($type === 'textarea'):
                echo '<textarea name="' . e($fname) . '">' . e($val) . '</textarea>';
            else:
                echo '<input type="' . e($type) . '" name="' . e($fname) . '" value="' . e($val) . '">';
            endif;
            echo '</label>';
        endforeach;
        echo '<button class="btn btn-gold" type="submit">Save</button>';
        echo '<a class="btn btn-sm" href="?a=' . e($action) . '">Cancel</a>';
        echo '</form>';
    elseif ($addFields):
        echo '<form method="post" style="display:grid;gap:10px;max-width:700px;margin-bottom:16px">';
        echo csrf_field();
        echo '<input type="hidden" name="admin_action" value="' . e($action) . '_add">';
        foreach ($addFields as $field):
            $fname = $field[0];
            $label = $field[1];
            $type = $field[2] ?? 'text';
            $options = $field[3] ?? [];
            echo '<label>' . e($label);
            if ($type === 'select'):
                $isList = array_is_list($options);
                echo '<select name="' . e($fname) . '">';
                foreach ($options as $optVal => $optLabel):
                    $v = $isList ? $optLabel : $optVal;
                    echo '<option value="' . e((string)$v) . '">' . e($optLabel) . '</option>';
                endforeach;
                echo '</select>';
            elseif ($type === 'textarea'):
                echo '<textarea name="' . e($fname) . '"></textarea>';
            else:
                echo '<input type="' . e($type) . '" name="' . e($fname) . '">';
            endif;
            echo '</label>';
        endforeach;
        echo '<button class="btn btn-green" type="submit">Add</button>';
        echo '</form>';
    endif;

    if (!$data):
        echo '<p class="muted">No records.</p>';
    else:
        echo '<div class="table-wrap"><table>';
        echo '<tr>';
        foreach ($columns as $col): echo '<th>' . e($col[0]) . '</th>'; endforeach;
        echo '<th>Actions</th></tr>';
        foreach ($data as $row):
            echo '<tr>';
            foreach ($columns as $col):
                $key = $col[1];
                $fmt = $col[2] ?? null;
                $val = $row[$key] ?? '';
                if ($fmt === 'money') $val = money($val);
                elseif ($fmt === 'bool') $val = $val ? 'Yes' : 'No';
                elseif ($fmt === 'date') $val = date('M j, Y', strtotime($val));
                elseif ($fmt === 'datetime') $val = date('M j, Y H:i', strtotime($val));
                echo '<td>' . e($val) . '</td>';
            endforeach;
            echo '<td>';
            echo '<a class="btn btn-sm" href="?a=' . e($action) . '&edit=' . e($row['id']) . '">Edit</a> ';
            echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Delete?\')">';
            echo csrf_field();
            echo '<input type="hidden" name="admin_action" value="' . e($action) . '_delete">';
            echo '<input type="hidden" name="id" value="' . e($row['id']) . '">';
            echo '<button class="btn btn-sm btn-danger" type="submit">Delete</button>';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        endforeach;
        echo '</table></div>';
    endif;
    echo '</div>';
}

// Main layout starts here
$tabs = [
    'dashboard' => 'Dashboard',
    'users' => 'Users',
    'settings' => 'Settings',
    'timers' => 'Timers',
    'missions' => 'Missions',
    'items' => 'Items',
    'bosses' => 'Bosses',
    'jobs' => 'Criminal Jobs',
    'drugs' => 'Drugs',
    'abilities' => 'Abilities',
    'gyms' => 'Gyms',
    'districts' => 'Districts',
    'tournaments' => 'Tournaments',
    'points_store' => 'Points Store',
    'achievements' => 'Achievements',
    'stickers' => 'Stickers',
    'factories' => 'Bullet Factories',
    'lottery' => 'Lottery',
    'economy' => 'Economy',
    'tickets' => 'Support Tickets',
    'suggestions' => 'Suggestions',
    'logs' => 'Event Logs',
    'analytics' => 'Analytics',
    'reports' => 'Reports',
    'audit' => 'Audit Log',
    'heists' => 'Heists',
    'properties' => 'Properties',
    'racing' => 'Racing',
    'market' => 'Marketplace',
    'politics' => 'City Hall',
    'crafting' => 'Workbench',
    'mini_events' => 'Mini Events',
    'weekend_events' => 'Weekend Events',
    'seasonal_events' => 'Seasonal Events',
    'deathmatch' => 'Deathmatch',
    'respect' => 'Respect',
    'prestige' => 'Prestige',
    'security' => 'Security',
];

echo '<div class="card" style="margin-bottom:18px">';
echo '<div class="panel-heading">Admin Panel</div>';
echo '<div class="pill-row" style="flex-wrap:wrap;gap:6px">';
foreach ($tabs as $key => $label) {
    $active = $key === $action ? ' on' : '';
    echo '<a class="pill' . $active . '" href="?a=' . e($key) . '">' . e($label) . '</a>';
}
echo '</div>';
echo '</div>';

switch ($action) {

case 'dashboard':
    echo '<div class="card"><div class="panel-heading">Server Overview</div>';
    echo '<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px">';
    $stats = [
        ['Users', number_format($totalUsers)],
        ['Online', number_format($onlineUsers)],
        ['Banned', number_format($bannedUsers)],
        ['Total Cash', money($totalMoney)],
        ['Bullets', number_format($totalBullets)],
        ['Points', number_format($totalPoints)],
        ['Kills', number_format($totalKills)],
        ['Crews', number_format($totalCrews)],
        ['Open Tickets', number_format($openTickets)],
        ['New Suggestions', number_format($pendingSuggestions)],
    ];
    foreach ($stats as $s) {
        echo '<div class="tile"><b style="font-size:1.25rem;color:var(--accent)">' . e($s[1]) . '</b><small>' . e($s[0]) . '</small></div>';
    }
    echo '</div></div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Recent Signups</div>';
    if ($recentUsers) {
        echo '<div class="table-wrap"><table><tr><th>User</th><th>Level</th><th>Cash</th><th>Points</th><th>Joined</th></tr>';
        foreach ($recentUsers as $ru) {
            echo '<tr><td>' . e($ru['username']) . '</td><td>' . (int)$ru['level'] . '</td><td>' . money($ru['money']) . '</td><td>' . (int)$ru['points'] . '</td><td>' . date('M j, Y', strtotime($ru['created_at'])) . '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No users yet.</p>'; }
    echo '</div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Recent Kills</div>';
    if ($recentKills) {
        echo '<div class="table-wrap"><table><tr><th>Attacker</th><th>Victim</th><th>When</th></tr>';
        foreach ($recentKills as $rk) {
            echo '<tr><td>' . e($rk['attacker']) . '</td><td>' . e($rk['victim']) . '</td><td>' . date('M j, Y H:i', strtotime($rk['created_at'])) . '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No kills yet.</p>'; }
    echo '</div>';
    break;

case 'users':
    echo '<div class="card"><div class="panel-heading">Find User</div>';
    echo '<form method="get" style="display:flex;gap:8px;flex-wrap:wrap;max-width:620px;margin:0 auto">';
    echo '<input type="hidden" name="a" value="users">';
    echo '<input type="text" name="search" value="' . e($userSearch) . '" placeholder="Username or email" style="flex:1;max-width:360px">';
    echo '<button class="btn btn-gold" type="submit">Search</button>';
    echo '</form></div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Users (' . count($users) . ')</div>';
    if ($users) {
        echo '<div class="table-wrap"><table><tr><th>ID</th><th>User</th><th>Lv</th><th>Cash</th><th>Bank</th><th>Pts</th><th>Bul</th><th>Kills</th><th>Last Visted</th><th>Status</th><th>Actions</th></tr>';
        foreach ($users as $usr) {
            echo '<tr><td>' . (int)$usr['id'] . '</td>';
            echo '<td>' . e($usr['username']) . ($usr['is_admin'] ? ' <span class="pill on" style="font-size:.65em">ADMIN</span>' : '') . '</td>';
            echo '<td>' . (int)$usr['level'] . '</td><td>' . money($usr['money']) . '</td><td>' . money($usr['bank']) . '</td>';
            echo '<td>' . (int)$usr['points'] . '</td><td>' . (int)$usr['bullets'] . '</td><td>' . (int)$usr['kills'] . '</td>';
            echo '<td>' . date('M j H:i', strtotime($usr['last_active'])) . '</td>';
            echo '<td>' . ($usr['is_banned'] ? '<span style="color:var(--red)">Banned</span>' : '<span style="color:var(--green)">Active</span>') . '</td>';
            echo '<td style="white-space:nowrap">';
            echo '<form method="post" style="display:inline">' . csrf_field()
                . '<input type="hidden" name="admin_action" value="' . ($usr['is_banned'] ? 'user_unban' : 'user_ban') . '">'
                . '<input type="hidden" name="user_id" value="' . (int)$usr['id'] . '">'
                . '<button class="btn btn-sm" type="submit">' . ($usr['is_banned'] ? 'Unban' : 'Ban') . '</button></form> ';
            echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Delete user ' . e($usr['username']) . '?\')">' . csrf_field()
                . '<input type="hidden" name="admin_action" value="user_delete">'
                . '<input type="hidden" name="user_id" value="' . (int)$usr['id'] . '">'
                . '<button class="btn btn-sm btn-danger" type="submit">Delete</button></form> ';
            echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Play as ' . e($usr['username']) . '?\')">' . csrf_field()
                . '<input type="hidden" name="admin_action" value="impersonate">'
                . '<input type="hidden" name="user_id" value="' . (int)$usr['id'] . '">'
                . '<button class="btn btn-sm" type="submit">Impersonate</button></form>';
            echo '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No users found.</p>'; }
    echo '</div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Grant Resources (by User ID)</div>';
    echo '<form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;justify-content:center;max-width:1000px">' . csrf_field();
    echo '<input type="hidden" name="admin_action" value="user_give_money">';
    echo '<label>User ID<br><input type="number" name="user_id" min="1" style="width:90px" required></label>';
    echo '<label>Amount<br><input type="number" name="amount" style="width:130px" required></label>';
    echo '<label>Wallet<br><select name="type"><option value="cash">Cash</option><option value="bank">Bank</option></select></label>';
    echo '<button class="btn btn-gold" type="submit">Grant Money</button></form>';
    echo '<form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;justify-content:center;max-width:1000px;margin-top:8px">' . csrf_field();
    echo '<input type="hidden" name="admin_action" value="user_give_points">';
    echo '<label>User ID<br><input type="number" name="user_id" min="1" style="width:90px" required></label>';
    echo '<label>Points<br><input type="number" name="amount" style="width:130px" required></label>';
    echo '<button class="btn btn-gold" type="submit">Grant Points</button></form>';
    echo '<form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;justify-content:center;max-width:1000px;margin-top:8px">' . csrf_field();
    echo '<input type="hidden" name="admin_action" value="user_give_bullets">';
    echo '<label>User ID<br><input type="number" name="user_id" min="1" style="width:90px" required></label>';
    echo '<label>Bullets<br><input type="number" name="amount" style="width:130px" required></label>';
    echo '<button class="btn btn-gold" type="submit">Grant Bullets</button></form>';
    echo '</div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Edit Field (by User ID)</div>';
    echo '<form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;justify-content:center;max-width:860px">' . csrf_field();
    echo '<input type="hidden" name="admin_action" value="user_edit">';
    echo '<label>User ID<br><input type="number" name="user_id" min="1" style="width:90px" required></label>';
    echo '<label>Field<br><select name="field">';
    foreach (['money','bank','points','bullets','energy','nerve','health','level','xp','strength','speed','defense','iq','district_id'] as $fld) {
        echo '<option value="' . e($fld) . '">' . e($fld) . '</option>';
    }
    echo '</select></label>';
    echo '<label>New value<br><input type="text" name="value" style="width:120px" required></label>';
    echo '<button class="btn btn-gold" type="submit">Update</button></form>';
    echo '<p class="muted small">Watch out: this sets the field directly without validation.</p></div>';
    break;

case 'settings':
    echo '<div class="card"><div class="panel-heading">Game Settings</div>';
    echo '<form method="post" style="display:grid;gap:10px;max-width:640px;margin:0 auto">' . csrf_field();
    echo '<input type="hidden" name="admin_action" value="save_settings">';
    $fieldDefs = [
        ['energy_tick', 'Energy regen tick (seconds)'],
        ['nerve_tick', 'Nerve regen tick (seconds)'],
        ['health_tick', 'Health regen tick (seconds)'],
        ['max_energy', 'Max energy'],
        ['max_nerve', 'Max nerve'],
        ['max_health', 'Max health'],
        ['start_money', 'New player start cash'],
        ['start_bullets', 'New player start bullets'],
        ['start_points', 'New player start points'],
        ['hospital_penalty', 'Hospital penalty (0–1)'],
    ];
    foreach ($fieldDefs as $fd) {
        $val = $settingsMap[$fd[0]] ?? '';
        echo '<label>' . e($fd[1]) . '<br><input type="text" name="' . e($fd[0]) . '" value="' . e($val) . '"></label>';
    }
    echo '<button class="btn btn-gold" type="submit">Save Settings</button>';
    echo '</form></div>';
    break;

case 'timers':
    echo '<div class="card"><div class="panel-heading">Action Timers & Cooldowns</div>';
    echo '<p class="muted small">Set cooldowns in seconds for each action. 0 = disabled. Sensible defaults applied on first save.</p>';
    echo '<form method="post" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:10px;max-width:1200px;margin:0 auto">' . csrf_field();
    echo '<input type="hidden" name="admin_action" value="save_timers">';
    $timerDefs = [
        ['timer_missions', 'Missions'],
        ['timer_gym', 'The Gym'],
        ['timer_bosses', 'Bosses'],
        ['timer_criminal_jobs', 'Criminal Jobs'],
        ['timer_kill', 'Kill'],
        ['timer_empire', 'The Empire'],
        ['timer_abilities', 'Abilities'],
        ['timer_drugs', 'Drugs'],
        ['timer_hospital', 'Hospital'],
        ['timer_districts', 'Districts'],
        ['timer_workbench', 'Workbench'],
        ['timer_heists', 'Heists'],
        ['timer_tournaments', 'Tournaments'],
        ['timer_money', 'Money'],
        ['timer_bank', 'Bank'],
        ['timer_black_market', 'Black Market'],
        ['timer_escrow', 'Escrow'],
        ['timer_equipment', 'Equipment'],
        ['timer_bullet_factory', 'Bullet Factory'],
        ['timer_points_store', 'Points Store'],
        ['timer_daily_rewards', 'Daily Rewards'],
        ['timer_properties', 'Properties'],
        ['timer_racing', 'Racing'],
        ['timer_marketplace', 'Marketplace'],
        ['timer_stock_market', 'Stock Market'],
        ['timer_pawn_shop', 'Pawn Shop'],
        ['timer_prestige_shop', 'Prestige Shop'],
        ['timer_city_hall', 'City Hall'],
        ['timer_casino', 'Casino'],
        ['timer_lottery', 'Lottery'],
        ['timer_poker', 'Poker'],
        ['timer_roulette', 'Roulette'],
        ['timer_video_poker', 'Video Poker'],
        ['timer_hilo', 'Hi-Lo'],
        ['timer_mines', 'Mines'],
        ['timer_blackjack', 'Blackjack'],
        ['timer_baccarat', 'Baccarat'],
        ['timer_keno', 'Keno'],
        ['timer_crash', 'Crash'],
        ['timer_dice', 'Dice'],
        ['timer_slots', 'Slots'],
        ['timer_sports_betting', 'Sports Betting'],
        ['timer_people', 'People'],
        ['timer_crew', 'Crew'],
        ['timer_territory', 'Territory'],
        ['timer_crew_wars', 'Crew Wars'],
        ['timer_diplomacy', 'Diplomacy'],
        ['timer_forum', 'Forum'],
        ['timer_users', 'Users'],
        ['timer_leaderboards', 'Leaderboards'],
        ['timer_rewards', 'Rewards'],
        ['timer_achievements', 'Achievements'],
        ['timer_scratch_cards', 'Scratch Cards'],
        ['timer_sticker_book', 'Sticker Book'],
        ['timer_referrals', 'Referrals'],
        ['timer_info', 'Info'],
        ['timer_updates', 'Updates'],
        ['timer_votes', 'Votes'],
        ['timer_statistics', 'Statistics'],
        ['timer_api_access', 'API Access'],
        ['timer_help', 'Help'],
        ['timer_support', 'Support'],
        ['timer_suggestions', 'Suggestions'],
        ['timer_events', 'Events'],
        ['timer_trades', 'Trades'],
        ['timer_crew_chat', 'Crew Chat'],
        ['timer_hitlist', 'Hitlist'],
        ['timer_bounties', 'Bounties'],
    ];
    foreach ($timerDefs as $td) {
        $val = $settingsMap[$td[0]] ?? '0';
        echo '<label>' . e($td[1]) . ' (s)<br><input type="number" name="' . e($td[0]) . '" value="' . e($val) . '" min="0" style="width:100%"></label>';
    }
    echo '<button class="btn btn-gold" type="submit" style="grid-column:1/-1">Save Timers</button>';
    echo '<button class="btn btn-ghost" type="submit" name="admin_action" value="load_timer_presets" style="grid-column:1/-1" onclick="return confirm(\'Load sensible default timers? This will overwrite current values.\')">Load Presets</button>';
    echo '</form></div>';
    break;

case 'missions':
    admin_section('Missions', 'missions', [], $missions, [
        ['Mission', 'name'], ['District', 'district_name'], ['Energy', 'energy_cost'], ['Lv', 'min_level'],
        ['Money', 'reward_money', 'money'], ['XP', 'reward_xp'], ['Pts', 'reward_points'], ['Risk', 'risk'],
    ], [
        ['district_id', 'District', 'select', $districtMap],
        ['name', 'Name'],
        ['description', 'Description', 'textarea'],
        ['energy_cost', 'Energy cost', 'number'],
        ['min_level', 'Min level', 'number'],
        ['reward_money', 'Reward money', 'number'],
        ['reward_xp', 'Reward XP', 'number'],
        ['reward_points', 'Reward points', 'number'],
        ['risk', 'Fail risk %', 'number'],
        ['story', 'Story', 'textarea'],
    ]);
    break;

case 'items':
    admin_section('Items', 'items', [], $items, [
        ['Name', 'name'], ['Type', 'type'], ['ATK', 'attack'], ['DEF', 'defense'],
        ['Cost', 'cost', 'money'], ['Lv', 'min_level'], ['Rarity', 'rarity'],
    ], [
        ['name', 'Name'],
        ['description', 'Description', 'textarea'],
        ['type', 'Type', 'select', ['weapon', 'armor', 'vehicle', 'misc']],
        ['attack', 'Attack', 'number'],
        ['defense', 'Defense', 'number'],
        ['cost', 'Cost', 'number'],
        ['min_level', 'Min level', 'number'],
        ['rarity', 'Rarity', 'select', ['common', 'uncommon', 'rare', 'epic', 'legendary']],
    ]);
    break;

case 'bosses':
    admin_section('Bosses', 'bosses', [], $bosses, [
        ['Name', 'name'], ['District', 'district_name'], ['HP', 'hp'], ['ATK', 'attack'], ['DEF', 'defense'],
        ['Lv', 'min_level'], ['Energy', 'energy_cost'], ['Money', 'reward_money', 'money'], ['XP', 'reward_xp'],
    ], [
        ['district_id', 'District', 'select', $districtMap],
        ['name', 'Name'],
        ['description', 'Description', 'textarea'],
        ['hp', 'HP', 'number'],
        ['attack', 'Attack', 'number'],
        ['defense', 'Defense', 'number'],
        ['min_level', 'Min level', 'number'],
        ['energy_cost', 'Energy cost', 'number'],
        ['reward_money', 'Reward money', 'number'],
        ['reward_xp', 'Reward XP', 'number'],
        ['reward_points', 'Reward points', 'number'],
        ['reward_item_id', 'Reward item', 'select', ['' => '— None —'] + $itemMap],
    ]);
    break;

case 'jobs':
    admin_section('Criminal Jobs', 'criminal_jobs', [], $jobs, [
        ['Name', 'name'], ['Nerve', 'nerve_cost'], ['Lv', 'min_level'], ['Payout', 'payout_min'],
        ['Max', 'payout_max'], ['XP', 'xp'], ['Risk', 'fail_risk'], ['Cooldown', 'cooldown'],
    ], [
        ['name', 'Name'],
        ['description', 'Description', 'textarea'],
        ['nerve_cost', 'Nerve cost', 'number'],
        ['min_level', 'Min level', 'number'],
        ['payout_min', 'Min payout', 'number'],
        ['payout_max', 'Max payout', 'number'],
        ['xp', 'XP', 'number'],
        ['fail_risk', 'Fail risk %', 'number'],
        ['cooldown', 'Cooldown (seconds)', 'number'],
    ]);
    break;

case 'drugs':
    admin_section('Drugs', 'drugs', [], $drugs, [
        ['Name', 'name'], ['Buy', 'buy_price', 'money'], ['Sell', 'sell_price', 'money'],
        ['Lv', 'min_level'], ['Effect', 'effect_stat'], ['Amt', 'effect_amount'], ['OD %', 'od_risk'],
    ], [
        ['name', 'Name'],
        ['description', 'Description', 'textarea'],
        ['buy_price', 'Buy price', 'number'],
        ['sell_price', 'Sell price', 'number'],
        ['min_level', 'Min level', 'number'],
        ['effect_stat', 'Effect stat', 'select', ['strength', 'speed', 'defense', 'iq', 'energy', 'nerve', 'health']],
        ['effect_amount', 'Effect amount', 'number'],
        ['od_risk', 'OD risk %', 'number'],
    ]);
    break;

case 'abilities':
    admin_section('Abilities', 'abilities', [], $abilities, [
        ['Name', 'name'], ['Pts', 'cost_points'], ['Lv', 'min_level'], ['Type', 'effect_type'],
        ['Value', 'effect_value'], ['Stat', 'stat'],
    ], [
        ['name', 'Name'],
        ['description', 'Description', 'textarea'],
        ['cost_points', 'Cost (points)', 'number'],
        ['min_level', 'Min level', 'number'],
        ['effect_type', 'Effect type', 'select', ['passive', 'active']],
        ['effect_value', 'Effect value', 'number'],
        ['stat', 'Affects stat', 'select', ['strength', 'speed', 'defense', 'iq', 'energy', 'nerve', 'health', 'max_energy', 'max_nerve', 'max_health']],
    ]);
    break;

case 'gyms':
    admin_section('Gyms', 'gyms', [], $gyms, [
        ['Name', 'name'], ['Stat', 'stat'], ['Cost', 'cost', 'money'], ['Gain', 'gain'],
        ['Energy', 'energy_cost'], ['Lv', 'min_level'],
    ], [
        ['name', 'Name'],
        ['stat', 'Stat', 'select', ['strength', 'speed', 'defense', 'iq']],
        ['cost', 'Cost', 'number'],
        ['gain', 'Gain per train', 'number'],
        ['energy_cost', 'Energy cost', 'number'],
        ['min_level', 'Min level', 'number'],
    ]);
    break;

case 'districts':
    admin_section('Districts', 'districts', [], $districts, [
        ['Name', 'name'], ['Unlock Lv', 'unlock_level'], ['Income Bonus', 'income_bonus'], ['Description', 'description'],
    ], [
        ['name', 'Name'],
        ['description', 'Description', 'textarea'],
        ['unlock_level', 'Unlock level', 'number'],
        ['income_bonus', 'Income bonus %', 'number'],
    ]);
    break;

case 'points_store':
    admin_section('Points Store', 'points_store', [], $pointsStore, [
        ['Name', 'name'], ['Pts', 'cost_points'], ['Kind', 'kind'], ['Amount', 'amount'], ['Item', 'item_name'],
    ], [
        ['name', 'Name'],
        ['description', 'Description', 'textarea'],
        ['cost_points', 'Cost (points)', 'number'],
        ['kind', 'Kind', 'select', ['money', 'bullets', 'energy', 'nerve', 'health', 'points', 'item']],
        ['amount', 'Amount', 'number'],
        ['item_id', 'Item', 'select', ['' => '— None —'] + $itemMap],
    ]);
    break;

case 'achievements':
    admin_section('Achievements', 'achievements', [], $achievements, [
        ['Code', 'code'], ['Name', 'name'], ['Points', 'reward_points'], ['Target', 'target'], ['Metric', 'metric'],
    ], [
        ['code', 'Code'],
        ['name', 'Name'],
        ['description', 'Description', 'textarea'],
        ['reward_points', 'Reward points', 'number'],
        ['target', 'Target count', 'number'],
        ['metric', 'Metric', 'select', ['kills', 'deaths', 'missions_done', 'crimes_done', 'boss_kills', 'wins', 'losses', 'money', 'points', 'bullets', 'strength', 'speed', 'defense', 'iq', 'daily_streak']],
    ]);
    break;

case 'stickers':
    admin_section('Stickers', 'stickers', [], $stickers, [
        ['Code', 'code'], ['Name', 'name'], ['Rarity', 'rarity'],
    ], [
        ['code', 'Code'],
        ['name', 'Name'],
        ['rarity', 'Rarity', 'select', ['common', 'uncommon', 'rare', 'epic', 'legendary']],
    ]);
    break;

case 'factories':
    echo '<div class="card" style="margin-top:18px"><div class="panel-heading">Bullet Factories</div>';
    if ($factories) {
        echo '<div class="table-wrap"><table><tr><th>District</th><th>Price</th><th>Production</th><th>Owner</th><th>Last Collect</th><th>Edit Price/Production</th></tr>';
        foreach ($factories as $f) {
            echo '<tr>';
            echo '<td>' . e($f['district_name']) . '</td>';
            echo '<td>' . money($f['price']) . '</td>';
            echo '<td>' . (int)$f['production'] . '</td>';
            echo '<td>' . ($f['owner_id'] ? '#' . (int)$f['owner_id'] : '<span class="muted">Unclaimed</span>') . '</td>';
            echo '<td>' . ($f['last_collect'] ? date('M j Y H:i', strtotime($f['last_collect'])) : '<span class="muted">Never</span>') . '</td>';
            echo '<td>';
            echo '<form method="post" style="display:flex;gap:6px;align-items:center">' . csrf_field();
            echo '<input type="hidden" name="admin_action" value="factory_edit">';
            echo '<input type="hidden" name="district_id" value="' . (int)$f['district_id'] . '">';
            echo '<input type="number" name="price" value="' . (int)$f['price'] . '" style="width:110px" title="Price">';
            echo '<input type="number" name="production" value="' . (int)$f['production'] . '" style="width:70px" title="Production">';
            echo '<button class="btn btn-sm" type="submit">Save</button>';
            echo '</form>';
            echo '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No factories.</p>'; }
    echo '</div>';
    break;

case 'lottery':
    echo '<div class="card" style="margin-top:18px"><div class="panel-heading">Lottery</div>';
    if ($lotteryDraw) {
        $ticketCount = (int)fetch_one('SELECT COUNT(*) FROM lottery_tickets WHERE draw_id = ?', [$lotteryDraw['id']], 0);
        echo '<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px">';
        echo '<div class="tile"><b>' . e($lotteryDraw['draw_date']) . '</b><small>Draw date</small></div>';
        echo '<div class="tile"><b style="color:var(--accent)">' . money($lotteryDraw['pot']) . '</b><small>Pot</small></div>';
        echo '<div class="tile"><b>' . number_format($ticketCount) . '</b><small>Tickets sold</small></div>';
        echo '</div>';
        echo '<form method="post" style="margin-top:12px;display:flex;gap:8px;justify-content:center">' . csrf_field();
        echo '<input type="hidden" name="admin_action" value="lottery_draw">';
        echo '<button class="btn btn-gold" type="submit">Draw Winning Number Now</button></form>';
        echo '<p class="muted small">Winning number is random 000–999; pot is split among matching tickets and credited automatically.</p>';
    } else {
        echo '<p class="muted">No open draw.</p>';
        echo '<form method="post"><input type="hidden" name="admin_action" value="lottery_create">' . csrf_field() . '<button class="btn btn-gold" type="submit">Create Tomorrow\'s Draw</button></form>';
    }
    echo '</div>';

    $pastDraws = fetch_all('SELECT * FROM lottery_draws WHERE status = ? ORDER BY draw_date DESC LIMIT 10', ['drawn']);
    if ($pastDraws) {
        echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Recent Draws</div>';
        echo '<div class="table-wrap"><table><tr><th>Date</th><th>Winning Number</th><th>Pot</th></tr>';
        foreach ($pastDraws as $pd) {
            echo '<tr><td>' . e($pd['draw_date']) . '</td><td>' . str_pad((string)$pd['winning_number'], 3, '0', STR_PAD_LEFT) . '</td><td>' . money($pd['pot']) . '</td></tr>';
        }
        echo '</table></div></div>';
    }
    break;

case 'economy':
    echo '<div class="card"><div class="panel-heading">Economy Overview</div>';
    echo '<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px">';
    $econStats = [
        ['Total Cash', money($totalMoney)],
        ['Total Bullets', number_format($totalBullets)],
        ['Total Points', number_format($totalPoints)],
        ['Total Kills', number_format($totalKills)],
    ];
    foreach ($econStats as $ec) {
        echo '<div class="tile"><b style="font-size:1.25rem;color:var(--accent)">' . e($ec[1]) . '</b><small>' . e($ec[0]) . '</small></div>';
    }
    echo '</div></div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Mass Money Adjustment</div>';
    echo '<form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;justify-content:center">' . csrf_field();
    echo '<input type="hidden" name="admin_action" value="mass_money">';
    echo '<label>Amount<br><input type="number" name="amount" required></label>';
    echo '<label>Wallet<br><select name="type"><option value="money">Cash</option><option value="bank">Bank</option></select></label>';
    echo '<label>Target<br><select name="target"><option value="all">All active players</option><option value="online">Online (5 min)</option><option value="level">By level range</option></select></label>';
    echo '<label>Min level<br><input type="number" name="min_level" value="1" style="width:80px"></label>';
    echo '<label>Max level<br><input type="number" name="max_level" value="100" style="width:80px"></label>';
    echo '<button class="btn btn-gold" type="submit">Apply</button></form>';
    echo '<p class="muted small">Positive amount gives cash; negative takes it. Applied to non-banned players only.</p></div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Recent Bank Transactions</div>';
    if ($bankTx) {
        echo '<div class="table-wrap"><table><tr><th>User</th><th>Amount</th><th>Reason</th><th>When</th></tr>';
        foreach ($bankTx as $tx) {
            $cls = $tx['amount'] < 0 ? 'style="color:var(--red)"' : 'style="color:var(--green)"';
            echo '<tr><td>' . e($tx['username']) . '</td><td ' . $cls . '>' . money($tx['amount']) . '</td><td>' . e($tx['reason']) . '</td><td>' . date('M j, Y H:i', strtotime($tx['created_at'])) . '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No transactions yet.</p>'; }
    echo '</div>';
    break;

case 'tickets':
    echo '<div class="card" style="margin-top:18px"><div class="panel-heading">Support Tickets (' . $openTickets . ' open)</div>';
    if ($tickets) {
        echo '<div class="table-wrap"><table><tr><th>ID</th><th>User</th><th>Subject</th><th>Body</th><th>Status</th><th>Created</th><th>Actions</th></tr>';
        foreach ($tickets as $tk) {
            echo '<tr><td>' . (int)$tk['id'] . '</td><td>' . e($tk['username']) . '</td><td>' . e($tk['subject']) . '</td><td style="max-width:320px">' . e($tk['body']) . '</td>';
            echo '<td>' . ($tk['status'] === 'open' ? '<span style="color:var(--green)">Open</span>' : '<span class="muted">Closed</span>') . '</td>';
            echo '<td>' . date('M j, Y H:i', strtotime($tk['created_at'])) . '</td><td style="white-space:nowrap">';
            echo '<form method="post" style="display:inline">' . csrf_field() . '<input type="hidden" name="admin_action" value="ticket_toggle"><input type="hidden" name="ticket_id" value="' . (int)$tk['id'] . '"><button class="btn btn-sm" type="submit">' . ($tk['status'] === 'open' ? 'Close' : 'Reopen') . '</button></form> ';
            echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Delete ticket?\')">' . csrf_field() . '<input type="hidden" name="admin_action" value="ticket_delete"><input type="hidden" name="ticket_id" value="' . (int)$tk['id'] . '"><button class="btn btn-sm btn-danger" type="submit">Delete</button></form>';
            echo '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No tickets.</p>'; }
    echo '</div>';
    break;

case 'suggestions':
    echo '<div class="card" style="margin-top:18px"><div class="panel-heading">Suggestions (' . $pendingSuggestions . ' new)</div>';
    if ($suggestions) {
        echo '<div class="table-wrap"><table><tr><th>ID</th><th>User</th><th>Title</th><th>Votes</th><th>Status</th><th>Created</th><th>Actions</th></tr>';
        foreach ($suggestions as $sg) {
            echo '<tr><td>' . (int)$sg['id'] . '</td><td>' . e($sg['username']) . '</td><td>' . e($sg['title']) . '</td><td>' . (int)$sg['votes'] . '</td>';
            echo '<td>' . e($sg['status']) . '</td><td>' . date('M j, Y H:i', strtotime($sg['created_at'])) . '</td><td style="white-space:nowrap">';
            echo '<form method="post" style="display:inline">' . csrf_field()
                . '<input type="hidden" name="admin_action" value="suggestion_status">'
                . '<input type="hidden" name="suggestion_id" value="' . (int)$sg['id'] . '">'
                . '<select name="status" onchange="this.form.submit()">';
            foreach (['new', 'open', 'locked', 'implemented', 'rejected'] as $st) {
                echo '<option value="' . e($st) . '"' . ($sg['status'] === $st ? ' selected' : '') . '>' . e($st) . '</option>';
            }
            echo '</select></form> ';
            echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Delete suggestion?\')">' . csrf_field() . '<input type="hidden" name="admin_action" value="suggestion_delete"><input type="hidden" name="suggestion_id" value="' . (int)$sg['id'] . '"><button class="btn btn-sm btn-danger" type="submit">Delete</button></form>';
            echo '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No suggestions.</p>'; }
    echo '</div>';
    break;

case 'logs':
    echo '<div class="card" style="margin-top:18px"><div class="panel-heading">Event Log</div>';
    if ($logs) {
        echo '<div class="table-wrap"><table><tr><th>ID</th><th>User</th><th>Type</th><th>Text</th><th>Amount</th><th>When</th></tr>';
        foreach ($logs as $lg) {
            echo '<tr><td>' . (int)$lg['id'] . '</td><td>' . (int)$lg['user_id'] . '</td><td>' . e($lg['type']) . '</td><td>' . e($lg['text']) . '</td><td>' . number_format($lg['amount']) . '</td><td>' . date('M j, Y H:i', strtotime($lg['created_at'])) . '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No log entries.</p>'; }
    echo '</div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Latest Casino Bets</div>';
    if ($casinoBets) {
        echo '<div class="table-wrap"><table><tr><th>User</th><th>Game</th><th>Stake</th><th>Payout</th><th>Detail</th><th>When</th></tr>';
        foreach ($casinoBets as $cb) {
            echo '<tr><td>' . e($cb['username']) . '</td><td>' . e($cb['game']) . '</td><td>' . money($cb['stake']) . '</td><td>' . money($cb['payout']) . '</td><td>' . e($cb['detail']) . '</td><td>' . date('M j, Y H:i', strtotime($cb['created_at'])) . '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No casino bets yet.</p>'; }
    echo '</div>';
    break;

case 'analytics':
    $range = isset($_GET['range']) && in_array($_GET['range'], [24, 72, 168, 720], true) ? (int)$_GET['range'] : 24;
    echo '<div class="card"><div class="panel-heading" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px"><span>Advanced Analytics Dashboard</span><div style="display:flex;gap:6px;flex-wrap:wrap">';
    foreach ([24=>'24h',72=>'3d',168=>'7d',720=>'30d'] as $h=>$label){
        echo '<a class="btn btn-sm '.($range===$h?'btn-gold':'').'" href="'.e(url('admin.php?a=analytics&range='.$h)).'">'.$label.'</a>';
    }
    echo '</div></div></div>';

    echo '<div class="analytics-kpi-grid">';
    $kpis = [
        ['Logins', analytics_count_since('login', $range), '&#128273;'],
        ['Registrations', analytics_count_since('register', $range), '&#10004;'],
        ['Missions Won', analytics_count_since('mission_complete', $range), '&#9876;'],
        ['Crimes Won', analytics_count_since('crime_complete', $range), '&#9760;'],
        ['Kills', analytics_count_since('kill', $range), '&#128481;'],
        ['Fights Lost', analytics_count_since('lost_fight', $range), '&#9768;'],
        ['Page Views', analytics_count_since('page_view', $range), '&#128196;'],
    ];
    foreach ($kpis as $k) {
        echo '<div class="analytics-kpi"><div class="analytics-kpi-value">' . number_format((int) $k[1]) . '</div><div class="analytics-kpi-label">'.$k[2].' '.e($k[0]).'</div></div>';
    }
    echo '</div>';

    $top = analytics_top_events($range, 12);
    if ($top) {
        echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Top Events (by volume)</div>';
        echo '<div class="table-wrap"><table class="analytics-table"><tr><th>Event</th><th>Count</th><th>Unique Users</th></tr>';
        foreach ($top as $t){
            echo '<tr><td><code>'.e($t['event_type']).'</code></td><td>'.number_format((int)$t['cnt']).'</td><td>'.number_format((int)($t['uniq']??0)).'</td></tr>';
        }
        echo '</table></div></div>';
    }

    $hourly = analytics_hourly('login', 24);
    if ($hourly){
        $maxH = 1; foreach ($hourly as $h){ $maxH = max($maxH,(int)$h['count']); }
        echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Login Activity (24h)</div>';
        echo '<div class="analytics-chart">';
        foreach ($hourly as $h){
            $hh = max(2,(int)round(((int)$h['count']/$maxH)*100));
            echo '<div class="analytics-chart-bar" title="'.e($h['label']).': '.(int)$h['count'].'"><div class="analytics-chart-bar-value" style="height:'.$hh.'%"></div><div class="analytics-chart-bar-label">'.e($h['label']).'</div></div>';
        }
        echo '</div></div>';
    }

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Active Users (14 days)</div>';
    $active = analytics_active_users_daily(14);
    $maxA = 1;
    foreach ($active as $a) { $maxA = max($maxA, (int) $a['count']); }
    echo '<div class="analytics-chart analytics-active-chart">';
    foreach ($active as $a) {
        $h = (int) round(((int) $a['count'] / $maxA) * 100);
        echo '<div class="analytics-active-chart-bar" title="' . e($a['date']) . ': ' . (int) $a['count'] . '">';
        echo '<div class="analytics-active-chart-bar-value" style="height:' . max(4, $h) . '%"></div>';
        echo '<div class="analytics-active-chart-bar-label">'.e(substr($a['date'],5)).'</div></div>';
    }
    echo '</div>';
    echo '<p class="muted">Peak: ' . number_format($maxA) . ' active users/day. Today: ' . (int) end($active)['count'] . '.</p>';
    echo '</div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Daily Events (14 days)</div>';
    $metrics = ['login', 'register', 'mission_complete', 'crime_complete', 'kill', 'page_view'];
    echo '<div class="table-wrap"><table class="analytics-table">';
    echo '<tr><th>Event</th>';
    $dailyCache = [];
    foreach ($metrics as $m) { $dailyCache[$m] = analytics_daily($m, 14); }
    if (!empty($dailyCache['login'])){
        foreach ($dailyCache['login'] as $day) {
            echo '<th style="font-size:.75rem">' . e(substr($day['date'], 5)) . '</th>';
        }
    }
    echo '</tr>';
    foreach ($metrics as $m) {
        echo '<tr><td><code>' . e($m) . '</code></td>';
        if (!empty($dailyCache[$m])){
            foreach ($dailyCache[$m] as $day) {
                $c = (int) $day['count'];
                echo '<td>' . ($c > 0 ? number_format($c) : '<span class="analytics-zero">0</span>') . '</td>';
            }
        }
        echo '</tr>';
    }
    echo '</table></div>';
    echo '</div>';

    $cohorts = analytics_cohorts(7);
    if ($cohorts){
        echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Cohort Retention (7 days)</div>';
        echo '<div class="table-wrap"><table class="analytics-table"><tr><th>Cohort</th><th>Size</th><th>Retained Next Day</th><th>Rate</th></tr>';
        foreach ($cohorts as $c){
            echo '<tr><td>'.e($c['label']).'</td><td>'.number_format((int)$c['size']).'</td><td>'.number_format((int)$c['retained']).'</td><td>'.(int)$c['pct'].'%</td></tr>';
        }
        echo '</table></div></div>';
    }

    $live = analytics_live(15);
    if ($live){
        echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Live Activity</div>';
        echo '<div class="table-wrap"><table class="analytics-table"><tr><th>Time</th><th>User</th><th>Event</th><th>Meta</th></tr>';
        foreach ($live as $ev){
            echo '<tr><td>'.e(date('H:i:s', strtotime($ev['created_at']))).'</td><td>'.($ev['username']?'<a href="'.e(url('admin.php?a=user&id='.$ev['user_id'])).'">'.e($ev['username']).'</a>':'<span class="muted">Guest</span>').'</td><td><code>'.e($ev['event_type']).'</code></td><td class="muted small">'.e(substr($ev['meta']??'',0,80)).'</td></tr>';
        }
        echo '</table></div></div>';
    }

    require_once __DIR__ . '/includes/session_redis.php';
    if (function_exists('session_redis_stats')) {
        $sessStats = session_redis_stats();
        echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Session Store</div>';
        echo '<div class="analytics-kpi-grid">';
        foreach ([
            'Backend' => $sessStats['backend'],
            'Active Sessions' => $sessStats['active_sessions'] ?? 'N/A',
            'Memory Usage' => $sessStats['memory_usage'] ?? 'N/A',
        ] as $k => $v) {
            echo '<div class="analytics-kpi"><div class="analytics-kpi-value">' . e($v) . '</div><div class="analytics-kpi-label">' . e($k) . '</div></div>';
        }
        if (!empty($sessStats['error'])) {
            echo '<div class="analytics-kpi"><div class="analytics-kpi-value" style="color:red">' . e($sessStats['error']) . '</div><div class="analytics-kpi-label">Error</div></div>';
        }
        echo '</div></div>';
    }
    break;

case 'reports':
    require_once __DIR__ . '/includes/admin_tools.php';
    $report = admin_economy_report();
    $retention = admin_retention_report();
    $content = admin_content_count();

    echo '<div class="card"><div class="panel-heading">Economy Report</div>';
    echo '<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px">';
    foreach ([
        ['Total Cash', money($report['total_money'])],
        ['Total Bank', money($report['total_bank'])],
        ['Total Points', number_format($report['total_points'])],
        ['Total Bullets', number_format($report['total_bullets'])],
        ['Average Money', money($report['avg_money'])],
        ['Richest Player', $report['richest'] ? $report['richest']['username'] . ' (' . money($report['richest']['money']) . ')' : 'None'],
        ['Daily Income', money($report['daily_income'])],
        ['Daily Expenses', money($report['daily_expenses'])],
        ['Market Volume (24h)', money($report['market_volume'])],
        ['Heist Payouts (24h)', money($report['heist_payouts'])],
    ] as $s) {
        echo '<div class="tile"><b style="font-size:1.25rem;color:var(--accent)">' . e($s[1]) . '</b><small>' . e($s[0]) . '</small></div>';
    }
    echo '</div></div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Player Retention</div>';
    echo '<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px">';
    foreach ([
        ['DAU', number_format($retention['dau'])],
        ['WAU', number_format($retention['wau'])],
        ['MAU', number_format($retention['mau'])],
        ['New Today', number_format($retention['new_today'])],
        ['New This Week', number_format($retention['new_week'])],
        ['New This Month', number_format($retention['new_month'])],
    ] as $s) {
        echo '<div class="tile"><b style="font-size:1.25rem;color:var(--accent)">' . e($s[1]) . '</b><small>' . e($s[0]) . '</small></div>';
    }
    echo '</div></div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Content Counts</div>';
    echo '<div class="table-wrap"><table><tr><th>Content</th><th>Count</th></tr>';
    foreach ($content as $key => $count) {
        echo '<tr><td>' . ucfirst(str_replace('_', ' ', $key)) . '</td><td>' . number_format($count) . '</td></tr>';
    }
    echo '</table></div></div>';
    break;

case 'audit':
    $page = max(1, (int)($_GET['page'] ?? 1));
    $audit = admin_get_audit_log([], $page, 50);

    echo '<div class="card"><div class="panel-heading">Audit Log</div>';
    echo '<div class="table-wrap"><table><tr><th>Time</th><th>Admin</th><th>Action</th><th>Target</th><th>Details</th></tr>';
    foreach ($audit['logs'] as $log) {
        echo '<tr><td>' . date('M j, Y H:i', strtotime($log['created_at'])) . '</td>';
        echo '<td>' . e($log['admin_name'] ?? 'Unknown') . '</td>';
        echo '<td>' . e($log['action']) . '</td>';
        echo '<td>' . e($log['target_name'] ?? '—') . '</td>';
        echo '<td><pre style="max-width:400px;overflow:auto">' . e($log['new_values'] ?? '') . '</pre></td></tr>';
    }
    echo '</table></div>';

    echo '</div>';
    break;

case 'security':
    require_once __DIR__ . '/includes/security.php';
    require_once __DIR__ . '/includes/twofa.php';
    
    // Handle actions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_verify();
        $action = $_POST['admin_action'] ?? '';
        
        if ($action === 'unban_ip') {
            $ip = $_POST['ip'] ?? '';
            if ($ip && unban_ip($ip)) {
                flash('IP unbanned.', 'success');
            } else {
                flash('Failed to unban IP.', 'error');
            }
            redirect('admin.php?a=security');
        } elseif ($action === 'ban_ip') {
            $ip = $_POST['ip'] ?? '';
            $reason = $_POST['reason'] ?? '';
            $expires = $_POST['expires_at'] ?? null;
            if ($ip && ban_ip($ip, $u['id'], $reason, $expires)) {
                flash('IP banned.', 'success');
            } else {
                flash('Failed to ban IP.', 'error');
            }
            redirect('admin.php?a=security');
        }
    }
    
    // Security Events
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = 50;
    $offset = ($page - 1) * $limit;
    
    $filters = [];
    $params = [];
    
    if (!empty($_GET['severity'])) {
        $filters[] = 'se = ?';
        $params[] = $_GET['severity'];
    }
    if (!empty($_GET['event_type'])) {
        $filters[] = 'event_type = ?';
        $params[] = $_GET['event_type'];
    }
    if (!empty($_GET['user_id'])) {
        $filters[] = 'user_id = ?';
        $params[] = (int) $_GET['user_id'];
    }
    if (!empty($_GET['ip'])) {
        $filters[] = 'ip_address LIKE ?';
        $params[] = '%' . $_GET['ip'] . '%';
    }
    
    $where = $filters ? 'WHERE ' . implode(' AND ', $filters) : '';
    $countParams = $params; // params without LIMIT/OFFSET for COUNT query
    $params[] = $limit;
    $params[] = $offset;
    
    $events = fetch_all("
        SELECT se.*, u.username
        FROM security_events se
        LEFT JOIN users u ON u.id = se.user_id
        $where
        ORDER BY se.created_at DESC
        LIMIT ? OFFSET ?
    ", $params);
    
    $totalEvents = (int) fetch_one("SELECT COUNT(*) FROM security_events $where", $countParams);
    $totalPages = max(1, ceil($totalEvents / $limit));
    
    // CSP Violations
    $cspPage = max(1, (int)($_GET['csp_page'] ?? 1));
    $cspOffset = ($cspPage - 1) * $limit;
    $cspViolations = fetch_all("
        SELECT * FROM csp_violations
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?
    ", [$limit, $cspOffset]);
    $totalCsp = (int) fetch_one('SELECT COUNT(*) FROM csp_violations', [], 0);
    $cspTotalPages = max(1, ceil($totalCsp / $limit));
    
    // 2FA Stats
    $total2fa = (int) fetch_one("SELECT COUNT(*) FROM users WHERE twofa_enabled = 1", [], 0);
    $totalUsers = (int) fetch_one("SELECT COUNT(*) FROM users WHERE is_banned = 0", [], 0);
    $twofaRate = $totalUsers > 0 ? round($total2fa / $totalUsers * 100, 1) : 0;
    
    // IP Bans
    $ipBans = fetch_all("
        SELECT ib.*, u.username as admin_name
        FROM admin_ip_bans ib
        LEFT JOIN users u ON u.id = ib.admin_id
        ORDER BY ib.created_at DESC
        LIMIT 50
    ");
    
    // Filters
    $severityOptions = ['low','medium','high','critical'];
    $eventTypeOptions = ['login','register','failed_login','rate_limit','csp_violation','2fa_failed','2fa_verified','2fa_enabled','2fa_disabled','ip_banned','ip_unbanned'];
    
    echo '<div class="card"><div class="panel-heading">Security Dashboard</div>';
    
    // Summary stats
    echo '<div class="grid grid-4" style="margin-bottom:16px">';
    foreach ([
        ['Total Users', number_format($totalUsers)],
        ['2FA Enabled', number_format($total2fa) . ' (' . $twofaRate . '%)'],
        ['Security Events (24h)', number_format((int) fetch_one("SELECT COUNT(*) FROM security_events WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)", [], 0))],
        ['CSP Violations (24h)', number_format((int) fetch_one("SELECT COUNT(*) FROM csp_violations WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)", [], 0))],
        ['Active IP Bans', number_format(count(array_filter($ipBans, fn($b) => !$b['expires_at'] || strtotime($b['expires_at']) > time())))],
        ['Failed Logins (24h)', number_format((int) fetch_one("SELECT COUNT(*) FROM security_events WHERE event_type = 'failed_login' AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)", [], 0))],
    ] as $stat) {
        echo '<div class="tile"><b style="font-size:1.25rem;color:var(--accent)">' . $stat[1] . '</b><small>' . $stat[0] . '</small></div>';
    }
    echo '</div>';
    
    // Security Events
    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Security Events';
    echo '<form method="get" style="display:inline;margin-left:16px">';
    echo '<input type="hidden" name="a" value="security">';
    echo '<select name="severity" style="padding:4px 8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">';
    echo '<option value="">All Severities</option>';
    foreach ($severityOptions as $s) {
        echo '<option value="' . $s . '"' . (($_GET['severity'] ?? '') === $s ? ' selected' : '') . '>' . ucfirst($s) . '</option>';
    }
    echo '</select>';
    echo '<select name="event_type" style="padding:4px 8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin-left:8px">';
    echo '<option value="">All Types</option>';
    foreach ($eventTypeOptions as $et) {
        echo '<option value="' . $et . '"' . (($_GET['event_type'] ?? '') === $et ? ' selected' : '') . '>' . $et . '</option>';
    }
    echo '</select>';
    echo '<input type="text" name="ip" placeholder="Filter by IP" style="padding:4px 8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin-left:8px;width:140px">';
    echo '<button class="btn btn-gold btn-sm" type="submit">Filter</button>';
    echo '<a class="btn btn-sm" href="admin.php?a=security" style="margin-left:8px">Clear</a>';
    echo '</form>';
    echo '</div>';
    
    if ($events) {
        echo '<div class="table-wrap"><table><tr><th>Time</th><th>Type</th><th>Severity</th><th>User</th><th>IP</th><th>Details</th></tr>';
        foreach ($events as $ev) {
            $severityClass = match($ev['severity']) {
                'critical' => 'tag tag-error',
                'high' => 'tag tag-legendary',
                'medium' => 'tag tag-gold',
                'low' => 'tag tag-common',
                default => 'tag tag-common',
            };
            $userLink = $ev['username'] ? '<a href="' . e(url('profile.php?id=' . $ev['user_id'])) . '">' . e($ev['username']) . '</a>' : '—';
            $details = json_decode($ev['details'] ?? '{}', true);
            $detailStr = $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : '—';
            echo '<tr>';
            echo '<td>' . date('M j H:i:s', strtotime($ev['created_at'])) . '</td>';
            echo '<td>' . e($ev['event_type']) . '</td>';
            echo '<td><span class="' . $severityClass . '">' . ucfirst($ev['severity']) . '</span></td>';
            echo '<td>' . $userLink . '</td>';
            echo '<td>' . e($ev['ip_address'] ?? '—') . '</td>';
            echo '<td><small class="muted">' . e($detailStr) . '</small></td>';
            echo '</tr>';
        }
        echo '</table></div>';
    } else {
        echo '<p class="muted">No security events found.</p>';
    }
    echo '</div>';
    
    // Pagination
    if ($totalPages > 1) {
        echo '<div class="pill-row" style="margin-top:12px;justify-content:center">';
        for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++) {
            $active = $i === $page ? ' on' : '';
            echo '<a class="pill' . $active . '" href="' . e(url('admin.php?a=security&page=' . $i . '&severity=' . urlencode($_GET['severity'] ?? '') . '&event_type=' . urlencode($_GET['event_type'] ?? '') . '&ip=' . urlencode($_GET['ip'] ?? ''))) . '">' . $i . '</a>';
        }
        echo '</div>';
    }
    
    // CSP Violations
    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">CSP Violations';
    if ($cspTotalPages > 1) {
        echo ' <span class="tag tag-gold">' . $totalCsp . ' total</span>';
    }
    echo '</div>';
    
    if ($cspViolations) {
        echo '<div class="table-wrap"><table><tr><th>Time</th><th>Directive</th><th>Blocked URI</th><th>Document</th><th>Source</th><th>Line</th></tr>';
        foreach ($cspViolations as $cv) {
            echo '<tr>';
            echo '<td>' . date('M j H:i', strtotime($cv['created_at'])) . '</td>';
            echo '<td><code class="muted">' . e($cv['violated_directive'] ?? '—') . '</code></td>';
            echo '<td><code class="muted">' . e($cv['blocked_uri'] ?? '—') . '</code></td>';
            echo '<td><small class="muted">' . e(substr($cv['document_uri'] ?? '', 0, 60)) . '</small></td>';
            echo '<td><small class="muted">' . e($cv['source_file'] ?? '—') . '</small></td>';
            echo '<td>' . ($cv['line_number'] ? (int) $cv['line_number'] : '—') . '</td>';
            echo '</tr>';
        }
        echo '</table></div>';
    } else {
        echo '<p class="muted">No CSP violations recorded.</p>';
    }
    echo '</div>';
    
    // CSP pagination
    if ($cspTotalPages > 1) {
        echo '<div class="pill-row" style="margin-top:8px;justify-content:center">';
        for ($i = max(1, $cspPage - 2); $i <= min($cspTotalPages, $cspPage + 2); $i++) {
            $active = $i === $cspPage ? ' on' : '';
            echo '<a class="pill' . $active . '" href="' . e(url('admin.php?a=security&csp_page=' . $i)) . '">' . $i . '</a>';
        }
        echo '</div>';
    }
    
    // IP Bans
    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">IP Bans</div>';
    echo '<form method="post" style="margin-bottom:16px;display:flex;gap:8px;flex-wrap:wrap">';
    echo csrf_field() . '<input type="hidden" name="admin_action" value="ban_ip">';
    echo '<input type="text" name="ip" placeholder="IP Address" required style="width:160px;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">';
    echo '<input type="text" name="reason" placeholder="Reason" required style="flex:1;min-width:200px;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">';
    echo '<input type="datetime-local" name="expires_at" style="padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">';
    echo '<button class="btn btn-gold" type="submit">Ban IP</button>';
    echo '</form>';
    
    if ($ipBans) {
        echo '<div class="table-wrap"><table><tr><th>IP</th><th>Reason</th><th>Admin</th><th>Created</th><th>Expires</th><th>Actions</th></tr>';
        foreach ($ipBans as $ban) {
            $expired = $ban['expires_at'] && strtotime($ban['expires_at']) < time();
            $statusClass = $expired ? 'tag tag-common' : 'tag tag-legendary';
            echo '<tr>';
            echo '<td><code>' . e($ban['ip_address']) . '</code></td>';
            echo '<td>' . e($ban['reason']) . '</td>';
            echo '<td>' . e($ban['admin_name'] ?? '—') . '</td>';
            echo '<td>' . date('M j Y H:i', strtotime($ban['created_at'])) . '</td>';
            echo '<td><span class="' . $statusClass . '">' . ($ban['expires_at'] ? date('M j Y H:i', strtotime($ban['expires_at'])) : 'Never') . '</span></td>';
            echo '<td>';
            if (!$expired) {
                echo '<form method="post" style="display:inline">' . csrf_field() . '<input type="hidden" name="admin_action" value="unban_ip"><input type="hidden" name="ip" value="' . e($ban['ip_address']) . '"><button class="btn btn-sm btn-danger" type="submit" onclick="return confirm(\'Unban this IP?\')">Unban</button></form>';
            } else {
                echo '<span class="muted">Expired</span>';
            }
            echo '</td></tr>';
        }
        echo '</table></div>';
    } else {
        echo '<p class="muted">No IP bans.</p>';
    }
    echo '</div>';
    break;

case 'heists':
    require_once __DIR__ . '/includes/heists.php';
    $heists = heist_get_all();
    $instances = fetch_all('SELECT hi.*, h.name as heist_name, c.name as crew_name FROM heist_instances hi JOIN heists h ON h.id = hi.heist_id JOIN crews c ON c.id = hi.crew_id ORDER BY hi.created_at DESC LIMIT 50');
    
    echo '<div class="card"><div class="panel-heading">Heists Overview</div>';
    if ($heists) {
        echo '<div class="table-wrap"><table><tr><th>Heist</th><th>Crew Lv</th><th>Members</th><th>Phases</th><th>Reward</th><th>Cooldown</th></tr>';
        foreach ($heists as $h) {
            echo '<tr><td><b>' . e($h['name']) . '</b><br><small class="muted">' . e($h['description']) . '</small></td>';
            echo '<td>' . (int)$h['min_crew_level'] . '</td>';
            echo '<td>' . (int)$h['min_members'] . '-' . (int)$h['max_members'] . '</td>';
            echo '<td>' . count(json_decode($h['phases'], true)) . '</td>';
            echo '<td>' . money($h['reward_money']) . ' | ' . number_format($h['reward_xp']) . ' XP | ' . number_format($h['reward_points']) . ' Pts</td>';
            echo '<td>' . (int)$h['cooldown_hours'] . 'h</td>';
        }
        echo '</table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Active Heist Instances</div>';
    if ($instances) {
        echo '<div class="table-wrap"><table><tr><th>Heist</th><th>Crew</th><th>Status</th><th>Phase</th><th>Started</th><th>Participants</th></tr>';
        foreach ($instances as $inst) {
            $statusClass = match($inst['status']) {
                'planning' => 'tag tag-gold',
                'active' => 'tag tag-legendary',
                'completed' => 'tag tag-legendary',
                'failed' => 'tag tag-common',
                'abandoned' => 'tag tag-common',
                default => 'tag tag-common',
            };
            echo '<tr><td>' . e($inst['heist_name']) . '</td>';
            echo '<td>' . e($inst['crew_name']) . '</td>';
            echo '<td><span class="' . $statusClass . '">' . ucfirst($inst['status']) . '</span></td>';
            echo '<td>' . (int)$inst['current_phase'] . ' / ' . count(json_decode(fetch('SELECT phases FROM heists WHERE id = ?', [$inst['heist_id']])['phases'], true)) . '</td>';
            echo '<td>' . date('M j H:i', strtotime($inst['started_at'] ?? $inst['created_at'])) . '</td>';
            echo '<td>' . count(json_decode($inst['participants'], true)) . '</td></tr>';
        }
        echo '</table></div>';
    } else {
        echo '<p class="muted">No active heist instances.</p>';
    }
    echo '</div>';
    break;

case 'properties':
    require_once __DIR__ . '/includes/properties.php';
    $types = property_get_types();
    $allProps = fetch_all("
        SELECT up.*, pt.name, pt.max_level,
               pt.income_money_per_hour, pt.income_bullets_per_hour, pt.income_points_per_hour,
               pt.storage_items, pt.storage_drugs, pt.storage_bullets,
               u.username
        FROM user_properties up
        JOIN property_types pt ON pt.id = up.property_type_id
        JOIN users u ON u.id = up.user_id
        WHERE up.is_active = 1
        ORDER BY up.level DESC, up.id DESC
        LIMIT 200
    ");
    
    echo '<div class="card"><div class="panel-heading">Properties Management</div>';
    echo '<div class="grid grid-2">';
    foreach ($types as $t) {
        echo '<div class="card">';
        echo '<b>' . e($t['name']) . '</b><br><small class="muted">' . e($t['description']) . '</small>';
        echo '<div class="stat"><span>Base Cost</span><b>' . money($t['base_price']) . '</b></div>';
        echo '<div class="stat"><span>Hourly Income (Lv 1)</span><b>' . money($t['income_money_per_hour']) . ' | ' . (int)$t['income_bullets_per_hour'] . ' bullets | ' . (int)$t['income_points_per_hour'] . ' pts</b></div>';
        echo '<div class="stat"><span>Storage</span><b>' . (int)$t['storage_items'] . ' items | ' . (int)$t['storage_drugs'] . ' drugs | ' . number_format($t['storage_bullets']) . ' bullets</b></div>';
        echo '<div class="stat"><span>Max Level</span><b>' . (int)$t['max_level'] . '</b></div>';
        echo '</div>';
    }
    echo '</div>';
    
    if ($allProps) {
        echo '<h2 style="margin-top:24px">All Player Properties</h2>';
        echo '<div class="table-wrap"><table><tr><th>Player</th><th>Property</th><th>Level</th><th>Income/Hr</th><th>Storage</th></tr>';
        foreach ($allProps as $p) {
            $preview = property_get_income_preview($p);
            echo '<tr><td>' . e($p['username']) . '</td>';
            echo '<td>' . e($p['name']) . ' <span class="tag tag-legendary">Lv ' . (int)$p['level'] . '</span></td>';
            echo '<td>' . (int)$p['level'] . ' / ' . (int)$p['max_level'] . '</td>';
            echo '<td>' . money($preview['per_hour']['money']) . ' | ' . $preview['per_hour']['bullets'] . ' bullets | ' . $preview['per_hour']['points'] . ' pts</td>';
            echo '<td>' . (int)$p['storage_items'] . ' items | ' . (int)$p['storage_drugs'] . ' drugs | ' . number_format($p['storage_bullets']) . ' bullets</td></tr>';
        }
        echo '</table></div>';
    }
    break;

case 'racing':
    require_once __DIR__ . '/includes/racing.php';
    $tracks = race_get_tracks();
    $activeRaces = race_get_active();
    
    echo '<div class="card"><div class="panel-heading">Racing Tracks</div>';
    if ($tracks) {
        echo '<div class="table-wrap"><table><tr><th>Track</th><th>Distance</th><th>Min Vehicle Lv</th><th>Entry Fee</th><th>Base Reward</th></tr>';
        foreach ($tracks as $t) {
            echo '<tr><td><b>' . e($t['name']) . '</b><br><small class="muted">' . e($t['description'] ?? '') . '</small></td>';
            echo '<td>' . (float)$t['distance_km'] . ' km</td>';
            echo '<td>' . (int)$t['min_vehicle_level'] . '</td>';
            echo '<td>' . money($t['entry_fee_money']) . ' | ' . (int)$t['entry_fee_bullets'] . ' bullets</td>';
            echo '<td>' . money($t['base_reward_money']) . ' | ' . number_format($t['base_reward_xp']) . ' XP</td>';
        }
        echo '</table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Active Races</div>';
    if ($activeRaces) {
        foreach ($activeRaces as $race) {
            echo '<div class="card" style="margin-top:8px">';
            echo '<div class="panel-heading"><span>' . e($race['track_name']) . '</span><span class="tag tag-' . ($race['status'] === 'waiting' ? 'gold' : 'legendary') . '">' . ucfirst($race['status']) . '</span></div>';
            echo '<div class="muted small">' . e($race['description'] ?? '') . '</div>';
            echo '<div class="stat"><span>Racers</span><b>' . count($race['participants']) . ' / ' . (int)$race['max_racers'] . '</b></div>';
            echo '<div class="stat"><span>Prize Pool</span><b>' . money($race['prize_pool_money']) . ' | ' . number_format($race['prize_pool_xp']) . ' XP</b></div>';
            
            if ($race['participants']) {
                echo '<div class="muted small" style="margin:8px 0"><b>Racers:</b> ';
                foreach ($race['participants'] as $p) {
                    echo '<span class="tag tag-' . ((int)$p['user_id'] === ($_SESSION['uid'] ?? 0) ? 'legendary' : 'common') . '" style="margin:2px">' . e($p['username']) . ' (' . e($p['vehicle_name'] ?? 'No Vehicle') . ')</span> ';
                }
                echo '</div>';
            }
            
            if ($race['status'] === 'waiting') {
                echo '<form method="post" style="margin-top:8px">' . csrf_field() . '<input type="hidden" name="admin_action" value="race_start"><input type="hidden" name="race_id" value="' . (int)$race['id'] . '"><button class="btn btn-green btn-sm" type="submit">Force Start Race</button></form>';
            } elseif ($race['status'] === 'racing') {
                echo '<form method="post" style="margin-top:8px" onsubmit="return confirm(\'Finish this race and pay out prizes?\')">' . csrf_field() . '<input type="hidden" name="admin_action" value="race_finish"><input type="hidden" name="race_id" value="' . (int)$race['id'] . '"><button class="btn btn-gold btn-sm" type="submit">Force Finish &amp; Pay Out</button></form>';
            }
            echo '</div>';
        }
    } else {
        echo '<p class="muted">No active races. Check back soon!</p>';
    }
    echo '</div>';
    break;

case 'market':
    require_once __DIR__ . '/includes/market.php';
    $stats = market_get_stats();
    $recentListings = fetch_all("
        SELECT ml.*, u.username AS seller_name
        FROM market_listings ml
        JOIN users u ON u.id = ml.seller_id
        ORDER BY ml.id DESC
        LIMIT 100
    ");
    $activeBids = (int) fetch_one("SELECT COUNT(*) FROM market_bids WHERE status = 'active'", [], 0);

    echo '<div class="card"><div class="panel-heading">Marketplace <span class="tag tag-gold">' . (int)$stats['active'] . ' Active</span></div>';
    echo '<p class="muted small">Buy and sell items, vehicles, drugs, and blueprints. Auctions with buyout option.</p>';
    echo '<div class="stat"><span>Active Listings</span><b>' . (int)$stats['active'] . '</b></div>';
    echo '<div class="stat"><span>Total Listings</span><b>' . (int)$stats['total'] . '</b></div>';
    echo '<div class="stat"><span>Active Bids</span><b>' . number_format($activeBids) . '</b></div>';
    echo '<div class="stat"><span>Volume</span><b>' . money((int)$stats['volume']) . '</b></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Recent Listings</div>';
    if ($recentListings) {
        echo '<div class="table-wrap"><table><tr><th>Seller</th><th>Type</th><th>Qty</th><th>Buyout</th><th>Bid</th><th>Status</th><th>Listed</th></tr>';
        foreach ($recentListings as $l) {
            $statusClass = match ((string) $l['status']) {
                'active' => 'tag tag-gold',
                'sold' => 'tag tag-legendary',
                default => 'tag tag-common',
            };
            echo '<tr><td>' . e($l['seller_name']) . '</td>';
            echo '<td>' . e(ucfirst((string) $l['item_type'])) . ' #' . (int)$l['item_id'] . '</td>';
            echo '<td>' . (int)$l['qty'] . '</td>';
            echo '<td>' . ((int)$l['buyout_price'] > 0 ? money((int)$l['buyout_price']) : '—') . '</td>';
            echo '<td>' . money((int)$l['bid_price']) . ' <small class="muted">(min ' . money((int)$l['min_bid']) . ')</small></td>';
            echo '<td><span class="' . $statusClass . '">' . e(ucfirst((string) $l['status'])) . '</span></td>';
            echo '<td><small class="muted">' . date('M j H:i', strtotime((string)$l['created_at'])) . '</small></td></tr>';
        }
        echo '</table></div>';
    } else {
        echo '<p class="muted">No listings yet.</p>';
    }
    echo '</div>';
    break;

case 'politics':
    require_once __DIR__ . '/includes/politics.php';
    $dashboard = politics_get_dashboard($_SESSION['uid'] ?? 0);
    $currentElection = $dashboard['current_election'];
    $mayor = $dashboard['mayor'];
    $policies = $dashboard['policies'];
    $candidates = $dashboard['candidates'];
    $userVote = $dashboard['user_vote'];
    $userCandidate = $dashboard['user_candidate'];
    $canNominate = $dashboard['can_nominate'];
    
    echo '<div class="card"><div class="panel-heading">City Hall</div>';
    echo '<p class="muted small">Participate in city governance. Run for Mayor, vote on policies, shape the city\'s future.</p>';
    echo '</div>';
    break;

case 'crafting':
    require_once __DIR__ . '/includes/crafting.php';
    $availableRecipes = crafting_get_available_recipes($_SESSION['uid'] ?? 0);
    $knownRecipes = crafting_get_known($_SESSION['uid'] ?? 0);
    $history = crafting_get_history($_SESSION['uid'] ?? 0, 20);
    
    echo '<div class="card"><div class="panel-heading">Workbench</div>';
    echo '<p class="muted small">Combine items and drugs to craft upgraded gear. Discover new recipes from blueprints.</p>';
    echo '<div class="stat"><span>Energy</span><b>' . (int)($u['energy'] ?? 0) . ' / ' . (int)($u['energy_max'] ?? 100) . '</b></div>';
    echo '<div class="stat"><span>Cash</span><b>' . money((int)($u['money'] ?? 0)) . '</b></div>';
    echo '<div class="stat"><span>Known Recipes</span><b>' . count($knownRecipes) . ' / ' . count($availableRecipes) . '</b></div>';
    echo '</div>';
    break;

case 'tournaments':
    echo '<div class="card"><div class="panel-heading">Tournament Scheduler</div>';
    echo '<p class="muted small">Recurring competitive events across PvP, racing, heists, missions, kill races and casino. Force-start a full event early, cancel to refund every entrant, or delete finished history. Prizes are paid automatically when an event concludes.</p>';
    echo '<form method="post" style="margin:8px 0">' . csrf_field() . '<input type="hidden" name="admin_action" value="tournament_sweep"><button class="btn btn-gold btn-sm" type="submit">Run scheduler sweep now</button></form>';
    echo '</div>';

    $tournaments = tournament_get_all(null, null, 100);
    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">All Tournaments <span class="tag tag-gold">' . count($tournaments) . '</span></div>';
    if ($tournaments) {
        echo '<div class="table-wrap"><table><tr><th>Event</th><th>Format</th><th>Game</th><th>Status</th><th>Entrants</th><th>Schedule</th><th>Prize Pool</th><th>Actions</th></tr>';
        foreach ($tournaments as $t) {
            $statusClass = match ((string) $t['status']) {
                'in_progress' => 'tag tag-legendary',
                'registration' => 'tag tag-gold',
                'completed' => 'tag tag-legendary',
                'cancelled' => 'tag tag-common',
                default => 'tag tag-common',
            };
            echo '<tr>';
            echo '<td><b>' . e($t['name']) . '</b><br><small class="muted">' . e($t['code']) . '</small></td>';
            echo '<td>' . e(tournament_type_label((string) $t['type'])) . '</td>';
            echo '<td>' . e(tournament_game_label((string) $t['game_type'])) . '</td>';
            echo '<td><span class="' . $statusClass . '">' . e(tournament_status_label((string) $t['status'])) . '</span></td>';
            echo '<td>' . (int) $t['participant_count'] . ' / ' . (int) $t['max_participants'] . '</td>';
            echo '<td><small class="muted">Starts ' . ($t['starts_at'] ? date('M j H:i', strtotime((string) $t['starts_at'])) : '—')
                . '<br>Closes ' . ($t['registration_closes_at'] ? date('M j H:i', strtotime((string) $t['registration_closes_at'])) : '—') . '</small></td>';
            echo '<td>' . money((int) $t['prize_pool_money']) . '<br><small class="muted">' . (int) $t['prize_pool_points'] . ' pts | ' . number_format((int) $t['prize_pool_xp']) . ' XP</small></td>';
            echo '<td style="white-space:nowrap">';
            if ((string) $t['status'] === 'registration') {
                echo '<form method="post" style="display:inline">' . csrf_field() . '<input type="hidden" name="admin_action" value="tournament_start"><input type="hidden" name="tournament_id" value="' . (int) $t['id'] . '"><button class="btn btn-sm btn-green" type="submit">Force start</button></form> ';
            }
            if (in_array((string) $t['status'], ['registration', 'draft', 'in_progress'], true)) {
                echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Cancel this event and refund every entrant?\')">' . csrf_field() . '<input type="hidden" name="admin_action" value="tournament_cancel"><input type="hidden" name="tournament_id" value="' . (int) $t['id'] . '"><button class="btn btn-sm" type="submit">Cancel + refund</button></form> ';
            }
            if (in_array((string) $t['status'], ['cancelled', 'completed'], true)) {
                echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Permanently delete this event and all of its history?\')">' . csrf_field() . '<input type="hidden" name="admin_action" value="tournament_delete"><input type="hidden" name="tournament_id" value="' . (int) $t['id'] . '"><button class="btn btn-sm btn-danger" type="submit">Delete</button></form>';
            }
            echo '</td></tr>';
        }
        echo '</table></div>';
    } else {
        echo '<p class="muted">No tournaments yet. The scheduler creates recurring events automatically.</p>';
    }
    echo '</div>';
    break;

case 'mini_events':
    if (!function_exists('mini_event_get_all')) require_once __DIR__ . '/includes/mini_events.php';
    if (!function_exists('mini_event_start')) require_once __DIR__ . '/includes/mini_events.php';
    if (!function_exists('mini_event_end')) require_once __DIR__ . '/includes/mini_events.php';

    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'mini_event_start') {
        csrf_verify();
        $type = $_POST['type'] ?? '';
        $result = mini_event_start($type);
        flash($result['ok'] ? 'Event started!' : $result['error'], $result['ok'] ? 'success' : 'error');
        redirect('admin.php?a=mini_events');
    }
    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'mini_event_end') {
        csrf_verify();
        $id = (int) ($_POST['event_id'] ?? 0);
        $result = mini_event_end($id);
        flash($result['ok'] ? 'Event ended!' : $result['error'], $result['ok'] ? 'success' : 'error');
        redirect('admin.php?a=mini_events');
    }

    echo '<div class="card"><div class="panel-heading">Trigger Mini Event</div>';
    echo '<p class="muted small">Mini events are random world occurrences (1-12h apart). Manually trigger one here.</p>';
    echo '<form method="post" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">' . csrf_field();
    echo '<input type="hidden" name="admin_action" value="mini_event_start">';
    echo '<select name="type" style="min-width:200px">';
    foreach (['drug_surge' => '💊 Drug Surge (2x prices, 10m)', 'bullet_restock' => '🔫 Bullet Restock (3x factory, 15m)', 'safe_deposit' => '💰 Safe Deposit (2x pot, 20m)', 'jackpot_boost' => '🎰 Jackpot Boost (+$40M slots, 30m)'] as $k => $v) {
        echo '<option value="' . $k . '">' . $v . '</option>';
    }
    echo '</select>';
    echo '<button class="btn btn-gold btn-sm" type="submit">Trigger</button>';
    echo '</form>';
    echo '</div>';

    $events = mini_event_get_all();
    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Active / Recent Mini Events <span class="tag tag-gold">' . count($events) . '</span></div>';
    if ($events) {
        echo '<div class="table-wrap"><table><tr><th>Type</th><th>City</th><th>Started</th><th>Ends</th><th>Status</th><th>Actions</th></tr>';
        foreach ($events as $ev) {
            $cityName = $ev['city_name'] ?? '—';
            $statusClass = $ev['is_active'] ? 'tag tag-legendary' : 'tag tag-common';
            echo '<tr>';
            echo '<td>' . e($ev['name']) . ' <small class="muted">(' . e($ev['type']) . ')</small></td>';
            echo '<td>' . e($cityName) . '</td>';
            echo '<td>' . ($ev['started_at'] ? date('M j H:i', strtotime($ev['started_at'])) : '—') . '</td>';
            echo '<td>' . ($ev['ends_at'] ? date('M j H:i', strtotime($ev['ends_at'])) : '—') . '</td>';
            echo '<td><span class="' . $statusClass . '">' . ($ev['is_active'] ? 'Active' : 'Ended') . '</span></td>';
            echo '<td>';
            if ($ev['is_active']) {
                echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Force end this event early?\')">' . csrf_field() . '<input type="hidden" name="admin_action" value="mini_event_end"><input type="hidden" name="event_id" value="' . (int) $ev['id'] . '"><button class="btn btn-sm btn-danger" type="submit">End now</button></form>';
            }
            echo '</td>';
            echo '</tr>';
        }
        echo '</table></div>';
    } else {
        echo '<p class="muted">No mini events recorded yet.</p>';
    }
    echo '</div>';
    break;

case 'weekend_events':
    if (!function_exists('weekend_event_get_all')) require_once __DIR__ . '/includes/weekend_events.php';
    if (!function_exists('weekend_event_toggle')) require_once __DIR__ . '/includes/weekend_events.php';

    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'weekend_event_toggle') {
        csrf_verify();
        $id = (int) ($_POST['event_id'] ?? 0);
        $result = weekend_event_toggle($id);
        flash($result['ok'] ? 'Event toggled!' : $result['error'], $result['ok'] ? 'success' : 'error');
        redirect('admin.php?a=weekend_events');
    }
    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'weekend_event_update') {
        csrf_verify();
        $id = (int) ($_POST['event_id'] ?? 0);
        $start = $_POST['start_at'] ?? '';
        $end = $_POST['end_at'] ?? '';
        if ($start && $end) {
            q('UPDATE weekend_events SET start_at = ?, end_at = ? WHERE id = ?', [$start, $end, $id]);
            flash('Schedule updated.', 'success');
        } else {
            flash('Invalid dates.', 'error');
        }
        redirect('admin.php?a=weekend_events');
    }

    $events = weekend_event_get_all();
    echo '<div class="card"><div class="panel-heading">Weekend Event Schedule <span class="tag tag-gold">' . count($events) . '</span></div>';
    echo '<p class="muted small">Recurring events per round week. Double XP, Bullet Rush, Looting Spree, Motor Madness, Crush Rush.</p>';
    if ($events) {
        echo '<div class="table-wrap"><table><tr><th>Week</th><th>Type</th><th>Start</th><th>End</th><th>Status</th><th>Actions</th></tr>';
        foreach ($events as $ev) {
            $statusClass = $ev['is_active'] ? 'tag tag-legendary' : 'tag tag-common';
            $typeLabel = [
                'double_xp' => '📈 Double XP', 'bullet_rush' => '🔫 Bullet Rush',
                'looting_spree' => '💎 Looting Spree', 'motor_madness' => '🏎️ Motor Madness',
                'crush_rush' => '👊 Crush Rush',
            ][$ev['event_type']] ?? $ev['event_type'];
            echo '<tr>';
            echo '<td>' . (int) $ev['week'] . '</td>';
            echo '<td>' . $typeLabel . '</td>';
            echo '<td>' . date('M j H:i', strtotime($ev['start_at'])) . '</td>';
            echo '<td>' . date('M j H:i', strtotime($ev['end_at'])) . '</td>';
            echo '<td><span class="' . $statusClass . '">' . ($ev['is_active'] ? 'Active' : 'Inactive') . '</span></td>';
            echo '<td style="white-space:nowrap">';
            echo '<form method="post" style="display:inline">' . csrf_field() . '<input type="hidden" name="admin_action" value="weekend_event_toggle"><input type="hidden" name="event_id" value="' . (int) $ev['id'] . '"><button class="btn btn-sm ' . ($ev['is_active'] ? 'btn-danger' : 'btn-green') . '" type="submit">' . ($ev['is_active'] ? 'Disable' : 'Enable') . '</button></form> ';
            echo '<form method="post" style="display:inline;margin-left:4px">' . csrf_field() . '<input type="hidden" name="admin_action" value="weekend_event_update"><input type="hidden" name="event_id" value="' . (int) $ev['id'] . '">';
            echo '<input type="datetime-local" name="start_at" value="' . date('Y-m-d\TH:i', strtotime($ev['start_at'])) . '" required>';
            echo '<input type="datetime-local" name="end_at" value="' . date('Y-m-d\TH:i', strtotime($ev['end_at'])) . '" required>';
            echo '<button class="btn btn-sm btn-gold" type="submit">Update</button></form>';
            echo '</td></tr>';
        }
        echo '</table></div>';
    }
    echo '</div>';
    break;

case 'seasonal_events':
    if (!function_exists('seasonal_event_get_all')) require_once __DIR__ . '/includes/seasonal_events.php';
    if (!function_exists('seasonal_event_toggle')) require_once __DIR__ . '/includes/seasonal_events.php';
    if (!function_exists('seasonal_event_upsert')) require_once __DIR__ . '/includes/seasonal_events.php';

    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'seasonal_event_toggle') {
        csrf_verify();
        $id = (int) ($_POST['event_id'] ?? 0);
        $result = seasonal_event_toggle($id);
        flash($result['ok'] ? 'Event toggled!' : $result['error'], $result['ok'] ? 'success' : 'error');
        redirect('admin.php?a=seasonal_events');
    }
    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'seasonal_event_upsert') {
        csrf_verify();
        $code = $_POST['holiday_code'] ?? '';
        $year = (int) ($_POST['year'] ?? date('Y'));
        $start = $_POST['start_at'] ?? '';
        $end = $_POST['end_at'] ?? '';
        $config = [];
        if (isset($_POST['config'])) {
            foreach ($_POST['config'] as $k => $v) {
                if ($v !== '') $config[$k] = $v;
            }
        }
        if ($code && $start && $end) {
            $result = seasonal_event_upsert($code, $year, $start, $end, $config);
            flash($result['ok'] ? 'Event saved!' : $result['error'], $result['ok'] ? 'success' : 'error');
        } else {
            flash('Code, start, and end are required.', 'error');
        }
        redirect('admin.php?a=seasonal_events');
    }

    $events = seasonal_event_get_all();
    echo '<div class="card"><div class="panel-heading">Seasonal Events</div>';
    echo '<p class="muted small">Calendar holidays: Valentine\'s, Easter, Independence, Halloween, Christmas. Each has unique vehicles, missions, currencies, perks, resprays.</p>';
    if ($events) {
        echo '<div class="table-wrap"><table><tr><th>Holiday</th><th>Year</th><th>Start</th><th>End</th><th>Status</th><th>Actions</th></tr>';
        foreach ($events as $ev) {
            $statusClass = $ev['is_active'] ? 'tag tag-legendary' : 'tag tag-common';
            echo '<tr>';
            echo '<td>' . e($ev['holiday_code']) . '</td>';
            echo '<td>' . (int) $ev['year'] . '</td>';
            echo '<td>' . date('M j', strtotime($ev['start_at'])) . '</td>';
            echo '<td>' . date('M j', strtotime($ev['end_at'])) . '</td>';
            echo '<td><span class="' . $statusClass . '">' . ($ev['is_active'] ? 'Active' : 'Inactive') . '</span></td>';
            echo '<td><form method="post" style="display:inline">' . csrf_field() . '<input type="hidden" name="admin_action" value="seasonal_event_toggle"><input type="hidden" name="event_id" value="' . (int) $ev['id'] . '"><button class="btn btn-sm ' . ($ev['is_active'] ? 'btn-danger' : 'btn-green') . '" type="submit">' . ($ev['is_active'] ? 'Disable' : 'Enable') . '</button></form></td>';
            echo '</tr>';
        }
        echo '</table></div>';
    }

    // Create new
    echo '<div class="card" style="margin-top:16px"><div class="panel-heading">Create / Update Seasonal Event</div>';
    echo '<form method="post" style="display:flex;flex-direction:column;gap:10px;max-width:600px">' . csrf_field() . '<input type="hidden" name="admin_action" value="seasonal_event_upsert">';
    echo '<div style="display:flex;gap:8px;flex-wrap:wrap"><input type="text" name="holiday_code" placeholder="holiday_code (valentines,easter,independence,halloween,christmas)" required style="min-width:250px"><input type="number" name="year" value="' . date('Y') . '" min="2020" max="2030" required style="width:100px"><input type="datetime-local" name="start_at" required><input type="datetime-local" name="end_at" required></div>';
    echo '<div style="display:flex;gap:8px;flex-wrap:wrap"><input type="text" name="config[vehicle]" placeholder="Vehicle name"><input type="number" name="config[theft_chance]" placeholder="Theft chance %" style="width:140px"><input type="text" name="config[loot_item]" placeholder="Loot item"><input type="text" name="config[mission]" placeholder="Mission name"><input type="text" name="config[respray]" placeholder="Respray name"></div>';
    echo '<label style="display:flex;align-items:center;gap:8px"><input type="checkbox" name="config[daily_giveaway]" value="1"> Daily giveaway (Christmas)</label>';
    echo '<button class="btn btn-gold" type="submit">Save Event</button></form>';
    echo '</div>';
    break;

case 'deathmatch':
    if (!function_exists('deathmatch_get_status')) require_once __DIR__ . '/includes/deathmatch.php';
    if (!function_exists('deathmatch_set_round_end')) require_once __DIR__ . '/includes/deathmatch.php';
    if (!function_exists('deathmatch_trigger_round_end')) require_once __DIR__ . '/includes/deathmatch.php';

    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'deathmatch_set_round') {
        csrf_verify();
        $ts = strtotime($_POST['round_end'] ?? '');
        if ($ts) { deathmatch_set_round_end($ts); flash('Round end set. Deathmatch will begin 7 days prior.', 'success'); }
        else { flash('Invalid timestamp.', 'error'); }
        redirect('admin.php?a=deathmatch');
    }
    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'deathmatch_trigger') {
        csrf_verify();
        deathmatch_trigger_round_end();
        flash('Deathmatch triggered — round ends in 7 days.', 'success');
        redirect('admin.php?a=deathmatch');
    }

    $status = deathmatch_get_status();
    $roundEnd = deathmatch_get_round_end();
    echo '<div class="card"><div class="panel-heading">Deathmatch Control</div>';
    echo '<p class="muted small">Final 7 days of round: escalating XP (2x→25x), rule changes, $5M/min free cash finale.</p>';
    echo '<div class="stat"><span>Status</span><b>' . ($status['active'] ? 'ACTIVE — Day ' . $status['day'] . ($status['finale'] ? ' FINALE' : '') : 'Inactive') . '</b></div>';
    echo '<div class="stat"><span>Days Remaining</span><b>' . deathmatch_get_days_remaining() . '</b></div>';
    echo '<div class="stat"><span>Round End</span><b>' . ($roundEnd ? date('M j, Y H:i', $roundEnd) : 'Not set') . '</b></div>';
    if ($status['active']) {
        echo '<div class="stat"><span>Current XP Multiplier</span><b>' . $status['config']['xp_multiplier'] . 'x</b></div>';
        echo '<div class="stat"><span>Finale</span><b>' . ($status['finale'] ? 'YES — 25x XP + $5M/min' : 'No') . '</b></div>';
    }
    echo '<form method="post" style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">' . csrf_field();
    echo '<input type="hidden" name="admin_action" value="deathmatch_set_round">';
    echo '<input type="datetime-local" name="round_end" value="' . ($roundEnd ? date('Y-m-d\TH:i', $roundEnd) : '') . '" required>';
    echo '<button class="btn btn-gold" type="submit">Set Round End</button>';
    echo '<input type="hidden" name="admin_action" value="deathmatch_trigger" style="display:none">';
    echo '<button class="btn btn-danger" type="submit" formaction="admin.php?a=deathmatch" formmethod="post" name="admin_action" value="deathmatch_trigger" onclick="return confirm(\'Trigger Deathmatch now? Round ends in 7 days.\')">Trigger Deathmatch (7 days)</button>';
    echo '</form>';
    echo '</div>';
    break;

case 'respect':
    if (!function_exists('respect_get_leaderboard')) require_once __DIR__ . '/includes/respect.php';
    if (!function_exists('respect_admin_adjust')) require_once __DIR__ . '/includes/respect.php';

    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'respect_adjust') {
        csrf_verify();
        $id = (int) ($_POST['user_id'] ?? 0);
        $amt = (int) ($_POST['amount'] ?? 0);
        if ($id && $amt !== 0) {
            $result = respect_admin_adjust($id, $amt, $u['id']);
            flash($result['ok'] ? 'Adjusted.' : $result['error'], $result['ok'] ? 'success' : 'error');
        }
        redirect('admin.php?a=respect');
    }

    echo '<div class="card"><div class="panel-heading">Respect System</div>';
    echo '<p class="muted small">Daily limit by level (1-10+). Send respect/disrespect. Profile shows net balance.</p>';
    echo '<form method="post" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">' . csrf_field() . '<input type="hidden" name="admin_action" value="respect_adjust">';
    echo '<input type="number" name="user_id" placeholder="User ID" required style="width:100px"><input type="number" name="amount" placeholder="Amount (+/-)" required style="width:120px">';
    echo '<button class="btn btn-gold" type="submit">Adjust Net Respect</button></form>';

    $top = respect_get_leaderboard(20);
    $bottom = respect_get_disrespected(20);
    echo '<div class="grid grid-2" style="margin-top:16px">';
    echo '<div class="card"><div class="panel-heading">Most Respected</div>';
    if ($top) { echo '<div class="table-wrap"><table><tr><th>Player</th><th>Level</th><th>Net Respect</th></tr>'; foreach ($top as $t) echo '<tr><td><a href="' . e(url('profile.php?id=' . $t['id'])) . '">' . e($t['username']) . '</a></td><td>' . (int) $t['level'] . '</td><td class="text-green">' . (int) $t['net_respect'] . '</td></tr>'; echo '</table></div>'; } else { echo '<p class="muted">No data.</p>'; } echo '</div>';
    echo '<div class="card"><div class="panel-heading">Most Disrespected</div>';
    if ($bottom) { echo '<div class="table-wrap"><table><tr><th>Player</th><th>Level</th><th>Net Respect</th></tr>'; foreach ($bottom as $b) echo '<tr><td><a href="' . e(url('profile.php?id=' . $b['id'])) . '">' . e($b['username']) . '</a></td><td>' . (int) $b['level'] . '</td><td class="text-red">' . (int) $b['net_respect'] . '</td></tr>'; echo '</table></div>'; } else { echo '<p class="muted">No data.</p>'; } echo '</div>';
    echo '</div>';
    break;

case 'prestige':
    if (!function_exists('prestige_get_leaderboard')) require_once __DIR__ . '/includes/prestige.php';
    if (!function_exists('prestige_admin_set')) require_once __DIR__ . '/includes/prestige.php';
    if (!function_exists('prestige_admin_grant')) require_once __DIR__ . '/includes/prestige.php';

    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'prestige_set') {
        csrf_verify();
        $id = (int) ($_POST['user_id'] ?? 0);
        $pl = (int) ($_POST['prestige_level'] ?? 0);
        $coins = (int) ($_POST['prestige_coins'] ?? -1);
        if ($id && $pl >= 0) {
            $result = prestige_admin_set($id, $pl, $coins);
            flash($result['ok'] ? 'Set.' : $result['error'], $result['ok'] ? 'success' : 'error');
        }
        redirect('admin.php?a=prestige');
    }
    if (isset($_POST['admin_action']) && $_POST['admin_action'] === 'prestige_grant') {
        csrf_verify();
        $id = (int) ($_POST['user_id'] ?? 0);
        $levels = (int) ($_POST['levels'] ?? 1);
        if ($id && $levels > 0) {
            $result = prestige_admin_grant($id, $levels);
            flash($result['ok'] ? 'Granted.' : $result['error'], $result['ok'] ? 'success' : 'error');
        }
        redirect('admin.php?a=prestige');
    }

    echo '<div class="card"><div class="panel-heading">Prestige System</div>';
    echo '<p class="muted small">Unlimited post-50 progression. P1=1k XP, P2=2k... Treated as Level 50 for combat. 1 Prestige Coin per level.</p>';
    echo '<div class="grid grid-2" style="margin-bottom:16px">';
    echo '<div class="card"><div class="panel-heading">Set Prestige Level</div>';
    echo '<form method="post" style="display:flex;gap:8px;flex-wrap:wrap">' . csrf_field() . '<input type="hidden" name="admin_action" value="prestige_set">';
    echo '<input type="number" name="user_id" placeholder="User ID" required style="width:100px"><input type="number" name="prestige_level" placeholder="Prestige Level" required min="0" style="width:140px"><input type="number" name="prestige_coins" placeholder="Prestige Coins (-1=auto)" style="width:160px">';
    echo '<button class="btn btn-gold" type="submit">Set</button></form></div>';
    echo '<div class="card"><div class="panel-heading">Grant Prestige Levels</div>';
    echo '<form method="post" style="display:flex;gap:8px;flex-wrap:wrap">' . csrf_field() . '<input type="hidden" name="admin_action" value="prestige_grant">';
    echo '<input type="number" name="user_id" placeholder="User ID" required style="width:100px"><input type="number" name="levels" placeholder="Levels to add" required min="1" value="1" style="width:140px">';
    echo '<button class="btn btn-gold" type="submit">Grant</button></form></div>';
    echo '</div>';

    $board = prestige_get_leaderboard(20);
    echo '<div class="card"><div class="panel-heading">Prestige Leaderboard</div>';
    if ($board) {
        echo '<div class="table-wrap"><table><tr><th>Player</th><th>Display</th><th>Prestige</th><th>Coins</th><th>Total XP</th></tr>';
        foreach ($board as $b) {
            $display = 'P' . (int) $b['prestige_level'];
            echo '<tr><td><a href="' . e(url('profile.php?id=' . $b['id'])) . '">' . e($b['username']) . '</a></td><td>' . $display . '</td><td>' . (int) $b['prestige_level'] . '</td><td>' . (int) $b['prestige_coins'] . '</td><td>' . number_format((int) $b['xp']) . '</td></tr>';
        }
        echo '</table></div>';
    } else { echo '<p class="muted">No prestige users yet.</p>'; }
    echo '</div>';
    break;

default:
    echo '<div class="card"><div class="panel-heading">Admin Panel</div><p class="muted">Select a section above.</p></div>';
}