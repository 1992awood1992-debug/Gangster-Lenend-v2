<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $bet = max(100, (int)($_POST['bet'] ?? 100));
    $lines = max(1, min(5, (int)($_POST['lines'] ?? 1)));
    $totalBet = $bet * $lines;
    if ((int)$u['money'] < $totalBet) {
        flash('Not enough cash.', 'error');
        redirect('casino.php');
    }
    $symbols = ['🍒','🍋','🍊','🍇','🔔','⭐','7️⃣','💎'];
    $weights = [25,20,18,15,10,6,4,2];
    function spin($symbols, $weights) {
        $r = mt_rand(1, array_sum($weights));
        $acc = 0;
        foreach ($weights as $i => $w) {
            $acc += $w;
            if ($r <= $acc) return $symbols[$i];
        }
        return $symbols[count($symbols)-1];
    }
    $grid = [];
    for ($col = 0; $col < 3; $col++) {
        for ($row = 0; $row < 3; $row++) {
            $grid[$col][$row] = spin($symbols, $weights);
        }
    }
    $win = 0;
    $pays = ['🍒'=>2,'🍋'=>5,'🍊'=>10,'🍇'=>20,'🔔'=>50,'⭐'=>100,'7️⃣'=>250,'💎'=>500];
    // Check 3 horizontal lines
    for ($row = 0; $row < 3; $row++) {
        $s = $grid[0][$row];
        if ($grid[1][$row] === $s && $grid[2][$row] === $s) {
            $win += $pays[$s] ?? 0;
        }
    }
    // Check diagonals
    if ($grid[0][0] === $grid[1][1] && $grid[1][1] === $grid[2][2]) $win += $pays[$grid[0][0]] ?? 0;
    if ($grid[0][2] === $grid[1][1] && $grid[1][1] === $grid[2][0]) $win += $pays[$grid[0][2]] ?? 0;
    $win = $win * $bet;
    $profit = $win - $totalBet;
    add_money($u['id'], $profit, 'Casino slots win');
    if ($profit > 0) {
        $_SESSION['casino_result'] = ['win' => true, 'profit' => $profit, 'win_amount' => $win, 'bet' => $totalBet, 'grid' => $grid];
    } else {
        $_SESSION['casino_result'] = ['win' => false, 'profit' => $profit, 'win_amount' => 0, 'bet' => $totalBet, 'grid' => $grid];
    }
    redirect('casino.php');
}
$page_title = 'Casino';
require __DIR__ . '/includes/header.php';
$u = current_user();
$result = $_SESSION['casino_result'] ?? null;
unset($_SESSION['casino_result']);
?>
<div class="card card-glass" style="text-align:center">
  <div class="panel-heading" style="justify-content:center">Casino — Slots</div>
  <p class="muted small">Spin the reels. Match 3 across any line to win.</p>
</div>
<?php if ($result): ?>
<div class="card card-glass alert alert-<?= $result['win'] ? 'success' : 'error' ?>" style="margin-top:12px;text-align:center">
  <div style="font-size:2.5rem;margin-bottom:6px"><?= $result['win'] ? '🎰' : '💸' ?></div>
  <?php if ($result['win']): ?>
    <b style="color:var(--gold-bright)">WINNER!</b><br>
    <span style="font-size:1.3rem">+<?= money((int)$result['profit']) ?></span>
  <?php else: ?>
    <b style="color:var(--red)">No win this spin.</b><br>
    <span style="font-size:1.1rem">-<?= money((int)$result['bet']) ?></span>
  <?php endif; ?>
</div>
<?php endif; ?>
<div class="card card-glass" style="margin-top:14px;text-align:center">
  <div class="panel-heading" style="border-bottom:none">Slot Machine</div>
  <div style="display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin:10px 0">
    <div style="font-size:3rem;line-height:1"><?= $result ? $result['grid'][0][0] : '🍒' ?></div>
    <div style="font-size:3rem;line-height:1"><?= $result ? $result['grid'][1][0] : '🍋' ?></div>
    <div style="font-size:3rem;line-height:1"><?= $result ? $result['grid'][2][0] : '🍊' ?></div>
  </div>
  <div style="display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin:4px 0">
    <div style="font-size:3rem;line-height:1"><?= $result ? $result['grid'][0][1] : '🔔' ?></div>
    <div style="font-size:3rem;line-height:1"><?= $result ? $result['grid'][1][1] : '⭐' ?></div>
    <div style="font-size:3rem;line-height:1"><?= $result ? $result['grid'][2][1] : '7️⃣' ?></div>
  </div>
  <div style="display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin:4px 0 12px">
    <div style="font-size:3rem;line-height:1"><?= $result ? $result['grid'][0][2] : '🍇' ?></div>
    <div style="font-size:3rem;line-height:1"><?= $result ? $result['grid'][1][2] : '💎' ?></div>
    <div style="font-size:3rem;line-height:1"><?= $result ? $result['grid'][2][2] : '🍒' ?></div>
  </div>
  <form method="post" style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">
    <?= csrf_field() ?>
    <label class="pill" style="cursor:pointer">
      Bet <select name="bet" style="background:var(--panel-2);color:var(--text);border:1px solid var(--line);padding:4px 8px;border-radius:6px"><option value="100">$100</option><option value="500">$500</option><option value="1000" selected>$1,000</option><option value="5000">$5,000</option></select>
    </label>
    <label class="pill" style="cursor:pointer">
      Lines <select name="lines" style="background:var(--panel-2);color:var(--text);border:1px solid var(--line);padding:4px 8px;border-radius:6px"><option value="1">1</option><option value="3">3</option><option value="5" selected>5</option></select>
    </label>
    <button class="btn btn-gold" type="submit" style="font-size:1.1rem;padding:12px 28px">SPIN</button>
  </form>
  <p class="muted small">Your cash: <?= money($u['money']) ?></p>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
