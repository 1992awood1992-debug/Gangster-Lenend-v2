<?php
/**
 * Eye Of The Mafia - Redis Session Handler
 * 
 * Provides a Redis-backed session handler for scalable session storage.
 * Falls back to file-based sessions if Redis is unavailable.
 */

declare(strict_types=1);

require_once __DIR__ . '/cache.php';

/**
 * Redis session handler class
 */
class RedisSessionHandler implements SessionHandlerInterface
{
    private ?Redis $redis = null;
    private int $ttl = 1800; // 30 minutes default
    private string $prefix = 'mafia:session:';
    private bool $available = false;

    public function __construct(int $ttl = 1800, string $prefix = 'mafia:session:')
    {
        $this->ttl = $ttl;
        $this->prefix = $prefix;
        $this->redis = cache_redis();
        $this->available = $this->redis !== null;
    }

    public function open(string $savePath, string $sessionName): bool
    {
        // Always return true - if Redis is not available, we'll fall back to file-based in read/write
        return true;
    }

    public function close(): bool
    {
        return true;
    }

    public function read(string $id): string|false
    {
        if (!$this->available) {
            return false; // Let PHP use default file handler
        }
        try {
            $data = $this->redis->get($this->prefix . $id);
            if ($data === false || $data === null) {
                return '';
            }
            return $data;
        } catch (Throwable $e) {
            return '';
        }
    }

    public function write(string $id, string $data): bool
    {
        if (!$this->available) {
            return false; // Let PHP use default file handler
        }
        try {
            return (bool) $this->redis->setex($this->prefix . $id, $this->ttl, $data);
        } catch (Throwable $e) {
            return false;
        }
    }

    public function destroy(string $id): bool
    {
        if (!$this->available) {
            return false; // Let PHP use default file handler
        }
        try {
            return (bool) $this->redis->del($this->prefix . $id);
        } catch (Throwable $e) {
            return false;
        }
    }

    public function gc(int $maxLifetime): int|false
    {
        // Redis handles expiration automatically via TTL
        return true;
    }

    public function isAvailable(): bool
    {
        return $this->available;
    }
}

/**
 * Initialize Redis session handler if available, otherwise use default file handler
 */
function init_redis_session(int $ttl = 1800): void
{
    if (session_status() !== PHP_SESSION_NONE) {
        return; // Already started
    }

    $handler = new RedisSessionHandler($ttl);
    
    if ($handler->isAvailable()) {
        session_set_save_handler($handler, true);
        // Extended session lifetime for Redis
        ini_set('session.gc_maxlifetime', (string) $ttl);
        ini_set('session.gc_probability', '1');
        ini_set('session.gc_divisor', '100');
    } else {
        // Fallback: ensure file-based sessions work well
        ini_set('session.gc_maxlifetime', (string) $ttl);
        ini_set('session.gc_probability', '1');
        ini_set('session.gc_divisor', '100');
        // Ensure session save path is writable
        $savePath = ini_get('session.save_path');
        if ($savePath && !is_dir($savePath)) {
            @mkdir($savePath, 0775, true);
        }
    }
}

/**
 * Get Redis session stats
 */
function session_redis_stats(): array
{
    $redis = cache_redis();
    if (!$redis) {
        return ['backend' => 'file', 'sessions' => 'N/A'];
    }
    try {
        $keys = $redis->keys('mafia:session:*');
        return [
            'backend' => 'redis',
            'active_sessions' => count($keys),
            'memory_usage' => $redis->info('memory')['used_memory_human'] ?? 'N/A',
        ];
    } catch (Throwable $e) {
        return ['backend' => 'redis', 'error' => $e->getMessage()];
    }
}