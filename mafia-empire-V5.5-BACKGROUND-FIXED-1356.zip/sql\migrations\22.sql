-- API v2: SSE Events & Webhook Retry -------------------------------------

-- SSE Events for real-time subscriptions
CREATE TABLE IF NOT EXISTS sse_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    channel VARCHAR(100) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    payload JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_channel_created (channel, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add retry columns to webhook_deliveries
ALTER TABLE webhook_deliveries
    ADD COLUMN IF NOT EXISTS retry_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER attempts,
    ADD COLUMN IF NOT EXISTS last_retry_at DATETIME NULL AFTER retry_count,
    ADD COLUMN IF NOT EXISTS next_retry_at DATETIME NULL AFTER last_retry_at;

-- Bump schema version
UPDATE settings SET v = '22' WHERE k = 'schema_version';