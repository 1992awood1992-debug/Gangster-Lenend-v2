<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);

require 'C:/Users/ash/Documents/Default Project/mafia-empire/config.php';
require 'C:/Users/ash/Documents/Default Project/mafia-empire/includes/db.php';

echo "Before init_secure_session:\n";
echo "Session status: " . session_status() . "\n";

$oldErrorHandler = set_error_handler(function($errno, $errstr, $errfile, $errline) {
    echo "ERROR [$errno]: $errstr in $errfile on line $errline\n";
    return true;
});

echo "Calling init_secure_session()...\n";
require_once __DIR__ . '/includes/security.php';

echo "session_start() return value: ";
$result = session_start();
var_dump($result);

echo "\nAfter init_secure_session:\n";
echo "Session status: " . session_status() . "\n";
echo "Session ID: " . session_id() . "\n";