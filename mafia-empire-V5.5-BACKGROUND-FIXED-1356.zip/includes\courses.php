﻿<?php
function course_get_groups(): array {
    return fetch_all("SELECT * FROM course_groups WHERE active=1 ORDER BY sort_order ASC");
}
function course_get_by_group(int $gid): array {
    return fetch_all("SELECT * FROM courses WHERE group_id=? AND active=1 ORDER BY sort_order ASC", [$gid]);
}
function course_get_user_active(int $uid): ?array {
    return fetch("SELECT uc.*, c.name as course_name FROM user_courses uc JOIN courses c ON c.id=uc.course_id WHERE uc.user_id=? AND uc.status='active' ORDER BY uc.id DESC LIMIT 1", [$uid]);
}
function course_get_user_completed(int $uid): array {
    return fetch_all("SELECT uc.*, c.name as course_name FROM user_courses uc JOIN courses c ON c.id=uc.course_id WHERE uc.user_id=? AND uc.status='completed' ORDER BY uc.completed_at DESC", [$uid]);
}
function course_can_enrol(int $uid, array $c): array {
    $u = fetch("SELECT * FROM users WHERE id=?", [$uid]);
    if ((int)$u["level"] < (int)$c["min_level"]) return ["ok"=>false,"error"=>"Level too low"];
    return ["ok"=>true];
}
