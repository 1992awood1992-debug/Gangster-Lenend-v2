<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: learn
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $abilityId = (int) ($_POST['ability_id'] ?? 0);
    $ability = fetch('SELECT * FROM abilities WHERE id = ?', [$abilityId]);
    if (!$ability) {
        flash('Ability not found.', 'error');
    } elseif ((int) $u['level'] < (int) $ability['min_level']) {
        flash('Level ' . (int) $ability['min_level'] . ' required.', 'error');
    } elseif ((int) $u['points'] < (int) $ability['cost_points']) {
        flash('Not enough points.', 'error');
    } elseif (fetch('SELECT 1 FROM user_abilities WHERE user_id = ? AND ability_id = ?', [$u['id'], $abilityId])) {
        flash('Already learned.', 'error');
    } elseif (action_on_cooldown($u['id'], 'abilities')) {
        $cd = action_on_cooldown($u['id'], 'abilities');
        flash('Abilities on cooldown. Try again in ' . $cd . '.', 'error');
    } else {
        add_points($u['id'], -(int) $ability['cost_points']);
        insert('user_abilities', ['user_id' => $u['id'], 'ability_id' => $abilityId]);
        // Apply immediate effect if passive stat
        if ($ability['effect_type'] === 'stat' && $ability['stat']) {
            $stat = $ability['stat'];
            $allowed = ['strength', 'speed', 'defense', 'iq'];
            if (in_array($stat, $allowed)) {
                q('UPDATE users SET `' . $stat . '` = `' . $stat . '` + ? WHERE id = ?', [(int) $ability['effect_value'], $u['id']]);
                flash('Learned ' . e($ability['name']) . '! Permanently gained ' . (int) $ability['effect_value'] . ' ' . ucfirst($stat) . '.', 'success');
            } else {
                flash('Learned ' . e($ability['name']) . '!', 'success');
            }
        } else {
            // Consumable-like: apply once immediately
            if ($ability['effect_type'] === 'heal') {
                q('UPDATE users SET health = health_max WHERE id = ?', [$u['id']]);
                flash('Learned ' . e($ability['name']) . '! Fully healed.', 'success');
            } elseif ($ability['effect_type'] === 'energy') {
                $new = min((int) $u['energy_max'], (int) $u['energy'] + (int) $ability['effect_value']);
                q('UPDATE users SET energy = ? WHERE id = ?', [$new, $u['id']]);
                flash('Learned ' . e($ability['name']) . '! Restored ' . (int) $ability['effect_value'] . ' energy.', 'success');
            } elseif ($ability['effect_type'] === 'nerve') {
                $new = min((int) $u['nerve_max'], (int) $u['nerve'] + (int) $ability['effect_value']);
                q('UPDATE users SET nerve = ? WHERE id = ?', [$new, $u['id']]);
                flash('Learned ' . e($ability['name']) . '! Restored ' . (int) $ability['effect_value'] . ' nerve.', 'success');
            } elseif ($ability['effect_type'] === 'bullets') {
                add_bullets($u['id'], (int) $ability['effect_value']);
                flash('Learned ' . e($ability['name']) . '! Gained ' . (int) $ability['effect_value'] . ' bullets.', 'success');
            } elseif ($ability['effect_type'] === 'xp') {
                grant_xp($u['id'], (int) $ability['effect_value']);
                flash('Learned ' . e($ability['name']) . '! Gained ' . number_format((int) $ability['effect_value']) . ' XP.', 'success');
            } elseif ($ability['effect_type'] === 'money') {
                add_money($u['id'], (int) $ability['effect_value'], 'Ability bonus');
                flash('Learned ' . e($ability['name']) . '! Gained ' . money((int) $ability['effect_value']) . '.', 'success');
            } else {
                flash('Learned ' . e($ability['name']) . '!', 'success');
            }
        }
    }
    redirect('abilities.php');
}

$page_title = 'Abilities';
require __DIR__ . '/includes/header.php';

$u = current_user();
$abilities = fetch_all('SELECT * FROM abilities ORDER BY min_level');
$learned = fetch_all('SELECT ability_id FROM user_abilities WHERE user_id = ?', [$u['id']]);
$learnedIds = array_column($learned, 'ability_id');
?>
<div class="card">
  <div class="panel-heading">Abilities</div>
  <p class="muted small">Spend points to learn passive stat boosts or one-time consumable effects.</p>
  <div class="stat"><span>Available Points</span><b><?= (int) $u['points'] ?></b></div>
</div>

<div class="grid grid-2">
  <?php foreach ($abilities as $a):
    $learned = in_array($a['id'], $learnedIds);
    $locked = (int) $u['level'] < (int) $a['min_level'];
    $afford = (int) $u['points'] >= (int) $a['cost_points'];
  ?>
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <b><?= e($a['name']) ?></b>
          <br><small class="muted"><?= e($a['description']) ?></small>
        </div>
        <span class="tag tag-<?= $learned ? 'legendary' : ($locked ? 'common' : 'uncommon') ?>">
          <?= $learned ? 'Learned' : ($locked ? 'Lvl ' . (int) $a['min_level'] : (int) $a['cost_points'] . ' pts') ?>
        </span>
      </div>
      <div class="pill-row" style="margin:8px 0">
        <span class="pill">Type: <?= e($a['effect_type']) ?></span>
        <?php if ($a['effect_type'] === 'stat'): ?><span class="pill">+<?= (int) $a['effect_value'] ?> <?= ucfirst($a['stat']) ?></span><?php endif; ?>
        <?php if ($a['effect_type'] === 'heal'): ?><span class="pill">Full Heal</span><?php endif; ?>
        <?php if ($a['effect_type'] === 'energy'): ?><span class="pill">+<?= (int) $a['effect_value'] ?> Energy</span><?php endif; ?>
        <?php if ($a['effect_type'] === 'nerve'): ?><span class="pill">+<?= (int) $a['effect_value'] ?> Nerve</span><?php endif; ?>
        <?php if ($a['effect_type'] === 'bullets'): ?><span class="pill">+<?= (int) $a['effect_value'] ?> Bullets</span><?php endif; ?>
        <?php if ($a['effect_type'] === 'xp'): ?><span class="pill">+<?= number_format((int) $a['effect_value']) ?> XP</span><?php endif; ?>
        <?php if ($a['effect_type'] === 'money'): ?><span class="pill">+<?= money((int) $a['effect_value']) ?></span><?php endif; ?>
      </div>
      <?php if (!$learned && !$locked && $afford): ?>
        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="ability_id" value="<?= (int) $a['id'] ?>">
          <button class="btn btn-green btn-block btn-sm" type="submit">Learn</button>
        </form>
      <?php elseif ($learned): ?>
        <span class="muted small">Already learned.</span>
      <?php elseif ($locked): ?>
        <span class="muted small">Requires level <?= (int) $a['min_level'] ?>.</span>
      <?php else: ?>
        <span class="muted small">Need <?= (int) $a['cost_points'] ?> points.</span>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>