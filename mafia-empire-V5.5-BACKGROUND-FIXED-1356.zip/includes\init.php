<?php
/**
 * Mafia Empire - bootstrap. Include at the top of every page.
 */
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/game.php';
require_once __DIR__ . '/migrate.php';
require_once __DIR__ . '/webhooks.php';
require_once __DIR__ . '/discord.php';
require_once __DIR__ . '/push.php';
require_once __DIR__ . '/cache.php';
require_once __DIR__ . '/analytics.php';
require_once __DIR__ . '/login_rewards.php';
require_once __DIR__ . '/crafting.php';
require_once __DIR__ . '/heists.php';
require_once __DIR__ . '/tournaments.php';
require_once __DIR__ . '/properties.php';
require_once __DIR__ . '/racing.php';
require_once __DIR__ . '/market.php';
require_once __DIR__ . '/politics.php';
require_once __DIR__ . '/social.php';
require_once __DIR__ . '/graphql.php';
require_once __DIR__ . '/logging.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/admin_tools.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/flash.php';
require_once __DIR__ . '/heat.php';
require_once __DIR__ . '/city_events.php';

// Initialize secure session FIRST (before current_user() calls session_start)
if (function_exists('init_secure_session')) {
    init_secure_session();
}

// Not installed yet? Send to the installer.
if (!db_installed()) {
    redirect('install.php');
}

run_migrations();

$user = current_user();
if ($user) {
    if ((int) $user['is_banned'] === 1) {
        session_destroy();
        http_response_code(403);
        exit('Your account has been banned.');
    }
    tick_user($user);
    set_current_user($user);
    q('UPDATE users SET last_active = ? WHERE id = ?', [now(), $user['id']]);

    // Process daily login reward (updates streak, determines eligibility)
    if (function_exists('login_process_daily')) {
        login_process_daily($user['id']);
    }
}

// Initialize request logging
if (function_exists('log_init_request')) {
    log_init_request();
}

// Register shutdown function to log request completion
if (function_exists('log_finish_request')) {
    register_shutdown_function(function () {
        $statusCode = http_response_code();
        if ($statusCode === false) {
            $statusCode = 200;
        }
        $durationMs = (microtime(true) - ($_SERVER['REQUEST_TIME_FLOAT'] ?? microtime(true))) * 1000;
        log_finish_request($statusCode, $durationMs);
    });
}

// Apply security headers
if (function_exists('apply_security_headers')) {
    apply_security_headers();
}

// Initialize rate limiting
if (function_exists('init_rate_limiter')) {
    init_rate_limiter();
}

/** Unread notification count for the header badge. */
function unread_notifications(): int
{
    if (!is_logged_in()) {
        return 0;
    }
    $uid = (int) ($_SESSION['uid'] ?? 0);
    if ($uid <= 0) {
        return 0;
    }
    $main = (int) fetch_one('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [$uid], 0);
    $social = 0;
    try {
        $social = (int) fetch_one('SELECT COUNT(*) FROM social_notifications WHERE user_id = ? AND is_read = 0', [$uid], 0);
    } catch (Throwable $e) {
        // social_notifications may be absent on very old installs.
    }
    return $main + $social;
}

// Seed default welcome flash (cheap after first run)
if (is_logged_in()) {
    db_seed_default_flashes();
}
