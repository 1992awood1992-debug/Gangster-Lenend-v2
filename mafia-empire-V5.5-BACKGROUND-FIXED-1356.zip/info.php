<?php
require_once __DIR__ . '/includes/init.php';
// Public page

$page_title = 'Info & Help';
require __DIR__ . '/includes/header.php';

$u = current_user();
?>
<div class="card">
  <div class="panel-heading">Welcome to <?= e(SITE_NAME) ?></div>
  <p><strong><?= e(SITE_NAME) ?></strong> is a text-based mafia RPG. Start as a street associate and climb to Syndicate Legend.</p>
  <h3>Core Mechanics</h3>
  <ul style="padding-left:20px;margin:8px 0">
    <li><b>Energy</b> — Used for missions, gym, bosses. Regenerates 1 per 5 minutes.</li>
    <li><b>Nerve</b> — Used for criminal jobs. Regenerates 1 per 10 minutes.</li>
    <li><b>Health</b> — Lost in fights. Regenerates 1 per 10 minutes. At 0 you're hospitalized.</li>
    <li><b>Bullets</b> — Ammo for attacks. Buy, win, or collect from bullet factories.</li>
    <li><b>Points</b> — Premium currency from achievements, daily rewards, referrals, voting.</li>
    <li><b>XP & Levels</b> — Earn XP from activities. Level up for stats and unlocks.</li>
  </ul>
  
  <h3>Quick Links</h3>
  <div class="grid grid-4" style="margin-top:10px">
    <a class="tile" href="<?= e(url('updates.php')) ?>"><span class="ico">📢</span><b>Updates</b></a>
    <a class="tile" href="<?= e(url('help.php')) ?>"><span class="ico">❓</span><b>Help</b></a>
    <a class="tile" href="<?= e(url('support.php')) ?>"><span class="ico">🎫</span><b>Support</b></a>
    <a class="tile" href="<?= e(url('suggestions.php')) ?>"><span class="ico">💡</span><b>Suggestions</b></a>
    <a class="tile" href="<?= e(url('votes.php')) ?>"><span class="ico">🗳️</span><b>Votes</b></a>
    <a class="tile" href="<?= e(url('statistics.php')) ?>"><span class="ico">📊</span><b>Statistics</b></a>
  </div>
</div>

<?php if ($u): ?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Your Account</div>
  <div class="grid grid-4">
    <div class="stat"><span>Rank</span><b><?= e(rank_for_level((int) $u['level'])['name']) ?></b></div>
    <div class="stat"><span>Level</span><b><?= (int) $u['level'] ?></b></div>
    <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
    <div class="stat"><span>Bank</span><b><?= money($u['bank']) ?></b></div>
    <div class="stat"><span>Bullets</span><b><?= number_format((int) $u['bullets']) ?></b></div>
    <div class="stat"><span>Points</span><b><?= number_format((int) $u['points']) ?></b></div>
    <div class="stat"><span>Kills</span><b><?= (int) $u['kills'] ?></b></div>
    <div class="stat"><span>District</span><b><?= e(fetch('SELECT name FROM districts WHERE id = ?', [$u['district_id']])['name'] ?? '—') ?></b></div>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>