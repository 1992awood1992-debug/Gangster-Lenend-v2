<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Output helpers: money formatting and HTML escaping.
 */
final class FormattingTest extends TestCase
{
    public function testMoneyFormatsWithThousandsSeparators(): void
    {
        $this->assertSame('$0', money(0));
        $this->assertSame('$1,234', money(1234));
        $this->assertSame('$1,234,567', money(1234567));
    }

    public function testMoneyAcceptsNumericStrings(): void
    {
        $this->assertSame('$500', money('500'));
        $this->assertSame('$2,500', money('2500'));
    }

    public function testMoneyRoundsFloats(): void
    {
        $this->assertSame('$10', money(9.6));
        $this->assertSame('$9', money(9.4));
    }

    public function testEscapeEncodesSpecialCharacters(): void
    {
        $this->assertSame('&lt;a&gt;&amp;&quot;x&quot;', e('<a>&"x"'));
        $this->assertSame('O&#039;Brien', e("O'Brien"));
    }

    public function testEscapeCastsNonStrings(): void
    {
        $this->assertSame('42', e(42));
        $this->assertSame('', e(null));
    }
}
