<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'Referral Program';
require __DIR__ . '/includes/header.php';

$u = current_user();
$refLink = url('register.php?ref=' . $u['referral_code']);
$stats = referral_get_stats($u['id']);
$history = referral_get_history($u['id']);
$pending = referral_get_pending($u['id']);

$milestones = [
    'signup' => ['label' => 'Sign Up', 'desc' => 'Referred player creates account', 'icon' => '👤'],
    'level_5' => ['label' => 'Level 5', 'desc' => 'Referred player reaches level 5', 'icon' => '🌱'],
    'level_10' => ['label' => 'Level 10', 'desc' => 'Referred player reaches level 10', 'icon' => '🌿'],
    'level_20' => ['label' => 'Level 20', 'desc' => 'Referred player reaches level 20', 'icon' => '🌳'],
    'level_50' => ['label' => 'Level 50', 'desc' => 'Referred player reaches level 50', 'icon' => '🏆'],
    'first_purchase' => ['label' => 'First Purchase', 'desc' => 'Referred player buys points', 'icon' => '💎'],
    'reach_rank' => ['label' => 'Rank Up', 'desc' => 'Referred player reaches a new rank', 'icon' => '⭐'],
];
?>
<div class="card">
  <div class="panel-heading">Referral Program</div>
  <p class="muted small">Share your referral link. Earn rewards when your referrals hit milestones!</p>
  
  <div class="grid grid-4" style="margin-bottom:14px">
    <div class="stat"><span>Your Code</span><b><?= e($u['referral_code']) ?></b></div>
    <div class="stat"><span>Total Referred</span><b><?= number_format($stats['total_referred']) ?></b></div>
    <div class="stat"><span>Points Earned</span><b><?= number_format($stats['total_points']) ?></b></div>
    <div class="stat"><span>Cash Earned</span><b><?= money($stats['total_cash']) ?></b></div>
  </div>

  <div style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap">
    <button class="btn btn-gold btn-sm" onclick="navigator.clipboard.writeText('<?= e($refLink) ?>');this.textContent='Copied!';setTimeout(()=>this.textContent='Copy Link',2000)">Copy Link</button>
    <button class="btn btn-sm" onclick="navigator.share({title:'Join me in Eye Of The Mafia',text:'Play with me!',url:'<?= e($refLink) ?>'})">Share</button>
    <a class="btn btn-sm" href="<?= e($refLink) ?>" target="_blank">Open Link</a>
  </div>
  <div class="stat" style="margin-top:8px"><span>Referral Link</span><b style="word-break:break-all"><a href="<?= e($refLink) ?>" target="_blank"><?= e($refLink) ?></a></b></div>
</div>

<!-- Milestone Rewards -->
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Milestone Rewards</div>
  <div class="grid grid-4" style="gap:12px">
    <?php foreach ($milestones as $key => $m): 
      $amount = (int)get_setting('referral_' . $key . '_bonus', 0);
      if ($key === 'signup') $amount = (int)get_setting('referral_signup_bonus', 50);
      if ($amount <= 0) continue;
    ?>
    <div class="card tile" style="padding:14px;text-align:center">
      <div style="font-size:2rem"><?= $m['icon'] ?></div>
      <b><?= e($m['label']) ?></b>
      <br><small class="muted"><?= e($m['desc']) ?></small>
      <div class="tag tag-gold" style="margin-top:8px;display:inline-block">+<?= number_format($amount) ?> pts</div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Pending Rewards -->
<?php if ($pending): ?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Pending Rewards <span class="tag tag-gold"><?= count($pending) ?></span></div>
  <div class="table-wrap"><table>
    <tr><th>Referred</th><th>Milestone</th><th>Reward</th><th>Date</th></tr>
    <?php foreach ($pending as $p): ?>
    <tr>
      <td><a href="<?= e(url('profile.php?id=' . (int) $p['referred_id'])) ?>"><?= e(fetch('SELECT username FROM users WHERE id = ?', [$p['referred_id']])['username'] ?? 'Unknown') ?></a></td>
      <td><?= e($milestones[$p['milestone']]['label'] ?? $p['milestone']) ?></td>
      <td><?= number_format($p['reward_amount']) ?> <?= e($p['reward_type']) ?></td>
      <td><?= date('M j, Y', strtotime($p['created_at'])) ?></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<!-- Referral History -->
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Reward History</div>
  <?php if (!$history): ?>
    <p class="muted">No referral rewards yet.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Referred</th><th>Milestone</th><th>Reward</th><th>Status</th><th>Date</th></tr>
      <?php foreach ($history as $h): ?>
      <tr>
        <td><a href="<?= e(url('profile.php?id=' . (int) $h['referred_id'])) ?>"><?= e(fetch('SELECT username FROM users WHERE id = ?', [$h['referred_id']])['username'] ?? 'Unknown') ?></a></td>
        <td><?= e($milestones[$h['milestone']]['label'] ?? $h['milestone']) ?></td>
        <td><?= number_format($h['reward_amount']) ?> <?= e($h['reward_type']) ?></td>
        <td><span class="tag tag-<?= $h['status'] === 'claimed' ? 'gold' : 'common' ?>"><?= ucfirst($h['status']) ?></span></td>
        <td><?= date('M j, Y', strtotime($h['created_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<!-- Your Referrals -->
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Your Referrals</div>
  <?php if (!$stats['referrals']): ?>
    <p class="muted">No referrals yet. Share your link to start earning!</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Player</th><th>Level</th><th>Rank</th><th>Milestones Hit</th><th>Joined</th></tr>
      <?php foreach ($stats['referrals'] as $r): ?>
        <tr>
          <td><a href="<?= e(url('profile.php?id=' . (int) $r['id'])) ?>"><b><?= e($r['username']) ?></b></a></td>
          <td><?= (int) $r['level'] ?></td>
          <td><?= e(rank_for_level((int) $r['level'])['name']) ?></td>
          <td><?= (int) $r['milestones_hit'] ?> / <?= count($milestones) ?></td>
          <td><?= date('M j, Y', strtotime($r['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>