<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$ticketId = isset($_GET['id']) ? (int) $_GET['id'] : null;

// POST: new ticket, reply
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'new_ticket') {
        $subject = trim($_POST['subject'] ?? '');
        $body = trim($_POST['body'] ?? '');
        if ($subject && $body) {
            $tid = insert('support_tickets', ['user_id' => $u['id'], 'subject' => $subject, 'body' => $body, 'status' => 'open']);
            flash('Ticket created.', 'success');
            redirect('support.php?id=' . $tid);
        }
    } elseif ($action === 'reply' && $ticketId) {
        $ticket = fetch('SELECT * FROM support_tickets WHERE id = ?', [$ticketId]);
        if (!$ticket) { flash('Ticket not found.', 'error'); }
        elseif ((int) $ticket['user_id'] !== $u['id'] && (int) $u['is_admin'] !== 1) { flash('Not your ticket.', 'error'); }
        elseif ((int) $ticket['status'] === 1) { flash('Ticket is closed.', 'error'); }
        else {
            $body = trim($_POST['body'] ?? '');
            if ($body) {
                $isStaff = (int) $u['is_admin'] === 1;
                insert('support_replies', ['ticket_id' => $ticketId, 'user_id' => $u['id'], 'body' => $body, 'is_staff' => $isStaff]);
                if ($isStaff && isset($_POST['close'])) {
                    q('UPDATE support_tickets SET status = ? WHERE id = ?', ['closed', $ticketId]);
                    flash('Reply posted and ticket closed.', 'success');
                } else {
                    flash('Reply posted.', 'success');
                }
            }
        }
    } elseif ($action === 'close' && $ticketId && (int) $u['is_admin'] === 1) {
        q('UPDATE support_tickets SET status = ? WHERE id = ?', ['closed', $ticketId]);
        flash('Ticket closed.', 'success');
    }
    redirect('support.php' . ($ticketId ? '?id=' . $ticketId : ''));
}

$page_title = 'Support';
require __DIR__ . '/includes/header.php';

if ($ticketId) {
    $ticket = fetch('SELECT st.*, u.username, u.avatar FROM support_tickets st JOIN users u ON u.id = st.user_id WHERE st.id = ?', [$ticketId]);
    if (!$ticket) { echo '<div class="card"><p class="muted">Ticket not found.</p></div>'; require __DIR__ . '/includes/footer.php'; exit; }
    if ((int) $ticket['user_id'] !== $u['id'] && (int) $u['is_admin'] !== 1) { echo '<div class="card"><p class="muted">Access denied.</p></div>'; require __DIR__ . '/includes/footer.php'; exit; }
    
    $replies = fetch_all('SELECT sr.*, u.username, u.avatar FROM support_replies sr JOIN users u ON u.id = sr.user_id WHERE sr.ticket_id = ? ORDER BY sr.created_at', [$ticketId]);
    
?>
<div class="card" style="margin-bottom:18px">
  <a class="btn btn-sm" href="<?= e(url('support.php')) ?>">&larr; Back to tickets</a>
  <?php if ((int) $u['is_admin'] === 1 && (int) $ticket['status'] === 0): ?>
    <form method="post" style="display:inline;margin-left:10px"><?= csrf_field() ?><input type="hidden" name="action" value="close"><button class="btn btn-sm" type="submit">Close Ticket</button></form>
  <?php endif; ?>
</div>

<div class="card">
  <div class="panel-heading"><?= e($ticket['subject']) ?> <span class="tag tag-<?= (int) $ticket['status'] ? 'common' : 'uncommon' ?>"><?= (int) $ticket['status'] ? 'Closed' : 'Open' ?></span></div>
  <div class="small muted">by <a href="<?= e(url('profile.php?id=' . (int) $ticket['user_id'])) ?>"><?= e($ticket['username']) ?></a> · <?= date('M j, Y H:i', strtotime($ticket['created_at'])) ?></div>
  <div style="margin-top:10px;white-space:pre-wrap"><?= e($ticket['body']) ?></div>
</div>

<?php foreach ($replies as $r): ?>
<div class="card" style="margin-top:10px">
  <div style="display:flex;gap:12px;align-items:flex-start">
    <img src="<?= e($r['avatar']) ?>" alt="" class="avatar" onerror="this.src='<?= e(url('assets/img/avatar-default.svg')) ?>'">
    <div style="flex:1">
      <b><?= e($r['username']) ?></b><?= (int) $r['is_staff'] ? ' <span class="tag tag-legendary">Staff</span>' : '' ?>
      <span class="muted small"> · <?= date('M j, H:i', strtotime($r['created_at'])) ?></span>
      <div style="margin-top:6px;white-space:pre-wrap"><?= e($r['body']) ?></div>
    </div>
  </div>
</div>
<?php endforeach; ?>

<?php if ((int) $ticket['status'] === 0): ?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Reply</div>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="reply">
    <label>Message <textarea name="body" required></textarea></label>
    <?php if ((int) $u['is_admin'] === 1): ?><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" name="close" value="1"> Close after reply</label><?php endif; ?>
    <button class="btn btn-gold" type="submit">Post Reply</button>
  </form>
</div>
<?php endif; ?>

<?php
} else {
    // List user's tickets
    $tickets = fetch_all('SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC', [$u['id']]);
?>
<div class="card">
  <div class="panel-heading">Support Tickets</div>
  <a class="btn btn-gold" href="#" onclick="document.getElementById('newTicket').scrollIntoView();return false" style="float:right">New Ticket</a>
</div>

<div class="card" id="newTicket">
  <div class="panel-heading">Create Ticket</div>
  <form method="post" style="max-width:600px;display:grid;gap:10px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="new_ticket">
    <label>Subject <input name="subject" maxlength="190" required></label>
    <label>Message <textarea name="body" required></textarea></label>
    <button class="btn btn-gold" type="submit">Submit</button>
  </form>
</div>

<?php if (!$tickets): ?>
  <div class="card" style="margin-top:18px"><p class="muted">No tickets yet.</p></div>
<?php else: ?>
  <div class="card" style="margin-top:18px">
    <div class="panel-heading">Your Tickets</div>
    <div class="table-wrap"><table>
      <tr><th>Subject</th><th>Status</th><th>Created</th><th></th></tr>
      <?php foreach ($tickets as $t): ?>
        <tr>
          <td><b><?= e($t['subject']) ?></b></td>
          <td><span class="tag tag-<?= (int) $t['status'] ? 'common' : 'uncommon' ?>"><?= (int) $t['status'] ? 'Closed' : 'Open' ?></span></td>
          <td><?= date('M j, Y H:i', strtotime($t['created_at'])) ?></td>
          <td><a class="btn btn-sm" href="<?= e(url('support.php?id=' . (int) $t['id'])) ?>">View</a></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
<?php endif; }
require __DIR__ . '/includes/footer.php'; ?>