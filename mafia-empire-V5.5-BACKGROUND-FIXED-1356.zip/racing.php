<?php
/**
 * Eye Of The Mafia - Racing
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/racing.php';

$u = require_login();

// POST handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'join') {
        $result = race_join($u['id'], (int) ($_POST['race_id'] ?? 0), (int) ($_POST['vehicle_id'] ?? 0));
        flash($result['error'] ?? 'Joined race!', $result['ok'] ? 'success' : 'error');
    } elseif ($action === 'bet') {
        $result = race_bet($u['id'], (int) ($_POST['race_id'] ?? 0), (int) ($_POST['target_id'] ?? 0), (int) ($_POST['amount_money'] ?? 0), (int) ($_POST['amount_bullets'] ?? 0));
        flash($result['error'] ?? 'Bet placed!', $result['ok'] ? 'success' : 'error');
    }
    redirect('racing.php');
}

$page_title = 'Racing';
require __DIR__ . '/includes/header.php';

$tracks = race_get_tracks();
$activeRaces = race_get_active();
$myVehicles = race_get_user_vehicles($u['id']);
$history = race_get_user_history($u['id'], 10);
$betHistory = race_get_bet_history($u['id'], 10);

?>

<div class="card">
  <div class="panel-heading">Street Racing</div>
  <p class="muted small">Race your vehicles against other crews. Bet on winners for big payouts.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
  <div class="stat"><span>Bullets</span><b><?= number_format((int) $u['bullets']) ?></b></div>
  <div class="stat"><span>Vehicles</span><b><?= count($myVehicles) ?></b></div>
</div>

<h2>Active Races</h2>
<?php if ($activeRaces): ?>
  <?php foreach ($activeRaces as $race): 
    $canJoin = race_can_join($u['id'], (int) $race['id']);
    $isInRace = false;
    foreach ($race['participants'] as $p) if ((int) $p['user_id'] === $u['id']) $isInRace = true;
  ?>
  <div class="card" style="margin-top:16px">
    <div class="panel-heading">
      <span><?= e($race['track_name']) ?></span>
      <span class="tag tag-<?= $race['status'] === 'waiting' ? 'gold' : 'legendary' ?>"><?= ucfirst($race['status']) ?></span>
    </div>
    <p class="muted small"><?= e($race['description'] ?? '') ?></p>
    <div class="stat"><span>Distance</span><b><?= (float) $race['distance_km'] ?> km</b></div>
    <div class="stat"><span>Entry Fee</span><b><?= money($race['entry_fee_money']) ?> | <?= (int) $race['entry_fee_bullets'] ?> bullets</b></div>
    <div class="stat"><span>Prize Pool</span><b><?= money($race['prize_pool_money']) ?> | <?= number_format($race['prize_pool_xp']) ?> XP | <?= number_format($race['prize_pool_points']) ?> Pts</b></div>
    <div class="stat"><span>Racers</span><b><?= count($race['participants']) ?> / <?= (int) $race['max_racers'] ?></b></div>
    
    <?php if ($race['participants']): ?>
      <div class="muted small" style="margin:8px 0">
        <b>Racers:</b> 
        <?php foreach ($race['participants'] as $i => $p): ?>
          <span class="<?= (int) $p['user_id'] === $u['id'] ? 'tag tag-gold' : 'tag tag-common' ?>" style="margin:2px">
            <?= (int) $p['position'] ? $p['position'] . '. ' : '' ?>
            <?= e($p['username']) ?> (<?= e($p['vehicle_name'] ?? 'No Vehicle') ?>)
          </span>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($race['status'] === 'waiting'): ?>
      <?php if ($isInRace): ?>
        <div class="muted small">You are in this race. Waiting for more racers...</div>
      <?php else: ?>
        <form method="post" style="margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="join">
          <input type="hidden" name="race_id" value="<?= (int) $race['id'] ?>">
          <select name="vehicle_id" required style="padding:6px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin-right:8px">
            <?php foreach ($myVehicles as $v): ?>
              <option value="<?= (int) $v['id'] ?>"><?= e($v['name']) ?> (ATK: <?= (int) $v['attack'] ?> DEF: <?= (int) $v['defense'] ?>)</option>
            <?php endforeach; ?>
          </select>
          <button class="btn btn-green btn-sm" type="submit">Join Race</button>
        </form>
      <?php endif; ?>
      
      <div style="margin-top:8px">
        <b>Place a Bet:</b>
        <form method="post" style="display:inline;margin:4px 0">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="bet">
          <input type="hidden" name="race_id" value="<?= (int) $race['id'] ?>">
          <select name="target_id" required style="padding:4px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin-right:4px">
            <?php foreach ($race['participants'] as $p): ?>
              <option value="<?= (int) $p['user_id'] ?>"><?= e($p['username']) ?> (<?= e($p['vehicle_name'] ?? '?') ?>)</option>
            <?php endforeach; ?>
          </select>
          <input type="number" name="amount_money" placeholder="Cash" min="1" value="1000" style="width:80px;padding:4px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin:0 4px">
          <input type="number" name="amount_bullets" placeholder="Bullets" min="0" value="0" style="width:80px;padding:4px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin:0 4px">
          <button class="btn btn-gold btn-sm" type="submit">Bet</button>
        </form>
      </div>
    <?php elseif ($race['status'] === 'racing'): ?>
      <div class="muted small">Race in progress...</div>
    <?php else: ?>
      <div class="muted small">Race finished.</div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
<?php else: ?>
  <div class="card" style="margin-top:16px"><p class="muted">No active races. Check back soon or wait for auto-generated races.</p></div>
<?php endif; ?>

<h2 style="margin-top:24px">Race Tracks</h2>
<div class="grid grid-2">
  <?php foreach ($tracks as $t): ?>
  <div class="card">
    <b><?= e($t['name']) ?></b>
    <br><small class="muted"><?= e($t['description'] ?? '') ?></small>
    <div class="stat"><span>Distance</span><b><?= (float) $t['distance_km'] ?> km</b></div>
    <div class="stat"><span>Min Vehicle Lv</span><b><?= (int) $t['min_vehicle_level'] ?></b></div>
    <div class="stat"><span>Entry Fee</span><b><?= money($t['entry_fee_money']) ?> | <?= (int) $t['entry_fee_bullets'] ?> bullets</b></div>
    <div class="stat"><span>Base Reward</span><b><?= money($t['base_reward_money']) ?> | <?= number_format($t['base_reward_xp']) ?> XP</b></div>
  </div>
  <?php endforeach; ?>
</div>

<?php if ($myVehicles): ?>
<h2 style="margin-top:24px">Your Garage</h2>
<div class="grid grid-3">
  <?php foreach ($myVehicles as $v): ?>
  <div class="card">
    <b><?= e($v['name']) ?></b>
    <div class="stat"><span>Speed (ATK)</span><b><?= (int) $v['attack'] ?></b></div>
    <div class="stat"><span>Handling (DEF)</span><b><?= (int) $v['defense'] ?></b></div>
    <div class="stat"><span>Qty</span><b><?= (int) $v['qty'] ?></b></div>
  </div>
  <?php endforeach; ?>
</div>
<?php else: ?>
<div class="card" style="margin-top:16px"><p class="muted">No vehicles owned. Buy one from the Equipment shop to race!</p></div>
<?php endif; ?>

<?php if ($history): ?>
<h2 style="margin-top:24px">Your Race History</h2>
<div class="table-wrap"><table>
  <tr><th>Date</th><th>Track</th><th>Vehicle</th><th>Position</th><th>Time</th><th>Winnings</th></tr>
  <?php foreach ($history as $h): ?>
  <tr class="<?= $h['position'] === 1 ? 'success' : '' ?>">
    <td><?= date('M j H:i', strtotime($h['finished_at'])) ?></td>
    <td><?= e($h['track_name']) ?></td>
    <td><?= e($h['vehicle_name'] ?? '?') ?></td>
    <td><?= $h['position'] ? '#' . (int) $h['position'] : 'DNF' ?></td>
    <td><?= $h['finish_time_ms'] ? number_format($h['finish_time_ms']) . 'ms' : '—' ?></td>
    <td><?= money($h['payout_money']) ?> | <?= number_format($h['payout_xp']) ?> XP | <?= number_format($h['payout_points']) ?> Pts</td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php endif; ?>

<?php if ($betHistory): ?>
<h2 style="margin-top:24px">Betting History</h2>
<div class="table-wrap"><table>
  <tr><th>Date</th><th>Track</th><th>Bet On</th><th>Amount</th><th>Result</th><th>Payout</th></tr>
  <?php foreach ($betHistory as $b): ?>
  <tr>
    <td><?= date('M j H:i', strtotime($b['placed_at'])) ?></td>
    <td><?= e($b['track_name']) ?></td>
    <td><?= e($b['target_name']) ?></td>
    <td><?= money($b['amount_money']) ?> | <?= (int) $b['amount_bullets'] ?> 🔫</td>
    <td><span class="tag tag-<?= $b['status'] === 'won' ? 'legendary' : ($b['status'] === 'lost' ? 'common' : 'gold') ?>"><?= ucfirst($b['status']) ?></span></td>
    <td><?= money($b['payout']) ?></td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>