# Push Checklist - Eye Of The Mafia

Before pushing to production, run through this checklist to ensure everything is working correctly.

## Pre-Deployment Checks

- [ ] All tests pass locally (`php vendor/bin/phpunit` or PHAR)
- [ ] PHP syntax check passes on all modified files (`php -l`)
- [ ] Database migrations are in order (`sql/migrations/` files sequential, current SCHEMA_VERSION = 8)
- [ ] `.env` is properly configured (not committed)
- [ ] Security headers are configured (Apache/nginx)
- [ ] Rate limiting is working on auth endpoints (login/register, 5 attempts / 15 min)
- [ ] `rate_limits` table exists (migration 6.sql)
- [ ] Social tables exist (migration 5.sql: trades, hitlist, bounties, crew_messages, social_notifications)
- [ ] `analytics_events` table exists (migration 7.sql)
- [ ] Content expansion applied (migration 8.sql: 2 districts, 8 missions, 2 bosses, 4 jobs, 4 legendary items)
- [ ] Web Push VAPID keys are generated (`php cron/run.php vapid`)

## Environment Setup

- [ ] Copy `.env.example` to `.env` and set strong passwords
- [ ] Set `MYSQL_ROOT_PASSWORD` to a secure random value
- [ ] Configure `DOMAIN` and `CERTBOT_EMAIL` for SSL
- [ ] Ensure disk space > 1GB available
- [ ] Database backup strategy in place

## Deployment Steps (Docker)

```bash
# 1. Pull latest code
git pull

# 2. Copy and configure environment
cp .env.example .env
# Edit .env with production values

# 3. Build and start containers
docker compose up -d --build

# 4. Run migrations
docker compose exec php php cron/run.php migrate

# 5. Generate VAPID keys if not exists
docker compose exec php php cron/run.php vapid

# 6. Set up SSL (if production with domain)
./scripts/ssl-init.sh
docker compose --profile tls up -d

# 7. Verify health
curl -f http://localhost:8080/health.php
```

## Post-Deployment

- [ ] Health check returns 200 (`/health.php`)
- [ ] Can access login/register pages
- [ ] Database connections working
- [ ] Cron jobs configured (tick/daily/weekly)
- [ ] Backups running on schedule
- [ ] Error logging working
- [ ] No PHP errors in logs

## Security Verification

- [ ] CSRF tokens present on forms
- [ ] Rate limiting active on login/register
- [ ] Password requirements enforced (8+ chars, upper/lower/digit/special)
- [ ] Security headers present (X-Content-Type-Options, CSP, etc.)
- [ ] Sessions use secure cookies in HTTPS
- [ ] No sensitive data in logs
- [ ] SQL injection protection verified (prepared statements)

## Performance Checks

- [ ] OPcache enabled and configured
- [ ] Static assets cached with proper headers
- [ ] Database indexes are in place
- [ ] Slow query log configured if needed

## Rollback Plan

- [ ] Database backup taken before deploy
- [ ] Previous Docker images tagged
- [ ] Rollback procedure documented and tested

## Notes

- Schema migrations auto-apply but major version changes should be tested first
- The `health.php` endpoint checks DB, schema version, installation status, disk space
- Cron jobs use file locking to prevent overlaps
- All secrets must be in `.env`, never in code
