-- Migration 13: Major Content Expansion + New Systems
-- Idempotent: CREATE TABLE IF NOT EXISTS, safe to re-run.

-- ============================================================
-- NEW TABLES: Player Housing / Safehouses
-- ============================================================
CREATE TABLE IF NOT EXISTS property_types (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    base_price BIGINT UNSIGNED NOT NULL DEFAULT 0,
    max_level INT UNSIGNED NOT NULL DEFAULT 10,
    income_money_per_hour BIGINT UNSIGNED NOT NULL DEFAULT 0,
    income_bullets_per_hour INT UNSIGNED NOT NULL DEFAULT 0,
    income_points_per_hour INT UNSIGNED NOT NULL DEFAULT 0,
    storage_items INT UNSIGNED NOT NULL DEFAULT 0,
    storage_drugs INT UNSIGNED NOT NULL DEFAULT 0,
    storage_bullets BIGINT UNSIGNED NOT NULL DEFAULT 0,
    -- Upgrade costs (compound formula: base * level^1.5)
    upgrade_money_base BIGINT UNSIGNED NOT NULL DEFAULT 10000,
    upgrade_bullets_base INT UNSIGNED NOT NULL DEFAULT 500,
    upgrade_points_base INT UNSIGNED NOT NULL DEFAULT 5,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_properties (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    property_type_id INT UNSIGNED NOT NULL,
    level INT UNSIGNED NOT NULL DEFAULT 1,
    -- Customization
    nickname VARCHAR(100) NULL,
    -- Status
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    last_collected_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    upgraded_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_user_property (user_id, property_type_id),
    KEY idx_user (user_id),
    KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS property_income_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    property_id BIGINT UNSIGNED NOT NULL,
    money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    bullets INT UNSIGNED NOT NULL DEFAULT 0,
    points INT UNSIGNED NOT NULL DEFAULT 0,
    collected_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user_date (user_id, collected_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- NEW TABLES: Vehicle Racing
-- ============================================================
CREATE TABLE IF NOT EXISTS race_tracks (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    min_vehicle_level INT UNSIGNED NOT NULL DEFAULT 1,
    distance_km DECIMAL(5,2) NOT NULL DEFAULT 10.00,
    base_reward_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    base_reward_xp BIGINT UNSIGNED NOT NULL DEFAULT 0,
    base_reward_points INT UNSIGNED NOT NULL DEFAULT 0,
    entry_fee_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    entry_fee_bullets INT UNSIGNED NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS race_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    track_id INT UNSIGNED NOT NULL,
    status ENUM('waiting','racing','finished','cancelled') NOT NULL DEFAULT 'waiting',
    max_racers INT UNSIGNED NOT NULL DEFAULT 8,
    entry_fee_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    entry_fee_bullets INT UNSIGNED NOT NULL DEFAULT 0,
    prize_pool_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    prize_pool_xp BIGINT UNSIGNED NOT NULL DEFAULT 0,
    prize_pool_points INT UNSIGNED NOT NULL DEFAULT 0,
    started_at DATETIME NULL,
    finished_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_status (status),
    KEY idx_track (track_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS race_participants (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    race_id BIGINT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    vehicle_id INT UNSIGNED NOT NULL, -- user_items.id
    position INT UNSIGNED NULL,
    finish_time_ms INT UNSIGNED NULL,
    bet_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    bet_bullets INT UNSIGNED NOT NULL DEFAULT 0,
    payout_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    payout_xp BIGINT UNSIGNED NOT NULL DEFAULT 0,
    payout_points INT UNSIGNED NOT NULL DEFAULT 0,
    joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_race_user (race_id, user_id),
    KEY idx_race (race_id),
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS race_bets (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    race_id BIGINT UNSIGNED NOT NULL,
    bettor_id INT UNSIGNED NOT NULL,
    target_user_id INT UNSIGNED NOT NULL,
    amount_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    amount_bullets INT UNSIGNED NOT NULL DEFAULT 0,
    payout BIGINT UNSIGNED NOT NULL DEFAULT 0,
    status ENUM('pending','won','lost') NOT NULL DEFAULT 'pending',
    placed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_race_bettor (race_id, bettor_id),
    KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- NEW TABLES: Player Marketplace (Auction House)
-- ============================================================
CREATE TABLE IF NOT EXISTS market_listings (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    seller_id INT UNSIGNED NOT NULL,
    -- What's being sold
    item_type ENUM('item','drug','vehicle','property','blueprint') NOT NULL,
    item_id INT UNSIGNED NOT NULL, -- item_id, drug_id, etc.
    qty INT UNSIGNED NOT NULL DEFAULT 1,
    -- Pricing
    buyout_price BIGINT UNSIGNED NULL,
    bid_price BIGINT UNSIGNED NOT NULL DEFAULT 0,
    min_bid BIGINT UNSIGNED NOT NULL DEFAULT 0,
    -- Auction
    auction_end DATETIME NULL,
    status ENUM('active','sold','cancelled','expired') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    sold_at DATETIME NULL,
    buyer_id INT UNSIGNED NULL,
    final_price BIGINT UNSIGNED NULL,
    PRIMARY KEY (id),
    KEY idx_status (status),
    KEY idx_seller (seller_id),
    KEY idx_buyer (buyer_id),
    KEY idx_type (item_type, item_id),
    KEY idx_end (auction_end)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS market_bids (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    listing_id BIGINT UNSIGNED NOT NULL,
    bidder_id INT UNSIGNED NOT NULL,
    amount BIGINT UNSIGNED NOT NULL,
    status ENUM('active','outbid','won','cancelled') NOT NULL DEFAULT 'active',
    placed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_listing (listing_id),
    KEY idx_bidder (bidder_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- NEW TABLES: Politics / Mayor System
-- ============================================================
CREATE TABLE IF NOT EXISTS mayor_elections (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    election_number INT UNSIGNED NOT NULL,
    status ENUM('nominations','voting','finished') NOT NULL DEFAULT 'nominations',
    term_start DATE NOT NULL,
    term_end DATE NOT NULL,
    mayor_id INT UNSIGNED NULL,
    total_votes INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_election_number (election_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mayor_candidates (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    election_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    platform TEXT,
    votes INT UNSIGNED NOT NULL DEFAULT 0,
    is_nominated TINYINT(1) NOT NULL DEFAULT 1,
    nominated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_election_user (election_id, user_id),
    KEY idx_election (election_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mayor_votes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    election_id INT UNSIGNED NOT NULL,
    voter_id INT UNSIGNED NOT NULL,
    candidate_id INT UNSIGNED NOT NULL,
    voted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_election_voter (election_id, voter_id),
    KEY idx_candidate (candidate_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS city_policies (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category ENUM('economy','crime','law_enforcement','social') NOT NULL,
    effect_type VARCHAR(50) NOT NULL, -- money_multiplier, xp_bonus, crime_rate, etc.
    effect_value DECIMAL(10,4) NOT NULL,
    cost_per_day BIGINT UNSIGNED NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    enacted_by INT UNSIGNED NULL,
    enacted_at DATETIME NULL,
    expires_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- NEW TABLES: GraphQL API (future) - placeholder
-- ============================================================
CREATE TABLE IF NOT EXISTS api_graphql_queries (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    api_key_id INT UNSIGNED NOT NULL,
    query_hash VARCHAR(64) NOT NULL,
    query_text TEXT NOT NULL,
    variables JSON,
    duration_ms INT UNSIGNED NOT NULL,
    status ENUM('success','error') NOT NULL,
    error_message TEXT NULL,
    executed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_apikey (api_key_id),
    KEY idx_date (executed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- DEFAULT DATA
-- ============================================================

-- Property Types
INSERT INTO property_types (code, name, description, base_price, max_level, income_money_per_hour, income_bullets_per_hour, income_points_per_hour, storage_items, storage_drugs, storage_bullets, upgrade_money_base, upgrade_bullets_base, upgrade_points_base) VALUES
('safehouse', 'Safehouse', 'A discreet hideout for stashing goods.', 50000, 10, 500, 10, 1, 20, 10, 5000, 10000, 500, 5),
('warehouse', 'Warehouse', 'Large storage for serious operations.', 200000, 15, 2000, 50, 5, 100, 50, 25000, 50000, 2000, 20),
('penthouse', 'Luxury Penthouse', 'High-end living with city views.', 1000000, 20, 5000, 100, 20, 50, 20, 10000, 200000, 10000, 100),
('dockyard', 'Dockyard', 'Smuggler\'s paradise on the waterfront.', 500000, 12, 3000, 200, 10, 80, 100, 50000, 100000, 5000, 50),
('casino', 'Private Casino', 'The house always wins.', 2000000, 25, 10000, 500, 100, 30, 10, 20000, 500000, 20000, 200)
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Race Tracks
INSERT INTO race_tracks (code, name, description, min_vehicle_level, distance_km, base_reward_money, base_reward_xp, base_reward_points, entry_fee_money, entry_fee_bullets) VALUES
('downtown_sprint', 'Downtown Sprint', 'Quick race through city streets.', 1, 5.00, 10000, 500, 10, 5000, 100),
('docks_drift', 'Docks Drift', 'Slippery turns by the water.', 3, 8.00, 25000, 1000, 25, 10000, 200),
('highway_blast', 'Highway Blast', 'Straight-line speed test.', 5, 15.00, 50000, 2000, 50, 25000, 500),
('mountain_pass', 'Mountain Pass', 'Treacherous winding roads.', 8, 20.00, 100000, 5000, 100, 50000, 1000),
('desert_run', 'Desert Run', 'Endurance across the sands.', 12, 50.00, 500000, 20000, 500, 100000, 2000)
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- City Policies
INSERT INTO city_policies (code, name, description, category, effect_type, effect_value, cost_per_day) VALUES
('tax_cut', 'Tax Cut', 'Reduce city taxes, boost citizen income.', 'economy', 'money_multiplier', 1.10, 50000),
('police_funding', 'Police Funding', 'Increase patrols, reduce crime success rates.', 'law_enforcement', 'crime_rate', 0.80, 75000),
('xp_boost', 'Education Initiative', 'City-wide XP gain bonus.', 'social', 'xp_multiplier', 1.15, 100000),
('ammo_subsidy', 'Ammo Subsidy', 'Cheaper bullets for everyone.', 'economy', 'bullet_cost_multiplier', 0.75, 50000),
('healthcare', 'Public Healthcare', 'Faster hospital recovery.', 'social', 'heal_rate', 1.50, 80000),
('black_market_permit', 'Black Market Permit', 'Legalize underground trading.', 'crime', 'market_fee_multiplier', 0.50, 200000)
ON DUPLICATE KEY UPDATE name=VALUES(name);