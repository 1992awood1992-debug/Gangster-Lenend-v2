-- Migration 10: Login rewards & streak system
-- Idempotent: CREATE TABLE IF NOT EXISTS, safe to re-run.

CREATE TABLE IF NOT EXISTS login_rewards (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    day_number INT UNSIGNED NOT NULL,
    reward_type ENUM('money','points','xp','item','bullets','energy','nerve') NOT NULL,
    reward_value INT NOT NULL DEFAULT 0,
    reward_item_id INT UNSIGNED NULL,
    is_milestone TINYINT(1) NOT NULL DEFAULT 0,
    milestone_label VARCHAR(100) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_day (day_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_login_streaks (
    user_id INT UNSIGNED NOT NULL,
    current_streak INT UNSIGNED NOT NULL DEFAULT 0,
    longest_streak INT UNSIGNED NOT NULL DEFAULT 0,
    last_login_date DATE NULL,
    last_claim_date DATE NULL,
    total_logins INT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_login_reward_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    day_number INT UNSIGNED NOT NULL,
    reward_type VARCHAR(20) NOT NULL,
    reward_value INT NOT NULL,
    claimed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user_date (user_id, claimed_at),
    KEY idx_day (day_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default login rewards (days 1-30, then repeats with milestone bonuses)
INSERT INTO login_rewards (day_number, reward_type, reward_value, reward_item_id, is_milestone, milestone_label) VALUES
(1, 'money', 1000, NULL, 0, NULL),
(2, 'xp', 50, NULL, 0, NULL),
(3, 'points', 5, NULL, 0, NULL),
(4, 'money', 2000, NULL, 0, NULL),
(5, 'bullets', 50, NULL, 1, 'Day 5 Bonus'),
(6, 'xp', 75, NULL, 0, NULL),
(7, 'money', 3000, NULL, 1, 'Week 1 Complete'),
(8, 'energy', 25, NULL, 0, NULL),
(9, 'points', 10, NULL, 0, NULL),
(10, 'money', 5000, NULL, 0, NULL),
(11, 'xp', 100, NULL, 0, NULL),
(12, 'bullets', 75, NULL, 0, NULL),
(13, 'money', 4000, NULL, 0, NULL),
(14, 'points', 15, NULL, 1, 'Week 2 Complete'),
(15, 'item', 0, 1, 1, 'Day 15: Baseball Bat'),  -- item_id 1 = Baseball Bat
(16, 'energy', 30, NULL, 0, NULL),
(17, 'money', 6000, NULL, 0, NULL),
(18, 'xp', 150, NULL, 0, NULL),
(19, 'points', 20, NULL, 0, NULL),
(20, 'bullets', 100, NULL, 1, 'Day 20 Bonus'),
(21, 'money', 8000, NULL, 1, 'Week 3 Complete'),
(22, 'energy', 40, NULL, 0, NULL),
(23, 'points', 25, NULL, 0, NULL),
(24, 'xp', 200, NULL, 0, NULL),
(25, 'money', 10000, NULL, 0, NULL),
(26, 'item', 0, 7, 1, 'Day 26: Leather Jacket'),  -- item_id 7 = Leather Jacket
(27, 'bullets', 150, NULL, 0, NULL),
(28, 'money', 12000, NULL, 1, 'Week 4 Complete'),
(29, 'points', 30, NULL, 0, NULL),
(30, 'energy', 50, NULL, 1, 'Month Complete')
ON DUPLICATE KEY UPDATE reward_type=VALUES(reward_type), reward_value=VALUES(reward_value), reward_item_id=VALUES(reward_item_id), is_milestone=VALUES(is_milestone), milestone_label=VALUES(milestone_label);