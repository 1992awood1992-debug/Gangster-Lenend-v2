# Performance Optimization Plan

## Current State
- **Redis**: Not installed/loaded on server
- **Caching**: Falls back to per-request in-memory only (no cross-request persistence)
- **Database**: MySQL with no connection pooling
- **Assets**: No CDN, no compression headers configured

## Priority Optimizations

### 1. Enable Redis (High Impact)
**Impact**: Cross-request caching, session storage, rate limiting, query cache
**Action**: Install Redis server + PHP Redis extension

```bash
# On Ubuntu/Debian
apt-get install redis-server php-redis

# On Windows (XAMPP)
# Download php_redis.dll for PHP 8.2 from https://pecl.php.net/package/redis
# Add extension=redis to php.ini
```

### 2. Database Indexes (High Impact)
**Impact**: Query performance for common lookups

```sql
-- users table
CREATE INDEX idx_users_last_active ON users(last_active);
CREATE INDEX idx_users_district ON users(district_id);
CREATE INDEX idx_users_crew ON users(crew_id);
CREATE INDEX idx_users_level ON users(level);
CREATE INDEX idx_users_last_login ON users(last_login_date);

-- market_listings
CREATE INDEX idx_market_status ON market_listings(status);
CREATE INDEX idx_market_seller ON market_listings(seller_id);
CREATE INDEX idx_market_type_item ON market_listings(item_type, item_id);

-- user_items
CREATE INDEX idx_user_items_user ON user_items(user_id);
CREATE INDEX idx_user_items_equipped ON user_items(user_id, equipped);

-- missions
CREATE INDEX idx_missions_district ON missions(district_id);

-- criminal_jobs
CREATE INDEX idx_jobs_level ON criminal_jobs(min_level);

-- race_events
CREATE INDEX idx_race_status ON race_events(status);

-- heist_instances
CREATE INDEX idx_heist_crew_status ON heist_instances(crew_id, status);

-- user_properties
CREATE INDEX idx_user_props_user ON user_properties(user_id);
```

### 3. Query Result Caching (High Impact)
**Impact**: Reduce DB load for frequently accessed data

Key pages to cache:
- `play.php` - leaderboard, ticker, district info
- `market.php` - active listings (cached 30s)
- `black-market.php` - user inventory, listings
- `crew.php` - crew data, armory, perks
- `bosses.php` - boss list
- `districts.php` - district list
- `achievements.php` - achievement list
- `leaderboards.php` - cached 60s

### 4. Database Connection Pooling (Medium Impact)
**Impact**: Reduce connection overhead

```php
// In db.php - use persistent connections
$pdo = new PDO($dsn, $user, $pass, [
    PDO::ATTR_PERSISTENT => true,
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
]);
```

### 5. Asset Optimization (Medium Impact)
- Enable gzip/deflate compression in Apache/nginx
- Configure long-term caching for static assets
- Enable HTTP/2 push for critical assets
- Minify CSS/JS (already done via build process?)

### 6. Database Query Optimization (High Impact)
**Key slow queries to optimize:**

1. **Leaderboards** - Cache 60s, add indexes
2. **Market listings** - Add composite indexes, cache 30s
3. **Crew data** - Cache crew data 60s
4. **User profile** - Cache profile data 30s
5. **Market listings** - Add covering indexes

### 7. Monitoring & Profiling (Medium Impact)
- Add slow query log
- Add query timing middleware
- Redis MONITOR for cache hit rates

## Implementation Priority

| Priority | Task | Effort | Impact |
|----------|------|--------|--------|
| 1 | Install Redis + PHP extension | Low | Very High |
| 2 | Add database indexes | Low | High |
| 3 | Enable query caching for top 10 pages | Medium | High |
| 4 | Enable persistent DB connections | Low | Medium |
| 7 | Add slow query logging | Low | Medium |
| 5 | Enable gzip/compression | Low | Medium |
| 6 | Configure asset caching headers | Low | Medium |

## Quick Wins (Can do today)

1. **Add database indexes** - Run SQL directly
2. **Enable persistent DB connections** - One line change in db.php
3. **Add cache headers for static assets** - Apache/nginx config
4. **Enable Redis** - Install extension, update cache.php config

## Redis Installation on Windows (XAMPP)

```powershell
# 1. Download php_redis.dll for PHP 8.2 from https://pecl.php.net/package/redis
# 2. Place in C:\xampp\php\ext\
# 2. Add to php.ini:
extension=redis
```

## Verification Commands

```bash
# Test Redis connection
php -r "echo extension_loaded('redis') ? 'OK' : 'MISSING';"

# Test cache
php -r "
require 'config.php';
require 'includes/db.php';
require 'includes/cache.php';
cache_set('test', 'hello', 60);
echo cache_get('test') ?: 'FAIL';
"

# Check indexes
mysql -u root -e "SHOW INDEX FROM mafia_empire.users;"
mysql -u root -e "SHOW INDEX FROM mafia_empire.market_listings;"
```

## Expected Performance Gains

| Metric | Before | After (est.) |
|--------|--------|--------------|
| Page load (play.php) | ~200ms | ~50ms |
| Market page | ~300ms | ~80ms |
| Leaderboard | ~150ms | ~20ms |
| DB queries/page | 15-30 | 3-8 |
| Cache hit rate | 0% | 85%+ |

## Next Steps
1. Install Redis + PHP extension
2. Run database index migration
3. Update cache.php to use Redis when available
4. Add cache tags to key queries
5. Monitor cache hit rates in admin analytics