<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: deposit / withdraw / transfer
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if (action_on_cooldown($u['id'], 'bank')) {
        $cd = action_on_cooldown($u['id'], 'bank');
        flash('Bank on cooldown. Try again in ' . $cd . '.', 'error');
        redirect('bank.php');
    }
    if ($action === 'deposit') {
        $amt = max(1, (int) ($_POST['amount'] ?? 0));
        if ($amt <= $u['money']) {
            add_money($u['id'], -$amt, 'Bank deposit', false);
            add_money($u['id'], $amt, 'Bank deposit', true);
            flash('Deposited ' . money($amt) . '.', 'success');
        } else {
            flash('Not enough cash.', 'error');
        }
    } elseif ($action === 'withdraw') {
        $amt = max(1, (int) ($_POST['amount'] ?? 0));
        if ($amt <= $u['bank']) {
            add_money($u['id'], -$amt, 'Bank withdrawal', true);
            add_money($u['id'], $amt, 'Bank withdrawal', false);
            flash('Withdrew ' . money($amt) . '.', 'success');
        } else {
            flash('Not enough in bank.', 'error');
        }
    } elseif ($action === 'transfer') {
        $targetName = trim($_POST['target'] ?? '');
        $amt = max(1, (int) ($_POST['amount'] ?? 0));
        if ($amt > $u['money']) {
            flash('Not enough cash.', 'error');
        } else {
            $target = fetch('SELECT id FROM users WHERE username = ?', [$targetName]);
            if (!$target) {
                flash('Player not found.', 'error');
            } elseif ((int) $target['id'] === $u['id']) {
                flash('You cannot transfer to yourself.', 'error');
            } else {
                add_money($u['id'], -$amt, 'Transfer to ' . $targetName, false);
                add_money((int) $target['id'], $amt, 'Transfer from ' . $u['username'], true);
                notify((int) $target['id'], $u['username'] . ' sent you ' . money($amt) . '.', 'bank.php');
                set_action_cooldown($u['id'], 'bank');
                flash('Transferred ' . money($amt) . ' to ' . e($targetName) . '.', 'success');
            }
        }
    }
    redirect('bank.php');
}

$page_title = 'Bank';
require __DIR__ . '/includes/header.php';

$u = current_user();
$transactions = fetch_all('SELECT * FROM bank_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 25', [$u['id']]);
?>
<div class="card">
  <div class="panel-heading">National Bank</div>
  <div class="grid grid-2">
    <div class="stat"><span>Cash on Hand</span><b><?= money($u['money']) ?></b></div>
    <div class="stat"><span>Bank Balance</span><b><?= money($u['bank']) ?></b></div>
  </div>
</div>

<div class="grid grid-2">
  <div class="card">
    <div class="panel-heading">Deposit</div>
    <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="deposit">
      <input type="number" name="amount" min="1" max="<?= (int) $u['money'] ?>" placeholder="Amount" style="width:120px" required>
      <button class="btn btn-green btn-sm" type="submit">Deposit</button>
      <button class="btn btn-sm" type="button" onclick="this.form.amount.value=<?= (int) $u['money'] ?>">All</button>
    </form>
  </div>
  <div class="card">
    <div class="panel-heading">Withdraw</div>
    <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="withdraw">
      <input type="number" name="amount" min="1" max="<?= (int) $u['bank'] ?>" placeholder="Amount" style="width:120px" required>
      <button class="btn btn-gold btn-sm" type="submit">Withdraw</button>
      <button class="btn btn-sm" type="button" onclick="this.form.amount.value=<?= (int) $u['bank'] ?>">All</button>
    </form>
  </div>
</div>

<div class="card">
  <div class="panel-heading">Transfer to Player</div>
  <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="transfer">
    <input type="text" name="target" placeholder="Username" required style="width:180px">
    <input type="number" name="amount" min="1" max="<?= (int) $u['money'] ?>" placeholder="Amount" style="width:120px" required>
    <button class="btn btn-gold btn-sm" type="submit">Send</button>
  </form>
</div>

<div class="card">
  <div class="panel-heading">Recent Transactions</div>
  <div class="table-wrap"><table>
    <tr><th>Type</th><th>Amount</th><th>Reason</th><th>Date</th></tr>
    <?php if (!$transactions): ?>
      <tr><td colspan="4" class="muted">No transactions yet.</td></tr>
    <?php else: foreach ($transactions as $t): ?>
      <tr>
        <td><?= (int) $t['amount'] >= 0 ? '<span style="color:var(--green)">+</span>' : '<span style="color:var(--red)">-</span>' ?></td>
        <td><?= money(abs((int) $t['amount'])) ?></td>
        <td><?= e($t['reason']) ?></td>
        <td><?= date('M j, H:i', strtotime($t['created_at'])) ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </table></div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>