<?php
/**
 * Eye Of The Mafia - Politics / City Hall
 * Mayor elections, city policies, civic engagement.
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/politics.php';

$u = require_login();

// POST handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'nominate') {
        $election = politics_get_current_election();
        if ($election) {
            $result = politics_nominate($u['id'], (int) $election['id'], (string) ($_POST['platform'] ?? ''));
            flash($result['error'] ?? 'Nomination submitted!', $result['ok'] ? 'success' : 'error');
        }
        redirect('politics.php');
    } elseif ($action === 'vote') {
        $election = politics_get_current_election();
        if ($election) {
            $result = politics_vote($u['id'], (int) $election['id'], (int) ($_POST['candidate_id'] ?? 0));
            flash($result['error'] ?? 'Vote cast!', $result['ok'] ? 'success' : 'error');
        }
        redirect('politics.php');
    } elseif ($action === 'enact') {
        $result = politics_enact_policy($u['id'], (int) ($_POST['policy_id'] ?? 0));
        flash($result['error'] ?? 'Policy enacted!', $result['ok'] ? 'success' : 'error');
        redirect('politics.php');
    } elseif ($action === 'revoke') {
        $result = politics_revoke_policy($u['id'], (int) ($_POST['policy_id'] ?? 0));
        flash($result['error'] ?? 'Policy revoked.', $result['ok'] ? 'success' : 'error');
        redirect('politics.php');
    }
}

$page_title = 'City Hall';
require __DIR__ . '/includes/header.php';

$dashboard = politics_get_dashboard($u['id']);
$currentElection = $dashboard['current_election'];
$mayor = $dashboard['mayor'];
$policies = $dashboard['policies'];
$candidates = $dashboard['candidates'];
$userVote = $dashboard['user_vote'];
$userCandidate = $dashboard['user_candidate'];
$canNominate = $dashboard['can_nominate'];

?>

<div class="card">
  <div class="panel-heading">City Hall</div>
  <p class="muted small">Participate in city governance. Run for Mayor, vote on policies, shape the city's future.</p>
</div>

<?php if ($mayor): ?>
<div class="card" style="margin-top:16px; border-left:4px solid var(--gold);">
  <div class="panel-heading">Current Mayor <span class="tag tag-gold"><?= e($mayor['username']) ?></span></div>
  <div class="stat"><span>Term</span><b>Election #<?= (int) $mayor['election_number'] ?></b></div>
  <div class="stat"><span>Term Ends</span><b><?= date('M j, Y', strtotime($mayor['term_end'])) ?></b></div>
</div>
<?php endif; ?>

<?php if ($currentElection): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">
    Election #<?= (int) $currentElection['election_number'] ?> 
    <span class="tag tag-<?= $currentElection['status'] === 'nominations' ? 'gold' : 'legendary' ?>">
      <?= ucfirst($currentElection['status']) ?>
    </span>
  </div>
  
  <?php if ($currentElection['status'] === 'nominations'): ?>
    <p class="muted small">Nominations open until 3 days after start. Need 2+ candidates to proceed to voting.</p>
    
    <?php if ($canNominate && !$userCandidate): ?>
      <form method="post" style="margin-top:16px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="nominate">
        <div class="stat"><span>Platform (optional)</span></div>
        <textarea name="platform" placeholder="Your campaign promises..." style="width:100%;min-height:80px;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin:8px 0"></textarea>
        <button class="btn btn-gold btn-block" type="submit">Run for Mayor</button>
      </form>
    <?php elseif ($userCandidate): ?>
      <div class="tag tag-legendary" style="margin-top:8px;display:inline-block">You are a candidate!</div>
    <?php else: ?>
      <div class="muted small" style="margin-top:8px">Level 20+ required to run for Mayor.</div>
    <?php endif; ?>
  
  <?php elseif ($currentElection['status'] === 'voting'): ?>
    <p class="muted small">Voting open for 3 days. Level 5+ can vote once.</p>
    
    <?php if ($candidates): ?>
      <div style="margin-top:16px">
        <?php foreach ($candidates as $c): 
          $hasVoted = $userVote && (int) $userVote['candidate_id'] === (int) $c['id'];
        ?>
        <div class="card" style="margin-top:8px">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <b><?= e($c['username']) ?></b> (Lv <?= (int) $c['level'] ?>)
              <br><small class="muted">Kills: <?= number_format((int) $c['kills']) ?> | Cash: <?= money((int) $c['money']) ?></small>
              <?php if ($c['platform']): ?>
                <br><small class="muted">"<?= e($c['platform']) ?>"</small>
              <?php endif; ?>
            </div>
            <div>
              <span class="tag tag-gold"><?= number_format((int) $c['votes']) ?> votes</span>
              <?php if (!$userVote && (int) $u['level'] >= 5): ?>
                <form method="post" style="display:inline;margin-left:8px">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="vote">
                  <input type="hidden" name="candidate_id" value="<?= (int) $c['id'] ?>">
                  <button class="btn btn-gold btn-sm" type="submit">Vote</button>
                </form>
              <?php elseif ($hasVoted): ?>
                <span class="tag tag-legendary" style="margin-left:8px">Voted</span>
              <?php elseif ((int) $u['level'] < 5): ?>
                <span class="muted small" style="margin-left:8px">Level 5+ to vote</span>
              <?php else: ?>
                <span class="tag tag-common">Voting closed</span>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  
  <?php else: ?>
    <p class="muted small">Election finished. Check history for results.</p>
  <?php endif; ?>
</div>
<?php else: ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">No Active Election</div>
  <p class="muted">No election currently running. Next cycle starts automatically.</p>
</div>
<?php endif; ?>

<h2 style="margin-top:24px">City Policies</h2>
<div class="card">
  <div class="panel-heading">Active Policies</div>
  <?php if ($policies): ?>
    <div class="table-wrap"><table>
      <tr><th>Policy</th><th>Category</th><th>Effect</th><th>Cost/Day</th><th>Expires</th><th></th></tr>
      <?php foreach ($policies as $p): ?>
      <tr>
        <td>
          <b><?= e($p['name']) ?></b>
          <br><small class="muted"><?= e($p['description']) ?></small>
        </td>
        <td><?= ucfirst($p['category']) ?></td>
        <td><?= e($p['effect_type']) ?>: x<?= (float) $p['effect_value'] ?></td>
        <td><?= money($p['cost_per_day']) ?></td>
        <td><?= $p['expires_at'] ? date('M j', strtotime($p['expires_at'])) : 'Permanent' ?></td>
        <td>
          <?php 
          $mayor = politics_get_mayor();
          $isMayor = $mayor && (int) $mayor['mayor_id'] === $u['id'];
          if ($isMayor): ?>
            <form method="post" style="display:inline" onsubmit="return confirm('Revoke this policy?')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="revoke">
              <input type="hidden" name="policy_id" value="<?= (int) $p['id'] ?>">
              <button class="btn btn-sm btn-danger" type="submit">Revoke</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  <?php else: ?>
    <p class="muted">No active policies.</p>
  <?php endif; ?>
  
  <h4 style="margin-top:16px">Available Policies</h4>
  <?php 
  $available = fetch_all('SELECT * FROM city_policies WHERE is_active = 0 ORDER BY category, name');
  if ($available): ?>
    <div class="table-wrap"><table>
      <tr><th>Policy</th><th>Category</th><th>Effect</th><th>Cost/Day</th><th></th></tr>
      <?php foreach ($available as $p): ?>
      <tr>
        <td>
          <b><?= e($p['name']) ?></b>
          <br><small class="muted"><?= e($p['description']) ?></small>
        </td>
        <td><?= ucfirst($p['category']) ?></td>
        <td><?= e($p['effect_type']) ?>: x<?= (float) $p['effect_value'] ?></td>
        <td><?= money($p['cost_per_day']) ?></td>
        <td>
          <?php 
          $mayor = politics_get_mayor();
          $isMayor = $mayor && (int) $mayor['mayor_id'] === $u['id'];
          if ($isMayor): ?>
            <form method="post" style="display:inline" onsubmit="return confirm('Enact this policy for 7 days?')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="enact">
              <input type="hidden" name="policy_id" value="<?= (int) $p['id'] ?>">
              <button class="btn btn-gold btn-sm" type="submit">Enact (7 days)</button>
            </form>
          <?php else: ?>
            <span class="muted small">Mayor only</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>