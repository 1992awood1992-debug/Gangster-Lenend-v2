<?php
/**
 * Mafia Empire - schema migration runner.
 *
 * Applies any sql/migrations/<N>.sql whose version is greater than the
 * currently stored schema_version and <= SCHEMA_VERSION. Safe to call from
 * both the web bootstrap (includes/init.php) and CLI scripts (includes/cli.php).
 */
require_once __DIR__ . '/db.php';

/** Run automatic schema migrations once per version bump. */
function run_migrations(): void
{
    $current = (int) fetch_one('SELECT v FROM settings WHERE k = ?', ['schema_version'], 0);
    if ($current >= SCHEMA_VERSION) {
        return;
    }
    $dir = __DIR__ . '/../sql/migrations';
    if (is_dir($dir)) {
        $files = glob($dir . '/*.sql') ?: [];
        sort($files, SORT_NATURAL);
        foreach ($files as $file) {
            $ver = (int) basename($file);
            if ($ver > $current && $ver <= SCHEMA_VERSION) {
                $sql = preg_replace('/^--.*$/m', '', file_get_contents($file));
                foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
                    try { db()->exec($stmt); } catch (Throwable $e) { /* tolerate already-applied */ }
                }
                q('INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)', ['schema_version', (string) $ver]);
            }
        }
    }
    q('INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)', ['schema_version', (string) SCHEMA_VERSION]);
}
