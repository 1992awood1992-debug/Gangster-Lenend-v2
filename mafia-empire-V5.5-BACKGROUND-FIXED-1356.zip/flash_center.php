<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'Flash Center';
require __DIR__ . '/includes/header.php';

$uid = (int) $u['id'];
$flashes = db_list_flashes();
$dismissed = fetch_all("SELECT fd.flash_id FROM user_flash_dismissals fd WHERE fd.user_id = ?", [$uid]);
$dismissedIds = array_column($dismissed ?? [], 'flash_id');
?>
<div class="card card-glass">
  <div class="panel-heading">Flash Center</div>
  <p class="muted small">All city announcements and flash messages. Dismiss the ones you've read.</p>
</div>

<div class="card card-glass" style="margin-top:14px">
  <div class="panel-heading">Active Announcements</div>
  <?php $now = date('Y-m-d H:i:s'); $active = array_filter($flashes, function($f) use ($now) {
    return (int)$f['active'] === 1
      && ($f['starts_at'] === null || $f['starts_at'] <= $now)
      && ($f['expires_at'] === null || $f['expires_at'] >= $now);
  }); ?>
  <?php if (!$active): ?>
    <p class="muted">No active announcements.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Title</th><th>Type</th><th>Target</th><th>Expires</th><th>Status</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach ($active as $f): $isDismissed = in_array((int)$f['id'], $dismissedIds); ?>
          <tr class="<?= $isDismissed ? 'opacity-50' : '' ?>">
            <td><b><?= e($f['title']) ?></b></td>
            <td><span class="tag tag-<?= e($f['type']) ?>"><?= ucfirst(e($f['type'])) ?></span></td>
            <td><?= e($f['target_type']) . ($f['target_value'] ? ' #' . (int)$f['target_value'] : '') ?></td>
            <td><?= $f['expires_at'] ? date('M j, Y', strtotime($f['expires_at'])) : 'Never' ?></td>
            <td><?= $isDismissed ? '<span class="tag tag-common">Dismissed</span>' : '<span class="tag tag-gold">Active</span>' ?></td>
            <td>
              <?php if (!$isDismissed): ?>
                <form method="post" action="ajax/dismiss_flash.php" style="display:inline" onsubmit="return confirm('Dismiss this announcement?')">
                  <?= csrf_field() ?>
                  <input type="hidden" name="flash_id" value="<?= (int)$f['id'] ?>">
                  <button class="btn btn-sm" type="submit">Dismiss</button>
                </form>
              <?php else: ?>
                <span class="muted small">—</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="card card-glass" style="margin-top:14px">
  <div class="panel-heading">Dismissed Announcements</div>
  <?php $dismissedFlashes = array_filter($flashes, function($f) use ($dismissedIds) {
    return in_array((int)$f['id'], $dismissedIds);
  }); ?>
  <?php if (!$dismissedFlashes): ?>
    <p class="muted">You haven't dismissed any announcements.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Title</th><th>Type</th><th>Dismissed</th></tr></thead>
        <tbody>
        <?php foreach ($dismissedFlashes as $f): ?>
          <tr>
            <td><b><?= e($f['title']) ?></b></td>
            <td><span class="tag tag-<?= e($f['type']) ?>"><?= ucfirst(e($f['type'])) ?></span></td>
            <td><?= e(date('M j, Y g:i a', strtotime($f['created_at']))) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
