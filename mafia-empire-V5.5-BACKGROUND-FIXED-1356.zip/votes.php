<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: claim vote reward
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $lastVote = fetch('SELECT created_at FROM event_log WHERE user_id = ? AND type = ? ORDER BY created_at DESC LIMIT 1', [$u['id'], 'vote']);
    if ($lastVote && strtotime($lastVote['created_at']) > time() - 12 * 3600) {
        flash('You can claim vote rewards once every 12 hours.', 'error');
    } else {
        add_money($u['id'], 2500, 'Vote reward');
        add_points($u['id'], 5);
        insert('event_log', ['user_id' => $u['id'], 'type' => 'vote', 'text' => 'Claimed vote reward', 'amount' => 2505]);
        flash('Thanks for voting! Received $2,500 and 5 points.', 'success');
    }
    redirect('votes.php');
}

$page_title = 'Vote for Us';
require __DIR__ . '/includes/header.php';

$u = current_user();
$lastVote = fetch('SELECT created_at FROM event_log WHERE user_id = ? AND type = ? ORDER BY created_at DESC LIMIT 1', [$u['id'], 'vote']);
$canClaim = !$lastVote || strtotime($lastVote['created_at']) <= time() - 12 * 3600;
$nextClaim = $lastVote ? date('Y-m-d H:i:s', strtotime($lastVote['created_at']) + 12 * 3600) : null;
?>
<div class="card">
  <div class="panel-heading">Vote for Eye Of The Mafia</div>
  <p class="muted small">Support the game by voting on topsites. Claim a reward of $2,500 + 5 points every 12 hours.</p>
  
  <div class="grid grid-3" style="margin-top:14px">
    <a class="tile" href="#" target="_blank"><span class="ico">🌐</span><b>TopSite 1</b><small>Vote here</small></a>
    <a class="tile" href="#" target="_blank"><span class="ico">🌐</span><b>TopSite 2</b><small>Vote here</small></a>
    <a class="tile" href="#" target="_blank"><span class="ico">🌐</span><b>TopSite 3</b><small>Vote here</small></a>
    <a class="tile" href="#" target="_blank"><span class="ico">🌐</span><b>TopSite 4</b><small>Vote here</small></a>
    <a class="tile" href="#" target="_blank"><span class="ico">🌐</span><b>TopSite 5</b><small>Vote here</small></a>
  </div>
  
  <?php if ($canClaim): ?>
    <form method="post" style="margin-top:18px">
      <?= csrf_field() ?>
      <button class="btn btn-gold btn-block btn-lg" type="submit">Claim Vote Reward ($2,500 + 5 pts)</button>
    </form>
  <?php else: ?>
    <div class="alert alert-info" style="margin-top:18px">Next reward available in: <b><span data-until="<?= e($nextClaim) ?>"></span></b></div>
  <?php endif; ?>
  
  <div style="margin-top:18px;padding-top:18px;border-top:1px solid var(line)">
    <b>How it works:</b>
    <ul style="margin:8px 0;padding-left:20px">
      <li>Click the vote links above (opens in new tab)</li>
      <li>Vote on each topsite for Eye Of The Mafia</li>
      <li>Return here and click "Claim Vote Reward"</li>
      <li>Rewards can be claimed once every 12 hours</li>
    </ul>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>