<?php
/**
 * Mafia Empire - WebSocket Server for Real-time Features
 * Run with: php cron/websocket_server.php
 */

require_once __DIR__ . '/../includes/init.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use React\Socket\SocketServer;
use React\EventLoop\Factory;

/**
 * WebSocket connection manager for real-time features
 */
class MafiaWebSocket implements MessageComponentInterface {
    protected array $connections = []; // resourceId => ConnectionInterface
    protected array $userConnections = []; // userId => resourceId[]
    protected array $channelSubscriptions = []; // channel => resourceId[]
    protected array $userChannels = []; // resourceId => channel[]
    
    public function onOpen(ConnectionInterface $conn) {
        $this->connections[$conn->resourceId] = $conn;
        echo "New connection: {$conn->resourceId}\n";
    }
    
    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        if (!$data) return;
        
        $action = $data['action'] ?? '';
        
        switch ($action) {
            case 'auth':
                $this->handleAuth($from, $data);
                break;
            case 'subscribe':
                $this->handleSubscribe($from, $data);
                break;
            case 'unsubscribe':
                $this->handleUnsubscribe($from, $data);
                break;
            case 'chat_message':
                $this->handleChatMessage($from, $data);
                break;
            case 'typing_start':
                $this->handleTyping($from, $data, true);
                break;
            case 'typing_stop':
                $this->handleTyping($from, $data, false);
                break;
            case 'presence':
                $this->handlePresence($from, $data);
                break;
            case 'reaction':
                $this->handleReaction($from, $data);
                break;
            case 'ping':
                $from->send(json_encode(['type' => 'pong', 'timestamp' => time()]));
                break;
        }
    }
    
    protected function handleAuth(ConnectionInterface $conn, array $data): void {
        $token = $data['token'] ?? '';
        if (!$token) {
            $this->sendError($conn, 'Missing auth token');
            return;
        }
        
        // Validate token against API keys or session
        $user = $this->validateToken($token);
        if (!$user) {
            $this->sendError($conn, 'Invalid auth token');
            return;
        }
        
        // Store user ID with connection
        $conn->userId = $user['id'];
        $conn->username = $user['username'];
        $conn->crewId = $user['crew_id'] ?? null;
        
        // Track user connections
        if (!isset($this->userConnections[$user['id']])) {
            $this->userConnections[$user['id']] = [];
        }
        $this->userConnections[$user['id']][] = $conn->resourceId;
        
        // Auto-subscribe to user's crew channel
        if ($conn->crewId) {
            $this->subscribeToChannel($conn, "crew_{$conn->crewId}");
        }
        
        // Auto-subscribe to user's personal channel
        $this->subscribeToChannel($conn, "user_{$user['id']}");
        
        $this->send($conn, [
            'type' => 'auth_success',
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'crewId' => $conn->crewId
            ],
            'channels' => $this->userChannels[$conn->resourceId] ?? []
        ]);
        
        // Broadcast presence
        $this->broadcastPresence($user['id'], 'online');
    }
    
    protected function validateToken(string $token): ?array {
        // Check API key first
        $key = fetch('SELECT k.*, u.id, u.username, u.crew_id 
            FROM api_keys k JOIN users u ON u.id = k.user_id 
            WHERE k.key_hash = ? AND k.revoked = 0', [hash('sha256', $token)]);
        if ($key) return $key;
        
        // Check session token (for browser connections)
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        if (!empty($_SESSION['uid'])) {
            $user = fetch('SELECT id, username, crew_id FROM users WHERE id = ?', [$_SESSION['uid']]);
            if ($user) return $user;
        }
        
        // Check JWT-like token in database (custom implementation)
        $tokenRecord = fetch('SELECT u.id, u.username, u.crew_id 
            FROM user_tokens t JOIN users u ON u.id = t.user_id 
            WHERE t.token = ? AND t.expires_at > NOW()', [$token]);
        if ($tokenRecord) return $tokenRecord;
        
        return null;
    }
    
    protected function handleSubscribe(ConnectionInterface $conn, array $data): void {
        $channel = $data['channel'] ?? '';
        if (!$channel) {
            $this->sendError($conn, 'Missing channel');
            return;
        }
        
        // Validate channel access
        if (!$this->canSubscribe($conn, $channel)) {
            $this->sendError($conn, 'Cannot subscribe to channel');
            return;
        }
        
        $this->subscribeToChannel($conn, $channel);
        $this->send($conn, ['type' => 'subscribed', 'channel' => $channel]);
    }
    
    protected function canSubscribe(ConnectionInterface $conn, string $channel): bool {
        // Crew channels - only crew members
        if (str_starts_with($channel, 'crew_')) {
            $crewId = (int)str_replace('crew_', '', $channel);
            return $conn->crewId === $crewId;
        }
        
        // User channels - only the user themselves
        if (str_starts_with($channel, 'user_')) {
            $userId = (int)str_replace('user_', '', $channel);
            return ($conn->userId ?? 0) === $userId;
        }
        
        // Public channels
        if (in_array($channel, ['global', 'announcements', 'events'])) {
            return true;
        }
        
        return false;
    }
    
    protected function subscribeToChannel(ConnectionInterface $conn, string $channel): void {
        if (!isset($this->channelSubscriptions[$channel])) {
            $this->channelSubscriptions[$channel] = [];
        }
        if (!in_array($conn->resourceId, $this->channelSubscriptions[$channel])) {
            $this->channelSubscriptions[$channel][] = $conn->resourceId;
        }
        
        if (!isset($this->userChannels[$conn->resourceId])) {
            $this->userChannels[$conn->resourceId] = [];
        }
        if (!in_array($channel, $this->userChannels[$conn->resourceId])) {
            $this->userChannels[$conn->resourceId][] = $channel;
        }
    }
    
    protected function handleUnsubscribe(ConnectionInterface $conn, array $data): void {
        $channel = $data['channel'] ?? '';
        if (!$channel) return;
        
        if (isset($this->channelSubscriptions[$channel])) {
            $this->channelSubscriptions[$channel] = array_filter(
                $this->channelSubscriptions[$channel],
                fn($id) => $id !== $conn->resourceId
            );
        }
        
        if (isset($this->userChannels[$conn->resourceId])) {
            $this->userChannels[$conn->resourceId] = array_filter(
                $this->userChannels[$conn->resourceId],
                fn($c) => $c !== $channel
            );
        }
        
        $this->send($conn, ['type' => 'unsubscribed', 'channel' => $channel]);
    }
    
    protected function handleChatMessage(ConnectionInterface $from, array $data): void {
        $channel = $data['channel'] ?? '';
        $message = trim($data['message'] ?? '');
        $replyTo = $data['reply_to'] ?? null;
        
        if (!$channel || !$message) {
            $this->sendError($from, 'Missing channel or message');
            return;
        }
        
        if (!$this->canSubscribe($from, $channel)) {
            $this->sendError($from, 'Cannot send to this channel');
            return;
        }
        
        // Save message to database
        $messageId = $this->saveMessage($from->userId, $channel, $message, $replyTo);
        if (!$messageId) {
            $this->sendError($from, 'Failed to save message');
            return;
        }
        
        // Broadcast to channel
        $this->broadcastToChannel($channel, [
            'type' => 'chat_message',
            'message' => [
                'id' => $messageId,
                'channel' => $channel,
                'user_id' => $from->userId,
                'username' => $from->username,
                'message' => $message,
                'reply_to' => $replyTo,
                'created_at' => date('Y-m-d H:i:s'),
                'reactions' => []
            ]
        ], $from->resourceId);
        
        // Send confirmation to sender
        $this->send($from, [
            'type' => 'message_sent',
            'message_id' => $messageId,
            'temp_id' => $data['temp_id'] ?? null
        ]);
    }
    
    protected function saveMessage(int $userId, string $channel, string $message, ?int $replyTo): ?int {
        if (str_starts_with($channel, 'crew_')) {
            $crewId = (int)str_replace('crew_', '', $channel);
            $mid = crew_message_send($userId, $crewId, $message);
            return $mid;
        }
        
        // For other channel types, use a generic messages table
        // Implementation depends on database schema
        return insert('chat_messages', [
            'channel' => $channel,
            'user_id' => $userId,
            'message' => $message,
            'reply_to' => $replyTo,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    protected function handleTyping(ConnectionInterface $from, array $data, bool $isTyping): void {
        $channel = $data['channel'] ?? '';
        if (!$channel || !$this->canSubscribe($from, $channel)) return;
        
        $this->broadcastToChannel($channel, [
            'type' => 'typing',
            'user_id' => $from->userId,
            'username' => $from->username,
            'is_typing' => $isTyping
        ], $from->resourceId);
    }
    
    protected function handlePresence(ConnectionInterface $from, array $data): void {
        $status = $data['status'] ?? 'online'; // online, away, busy, offline
        $this->broadcastPresence($from->userId, $status);
    }
    
    protected function handleReaction(ConnectionInterface $from, array $data): void {
        $messageId = $data['message_id'] ?? 0;
        $emoji = $data['emoji'] ?? '';
        $channel = $data['channel'] ?? '';
        
        if (!$messageId || !$emoji || !$channel) return;
        
        // Save reaction to database
        // Implementation depends on schema
        
        // Broadcast reaction
        $this->broadcastToChannel($channel, [
            'type' => 'reaction',
            'message_id' => $messageId,
            'user_id' => $from->userId,
            'username' => $from->username,
            'emoji' => $emoji
        ], $from->resourceId);
    }
    
    protected function broadcastPresence(int $userId, string $status): void {
        $user = fetch('SELECT id, username FROM users WHERE id = ?', [$userId]);
        if (!$user) return;
        
        $payload = [
            'type' => 'presence',
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'status' => $status,
                'last_seen' => $status === 'offline' ? date('Y-m-d H:i:s') : null
            ]
        ];
        
        // Broadcast to all relevant channels (crew, friends, etc.)
        $crew = fetch('SELECT crew_id FROM users WHERE id = ?', [$userId]);
        if ($crew) {
            $this->broadcastToChannel("crew_{$crew['crew_id']}", $payload);
        }
        
        // Broadcast to friends/crew members
        foreach ($this->userConnections[$userId] ?? [] as $connId) {
            if (isset($this->connections[$connId])) {
                $this->send($this->connections[$connId], $payload);
            }
        }
    }
    
    protected function broadcastToChannel(string $channel, array $payload, ?int $excludeConnId = null): void {
        foreach ($this->channelSubscriptions[$channel] ?? [] as $connId) {
            if ($connId === $excludeConnId) continue;
            if (isset($this->connections[$connId])) {
                $this->send($this->connections[$connId], $payload);
            }
        }
    }
    
    protected function send(ConnectionInterface $conn, array $payload): void {
        $conn->send(json_encode($payload));
    }
    
    protected function sendError(ConnectionInterface $conn, string $message): void {
        $this->send($conn, ['type' => 'error', 'message' => $message]);
    }
    
    public function onClose(ConnectionInterface $conn) {
        $userId = $conn->userId ?? null;
        
        // Remove from channel subscriptions
        foreach ($this->userChannels[$conn->resourceId] ?? [] as $channel) {
            if (isset($this->channelSubscriptions[$channel])) {
                $this->channelSubscriptions[$channel] = array_filter(
                    $this->channelSubscriptions[$channel],
                    fn($id) => $id !== $conn->resourceId
                );
            }
        }
        
        // Remove from user connections
        if ($userId && isset($this->userConnections[$userId])) {
            $this->userConnections[$userId] = array_filter(
                $this->userConnections[$userId],
                fn($id) => $id !== $conn->resourceId
            );
            
            // If no more connections for this user, broadcast offline
            if (empty($this->userConnections[$userId])) {
                $this->broadcastPresence($userId, 'offline');
            }
        }
        
        unset($this->connections[$conn->resourceId]);
        unset($this->userChannels[$conn->resourceId]);
        
        echo "Connection closed: {$conn->resourceId}\n";
    }
    
    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "WebSocket error: {$e->getMessage()}\n";
        $conn->close();
    }
}

// Create and run server
$loop = Factory::create();
$socket = new SocketServer('0.0.0.0:8080', $loop);
$server = new IoServer(
    new HttpServer(
        new WsServer(new MafiaWebSocket())
    ),
    $socket,
    $loop
);

echo "WebSocket server started on port 8080\n";
$loop->run();