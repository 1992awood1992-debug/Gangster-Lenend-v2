<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: train
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $gymId = (int) ($_POST['gym_id'] ?? 0);
    $g = fetch('SELECT * FROM gyms WHERE id = ?', [$gymId]);
    if (!$g) {
        flash('Gym not found.', 'error');
    } elseif ((int) $u['level'] < (int) $g['min_level']) {
        flash('Level ' . (int) $g['min_level'] . ' required.', 'error');
    } elseif ((int) $u['money'] < (int) $g['cost']) {
        flash('Not enough cash.', 'error');
    } elseif ((int) $u['energy'] < (int) $g['energy_cost']) {
        flash('Not enough energy.', 'error');
    } elseif (is_hospitalized($u)) {
        flash('You are hospitalized.', 'error');
    } elseif (action_on_cooldown($u['id'], 'gym')) {
        $cd = action_on_cooldown($u['id'], 'gym');
        flash('Gym on cooldown. Try again in ' . $cd . '.', 'error');
    } else {
        $stat = $g['stat'];
        $allowed = ['strength', 'speed', 'defense', 'iq'];
        if (!in_array($stat, $allowed)) { flash('Invalid gym.', 'error'); }
        else {
            $cost = (int) $g['cost'];
            $ecost = (int) $g['energy_cost'];
            $gain = (int) $g['gain'];
            add_money($u['id'], -$cost, 'Gym: ' . $g['name']);
            q('UPDATE users SET energy = energy - ?, `' . $stat . '` = `' . $stat . '` + ? WHERE id = ?', [$ecost, $gain, $u['id']]);
            flash('Trained ' . $gain . ' ' . ucfirst($stat) . ' at ' . e($g['name']) . '.', 'success');
        }
    }
    redirect('gym.php');
}

$page_title = 'The Gym';
require __DIR__ . '/includes/header.php';

$gyms = fetch_all('SELECT * FROM gyms ORDER BY min_level');
$power = combat_power($u['id']);
?>
<div class="card">
  <div class="panel-heading">The Gym</div>
  <p class="muted small">Train your base stats. Each session costs cash and energy.</p>
  <div class="grid grid-4">
    <div class="stat"><span>Strength</span><b><?= (int) $u['strength'] ?></b></div>
    <div class="stat"><span>Speed</span><b><?= (int) $u['speed'] ?></b></div>
    <div class="stat"><span>Defense</span><b><?= (int) $u['defense'] ?></b></div>
    <div class="stat"><span>IQ</span><b><?= (int) $u['iq'] ?></b></div>
  </div>
  <div style="margin-top:8px">
    <div class="stat"><span>Total Attack</span><b><?= $power['attack'] ?></b></div>
    <div class="stat"><span>Total Defense</span><b><?= $power['defense'] ?></b></div>
  </div>
</div>

<div class="grid grid-3">
  <?php foreach ($gyms as $g): $locked = (int) $u['level'] < (int) $g['min_level']; ?>
    <div class="card tile" style="padding:14px">
      <b><?= e($g['name']) ?></b>
      <br><small class="muted">Trains: <b><?= ucfirst($g['stat']) ?></b></small>
      <div class="pill-row" style="margin-top:8px">
        <span class="pill">Cost: <?= money($g['cost']) ?></span>
        <span class="pill">Energy: <?= (int) $g['energy_cost'] ?></span>
        <span class="pill">Gain: +<?= (int) $g['gain'] ?></span>
        <span class="pill">Min Lvl: <?= (int) $g['min_level'] ?></span>
        <?php $cd = action_on_cooldown($u['id'], 'gym'); if ($cd): ?><span class="pill tag-red">CD: <?= e($cd) ?></span><?php endif; ?>
      </div>
      <?php if (!$locked): ?>
        <form method="post" style="margin-top:10px">
          <?= csrf_field() ?>
          <input type="hidden" name="gym_id" value="<?= (int) $g['id'] ?>">
          <button class="btn btn-green btn-block btn-sm" type="submit">Train</button>
        </form>
      <?php else: ?>
        <span class="tag tag-common">Level <?= (int) $g['min_level'] ?> required</span>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>