<?php
/**
 * Mafia Empire - game engine: regeneration ticks, combat, rewards.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

/**
 * Regenerate energy / nerve / health based on elapsed time.
 * Called once per request for the logged-in user.
 */
function tick_user(array &$u): void
{
    $now = time();
    $updates = [];

    // Energy
    if (strtotime($u['last_energy_tick']) <= $now) {
        $elapsed = $now - strtotime($u['last_energy_tick']);
        $gain = intdiv(max(0, $elapsed), ENERGY_TICK_SECONDS);
        if ($gain > 0 && (int) $u['energy'] < (int) $u['energy_max']) {
            $new = min((int) $u['energy_max'], (int) $u['energy'] + $gain);
            $updates['energy'] = $new;
            $updates['last_energy_tick'] = date('Y-m-d H:i:s', strtotime($u['last_energy_tick']) + $gain * ENERGY_TICK_SECONDS);
        }
    }

    // Nerve
    $elapsed = $now - strtotime($u['last_nerve_tick']);
    $gain = intdiv(max(0, $elapsed), NERVE_TICK_SECONDS);
    if ($gain > 0 && (int) $u['nerve'] < (int) $u['nerve_max']) {
        $new = min((int) $u['nerve_max'], (int) $u['nerve'] + $gain);
        $updates['nerve'] = $new;
        $updates['last_nerve_tick'] = date('Y-m-d H:i:s', strtotime($u['last_nerve_tick']) + $gain * NERVE_TICK_SECONDS);
    }

    // Health
    $elapsed = $now - strtotime($u['last_health_tick']);
    $gain = intdiv(max(0, $elapsed), HEALTH_TICK_SECONDS);
    if ($gain > 0 && (int) $u['health'] < (int) $u['health_max']) {
        $new = min((int) $u['health_max'], (int) $u['health'] + $gain);
        $updates['health'] = $new;
        $updates['last_health_tick'] = date('Y-m-d H:i:s', strtotime($u['last_health_tick']) + $gain * HEALTH_TICK_SECONDS);
    }

    if ($updates) {
        update_row('users', $updates, 'id = ?', [$u['id']]);
        foreach ($updates as $k => $v) {
            $u[$k] = $v;
        }
    }
}

/** Hospitalize a player. */
function hospitalize(int $uid, int $seconds, string $reason, array $victim = null): void
{
    // An active Public Healthcare policy speeds up recovery (shorter stay).
    if (function_exists('politics_apply_policy_effect')) {
        $healRate = politics_apply_policy_effect('heal_rate', 1.0);
        if ($healRate > 0.0 && $healRate !== 1.0) {
            $seconds = (int) max(1, round($seconds / $healRate));
        }
    }
    q('UPDATE users SET hospital_until = ?, hospital_reason = ? WHERE id = ?',
        [date('Y-m-d H:i:s', time() + $seconds), $reason, $uid]);
    if ($victim) {
        $loss = (int) floor((int) $victim['money'] * HOSPITAL_PENALTY_RATIO);
        if ($loss > 0) {
            add_money($uid, -$loss, 'Hospital bills');
        }
    }
    notify($uid, 'You were hospitalized: ' . $reason, 'hospital.php');
}

/** Total attack/defense power from base stats + equipped items. */
function combat_power(int $uid): array
{
    $u = fetch('SELECT strength, speed, defense, iq FROM users WHERE id = ?', [$uid]);
    $items = fetch_all('SELECT i.attack, i.defense FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.equipped = 1', [$uid]);
    $atk = (int) ($u['strength'] ?? 0) + (int) ($u['speed'] ?? 0);
    $def = (int) ($u['defense'] ?? 0) + (int) ($u['iq'] ?? 0);
    foreach ($items as $it) {
        $atk += (int) $it['attack'];
        $def += (int) $it['defense'];
    }
    return ['attack' => max(1, $atk), 'defense' => max(1, $def)];
}

/**
 * Resolve a fight between two user rows.
 * Returns an array with the winner id, the log, and damage dealt.
 */
function resolve_fight(array $a, array $b): array
{
    $pa = combat_power((int) $a['id']);
    $pb = combat_power((int) $b['id']);

    $hpA = max(1, (int) $a['health']);
    $hpB = max(1, (int) $b['health']);
    $maxHpA = $hpA;
    $maxHpB = $hpB;
    $log = [];
    $round = 0;

    while ($hpA > 0 && $hpB > 0 && $round < 20) {
        $round++;
        // A attacks B
        $dmg = (int) max(1, round($pa['attack'] * (0.75 + mt_rand(0, 50) / 100) - $pb['defense'] * 0.4));
        $hpB -= $dmg;
        $log[] = "{$a['username']} hits {$b['username']} for $dmg.";
        if ($hpB <= 0) {
            break;
        }
        // B attacks A
        $dmg = (int) max(1, round($pb['attack'] * (0.75 + mt_rand(0, 50) / 100) - $pa['defense'] * 0.4));
        $hpA -= $dmg;
        $log[] = "{$b['username']} hits {$a['username']} for $dmg.";
    }

    return [
        'winner' => $hpB <= 0 ? (int) $a['id'] : (int) $b['id'],
        'log'    => $log,
        'rounds' => $round,
    ];
}

/** Award a kill: XP, cash from victim, stat growth, level check. */
function award_kill(array $attacker, array $victim): array
{
    $steal = (int) min((int) $victim['money'], max(100, (int) floor((int) $victim['money'] * 0.15)));
    add_money((int) $attacker['id'], $steal, 'Kill payout: ' . $victim['username']);
    $xp = 15 + (int) floor((int) $victim['level'] * 6);
    $levels = grant_xp((int) $attacker['id'], $xp);
    q('UPDATE users SET kills = kills + 1, wins = wins + 1 WHERE id = ?', [$attacker['id']]);
    event_track('kills', 1, (int) $attacker['id']);
    q('UPDATE users SET deaths = deaths + 1 WHERE id = ?', [$victim['id']]);
    log_event((int) $attacker['id'], 'kill', 'You killed ' . $victim['username'], $steal);
    notify((int) $victim['id'], $attacker['username'] . ' killed you and took ' . money($steal) . '!', 'hospital.php');
    // Victim loses health and goes to hospital for 5-20 min.
    $secs = mt_rand(300, 1200);
    hospitalize((int) $victim['id'], $secs, 'Killed by ' . $attacker['username'], $victim);
    if (function_exists('webhook_dispatch')) {
        webhook_dispatch((int) $attacker['id'], 'kill', [
            'victim_id'   => (int) $victim['id'],
            'victim'      => (string) $victim['username'],
            'stolen'      => $steal,
            'xp'          => $xp,
            'levels_gained' => $levels,
        ]);
    }
    return ['steal' => $steal, 'xp' => $xp, 'levels' => $levels];
}

/**
 * Track event progress for a metric.
 * Called after actions that should count towards event challenges.
 * Pass $userId for actions performed on behalf of a non-session user.
 */
function event_track(string $metric, int $increment = 1, ?int $userId = null): void
{
    if ($userId === null) {
        if (!is_logged_in()) return;
        $userId = (int) $_SESSION['uid'];
    }
    require_once __DIR__ . '/events.php';
    event_track_metric($userId, $metric, $increment);
}
