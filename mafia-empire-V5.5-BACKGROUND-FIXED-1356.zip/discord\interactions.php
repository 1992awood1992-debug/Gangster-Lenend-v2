<?php
/**
 * Mafia Empire - Discord interactions endpoint.
 *
 * Point a Discord application's "Interactions Endpoint URL" at this file.
 * Discord signs every request with Ed25519; we verify with the sodium
 * extension before trusting anything. Without sodium we answer 503 rather
 * than process an unverified payload.
 *
 * Supported slash commands: /stats, /leaderboard, /serverstat.
 *
 * Configure via environment:
 *   DISCORD_PUBLIC_KEY, DISCORD_APP_ID, DISCORD_ADMIN_IDS
 */
require_once __DIR__ . '/../includes/discord.php';
require_once __DIR__ . '/../includes/migrate.php';

header('Content-Type: application/json; charset=utf-8');

function discord_respond(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    discord_respond(['error' => 'POST required'], 405);
}

$timestamp = (string) ($_SERVER['HTTP_X_SIGNATURE_TIMESTAMP'] ?? '');
$signature = (string) ($_SERVER['HTTP_X_SIGNATURE_ED25519'] ?? '');
$body      = (string) file_get_contents('php://input');

if (!function_exists('sodium_crypto_sign_verify_detached')) {
    discord_respond(['error' => 'Signature verification unavailable: the sodium extension is required.'], 503);
}
if (DISCORD_PUBLIC_KEY === '') {
    discord_respond(['error' => 'Discord is not configured (DISCORD_PUBLIC_KEY is empty).'], 503);
}
if ($timestamp === '' || $signature === '' || !discord_verify_signature($timestamp, $body, $signature)) {
    discord_respond(['error' => 'invalid request signature'], 401);
}

$interaction = json_decode($body, true);
if (!is_array($interaction)) {
    discord_respond(['error' => 'invalid JSON body'], 400);
}

if (!db_installed()) {
    discord_respond(['error' => 'The game database is not installed yet.'], 503);
}
run_migrations();

try {
    discord_respond(discord_handle_interaction($interaction));
} catch (Throwable $e) {
    discord_respond(discord_respond_payload_error($e), 500);
}

/** Convert an unexpected failure into a safe ephemeral reply. */
function discord_respond_payload_error(Throwable $e): array
{
    return ['type' => 4, 'data' => ['content' => 'Something went wrong handling that command.', 'flags' => 64]];
}
