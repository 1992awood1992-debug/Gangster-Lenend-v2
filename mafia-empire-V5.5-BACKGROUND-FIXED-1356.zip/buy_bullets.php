﻿<?php
require_once __DIR__ . "/includes/init.php";
$u = require_login();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    csrf_verify();
    $qty = max(1, (int)($_POST["qty"] ?? 1));
    $cost = $qty * 1000;
    if ((int)$u["money"] < $cost) {
        flash("Not enough cash.", "error");
        redirect("buy_bullets.php");
    }
    add_money($u["id"], -$cost, "Bought bullets");
    add_bullets($u["id"], $qty);
    flash("Purchased bullets.", "success");
    redirect("kill.php");
}
$page_title = "Buy Bullets";
require __DIR__ . "/includes/header.php";
?>
<div class="card"><div class="panel-heading">Buy Bullets</div><p class="muted">1 bullet = $1,000 cash.</p><form method="post"><?= csrf_field() ?><label>Qty <input type="number" name="qty" min="1" max="100" value="10"></label><button class="btn btn-gold">Buy</button></form></div>
<?php require __DIR__ . "/includes/footer.php"; ?>
