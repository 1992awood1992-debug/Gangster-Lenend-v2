<?php
/**
 * Eye Of The Mafia - Hitlist
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/social.php';

$u = require_login();
$page_title = 'Hitlist';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'place') {
        $target = trim($_POST['target'] ?? '');
        $bounty = (int)($_POST['bounty'] ?? 0);
        $targetUser = fetch('SELECT id FROM users WHERE username = ?', [$target]);
        if (!$targetUser) {
            $error = 'Player not found.';
        } elseif ($bounty <= 0) {
            $error = 'Bounty must be greater than 0.';
        } else {
            $hid = hitlist_add($u['id'], (int)$targetUser['id'], $bounty);
            if ($hid) {
                $success = 'Hit placed successfully.';
            } else {
                $error = 'Failed to place hit (insufficient funds or invalid target).';
            }
        }
    } elseif ($action === 'claim') {
        $hid = (int)($_POST['hit_id'] ?? 0);
        if (hitlist_claim($u['id'], $hid)) {
            $success = 'Hit claimed! Bounty awarded.';
        } else {
            $error = 'Failed to claim hit.';
        }
    }
}

$hits = hitlist_get_active();

require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <div class="panel-heading">Hitlist</div>
  <p class="muted small">Place hits on players with bounties. Claim bounties by taking down targets.</p>
</div>

<?php if ($error): ?><div class="alert alert-error" style="margin-top:12px"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success" style="margin-top:12px"><?= e($success) ?></div><?php endif; ?>

<div class="card" style="margin-top:12px">
  <div class="panel-heading">Place a Hit</div>
  <form method="post" action="hitlist.php">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="place">
    <div class="form-row">
      <label>Target Username</label>
      <input type="text" name="target" class="input" required>
    </div>
    <div class="form-row">
      <label>Bounty Amount ($)</label>
      <input type="number" name="bounty" class="input" min="1" required>
    </div>
    <div style="margin-top:10px">
      <button class="btn btn-gold" type="submit">Place Hit</button>
    </div>
  </form>
</div>

<div class="card" style="margin-top:12px">
  <div class="panel-heading">Active Hits</div>
  <?php if (empty($hits)): ?>
    <p class="muted small">No active hits.</p>
  <?php else: ?>
    <div style="overflow-x:auto">
      <table class="table">
        <thead>
          <tr>
            <th>Target</th>
            <th>Bounty</th>
            <th>Placed By</th>
            <th>Expires</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($hits as $h): ?>
            <tr>
              <td><?= e($h['target_name']) ?></td>
              <td><?= money((int)$h['reward_money']) ?></td>
              <td><?= e($h['placer_name']) ?></td>
              <td class="muted small"><?= e($h['expires_at']) ?></td>
              <td>
                <?php if ((int)$h['target_id'] !== $u['id']): ?>
                  <form method="post" action="hitlist.php" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="claim">
                    <input type="hidden" name="hit_id" value="<?= (int)$h['id'] ?>">
                    <button class="btn btn-sm" type="submit">Claim</button>
                  </form>
                <?php else: ?>
                  <span class="muted small">On your head</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
