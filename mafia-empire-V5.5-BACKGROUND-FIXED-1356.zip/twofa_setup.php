<?php
/**
 * Eye Of The Mafia - 2FA Setup & Management
 */

require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/twofa.php';
$u = require_login();

$status = twofa_get_status($u['id']);
$page_title = 'Two-Factor Authentication';
require __DIR__ . '/includes/header.php';

$error = '';
$success = '';
$setupData = null;

// POST: Enable/Disable/Regenerate
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'enable') {
        if ($status['enabled']) {
            $error = '2FA is already enabled.';
        } else {
            $secret = twofa_generate_secret();
            $backupCodes = twofa_generate_backup_codes(10);
            $result = twofa_enable($u['id'], $secret, $backupCodes);
            if (!empty($result['ok'])) {
                $setupData = ['secret' => $secret, 'backup_codes' => $backupCodes];
                $success = '2FA enabled! Save your backup codes securely.';
            } else {
                $error = $result['error'] ?? 'Failed to enable 2FA.';
            }
        }
    } elseif ($action === 'disable') {
        if (!$status['enabled']) {
            $error = '2FA is not enabled.';
        } else {
            // Require 2FA code to disable
            $code = trim($_POST['code'] ?? '');
            $verify = twofa_verify($u['id'], $code);
            if ($verify['ok']) {
                twofa_disable($u['id']);
                $success = '2FA disabled successfully.';
            } else {
                $error = $verify['error'] ?? 'Invalid 2FA code.';
            }
        }
    } elseif ($action === 'regenerate_codes') {
        $result = twofa_regenerate_backup_codes($u['id']);
        if ($result['ok']) {
            $setupData = ['backup_codes' => $result['codes']];
            $success = 'Backup codes regenerated! Save them securely.';
        } else {
            $error = 'Failed to regenerate backup codes.';
        }
    } elseif ($action === 'verify_test') {
        $code = trim($_POST['code'] ?? '');
        $verify = twofa_verify($u['id'], $code);
        if ($verify['ok']) {
            $success = '2FA code verified successfully! Method: ' . $verify['method'];
        } else {
            $error = $verify['error'] ?? 'Invalid code.';
        }
    }
}

?>
<div class="card">
  <div class="panel-heading">Two-Factor Authentication (2FA)</div>
  <p class="muted small">Add an extra layer of security to your account. Use an authenticator app (Google Authenticator, Authy, etc.) to generate codes.</p>
</div>

<?php if ($error): ?>
<div class="card" style="margin-top:16px;border-left:4px solid var(--red);">
  <div class="alert alert-error"><?= e($error) ?></div>
</div>
<?php endif; ?>

<?php if ($success): ?>
<div class="card" style="margin-top:16px;border-left:4px solid var(--green);">
  <div class="alert alert-success"><?= e($success) ?></div>
</div>
<?php endif; ?>

<?php if (!$status['enabled']): ?>
<!-- Enable 2FA -->
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Enable 2FA</div>
  <p class="muted small">Scan the QR code with your authenticator app, then enter the 6-digit code to verify.</p>
  
  <form method="post" style="margin-top:16px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="enable">
    <button class="btn btn-gold btn-block" type="submit">Generate QR Code & Enable 2FA</button>
  </form>
</div>

<?php else: ?>
<!-- 2FA Enabled - Status & Management -->
<div class="card" style="margin-top:16px">
  <div class="panel-heading">2FA Status: <span class="tag tag-gold">ENABLED</span></div>
  <div class="stat"><span>Method</span><b>TOTP (Authenticator App)</b></div>
  <div class="stat"><span>Backup Codes Remaining</span><b><?= $status['recovery_codes_remaining'] ?></b></div>
  <div class="stat"><span>Last Used</span><b><?= $status['last_used'] ? date('M j, Y H:i', strtotime($status['last_used'])) : 'Never' ?></b></div>
</div>

<div class="grid grid-2" style="margin-top:16px">
  <!-- Disable 2FA -->
  <div class="card">
    <div class="panel-heading">Disable 2FA</div>
    <p class="muted small">Enter a 2FA code from your authenticator app or a backup code to disable.</p>
    <form method="post" style="margin-top:12px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="disable">
      <label>2FA Code <input type="text" name="code" maxlength="6" pattern="[0-9]{6}" placeholder="123456" required style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin-bottom:8px"></label>
      <button class="btn btn-danger btn-block" type="submit">Disable 2FA</button>
    </form>
  </div>
  
  <!-- Regenerate Backup Codes -->
  <div class="card">
    <div class="panel-heading">Regenerate Backup Codes</div>
    <p class="muted small">Invalidates all existing backup codes and generates 10 new ones.</    <form method="post" style="margin-top:12px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="regenerate_codes">
      <button class="btn btn-gold btn-block" type="submit" onclick="return confirm('This will invalidate all current backup codes. Continue?')">Regenerate Backup Codes</button>
    </form>
  </div>
  
  <!-- Test 2FA -->
  <div class="card">
    <div class="panel-heading">Test 2FA</div>
    <p class="muted small">Verify your authenticator app is working correctly.</p>
    <form method="post" style="margin-top:12px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="verify_test">
      <label>2FA Code <input type="text" name="code" maxlength="6" pattern="[0-9]{6}" placeholder="123456" required style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin-bottom:8px"></label>
      <button class="btn btn-gold btn-block" type="submit">Test Code</button>
    </form>
  </div>
</div>
<?php endif; ?>

<?php if ($setupData): ?>
<!-- 2FA Setup Complete -->
<div class="card" style="margin-top:16px;border-left:4px solid var(--gold);">
  <div class="panel-heading">2FA Setup Complete!</div>
  <p class="muted small"><strong>IMPORTANT:</strong> Save your backup codes in a safe place. You will not be able to see them again.</p>
  
  <?php if (!empty($setupData['secret'])): ?>
  <div class="card" style="margin-top:16px">
    <div class="panel-heading">Scan QR Code</div>
    <div style="text-align:center;margin:16px 0">
      <?= twofa_get_qr_uri($setupData['secret'], $u['username']) ?>
    </div>
    <div class="stat"><span>Secret Key</span><b style="font-family:monospace;letter-spacing:2px"><?= e(chunk_split($setupData['secret'], 4, ' ')) ?></b></div>
    <p class="muted small">Enter this key manually if you can't scan the QR code.</p>
  </div>
  <?php endif; ?>
  
  <?php if (!empty($setupData['backup_codes'])): ?>
  <div class="card" style="margin-top:16px">
    <div class="panel-heading">Backup Codes (<span class="tag tag-gold">10 codes</span>)</div>
    <p class="muted small">Each code can be used once. Store these securely!</p>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px;margin-top:12px">
      <?php foreach ($setupData['backup_codes'] as $code): ?>
        <div class="stat" style="background:var(--bg);border:1px solid var(--line);text-align:center;font-family:monospace;font-size:.9rem">
          <code><?= e($code) ?></code>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
  
  <div style="margin-top:16px">
    <form method="post" style="display:inline">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="verify_test">
      <label>Test your 2FA code: <input type="text" name="code" maxlength="6" pattern="[0-9]{6}" placeholder="123456" required style="width:100px;padding:6px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin-right:8px"></label>
      <button class="btn btn-gold btn-sm" type="submit">Verify</button>
    </form>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>