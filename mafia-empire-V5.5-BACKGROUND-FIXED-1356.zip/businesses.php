﻿<?php
require_once __DIR__ . "/includes/init.php";
$u = require_login();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  csrf_verify();
  $action = $_POST["action"] ?? "";
  $bid = (int)($_POST["business_id"] ?? 0);
  $biz = fetch("SELECT * FROM businesses WHERE id=? AND active=1", [$bid]);
  if (!$biz) { flash("Business not found.", "error"); redirect("businesses.php"); }
  if ($action === "buy") {
    if ((int)$u["level"] < (int)$biz["min_level"]) { flash("Level too low.", "error"); redirect("businesses.php"); }
    if ((int)$u["money"] < (int)$biz["cost"]) { flash("Not enough cash.", "error"); redirect("businesses.php"); }
    $own = fetch("SELECT id FROM user_businesses WHERE user_id=? AND business_id=?", [$u["id"], $bid]);
    if ($own) { flash("Already owned.", "error"); redirect("businesses.php"); }
    add_money($u["id"], -(int)$biz["cost"], "Bought " . $biz["name"]);
    insert("user_businesses", ["user_id"=>$u["id"],"business_id"=>$bid,"level"=>1,"income_total"=>0,"active"=>1]);
    flash("Purchased " . e($biz["name"]) . ".", "success");
  } elseif ($action === "collect") {
    $ub = fetch("SELECT ub.*, b.* FROM user_businesses ub JOIN businesses b ON b.id=ub.business_id WHERE ub.id=? AND ub.user_id=? AND ub.active=1", [$bid, $u["id"]]);
    if (!$ub) { flash("Not owned.", "error"); redirect("businesses.php"); }
    $last = $ub["last_collect"] ? strtotime($ub["last_collect"]) : time();
    $hours = min(168, (time() - $last) / 3600);
    $gain = (int) floor((int)$ub["income_per_hour"] * $hours * (int)$ub["level"]);
    if ($gain <= 0) { flash("Nothing to collect yet.", "error"); redirect("businesses.php"); }
    add_money($u["id"], $gain, "Business income: " . e($ub["name"]));
    q("UPDATE user_businesses SET income_total=income_total+?, last_collect=? WHERE id=?", [$gain, date("Y-m-d H:i:s"), (int)$ub["id"]]);
    flash("Collected " . money($gain) . " from " . e($ub["name"]) . ".", "success");
  } elseif ($action === "upgrade") {
    $ub = fetch("SELECT ub.*, b.* FROM user_businesses ub JOIN businesses b ON b.id=ub.business_id WHERE ub.id=? AND ub.user_id=? AND ub.active=1", [$bid, $u["id"]]);
    if (!$ub) { flash("Not owned.", "error"); redirect("businesses.php"); }
    $cost = (int) floor((int)$biz["cost"] * 0.3 * (int)$ub["level"]);
    if ((int)$u["money"] < $cost) { flash("Not enough cash to upgrade.", "error"); redirect("businesses.php"); }
    add_money($u["id"], -$cost, "Upgrade " . $biz["name"]);
    q("UPDATE user_businesses SET level=level+1 WHERE id=?", [(int)$ub["id"]]);
    flash("Upgraded " . e($biz["name"]) . " to level " . ((int)$ub["level"] + 1) . ".", "success");
  }
  redirect("businesses.php");
}
$page_title = "Businesses";
require __DIR__ . "/includes/header.php";
$u = current_user();
$all = fetch_all("SELECT * FROM businesses WHERE active=1 ORDER BY sort_order ASC, id ASC");
$owned = fetch_all("SELECT ub.*, b.* FROM user_businesses ub JOIN businesses b ON b.id=ub.business_id WHERE ub.user_id=? AND ub.active=1 ORDER BY ub.id ASC", [$u["id"]]);
$ownedIds = array_column($owned ?? [], "business_id");
?>
<div class="card"><div class="panel-heading">Businesses</div><p class="muted small">Buy businesses to generate passive income. Collect hourly.</p></div>
<div class="grid grid-3" style="margin-top:14px">
<?php foreach ($all as $b): $ownedBiz = $ownedIds ? array_filter($owned, fn($o)=>(int)$o["business_id"]===(int)$b["id"]) : []; $ub = reset($ownedBiz) ?: null; $canAfford = (int)$u["money"] >= (int)$b["cost"]; $levelOk = (int)$u["level"] >= (int)$b["min_level"]; ?>
  <div class="card" style="border-top:3px solid #c4a484">
    <div class="panel-heading" style="border:none;padding:0;margin-bottom:8px"><?= e($b["name"]) ?></div>
    <div class="pill-row" style="margin:6px 0">
      <span class="pill"><?= ucfirst(e($b["type"])) ?></span>
      <span class="pill">Lvl <?= (int)$b["min_level"] ?>+</span>
      <span class="pill"><?= money((int)$b["income_per_hour"]) ?>/hr</span>
    </div>
    <p class="muted small"><?= e($b["description"]) ?></p>
    <?php if ($ub): ?>
      <div class="stat"><span>Level</span><b><?= (int)$ub["level"] ?></b></div>
      <div class="stat"><span>Income/hr</span><b><?= money((int)$b["income_per_hour"] * (int)$ub["level"]) ?></b></div>
      <div class="stat"><span>Total Earned</span><b><?= money((int)$ub["income_total"]) ?></b></div>
      <form method="post" style="display:inline-block;margin:4px 4px 0 0"><?= csrf_field() ?><input type="hidden" name="action" value="collect"><input type="hidden" name="business_id" value="<?= (int)$b["id"] ?>"><button class="btn btn-gold btn-sm" type="submit">Collect</button></form>
      <form method="post" style="display:inline-block;margin:4px 0 0 0"><?= csrf_field() ?><input type="hidden" name="action" value="upgrade"><input type="hidden" name="business_id" value="<?= (int)$b["id"] ?>"><button class="btn btn-sm" type="submit">Upgrade (<?= money((int)floor((int)$b["cost"] * 0.3 * (int)$ub["level"])) ?>)</button></form>
    <?php elseif ($canAfford && $levelOk): ?>
      <div class="stat"><span>Cost</span><b><?= money((int)$b["cost"]) ?></b></div>
      <form method="post" style="margin-top:8px"><?= csrf_field() ?><input type="hidden" name="action" value="buy"><input type="hidden" name="business_id" value="<?= (int)$b["id"] ?>"><button class="btn btn-gold btn-sm" type="submit">Buy Business</button></form>
    <?php elseif (!$canAfford): ?>
      <span class="tag tag-common">Too expensive: <?= money((int)$b["cost"]) ?></span>
    <?php else: ?>
      <span class="tag tag-common">Unlocks at level <?= (int)$b["min_level"] ?></span>
    <?php endif; ?>
  </div>
<?php endforeach; ?>
</div>
<?php require __DIR__ . "/includes/footer.php"; ?>
