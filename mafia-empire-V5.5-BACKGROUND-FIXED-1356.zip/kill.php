<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: attack
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $targetId = (int) ($_POST['target_id'] ?? 0);
    $target = fetch('SELECT * FROM users WHERE id = ? AND is_banned = 0', [$targetId]);
    if (!$target) {
        flash('Target not found.', 'error');
    } elseif ($targetId === $u['id']) {
        flash('You cannot attack yourself.', 'error');
    } elseif (is_hospitalized($u)) {
        flash('You are hospitalized.', 'error');
    } elseif (is_hospitalized($target)) {
        flash('Target is already hospitalized.', 'error');
    } elseif (action_on_cooldown($u['id'], 'kill')) {
        $cd = action_on_cooldown($u['id'], 'kill');
        flash('Kill on cooldown. Try again in ' . $cd . '.', 'error');
    } elseif ((int) $u['health'] <= 0) {
        flash('You have no health.', 'error');
    } elseif ((int)$u['bullets'] < 1) {
        flash('You need bullets to kill. Buy them from the Bullet Factory or Black Market.', 'error');
    } elseif (abs((int) $u['level'] - (int) $target['level']) > 5) {
        flash('Level difference too great (max 5).', 'error');
    } else {
        // Consume 1 bullet for kill
        add_bullets($u['id'], -1);
        // Simple attack cooldown check via a custom notification or session
        // For simplicity, just allow but limit via hospital
        $result = resolve_fight($u, $target);
        if ((int) $result['winner'] === $u['id']) {
            $award = award_kill($u, $target);
            insert('kill_log', ['attacker_id' => $u['id'], 'victim_id' => $targetId, 'stolen' => $award['steal']]);
            score_war_kill($u['id'], $targetId);
            tournament_report_metric('kill_race', (int) $u['id'], 1);
            analytics_track('kill', $u['id'], ['victim' => $targetId, 'stolen' => (int) $award['steal']]);
            set_action_cooldown($u['id'], 'kill');
            flash('You won! ' . implode('<br>', $result['log']) . '<br>Stole ' . money($award['steal']) . ' and gained ' . $award['xp'] . ' XP.', 'success');
            heat_add($u['id'], 1, 'kill');
            $_SESSION['fw_fight_result'] = [
                'won' => true,
                'victim' => $target['username'],
                'steal' => (int) $award['steal'],
                'xp' => (int) $award['xp'],
                'log' => $result['log'],
            ];
        } else {
            // Attacker lost
            $hpLoss = mt_rand(15, 35);
            $newHealth = max(0, (int) $u['health'] - $hpLoss);
            q('UPDATE users SET health = ?, losses = losses + 1 WHERE id = ?', [$newHealth, $u['id']]);
            q('UPDATE users SET wins = wins + 1 WHERE id = ?', [$targetId]);
            if ($newHealth <= 0) {
                hospitalize($u['id'], 600, 'Killed by ' . $target['username']);
            }
            insert('kill_log', ['attacker_id' => $targetId, 'victim_id' => $u['id'], 'stolen' => 0]);
            score_war_kill($targetId, $u['id']);
            tournament_report_metric('kill_race', $targetId, 1);
            analytics_track('lost_fight', $u['id'], ['vs' => $targetId]);
            flash('You lost. ' . implode('<br>', $result['log']) . '<br>Lost ' . $hpLoss . ' health.', 'error');
            $_SESSION['fw_fight_result'] = [
                'won' => false,
                'victim' => $target['username'],
                'hpLoss' => $hpLoss,
                'log' => $result['log'],
            ];
        }
    }
    redirect('kill.php');
}

$page_title = 'Kill';
require __DIR__ . '/includes/header.php';

$u = current_user();
$power = combat_power($u['id']);

// Find targets
$targets = fetch_all('SELECT * FROM users WHERE id != ? AND is_banned = 0 AND health > 0 AND (hospital_until IS NULL OR hospital_until <= NOW()) AND level BETWEEN ? AND ? ORDER BY RAND() LIMIT 20', [$u['id'], max(1, (int) $u['level'] - 5), (int) $u['level'] + 5]);
$killLog = fetch_all('SELECT kl.*, ua.username AS attacker, uv.username AS victim FROM kill_log kl JOIN users ua ON ua.id = kl.attacker_id JOIN users uv ON uv.id = kl.victim_id WHERE kl.attacker_id = ? OR kl.victim_id = ? ORDER BY kl.created_at DESC LIMIT 20', [$u['id'], $u['id']]);
?>
<div class="card">
  <div class="panel-heading">Kill</div>
  <p class="muted small">Attack players within 5 levels of you. Winner takes cash and XP.</p>
  <div class="grid grid-4">
    <div class="stat"><span>Health</span><b><?= (int) $u['health'] ?> / <?= (int) $u['health_max'] ?></b></div>
    <div class="stat"><span>Attack</span><b><?= $power['attack'] ?></b></div>
    <div class="stat"><span>Defense</span><b><?= $power['defense'] ?></b></div>
    <div class="stat"><span>Kills / Deaths</span><b><?= (int) $u['kills'] ?> / <?= (int) $u['deaths'] ?></b></div>
    <?php $heat = heat_info($u['id']); ?>
    <div class="stat"><span>Heat</span><b style="color:<?= e($heat['color']) ?>"><?= $heat['icon'] ?> <?= e($heat['name']) ?></b></div>
    <div class="stat"><span>Earnings</span><b><?= (int) round($heat['multiplier'] * 100) ?>%</b></div>
  </div>
</div>

<?php
$fight = $_SESSION['fw_fight_result'] ?? null;
unset($_SESSION['fw_fight_result']);
if ($fight):
?>
<div class="card alert alert-<?= $fight['won'] ? 'success' : 'error' ?>" style="margin-top:14px;position:relative;overflow:hidden">
  <div class="panel-heading" style="border-bottom:none;background:transparent;box-shadow:none;padding-bottom:8px">
    <span style="font-size:1.5rem;margin-right:8px"><?= $fight['won'] ? '&#128128;' : '&#128557;' ?></span>
    <b><?= $fight['won'] ? 'VICTORY' : 'DEFEAT' ?></b>
    <span style="float:right;font-size:.85rem;color:var(--muted)">vs <?= e($fight['victim']) ?></span>
  </div>
  <div style="display:flex;gap:16px;flex-wrap:wrap">
    <?php if ($fight['won']): ?>
      <div style="flex:1;min-width:140px">
        <div class="stat"><span>Stole</span><b class="text-gold"><?= money((int) $fight['steal']) ?></b></div>
        <div class="stat"><span>XP Gained</span><b><?= (int) $fight['xp'] ?></b></div>
      </div>
    <?php else: ?>
      <div style="flex:1;min-width:140px">
        <div class="stat"><span>Health Lost</span><b class="text-red"><?= (int) $fight['hpLoss'] ?></b></div>
      </div>
    <?php endif; ?>
    <div style="flex:1;min-width:200px">
      <small class="muted">Combat log:</small>
      <div style="max-height:120px;overflow-y:auto;font-family:monospace;font-size:.8rem;background:rgba(0,0,0,.4);padding:8px;border-radius:6px;border:1px solid var(--line)">
        <?php foreach ($fight['log'] as $line): ?><div style="margin:2px 0"><?= e($line) ?></div><?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<h2>Targets</h2>
<?php if (!$targets): ?>
  <div class="card">
    <div class="table-wrap"><table class="target-table">
      <thead>
        <tr><th>Player</th><th>Level</th><th>Health</th><th>District</th><th class="text-right">Action</th></tr>
      </thead>
      <tbody>
        <?php foreach ($targets as $t): $tPower = combat_power($t['id']); ?>
          <tr class="target-row">
            <td class="target-name"><b><?= e($t['username']) ?></b></td>
            <td class="target-level"><?= (int) $t['level'] ?></td>
            <td class="target-health"><?= (int) $t['health'] ?> / <?= (int) $t['health_max'] ?></td>
            <td class="target-district"><?= e(fetch('SELECT name FROM districts WHERE id = ?', [$t['district_id']])['name'] ?? '—') ?></td>
            <td class="target-action">
              <form method="post" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="target_id" value="<?= (int) $t['id'] ?>">
                <button class="btn btn-danger btn-sm" type="submit" data-confirm="Attack <?= e($t['username']) ?>?">Attack</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
<?php endif; ?>

<h2 style="margin-top:24px">Recent Kill Log</h2>
<div class="card">
  <?php if (!$killLog): ?>
    <p class="muted">No kills yet.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Attacker</th><th>Victim</th><th>Stolen</th><th>Date</th></tr>
      <?php foreach ($killLog as $k): ?>
        <tr>
          <td><?= e($k['attacker']) ?></td>
          <td><?= e($k['victim']) ?></td>
          <td><?= money($k['stolen']) ?></td>
          <td><?= date('M j, H:i', strtotime($k['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>