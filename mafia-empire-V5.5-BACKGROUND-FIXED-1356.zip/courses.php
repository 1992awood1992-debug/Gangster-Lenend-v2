﻿<?php
require_once __DIR__ . "/includes/init.php";
require_once __DIR__ . "/includes/courses.php";
$u = require_login();
$page_title = "Advanced Courses";
require __DIR__ . "/includes/header.php";
$u = current_user();
$groups = course_get_groups();
$active = course_get_user_active($u["id"]);
$completed = course_get_user_completed($u["id"]);
?>
<div class="card"><div class="panel-heading">Advanced Courses</div><p class="muted small">Level up learning! Enrol onto courses to unlock passive effects and one-time rewards.</p></div>
<?php if ($active): ?><div class="card"><div class="panel-heading">In Progress</div><div class="stat"><span><b><?= e($active["course_name"]) ?></b></span><span class="muted">Ends <?= e($active["ends_at"]) ?></span></div></div><?php endif; ?>
<?php foreach ($groups as $g): ?><h2><?= e($g["name"]) ?></h2><div class="grid grid-3"><?php foreach (course_get_by_group($g["id"]) as $c): $can = course_can_enrol($u["id"], $c); ?><div class="card" style="border-top:3px solid <?= e($c["color"] ?? "#c4a484") ?>"><div class="panel-heading" style="border:none;padding:0;margin-bottom:8px"><?= e($c["name"]) ?></div><p class="muted small"><?= e($c["description"]) ?></p><div class="pill-row" style="margin:10px 0"><span class="pill">Duration: <?= (int)$c["duration_hours"] ?>h</span></div><?php if ($can["ok"] && !$active): ?><form method="post" action="courses_action.php"><?= csrf_field() ?><input type="hidden" name="action" value="enrol"><input type="hidden" name="course_id" value="<?= (int)$c["id"] ?>"><button class="btn btn-gold btn-sm">Enrol</button></form><?php elseif ($active): ?><span class="tag tag-common">Already Enrolled</span><?php else: ?><span class="tag tag-red"><?= e($can["error"]) ?></span><?php endif; ?></div><?php endforeach; ?></div><?php endforeach; ?>
<?php require __DIR__ . "/includes/footer.php"; ?>
