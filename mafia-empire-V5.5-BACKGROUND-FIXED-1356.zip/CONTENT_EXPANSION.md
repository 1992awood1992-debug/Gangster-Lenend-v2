# Content Expansion

## Already Done

### Phase 2 (base content)
- [x] 50+ missions across districts
- [x] 10+ bosses with unique mechanics
- [x] 30+ items (weapons, armor, vehicles, special)
- [x] 15+ drugs with varied effects
- [x] 20+ abilities (active + passive)
- [x] 50+ achievements with chains
- [x] 20+ stickers with sets/collections

### Phase 16 (migration 8 — idempotent content drop)
- [x] 2 new districts: **Chinatown** (unlock 30) and **The Suburbs** (unlock 45)
- [x] 8 new missions (4 per new district) with scaling rewards/risk
- [x] 2 new bosses: Madame Lin Zhao, Senator Charles Vandermeer
- [x] 4 new criminal jobs (Smuggle Contraband → Broker a Hostile Takeover)
- [x] 4 legendary items: Golden Tommy Gun, Dragon Breath Shotgun,
      Dragon Scale Vest, Armored Limousine

Live totals after the drop: **6 districts, 74 missions, 16 bosses, 24 criminal
jobs, 49 items**.

## How It Was Added

`schema.sql` creates the tables; `includes/seed.php` seeds the base content on a
fresh install; `sql/migrations/8.sql` adds the expansion. Every insert in the
migration is guarded with `WHERE NOT EXISTS (...)`, so it is safe to re-run and
won't duplicate on fresh installs (which replay migrations up to `SCHEMA_VERSION`).

## Ideas For Future Drops

1. **Missions**
- Storyline missions with multiple stages
- Faction-specific mission chains
- Hardcore difficulty missions with better rewards

2. **Items**
- Set items (bonuses when wearing multiple)
- Craftable items / crafting bench
- Tradeable cosmetics

3. **Bosses**
- World bosses (scheduled events) — reuses the events system
- Multi-stage / raid bosses (crew-based)
- Seasonal bosses

4. **Achievements**
- Secret achievements
- Community goals
- Progressive milestones (level 100, etc.)

5. **Drugs / Abilities**
- Temporary buffs/debuffs, synergy effects, tiered progression

6. **Locations**
- Hidden locations, safehouses with benefits

## Files

- `includes/seed.php` — base content (fresh installs)
- `sql/migrations/8.sql` — content expansion (existing + fresh installs)
- `sql/schema.sql` — table definitions
