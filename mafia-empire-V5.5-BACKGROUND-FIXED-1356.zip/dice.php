<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (($_POST['action'] ?? '') === 'roll') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        $bet = $_POST['bet'] ?? 'over7';
        if (!in_array($bet, ['under7', 'over7', 'seven', 'doubles'], true)) { $bet = 'over7'; }
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('dice.php'); }
        add_money($u['id'], -$stake, 'Dice bet');
        $d1 = mt_rand(1, 6);
        $d2 = mt_rand(1, 6);
        $total = $d1 + $d2;
        $doubles = $d1 === $d2;
        $win = false;
        $mult = 0;
        if ($bet === 'under7' && $total < 7) { $win = true; $mult = 1; }
        elseif ($bet === 'over7' && $total > 7) { $win = true; $mult = 1; }
        elseif ($bet === 'seven' && $total === 7) { $win = true; $mult = 4; }
        elseif ($bet === 'doubles' && $doubles) { $win = true; $mult = 5; }
        $payout = $win ? $stake * ($mult + 1) : 0;
        if ($payout > 0) { add_money($u['id'], $payout, 'Dice win'); event_track('casino_won', (int) $payout); }
        $names = ['under7' => 'Under 7', 'over7' => 'Over 7', 'seven' => 'Exactly 7', 'doubles' => 'Doubles'];
        insert('casino_bets', ['user_id' => $u['id'], 'game' => 'dice', 'stake' => $stake, 'payout' => $payout, 'detail' => $names[$bet] . ' roll ' . $d1 . '+' . $d2 . '=' . $total]);
        $result = ['d1' => $d1, 'd2' => $d2, 'total' => $total, 'doubles' => $doubles, 'bet' => $bet, 'win' => $win, 'payout' => $payout, 'stake' => $stake];
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'dice', json_encode(['last' => $result])]);
    }
    redirect('dice.php');
}

$saved = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'dice']);
$saved = $saved ? json_decode($saved['state'], true) : null;
$result = $saved['last'] ?? null;

$page_title = 'Dice';
require __DIR__ . '/includes/header.php';
$u = current_user();
function die_pip(int $v): string
{
    return '<span class="die">' . $v . '</span>';
}
?>
<style>
.die{display:inline-flex;align-items:center;justify-content:center;width:56px;height:56px;background:#f5ead0;color:#2a2320;border:1px solid #8a7448;border-radius:10px;font-size:1.6rem;font-weight:800;margin:0 6px;box-shadow:0 3px 5px rgba(0,0,0,.4)}
</style>
<div class="card">
  <div class="panel-heading">Dice</div>
  <p class="muted small">Roll two dice. Under 7 and Over 7 pay 1:1, exact seven pays 4:1, doubles pay 5:1. Seven is the house number — tread carefully.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<div class="card">
  <form method="post" style="max-width:400px;display:grid;gap:10px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="roll">
    <div>
      <label>Bet on</label>
      <select name="bet" class="full">
        <option value="under7">Under 7 — pays 1:1</option>
        <option value="over7" selected>Over 7 — pays 1:1</option>
        <option value="seven">Exactly 7 — pays 4:1</option>
        <option value="doubles">Doubles — pays 5:1</option>
      </select>
    </div>
    <label>Wager (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="50" required></label>
    <button class="btn btn-gold" type="submit">Roll Dice</button>
  </form>
</div>

<?php if ($result): ?>
<div class="card">
  <div class="panel-heading"><?= $result['win'] ? '<span class="text-green">WIN — +' . money($result['payout'] - $result['stake']) . '</span>' : '<span class="text-danger">LOSE</span>' ?> · Rolled <?= $result['d1'] ?> + <?= $result['d2'] ?> = <b><?= $result['total'] ?></b><?= $result['doubles'] ? ' (doubles!)' : '' ?></div>
  <div style="padding:8px 0">
    <?= die_pip($result['d1']) ?><?= die_pip($result['d2']) ?>
  </div>
  <p class="muted small">Bet: <?= e(['under7' => 'Under 7', 'over7' => 'Over 7', 'seven' => 'Exactly 7', 'doubles' => 'Doubles'][$result['bet']]) ?> · Returned <?= money($result['payout']) ?></p>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>