# Eye Of The Mafia - Mafia Empire Game

A PHP 8.2 + MariaDB mafia-themed empire game with dark red mafia theme, Halloween boot screen, events system, social features, and comprehensive testing.

## Quick Start

### Local (XAMPP/Apache)
1. Clone/copy to `C:\xampp\htdocs\mafia-empire` or web root
2. Create database `mafia_empire` in MySQL
3. Visit `http://localhost/mafia-empire/install.php`
4. Complete installation

### Docker
```bash
cp .env.example .env
docker compose up -d --build
docker compose exec php php cron/run.php migrate
# Visit http://localhost:8080
```

## Key Features

- Dark red mafia theme with Halloween boot screen
- Events system (daily/weekly/seasonal) with challenge tracking
- Social features (trading, crew chat, hitlist, bounties)
- REST API with API keys, webhooks, rate limiting
- Web Push notifications (VAPID)
- Discord bot integration
- PWA with service worker
- Crew wars & territory control
- Casino games (Blackjack, Baccarat, Keno, Crash, Dice, Slots)
- Admin panel
- Comprehensive PHPUnit test suite (125 tests, 434 assertions)

## Requirements

- PHP 8.2+
- MariaDB 10.11+ / MySQL 8+
- Extensions: `pdo_mysql`, `mbstring`, `gd`, `openssl` (optional for VAPID)

## Testing

```bash
# Local with PHAR
$env:OPENSSL_CONF="C:\xampp\php\extras\openssl\openssl.cnf"
C:\xampp\php\php.exe C:\Users\ash\AppData\Local\Temp\opencode\phpunit.phar --no-coverage
```

See [docs/TESTING.md](docs/TESTING.md) for full testing guide.

## Documentation

- [API Documentation](docs/API.md) - REST API, Web Push, Events
- [Deployment Guide](docs/DEPLOY.md) - Production deployment
- [Testing Guide](docs/TESTING.md) - Running tests
- [Push Checklist](PUSH.md) - Pre-deployment checklist
- [Roadmap](ROADMAP.md) - Project roadmap

## Scripts

- `scripts/backup.sh` / `scripts/backup.bat` - Database backup
- `scripts/restore.sh` / `scripts/restore.bat` - Database restore
- `scripts/ssl-init.sh` - Let's Encrypt SSL setup
- `cron/run.php` - Task dispatcher (tick/daily/weekly/migrate/vapid)

## License

See LICENSE file if present.