<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

function achievement_progress(array $u, string $metric): int
{
    switch ($metric) {
        case 'money':     return (int) $u['money'] + (int) $u['bank'];
        case 'level':     return (int) $u['level'];
        case 'wins':      return (int) $u['wins'];
        case 'losses':    return (int) $u['losses'];
        case 'deaths':    return (int) $u['deaths'];
        case 'points':    return (int) $u['points'];
        case 'bullets':   return (int) $u['bullets'];
        case 'strength':  return (int) $u['strength'];
        case 'speed':     return (int) $u['speed'];
        case 'defense':   return (int) $u['defense'];
        case 'iq':        return (int) $u['iq'];
        case 'daily_streak': return (int) $u['daily_streak'];
        default:          return (int) ($u[$metric] ?? 0);
    }
}

// Auto-unlock on page load
$allAch = fetch_all('SELECT * FROM achievements ORDER BY id');
$unlockedIds = array_column(fetch_all('SELECT achievement_id FROM user_achievements WHERE user_id = ?', [$u['id']]), 'achievement_id');
$newUnlocks = [];

foreach ($allAch as $a) {
    if (in_array($a['id'], $unlockedIds)) continue;
    $progress = achievement_progress($u, $a['metric']);
    
    if ($progress >= $a['target']) {
        insert('user_achievements', ['user_id' => $u['id'], 'achievement_id' => $a['id']]);
        add_points($u['id'], (int) $a['reward_points']);
        notify($u['id'], 'Achievement unlocked: ' . $a['name'] . '! Earned ' . (int) $a['reward_points'] . ' points.', 'achievements.php');
        if (function_exists('webhook_dispatch')) {
            webhook_dispatch((int) $u['id'], 'achievement', [
                'id'     => (int) $a['id'],
                'name'   => (string) $a['name'],
                'points' => (int) $a['reward_points'],
            ]);
        }
        $newUnlocks[] = $a;
    }
}

$page_title = 'Achievements';
require __DIR__ . '/includes/header.php';

if ($newUnlocks) {
    foreach ($newUnlocks as $na) {
        echo '<div class="alert alert-gold flash">🏆 Achievement Unlocked: <b>' . e($na['name']) . '</b> — ' . e($na['description']) . ' (+' . (int) $na['reward_points'] . ' pts)</div>';
    }
}

$u = current_user(); // refresh
$unlockedIds = array_column(fetch_all('SELECT achievement_id FROM user_achievements WHERE user_id = ?', [$u['id']]), 'achievement_id');
?>
<div class="card">
  <div class="panel-heading">Achievements</div>
  <div class="stat"><span>Unlocked</span><b><?= count($unlockedIds) ?> / <?= count($allAch) ?></b></div>
  <div class="stat"><span>Total Points from Achievements</span><b><?= (int) fetch_one('SELECT COALESCE(SUM(reward_points),0) FROM user_achievements ua JOIN achievements a ON a.id = ua.achievement_id WHERE ua.user_id = ?', [$u['id']], 0) ?></b></div>
</div>

<div class="card">
  <div class="grid grid-3">
    <?php foreach ($allAch as $a):
      $unlocked = in_array($a['id'], $unlockedIds);
      $progress = achievement_progress($u, $a['metric']);
      $pct = $a['target'] > 0 ? min(100, round($progress / $a['target'] * 100)) : 100;
    ?>
      <div class="tile" style="opacity:<?= $unlocked ? 1 : 0.55 ?>">
        <b><?= e($a['name']) ?></b>
        <br><small class="muted"><?= e($a['description']) ?></small>
        <div class="progress" style="margin:8px 0"><i style="width:<?= $pct ?>%"></i></div>
        <small class="muted"><?= $unlocked ? '✓ Unlocked' : "$progress / {$a['target']} ({$pct}%)" ?></small>
        <div style="margin-top:6px"><span class="tag tag-legendary">+<?= (int) $a['reward_points'] ?> pts</span></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>