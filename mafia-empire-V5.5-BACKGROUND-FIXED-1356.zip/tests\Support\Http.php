<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Support;

/**
 * Tiny cookie-aware HTTP client built on cURL, used by the functional suite.
 *
 * Redirects are followed manually (rather than with CURLOPT_FOLLOWLOCATION)
 * so that cookies set on a redirect hop are applied to the next request. The
 * app regenerates its session id on login, so auto-following with a static
 * cookie header would silently drop the new session.
 *
 * The functional suite drives a *running* copy of the app (the PHP built-in
 * server in CI, or XAMPP locally). Tests are skipped unless the APP_URL
 * environment variable points at that server.
 */
final class Http
{
    private string $baseUrl;

    /** @var array<string,string> name => value */
    private array $cookies = [];

    public function __construct(string $baseUrl)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    public static function configured(): bool
    {
        return (string) (getenv('APP_URL') ?: '') !== '';
    }

    public static function baseUrl(): string
    {
        return rtrim((string) (getenv('APP_URL') ?: ''), '/');
    }

    /** @return array{0:int,1:string,2:array<string,string>} */
    public function get(string $path, array $headers = []): array
    {
        return $this->request('GET', $path, [], $headers);
    }

    /** @return array{0:int,1:string,2:array<string,string>} */
    public function post(string $path, array $fields, array $headers = []): array
    {
        return $this->request('POST', $path, $fields, $headers);
    }

    public function csrfFrom(string $path): string
    {
        [, $body] = $this->get($path);
        if (preg_match('/name="csrf"\s+value="([^"]+)"/', $body, $m)) {
            return $m[1];
        }
        return '';
    }

    /** @return array{0:int,1:string,2:array<string,string>} */
    public function login(string $username, string $password): array
    {
        $csrf = $this->csrfFrom('/login.php');
        return $this->post('/login.php', [
            'csrf'     => $csrf,
            'username' => $username,
            'password' => $password,
        ]);
    }

    /**
     * Perform a request, following up to five redirects by hand.
     *
     * @return array{0:int,1:string,2:array<string,string>}
     */
    private function request(string $method, string $path, array $fields = [], array $headers = []): array
    {
        $method = strtoupper($method);
        $url    = $this->baseUrl . '/' . ltrim($path, '/');

        $extraHeaders = [];
        foreach ($headers as $name => $value) {
            $extraHeaders[] = $name . ': ' . $value;
        }

        for ($hop = 0; $hop < 5; $hop++) {
            $responseHeaders = [];
            $ch              = curl_init();

            curl_setopt_array($ch, [
                CURLOPT_URL            => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_HEADERFUNCTION => function ($c, $line) use (&$responseHeaders) {
                    if (str_contains($line, ':')) {
                        [$k, $v] = explode(':', $line, 2);
                        $k = strtolower(trim($k));
                        $v = trim($v);
                        if ($k === 'set-cookie') {
                            $pair = explode(';', $v, 2)[0];
                            if (str_contains($pair, '=')) {
                                [$cn, $cv] = explode('=', $pair, 2);
                                $this->cookies[trim($cn)] = $cv;
                            }
                        }
                        $responseHeaders[$k] = $v;
                    }
                    return strlen($line);
                },
            ]);

            if ($extraHeaders) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $extraHeaders);
            }

            if ($this->cookies) {
                $pairs = [];
                foreach ($this->cookies as $name => $value) {
                    $pairs[] = $name . '=' . $value;
                }
                curl_setopt($ch, CURLOPT_COOKIE, implode('; ', $pairs));
            }

            if ($method === 'POST') {
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
            }

            $body   = curl_exec($ch);
            $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            curl_close($ch);

            $location = $responseHeaders['location'] ?? '';
            if ($status >= 300 && $status < 400 && $location !== '') {
                $url = $location;
                // Browsers turn a POST into a GET on 301/302/303.
                if ($method === 'POST' && in_array($status, [301, 302, 303], true)) {
                    $method = 'GET';
                    $fields = [];
                    $extraHeaders = [];
                }
                continue;
            }

            return [$status, (string) $body, $responseHeaders];
        }

        return [$status ?? 0, (string) ($body ?? ''), $responseHeaders ?? []];
    }
}
