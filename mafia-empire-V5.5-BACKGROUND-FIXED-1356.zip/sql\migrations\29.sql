-- Enhanced Referral Program
-- Add referral tracking to users
ALTER TABLE users ADD COLUMN IF NOT EXISTS referrer_id INT UNSIGNED NULL AFTER referral_code;
ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_earnings BIGINT NOT NULL DEFAULT 0 AFTER referrer_id;

-- Enhanced referral rewards with tier/milestone tracking
CREATE TABLE IF NOT EXISTS referral_rewards_v2 (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  referrer_id INT UNSIGNED NOT NULL,
  referred_id INT UNSIGNED NOT NULL,
  milestone VARCHAR(40) NOT NULL, -- 'signup', 'level_5', 'level_10', 'level_20', 'level_50', 'first_purchase', 'reach_rank'
  reward_type VARCHAR(20) NOT NULL, -- 'points', 'cash', 'bullets', 'item', 'commission'
  reward_amount BIGINT NOT NULL DEFAULT 0,
  reward_item_id INT DEFAULT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending', -- 'pending', 'claimed', 'expired'
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  claimed_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_referrer (referrer_id),
  KEY idx_referred (referred_id),
  UNIQUE KEY uniq_milestone (referrer_id, referred_id, milestone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Referral commission settings
INSERT IGNORE INTO settings (k, v) VALUES
('referral_commission_pct', '5'),           -- % of referred user's cash earnings
('referral_commission_cap', '100000'),      -- max commission per referral
('referral_signup_bonus', '50'),            -- points on signup
('referral_level_5_bonus', '100'),          -- points at level 5
('referral_level_10_bonus', '250'),         -- points at level 10
('referral_level_20_bonus', '500'),         -- points at level 20
('referral_level_50_bonus', '1000'),        -- points at level 50
('referral_first_purchase_bonus', '200'),   -- points when referred buys points
('referral_reach_rank_bonus', '500');       -- points when referred reaches rank