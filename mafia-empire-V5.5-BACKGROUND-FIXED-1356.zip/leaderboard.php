<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'Leaderboard';
require __DIR__ . '/includes/header.php';

$type = $_GET['t'] ?? 'level';
$orders = [
  'level'  => ['ORDER BY level DESC, xp DESC', 'Level', 'Level', '#'],
  'money'  => ['ORDER BY money DESC, bank DESC', 'Richest', 'Cash', '$'],
  'kills'  => ['ORDER BY kills DESC, deaths ASC', 'Most Wanted', 'Kills', '&#128299;'],
  'respect'=> ['ORDER BY net_respect DESC', 'Most Respected', 'Respect', '&#128161;'],
];
$ord = $orders[$type] ?? $orders['level'];

$top = fetch_all("SELECT username, level, xp, money, bank, kills, deaths, net_respect, avatar FROM users WHERE is_banned=0 {$ord[0]} LIMIT 50");
$youPos = null;
$allIds = fetch_all("SELECT username FROM users WHERE is_banned=0 {$ord[0]}");
foreach ($allIds as $i => $row) {
  if ($row['username'] === $u['username']) { $youPos = $i + 1; break; }
}
?>
<div class="card card-glass">
  <div class="panel-heading" style="justify-content:space-between;align-items:center">
    <span>Leaderboard &#127942;</span>
    <div style="display:flex;gap:6px">
      <a class="btn btn-sm <?= $type==='level'?'btn-gold':'btn' ?>" href="?t=level">Level</a>
      <a class="btn btn-sm <?= $type==='money'?'btn-gold':'btn' ?>" href="?t=money">Richest</a>
      <a class="btn btn-sm <?= $type==='kills'?'btn-gold':'btn' ?>" href="?t=kills">Kills</a>
      <a class="btn btn-sm <?= $type==='respect'?'btn-gold':'btn' ?>" href="?t=respect">Respect</a>
    </div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Player</th><th><?= $ord[1] ?></th><th>Level</th><th>Respect</th><th>Status</th></tr></thead>
      <tbody>
      <?php $rank=0; foreach ($top as $t): $rank++; $isYou = $t['username'] === $u['username']; ?>
        <tr class="<?= $isYou ? 'fw-gold-glow' : '' ?>">
          <td><b style="color:<?= $rank<=3?'var(--gold-bright)':'var(--muted)' ?>"><?= $rank ?></b></td>
          <td>
            <img src="<?= e($t['avatar']) ?>" alt="" style="width:28px;height:28px;border-radius:50%;border:1px solid var(--line);margin-right:8px" onerror="this.src='<?= e(url('assets/img/avatar-default.svg')) ?>'">
            <b><?= e($t['username']) ?></b><?= $isYou ? ' <span class="tag tag-gold">YOU</span>' : '' ?>
          </td>
          <td><?= $ord[2] === 'Cash' ? money((int)($t['money'] + $t['bank'])) : (in_array($ord[2], ['Kills','Respect']) ? (($ord[2] === 'Kills') ? (int) $t['kills'] : (int) $t['net_respect']) : 0) ?></td>
          <td><?= (int) $t['level'] ?></td>
          <td><span class="tag tag-<?= (int)$t['net_respect'] >= 10000 ? 'legendary' : ((int)$t['net_respect'] >= 5000 ? 'epic' : 'common') ?>"><?= (int) $t['net_respect'] ?></span></td>
          <td><?= $isYou ? '<span style="color:var(--gold-bright)">Online</span>' : '<span class="muted">—</span>' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($youPos && $youPos > 50): ?>
  <div class="card card-glass" style="margin-top:14px;text-align:center">
    <div class="stat"><span>Your Rank</span><b style="color:var(--gold-bright)">#<?= $youPos ?></b></div>
    <p class="muted small">Keep climbing to reach the top 50.</p>
  </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
