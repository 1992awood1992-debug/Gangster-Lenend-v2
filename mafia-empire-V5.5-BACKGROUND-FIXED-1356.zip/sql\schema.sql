-- Mafia Empire - database schema
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(32) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  avatar VARCHAR(255) NOT NULL DEFAULT 'assets/img/avatar-default.svg',
  bio VARCHAR(255) NOT NULL DEFAULT '',
  level INT NOT NULL DEFAULT 1,
  xp BIGINT NOT NULL DEFAULT 0,
  money BIGINT NOT NULL DEFAULT 2500,
  bank BIGINT NOT NULL DEFAULT 0,
  points INT NOT NULL DEFAULT 10,
  bullets INT NOT NULL DEFAULT 50,
  energy INT NOT NULL DEFAULT 100,
  energy_max INT NOT NULL DEFAULT 100,
  nerve INT NOT NULL DEFAULT 50,
  nerve_max INT NOT NULL DEFAULT 50,
  health INT NOT NULL DEFAULT 100,
  health_max INT NOT NULL DEFAULT 100,
  strength INT NOT NULL DEFAULT 5,
  speed INT NOT NULL DEFAULT 5,
  defense INT NOT NULL DEFAULT 5,
  iq INT NOT NULL DEFAULT 5,
  kills INT NOT NULL DEFAULT 0,
  deaths INT NOT NULL DEFAULT 0,
  wins INT NOT NULL DEFAULT 0,
  losses INT NOT NULL DEFAULT 0,
  missions_done INT NOT NULL DEFAULT 0,
  crimes_done INT NOT NULL DEFAULT 0,
  boss_kills INT NOT NULL DEFAULT 0,
  district_id INT NOT NULL DEFAULT 1,
  crew_id INT UNSIGNED NULL DEFAULT NULL,
  crew_rank VARCHAR(20) NOT NULL DEFAULT '',
  hospital_until DATETIME NULL DEFAULT NULL,
  hospital_reason VARCHAR(190) NOT NULL DEFAULT '',
  jail_until DATETIME NULL DEFAULT NULL,
  last_energy_tick DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_nerve_tick DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_health_tick DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_daily DATE NULL DEFAULT NULL,
  daily_streak INT NOT NULL DEFAULT 0,
  referral_code VARCHAR(16) NOT NULL,
  referred_by INT UNSIGNED NULL DEFAULT NULL,
  is_admin TINYINT(1) NOT NULL DEFAULT 0,
  is_banned TINYINT(1) NOT NULL DEFAULT 0,
  last_active DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_username (username),
  UNIQUE KEY uniq_email (email),
  UNIQUE KEY uniq_refcode (referral_code),
  KEY idx_crew (crew_id),
  KEY idx_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ranks (
  id INT NOT NULL AUTO_INCREMENT,
  level INT NOT NULL,
  name VARCHAR(60) NOT NULL,
  PRIMARY KEY (id),
  KEY idx_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS districts (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(80) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  unlock_level INT NOT NULL DEFAULT 1,
  income_bonus INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS settings (
  k VARCHAR(60) NOT NULL,
  v TEXT,
  PRIMARY KEY (k)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  text VARCHAR(255) NOT NULL,
  link VARCHAR(190) NOT NULL DEFAULT '',
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS event_log (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  type VARCHAR(30) NOT NULL,
  text VARCHAR(255) NOT NULL,
  amount BIGINT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS bank_transactions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  amount BIGINT NOT NULL,
  reason VARCHAR(120) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Missions -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS missions (
  id INT NOT NULL AUTO_INCREMENT,
  district_id INT NOT NULL DEFAULT 1,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  energy_cost INT NOT NULL DEFAULT 5,
  min_level INT NOT NULL DEFAULT 1,
  reward_money BIGINT NOT NULL DEFAULT 0,
  reward_xp INT NOT NULL DEFAULT 0,
  reward_points INT NOT NULL DEFAULT 0,
  risk INT NOT NULL DEFAULT 20,
  story TEXT,
  PRIMARY KEY (id),
  KEY idx_district (district_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_missions (
  user_id INT UNSIGNED NOT NULL,
  mission_id INT NOT NULL,
  times_done INT NOT NULL DEFAULT 0,
  completed TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, mission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Gym ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gyms (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(80) NOT NULL,
  stat VARCHAR(20) NOT NULL,
  cost BIGINT NOT NULL DEFAULT 100,
  gain INT NOT NULL DEFAULT 1,
  energy_cost INT NOT NULL DEFAULT 5,
  min_level INT NOT NULL DEFAULT 1,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bosses ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bosses (
  id INT NOT NULL AUTO_INCREMENT,
  district_id INT NOT NULL DEFAULT 1,
  name VARCHAR(100) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  hp INT NOT NULL DEFAULT 100,
  attack INT NOT NULL DEFAULT 10,
  defense INT NOT NULL DEFAULT 5,
  min_level INT NOT NULL DEFAULT 1,
  energy_cost INT NOT NULL DEFAULT 20,
  reward_money BIGINT NOT NULL DEFAULT 0,
  reward_xp INT NOT NULL DEFAULT 0,
  reward_points INT NOT NULL DEFAULT 0,
  reward_item_id INT NULL DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS boss_fights (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  boss_id INT NOT NULL,
  boss_hp INT NOT NULL,
  turns INT NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id, active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Criminal jobs ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS criminal_jobs (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  nerve_cost INT NOT NULL DEFAULT 2,
  min_level INT NOT NULL DEFAULT 1,
  payout_min BIGINT NOT NULL DEFAULT 50,
  payout_max BIGINT NOT NULL DEFAULT 150,
  xp INT NOT NULL DEFAULT 5,
  fail_risk INT NOT NULL DEFAULT 20,
  cooldown INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_job_cooldowns (
  user_id INT UNSIGNED NOT NULL,
  job_id INT NOT NULL,
  ready_at DATETIME NOT NULL,
  PRIMARY KEY (user_id, job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Abilities -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS abilities (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(80) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  cost_points INT NOT NULL DEFAULT 5,
  min_level INT NOT NULL DEFAULT 1,
  effect_type VARCHAR(30) NOT NULL DEFAULT 'passive',
  effect_value INT NOT NULL DEFAULT 0,
  stat VARCHAR(20) NOT NULL DEFAULT '',
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_abilities (
  user_id INT UNSIGNED NOT NULL,
  ability_id INT NOT NULL,
  learned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, ability_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Drugs -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS drugs (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  buy_price BIGINT NOT NULL DEFAULT 100,
  sell_price BIGINT NOT NULL DEFAULT 150,
  min_level INT NOT NULL DEFAULT 1,
  effect_stat VARCHAR(20) NOT NULL DEFAULT '',
  effect_amount INT NOT NULL DEFAULT 0,
  od_risk INT NOT NULL DEFAULT 10,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_drugs (
  user_id INT UNSIGNED NOT NULL,
  drug_id INT NOT NULL,
  qty INT NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, drug_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Items / equipment -----------------------------------------------------
CREATE TABLE IF NOT EXISTS items (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  type ENUM('weapon','armor','vehicle','misc') NOT NULL DEFAULT 'misc',
  attack INT NOT NULL DEFAULT 0,
  defense INT NOT NULL DEFAULT 0,
  cost BIGINT NOT NULL DEFAULT 0,
  min_level INT NOT NULL DEFAULT 1,
  rarity VARCHAR(20) NOT NULL DEFAULT 'common',
  PRIMARY KEY (id),
  KEY idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_items (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  item_id INT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  equipped TINYINT(1) NOT NULL DEFAULT 0,
  acquired_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Black market / escrow -------------------------------------------------
CREATE TABLE IF NOT EXISTS market_listings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  seller_id INT UNSIGNED NOT NULL,
  item_type ENUM('item','drug','vehicle','property','blueprint') NOT NULL DEFAULT 'item',
  item_id INT UNSIGNED NOT NULL,
  qty INT UNSIGNED NOT NULL DEFAULT 1,
  buyout_price BIGINT UNSIGNED NULL,
  bid_price BIGINT UNSIGNED NOT NULL DEFAULT 0,
  min_bid BIGINT UNSIGNED NOT NULL DEFAULT 0,
  auction_end DATETIME NULL,
  -- Legacy column retained for backward compatibility.
  price BIGINT NULL DEFAULT NULL,
  status ENUM('active','sold','cancelled','expired') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sold_at DATETIME NULL,
  buyer_id INT UNSIGNED NULL,
  final_price BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_status (status),
  KEY idx_seller (seller_id),
  KEY idx_buyer (buyer_id),
  KEY idx_type (item_type, item_id),
  KEY idx_end (auction_end)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS market_bids (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  listing_id BIGINT UNSIGNED NOT NULL,
  bidder_id INT UNSIGNED NOT NULL,
  amount BIGINT UNSIGNED NOT NULL,
  status ENUM('active','outbid','won','cancelled') NOT NULL DEFAULT 'active',
  placed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_listing (listing_id),
  KEY idx_bidder (bidder_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS escrow (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  creator_id INT UNSIGNED NOT NULL,
  counterparty_id INT UNSIGNED NULL DEFAULT NULL,
  amount BIGINT NOT NULL DEFAULT 0,
  terms VARCHAR(255) NOT NULL DEFAULT '',
  status ENUM('open','accepted','released','cancelled') NOT NULL DEFAULT 'open',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bullet factory --------------------------------------------------------
CREATE TABLE IF NOT EXISTS bullet_factories (
  district_id INT NOT NULL,
  owner_id INT UNSIGNED NULL DEFAULT NULL,
  price BIGINT NOT NULL DEFAULT 5000000,
  production INT NOT NULL DEFAULT 50,
  last_collect DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (district_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Points store ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS points_store (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  cost_points INT NOT NULL DEFAULT 1,
  kind VARCHAR(20) NOT NULL DEFAULT 'money',
  amount BIGINT NOT NULL DEFAULT 0,
  item_id INT NULL DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Lottery ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lottery_draws (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  draw_date DATE NOT NULL,
  winning_number INT NULL DEFAULT NULL,
  pot BIGINT NOT NULL DEFAULT 0,
  status ENUM('open','drawn') NOT NULL DEFAULT 'open',
  PRIMARY KEY (id),
  UNIQUE KEY uniq_date (draw_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lottery_tickets (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  draw_id INT UNSIGNED NOT NULL,
  number INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_draw (draw_id, number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Casino logs -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS casino_bets (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  game VARCHAR(20) NOT NULL,
  stake BIGINT NOT NULL,
  payout BIGINT NOT NULL DEFAULT 0,
  detail VARCHAR(190) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_game (game)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS casino_state (
  user_id INT UNSIGNED NOT NULL,
  game VARCHAR(20) NOT NULL,
  state TEXT,
  PRIMARY KEY (user_id, game)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crews -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS crews (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL,
  tag VARCHAR(6) NOT NULL,
  leader_id INT UNSIGNED NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  money BIGINT NOT NULL DEFAULT 0,
  bullets INT NOT NULL DEFAULT 0,
  points INT NOT NULL DEFAULT 0,
  level INT NOT NULL DEFAULT 1,
  xp INT NOT NULL DEFAULT 0,
  xp_spent INT NOT NULL DEFAULT 0,
  wars_won INT NOT NULL DEFAULT 0,
  wars_lost INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crew_members (
  user_id INT UNSIGNED NOT NULL,
  crew_id INT UNSIGNED NOT NULL,
  rank VARCHAR(20) NOT NULL DEFAULT 'Recruit',
  joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  KEY idx_crew (crew_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crew_invites (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  crew_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  invited_by INT UNSIGNED NOT NULL,
  status ENUM('pending','accepted','declined') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Territory zones (districts split into turf)
CREATE TABLE IF NOT EXISTS zones (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  district_id INT UNSIGNED NOT NULL,
  name VARCHAR(80) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  base_income INT NOT NULL DEFAULT 500,
  min_crew_level INT NOT NULL DEFAULT 1,
  px INT NOT NULL DEFAULT 0,
  py INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_zone_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS zone_control (
  zone_id INT UNSIGNED NOT NULL,
  crew_id INT UNSIGNED NOT NULL,
  level INT NOT NULL DEFAULT 1,
  captured_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_collect DATETIME NULL,
  PRIMARY KEY (zone_id),
  KEY idx_crew (crew_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crew_wars (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  attacker_id INT UNSIGNED NOT NULL,
  defender_id INT UNSIGNED NOT NULL,
  status ENUM('declared','active','finished') NOT NULL DEFAULT 'declared',
  attacker_score INT NOT NULL DEFAULT 0,
  defender_score INT NOT NULL DEFAULT 0,
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ends_at DATETIME NOT NULL,
  winner_id INT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_attacker (attacker_id),
  KEY idx_defender (defender_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crew_armory (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  crew_id INT UNSIGNED NOT NULL,
  item_id INT UNSIGNED NOT NULL,
  qty INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_crew_item (crew_id, item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crew_perks (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(60) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  cost_xp INT NOT NULL DEFAULT 0,
  requires_code VARCHAR(40) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_perk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crew_unlocked_perks (
  crew_id INT UNSIGNED NOT NULL,
  perk_code VARCHAR(40) NOT NULL,
  unlocked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (crew_id, perk_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crew_diplomacy (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  crew_a INT UNSIGNED NOT NULL,
  crew_b INT UNSIGNED NOT NULL,
  type ENUM('alliance','nap') NOT NULL,
  status ENUM('pending','active','broken') NOT NULL DEFAULT 'pending',
  declared_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_pair (crew_a, crew_b)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS zone_raids (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  zone_id INT UNSIGNED NOT NULL,
  crew_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_zone_crew (zone_id, crew_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Forum -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS forum_categories (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(80) NOT NULL,
  description VARCHAR(190) NOT NULL DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS forum_threads (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id INT NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(190) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_post DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  views INT NOT NULL DEFAULT 0,
  locked TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_cat (category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS forum_posts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  thread_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_thread (thread_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Rewards / achievements / collectibles ---------------------------------
CREATE TABLE IF NOT EXISTS achievements (
  id INT NOT NULL AUTO_INCREMENT,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(100) NOT NULL,
  description VARCHAR(190) NOT NULL DEFAULT '',
  reward_points INT NOT NULL DEFAULT 5,
  target INT NOT NULL DEFAULT 1,
  metric VARCHAR(30) NOT NULL DEFAULT 'kills',
  PRIMARY KEY (id),
  UNIQUE KEY uniq_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_achievements (
  user_id INT UNSIGNED NOT NULL,
  achievement_id INT NOT NULL,
  unlocked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, achievement_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stickers (
  id INT NOT NULL AUTO_INCREMENT,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(80) NOT NULL,
  rarity VARCHAR(20) NOT NULL DEFAULT 'common',
  PRIMARY KEY (id),
  UNIQUE KEY uniq_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_stickers (
  user_id INT UNSIGNED NOT NULL,
  sticker_id INT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  PRIMARY KEY (user_id, sticker_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS scratch_cards (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  prize VARCHAR(120) NOT NULL,
  amount BIGINT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS referral_rewards (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  referrer_id INT UNSIGNED NOT NULL,
  referred_id INT UNSIGNED NOT NULL,
  points INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Info & help -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS updates (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(190) NOT NULL,
  body TEXT NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS update_votes (
  user_id INT UNSIGNED NOT NULL,
  update_id INT UNSIGNED NOT NULL,
  value TINYINT NOT NULL DEFAULT 1,
  PRIMARY KEY (user_id, update_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS update_comments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  update_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS suggestions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(190) NOT NULL,
  body TEXT NOT NULL,
  status ENUM('new','open','locked','implemented','rejected') NOT NULL DEFAULT 'new',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS suggestion_votes (
  user_id INT UNSIGNED NOT NULL,
  suggestion_id INT UNSIGNED NOT NULL,
  value TINYINT NOT NULL DEFAULT 1,
  PRIMARY KEY (user_id, suggestion_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS suggestion_comments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  suggestion_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS support_tickets (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  subject VARCHAR(190) NOT NULL,
  body TEXT NOT NULL,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS support_replies (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  ticket_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  body TEXT NOT NULL,
  is_staff TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS faqs (
  id INT NOT NULL AUTO_INCREMENT,
  question VARCHAR(190) NOT NULL,
  answer TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kill_log (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  attacker_id INT UNSIGNED NOT NULL,
  victim_id INT UNSIGNED NOT NULL,
  stolen BIGINT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_attacker (attacker_id),
  KEY idx_victim (victim_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Phase 7: REST API, Webhooks & Integrations -----------------------------
CREATE TABLE IF NOT EXISTS api_keys (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  name VARCHAR(60) NOT NULL DEFAULT 'API key',
  prefix VARCHAR(16) NOT NULL,
  key_hash CHAR(64) NOT NULL,
  scopes VARCHAR(120) NOT NULL DEFAULT 'read',
  rate_limit INT NOT NULL DEFAULT 60,
  request_count BIGINT NOT NULL DEFAULT 0,
  last_used_at DATETIME NULL DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_prefix (prefix),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS api_rate (
  key_id INT UNSIGNED NOT NULL,
  window_start INT UNSIGNED NOT NULL,
  hits INT NOT NULL DEFAULT 0,
  PRIMARY KEY (key_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS api_requests (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  key_id INT UNSIGNED NULL DEFAULT NULL,
  user_id INT UNSIGNED NULL DEFAULT NULL,
  method VARCHAR(8) NOT NULL,
  path VARCHAR(190) NOT NULL,
  status INT NOT NULL DEFAULT 200,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_key (key_id),
  KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS webhooks (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  url VARCHAR(500) NOT NULL,
  secret VARCHAR(64) NOT NULL,
  events VARCHAR(190) NOT NULL DEFAULT '*',
  active TINYINT(1) NOT NULL DEFAULT 1,
  failures INT NOT NULL DEFAULT 0,
  last_status INT NULL DEFAULT NULL,
  last_called_at DATETIME NULL DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id),
  KEY idx_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS webhook_deliveries (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  webhook_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  event VARCHAR(40) NOT NULL,
  payload MEDIUMTEXT NOT NULL,
  status ENUM('pending','delivered','failed') NOT NULL DEFAULT 'pending',
  attempts INT NOT NULL DEFAULT 0,
  response_code INT NULL DEFAULT NULL,
  error VARCHAR(255) NOT NULL DEFAULT '',
  next_attempt_at DATETIME NULL DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  delivered_at DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY idx_status (status),
  KEY idx_webhook (webhook_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  endpoint_hash CHAR(64) NOT NULL,
  endpoint VARCHAR(1000) NOT NULL,
  p256dh VARCHAR(255) NOT NULL,
  auth VARCHAR(255) NOT NULL,
  user_agent VARCHAR(255) NOT NULL DEFAULT '',
  fail_count INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_endpoint (endpoint_hash),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS push_outbox (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(120) NOT NULL DEFAULT '',
  body VARCHAR(400) NOT NULL DEFAULT '',
  url VARCHAR(255) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
