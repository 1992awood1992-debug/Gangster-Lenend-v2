<?php
/**
 * Mafia Empire - API v2
 * 
 * GraphQL mutations, real-time subscriptions (SSE), webhook retries.
 * 
 * Endpoints:
 *   POST /api/v2/graphql           - GraphQL queries/mutations
 *   GET  /api/v2/stream            - Server-Sent Events for real-time updates
 *   POST /api/v2/webhooks/retry    - Manual webhook retry
 *   GET  /api/v2/webhooks/status   - Webhook delivery status
 */

require_once __DIR__ . '/../includes/api.php';
require_once __DIR__ . '/../includes/migrate.php';
require_once __DIR__ . '/../includes/webhooks.php';
require_once __DIR__ . '/../includes/graphql.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    api_cors();
    http_response_code(204);
    header('Content-Length: 0');
    exit;
}
api_cors();
api_register_logging();

if (!db_installed()) {
    api_fail(503, 'The game database is not installed yet.', 'not_installed');
}
run_migrations();

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$seg    = api_segments();
$version = $seg[0] ?? '';

if ($version === '') {
    api_ok([
        'name'      => SITE_NAME,
        'version'   => GAME_VERSION,
        'api'       => 'v2',
        'docs'      => 'docs/API_v2.md',
        'endpoints' => [
            'POST   v2/graphql',
            'GET    v2/stream',
            'POST   v2/webhooks/retry',
            'GET    v2/webhooks/status',
            'GET    v2/health',
        ],
        'graphql'   => [
            'query'        => 'player, leaderboard, market, crew',
            'mutation'     => 'buyItem, placeBet, sendRespect, startHeist',
            'subscription' => 'playerUpdate, marketUpdate, crewUpdate, newEvent',
        ],
    ]);
}

if (!in_array($version, ['v2', 'v2.php'], true)) {
    api_fail(404, 'Unknown API version. Only v2 is available.', 'not_found');
}
array_shift($seg);

$resource = $seg[0] ?? '';
$param    = $seg[1] ?? '';

/* ------------------------- Public: health ------------------------- */
if ($resource === 'health') {
    if ($method !== 'GET') { api_fail(405, 'Use GET for this endpoint.', 'method_not_allowed'); }
    api_ok([
        'status'         => 'ok',
        'game_version'   => GAME_VERSION,
        'schema_version' => (int) fetch_one('SELECT v FROM settings WHERE k = ?', ['schema_version'], 0),
        'time'           => now(),
    ]);
}

/* ------------------------- GraphQL Endpoint ------------------------- */
if ($resource === 'graphql') {
    if ($method !== 'POST') { api_fail(405, 'Use POST for GraphQL.', 'method_not_allowed'); }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $query = $input['query'] ?? '';
    $variables = $input['variables'] ?? [];
    $operationName = $input['operationName'] ?? null;
    
    if (!$query) { api_fail(400, 'Missing query.', 'bad_request'); }
    
    try {
        $result = graphql_execute($query, $variables, $operationName);
        api_ok($result);
    } catch (Throwable $e) {
        api_fail(500, 'GraphQL error: ' . $e->getMessage(), 'graphql_error');
    }
}

/* ------------------------- SSE Stream ------------------------- */
if ($resource === 'stream') {
    if ($method !== 'GET') { api_fail(405, 'Use GET for SSE stream.', 'method_not_allowed'); }
    
    // Authenticate for SSE
    $token = $_GET['token'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (str_starts_with($token, 'Bearer ')) $token = substr($token, 7);
    $user = fetch('SELECT * FROM users WHERE api_key_hash = ?', [hash('sha256', $token)]);
    if (!$user) { api_fail(401, 'Invalid or missing token for SSE.', 'unauthorized'); }
    
    // SSE headers
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no'); // Disable nginx buffering
    
    // Send initial connection event
    echo "event: connected\n";
    echo "data: " . json_encode(['type' => 'connected', 'user_id' => (int) $user['id'], 'time' => time()]) . "\n\n";
    ob_flush(); flush();
    
    // Heartbeat loop (run for max 5 minutes)
    $start = time();
    $lastEventId = (int) ($_SERVER['HTTP_LAST_EVENT_ID'] ?? 0);
    $crewId = $user['crew_id'] ?? 0;
    $channels = ['global', "user_{$user['id']}", "crew_{$crewId}"];
    
    while (time() - $start < 300) {
        // Check for new events in channels
        foreach ($channels as $channel) {
            $events = fetch_all("
                SELECT * FROM sse_events 
                WHERE channel = ? AND id > ? 
                ORDER BY id ASC LIMIT 50
            ", [$channel, $lastEventId]);
            
            foreach ($events as $ev) {
                echo "event: {$ev['event_type']}\n";
                echo "id: {$ev['id']}\n";
                echo "data: {$ev['payload']}\n\n";
                $lastEventId = max($lastEventId, (int) $ev['id']);
            }
        }
        
        // Heartbeat
        echo "event: heartbeat\n";
        echo "data: " . json_encode(['time' => time()]) . "\n\n";
        ob_flush(); flush();
        sleep(2);
        
        // Check if client disconnected
        if (connection_aborted()) break;
    }
    exit;
}

/* ------------------------- Webhook Retry ------------------------- */
if ($resource === 'webhooks' && $param === 'retry') {
    if ($method !== 'POST') { api_fail(405, 'Use POST.', 'method_not_allowed'); }
    
    // Admin only
    $user = api_current_user();
    if (!$user || (int) $user['is_admin'] !== 1) { api_fail(403, 'Admin only.', 'forbidden'); }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $deliveryId = $input['delivery_id'] ?? null;
    $webhookId = $input['webhook_id'] ?? null;
    
    if ($deliveryId) {
        $result = webhook_retry_delivery((int) $deliveryId);
        api_ok(['retried' => $result]);
    } elseif ($webhookId) {
        $count = webhook_retry_all_for_webhook((int) $webhookId);
        api_ok(['retried' => $count]);
    } else {
        $count = webhook_retry_all_failed();
        api_ok(['retried' => $count]);
    }
}

/* ------------------------- Webhook Status ------------------------- */
if ($resource === 'webhooks' && $param === 'status') {
    if ($method !== 'GET') { api_fail(405, 'Use GET.', 'method_not_allowed'); }
    
    $user = api_current_user();
    if (!$user || (int) $user['is_admin'] !== 1) { api_fail(403, 'Admin only.', 'forbidden'); }
    
    $webhookId = isset($_GET['webhook_id']) ? (int) $_GET['webhook_id'] : null;
    $limit = min(100, max(1, (int) ($_GET['limit'] ?? 50)));
    $status = $_GET['status'] ?? null; // pending, delivered, failed
    
    $where = [];
    $params = [];
    if ($webhookId) { $where[] = 'wd.webhook_id = ?'; $params[] = $webhookId; }
    if ($status) { $where[] = 'wd.status = ?'; $params[] = $status; }
    
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
    $params[] = $limit;
    
    $deliveries = fetch_all("
        SELECT wd.*, w.url as webhook_url, w.events as webhook_events
        FROM webhook_deliveries wd
        JOIN webhooks w ON w.id = wd.webhook_id
        $whereSql
        ORDER BY wd.created_at DESC
        LIMIT ?
    ", $params);
    
    api_ok($deliveries);
}

api_fail(404, 'Endpoint not found.', 'not_found');