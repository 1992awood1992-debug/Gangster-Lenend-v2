<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Pure helpers behind the outbound-webhook system: signing, event
 * subscription parsing and payload shaping.
 */
final class WebhookSignTest extends TestCase
{
    public function testSignatureIsHmacSha256Prefixed(): void
    {
        $sig = webhook_sign('{"a":1}', 'topsecret');
        $this->assertStringStartsWith('sha256=', $sig);
        $this->assertSame('sha256=' . hash_hmac('sha256', '{"a":1}', 'topsecret'), $sig);
    }

    public function testSignatureChangesWithSecretAndBody(): void
    {
        $a = webhook_sign('body', 'one');
        $b = webhook_sign('body', 'two');
        $c = webhook_sign('other', 'one');
        $this->assertNotSame($a, $b);
        $this->assertNotSame($a, $c);
    }

    public function testValidEventsParsesListsAndWildcard(): void
    {
        $this->assertSame(['*'], webhook_valid_events('*'));
        $this->assertSame(['kill', 'levelup'], webhook_valid_events('kill, levelup'));
    }

    public function testValidEventsDropsUnknownEntries(): void
    {
        $this->assertSame(['kill'], webhook_valid_events('kill,bogus'));
        $this->assertSame([], webhook_valid_events(''));
    }

    public function testBuildPayloadIsValidJsonWithEnvelope(): void
    {
        $json = webhook_build_payload('kill', 7, ['victim' => 'Sal']);
        $data = json_decode($json, true);
        $this->assertIsArray($data);
        $this->assertSame('kill', $data['event']);
        $this->assertSame(7, $data['user_id']);
        $this->assertSame('Sal', $data['data']['victim']);
        $this->assertArrayHasKey('created_at', $data);
    }

    public function testEventsCatalogueCoversRoadmapEvents(): void
    {
        $events = webhook_events();
        foreach (['kill', 'levelup', 'achievement', 'purchase'] as $e) {
            $this->assertArrayHasKey($e, $events);
        }
    }
}
