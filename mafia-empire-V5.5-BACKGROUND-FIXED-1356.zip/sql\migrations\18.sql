-- Migration 18: Reconcile market_listings with the auction-house schema.
-- schema.sql historically created a simplified market_listings, which made the
-- richer migration 13 definition a no-op (CREATE TABLE IF NOT EXISTS). The
-- statements below are idempotent: the runner tolerates "duplicate column" and
-- "already exists" errors on databases that are already up to date.

ALTER TABLE market_listings ADD COLUMN item_type ENUM('item','drug','vehicle','property','blueprint') NOT NULL DEFAULT 'item';
ALTER TABLE market_listings ADD COLUMN buyout_price BIGINT UNSIGNED NULL;
ALTER TABLE market_listings ADD COLUMN bid_price BIGINT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE market_listings ADD COLUMN min_bid BIGINT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE market_listings ADD COLUMN auction_end DATETIME NULL;
ALTER TABLE market_listings ADD COLUMN sold_at DATETIME NULL;
ALTER TABLE market_listings ADD COLUMN buyer_id INT UNSIGNED NULL;
ALTER TABLE market_listings ADD COLUMN final_price BIGINT UNSIGNED NULL;
ALTER TABLE market_listings MODIFY COLUMN price BIGINT NULL DEFAULT NULL;
ALTER TABLE market_listings MODIFY COLUMN id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT;
ALTER TABLE market_listings MODIFY COLUMN item_id INT UNSIGNED NOT NULL;
ALTER TABLE market_listings MODIFY COLUMN qty INT UNSIGNED NOT NULL DEFAULT 1;
ALTER TABLE market_listings MODIFY COLUMN status ENUM('open','active','sold','cancelled','expired') NOT NULL DEFAULT 'active';
UPDATE market_listings SET status = 'active' WHERE status = 'open';
ALTER TABLE market_listings MODIFY COLUMN status ENUM('active','sold','cancelled','expired') NOT NULL DEFAULT 'active';
UPDATE market_listings SET final_price = price WHERE final_price IS NULL AND status = 'sold' AND price IS NOT NULL;
CREATE TABLE IF NOT EXISTS market_bids (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    listing_id BIGINT UNSIGNED NOT NULL,
    bidder_id INT UNSIGNED NOT NULL,
    amount BIGINT UNSIGNED NOT NULL,
    status ENUM('active','outbid','won','cancelled') NOT NULL DEFAULT 'active',
    placed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_listing (listing_id),
    KEY idx_bidder (bidder_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE INDEX IF NOT EXISTS idx_market_listings_type_status ON market_listings (item_type, status);
CREATE INDEX IF NOT EXISTS idx_market_listings_seller_status ON market_listings (seller_id, status);
CREATE INDEX IF NOT EXISTS idx_market_listings_end ON market_listings (auction_end);
