<?php
/**
 * Eye Of The Mafia - Structured Logging
 * JSON logs for Loki/Elastic integration, with contextual enrichment.
 */

require_once __DIR__ . '/init.php';

/**
 * Log levels (RFC 5424 / PSR-3 compatible)
 */
if (!defined('LOG_EMERGENCY'))   define('LOG_EMERGENCY',   'emergency');
if (!defined('LOG_ALERT'))       define('LOG_ALERT',       'alert');
if (!defined('LOG_CRITICAL'))    define('LOG_CRITICAL',    'critical');
if (!defined('LOG_ERROR'))       define('LOG_ERROR',       'error');
if (!defined('LOG_WARNING'))     define('LOG_WARNING',     'warning');
if (!defined('LOG_NOTICE'))      define('LOG_NOTICE',      'notice');
if (!defined('LOG_INFO'))        define('LOG_INFO',        'info');
if (!defined('LOG_DEBUG'))       define('LOG_DEBUG',       'debug');

/**
 * Global log context (request ID, trace ID, etc.)
 */
$log_context = [];

/**
 * Set global log context (called at request start)
 */
function log_set_context(array $context): void
{
    global $log_context;
    $log_context = array_merge($log_context ?? [], $context);
}

/**
 * Clear log context (called at request end)
 */
function log_clear_context(): void
{
    global $log_context;
    $log_context = [];
}

/**
 * Core log function
 */
function log_write(string $level, string $channel, string $message, array $context = []): void
{
    global $log_context;
    $record = [
        'timestamp' => date('c'),
        'level' => $level,
        'channel' => $channel,
        'message' => $message,
        'context' => $context,
    ];
    
    // Add global context
    if (!empty($log_context)) {
        $record['global_context'] = $log_context;
    }
    
    // Add request info if available
    if (isset($_SERVER['REQUEST_URI'])) {
        $record['request'] = [
            'method' => $_SERVER['REQUEST_METHOD'] ?? 'CLI',
            'uri' => $_SERVER['REQUEST_URI'] ?? '',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'CLI',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        ];
    }
    
    // Add user info if logged in
    if (is_logged_in()) {
        $u = current_user();
        $record['user'] = [
            'id' => $u['id'],
            'username' => $u['username'],
            'level' => $u['level'],
        ];
    }
    
    // Add request ID if available
    if (!empty($_SERVER['HTTP_X_REQUEST_ID'])) {
        $record['request_id'] = $_SERVER['HTTP_X_REQUEST_ID'];
    }
    
    // Add trace context if available
    if (!empty($_SERVER['HTTP_X_B3_TRACEID'])) {
        $record['trace_id'] = $_SERVER['HTTP_X_B3_TRACEID'];
        $record['span_id'] = $_SERVER['HTTP_X_B3_SPANID'] ?? '';
    }
    
    // Write to database (for Loki/Elastic ingestion)
    if (defined('LOG_TO_DB') && LOG_TO_DB) {
        try {
            insert('log_entries', [
                'level' => $level,
                'channel' => 'app',
                'message' => $message,
                'context' => json_encode($context),
                'user_id' => is_logged_in() ? (int) $_SESSION['uid'] : null,
                'request_id' => $_SERVER['HTTP_X_REQUEST_ID'] ?? null,
                'trace_id' => $_SERVER['HTTP_X_B3_TRACEID'] ?? null,
                'span_id' => $_SERVER['HTTP_X_B3_SPANID'] ?? '',
            ]);
        } catch (Throwable $e) {
            // Fallback to file if DB fails
        }
    }
    
    // Write to file (JSON lines format for Loki)
    $logLine = json_encode($record, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
    $logFile = __DIR__ . '/../logs/app-' . date('Y-m-d') . '.log';
    @file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
    
    // Also write to error log for critical+
    if (in_array($level, [LOG_CRITICAL, LOG_ALERT, LOG_EMERGENCY], true)) {
        error_log("[$level] $channel: $message");
    }
}

/**
 * Convenience methods
 */
function log_debug(string $message, array $context = [], string $channel = 'app'): void
{
    log_write(LOG_DEBUG, $channel, $message);
}

function log_info(string $message, array $context = [], string $channel = 'app'): void
{
    log_write(LOG_INFO, $channel, $message);
}

function log_notice(string $message, array $context = [], string $channel = 'app'): void
{
    log_write(LOG_NOTICE, $channel, $message);
}

function log_warning(string $message, array $context = [], string $channel = 'app'): void
{
    log_write(LOG_WARNING, $channel, $message);
}

function log_error(string $message, array $context = [], string $channel = 'app'): void
{
    log_write(LOG_ERROR, $channel, $message);
}

function log_critical(string $message, array $context = [], string $channel = 'app'): void
{
    log_write(LOG_CRITICAL, $channel, $message);
}

function log_alert(string $message, array $context = [], string $channel = 'app'): void
{
    log_write(LOG_ALERT, $channel, $message);
}

function log_emergency(string $message, array $context = [], string $channel = 'app'): void
{
    log_write(LOG_EMERGENCY, $channel, $message);
}

/**
 * Log SQL query (for slow query detection)
 */
function log_query(string $sql, array $params = [], float $durationMs = 0): void
{
    $context = [
        'sql' => $sql,
        'params' => $params,
        'duration_ms' => round($durationMs, 2),
    ];
    
    $level = $durationMs > 1000 ? LOG_WARNING : ($durationMs > 100 ? LOG_NOTICE : LOG_DEBUG);
    log_write($level, 'db', 'SQL Query', ['sql' => $sql, 'params' => $params, 'duration_ms' => round($durationMs, 2)]);
}

/**
 * Log API request
 */
function log_api_request(string $method, string $endpoint, int $statusCode, float $durationMs, int $userId = 0): void
{
    $context = [
        'method' => $method,
        'endpoint' => $endpoint,
        'status_code' => $statusCode,
        'duration_ms' => round($durationMs, 2),
        'user_id' => $userId,
    ];
    
    $level = $statusCode >= 500 ? LOG_ERROR : ($statusCode >= 400 ? LOG_WARNING : LOG_INFO);
    log_write($level, 'api', "$method $endpoint $statusCode", $context);
}

/**
 * Log authentication event
 */
function log_auth(string $event, int $userId = 0, bool $success = true, array $context = []): void
{
    $context = array_merge($context, ['user_id' => $userId, 'success' => $success]);
    log_write($success ? LOG_INFO : LOG_WARNING, 'auth', "Auth: $event", $context);
}

/**
 * Log security event
 */
function log_security(string $event, array $context = []): void
{
    log_write(LOG_WARNING, 'security', "Security: $event", $context);
}

/**
 * Log business event (analytics)
 */
function log_business(string $event, int $userId = 0, array $context = []): void
{
    $context = array_merge($context, ['user_id' => $userId]);
    log_write(LOG_INFO, 'business', "Business: $event", $context);
}

/**
 * Initialize logging for a request (call at bootstrap)
 */
function log_init_request(): void
{
    $requestId = $_SERVER['HTTP_X_REQUEST_ID'] ?? bin2hex(random_bytes(8));
    $_SERVER['HTTP_X_REQUEST_ID'] = $requestId;
    
    // Add to response headers
    header("X-Request-ID: " . $requestId);
    
    log_set_context([
        'request_id' => $requestId,
    ]);
    
    // Log request start
    log_info('Request started', [
        'method' => $_SERVER['REQUEST_METHOD'] ?? 'CLI',
        'uri' => $_SERVER['REQUEST_URI'] ?? '',
    ]);
}

/**
 * Finalize logging for a request
 */
function log_finish_request(int $statusCode = 200, float $durationMs = 0): void
{
    log_info('Request finished', [
        'status_code' => $statusCode,
        'duration_ms' => round($durationMs, 2),
    ]);
    
    log_clear_context();
}

/**
 * Query log entries (for admin dashboard)
 */
function log_query_entries(array $filters = [], int $limit = 100, int $offset = 0): array
{
    $where = [];
    $params = [];
    
    if (!empty($filters['level'])) {
        $where[] = 'level = ?';
        $params[] = $filters['level'];
    }
    if (!empty($filters['channel'])) {
        $where[] = 'channel = ?';
        $params[] = $filters['channel'];
    }
    if (!empty($filters['user_id'])) {
        $where[] = 'user_id = ?';
        $params[] = (int) $filters['user_id'];
    }
    if (!empty($filters['request_id'])) {
        $where[] = 'request_id = ?';
        $params[] = $filters['request_id'];
    }
    if (!empty($filters['trace_id'])) {
        $where[] = 'trace_id = ?';
        $params[] = $filters['trace_id'];
    }
    if (!empty($filters['date_from'])) {
        $where[] = 'created_at >= ?';
        $params[] = $filters['date_from'];
    }
    if (!empty($filters['date_to'])) {
        $where[] = 'created_at <= ?';
        $params[] = $filters['date_to'];
    }
    
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
    
    $params[] = $limit;
    $params[] = $offset;
    
    return fetch_all("
        SELECT * FROM log_entries
        $whereSql
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?
    ", $params);
}

/**
 * Get log statistics
 */
function log_get_stats(): array
{
    return [
        'total' => (int) fetch_one('SELECT COUNT(*) FROM log_entries', [], 0),
        'by_level' => fetch_all("
            SELECT level, COUNT(*) as count 
            FROM log_entries 
            GROUP BY level 
            ORDER BY count DESC
        "),
        'by_channel' => fetch_all("
            SELECT channel, COUNT(*) as count 
            FROM log_entries 
            GROUP BY channel 
            ORDER BY count DESC
        "),
        'recent_errors' => (int) fetch_one("
            SELECT COUNT(*) FROM log_entries 
            WHERE level IN ('error','critical','alert','emergency') 
            AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ", [], 0),
    ];
}

/**
 * Cleanup old logs (cron job)
 */
function log_cleanup(int $daysToKeep = 30): int
{
    $deleted = 0;
    try {
        $deleted = (int) q('DELETE FROM log_entries WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)', [$daysToKeep]);
    } catch (Throwable $e) {
        // Ignore
    }
    return $deleted;
}