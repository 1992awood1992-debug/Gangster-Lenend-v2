<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/respect.php';
require_once __DIR__ . '/includes/prestige.php';
$u = require_login();

$targetId = isset($_GET['id']) ? (int) $_GET['id'] : $u['id'];
$target = fetch('SELECT * FROM users WHERE id = ?', [$targetId]);
if (!$target) {
    http_response_code(404);
    exit('Player not found.');
}

// POST: edit bio/avatar (self only) OR send respect
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $targetId === $u['id']) {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'edit_profile') {
        $bio = trim(substr($_POST['bio'] ?? '', 0, 255));
        $avatar = trim($_POST['avatar'] ?? '');
        if ($avatar !== '' && !preg_match('#^(https?://|/assets/)#', $avatar)) {
            flash('Avatar must be a URL or a path under /assets/.', 'error');
        } else {
            q('UPDATE users SET bio = ?, avatar = ? WHERE id = ?', [$bio, $avatar ?: 'assets/img/avatar-default.svg', $u['id']]);
            flash('Profile updated.', 'success');
        }
        redirect('profile.php?id=' . $u['id']);
    }
}

// POST: send respect (viewing other profile)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $targetId !== $u['id']) {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'send_respect') {
        $amount = max(1, (int) ($_POST['amount'] ?? 1));
        $type = $_POST['type'] ?? 'respect';
        $anonymous = isset($_POST['anonymous']);
        $message = trim(substr($_POST['message'] ?? '', 0, 255));
        $result = respect_send($u['id'], $targetId, $amount, $type, $anonymous, $message);
        if (!empty($result['ok'])) {
            flash('Sent! ' . $result['remaining'] . ' points remaining today.', 'success');
        } else {
            flash($result['error'], 'error');
        }
        redirect('profile.php?id=' . $targetId);
    }
}

$page_title = 'Profile — ' . $target['username'];
require __DIR__ . '/includes/header.php';

$isSelf = $targetId === $u['id'];
$prestigeInfo = prestige_get_profile_info($targetId);
$netRespect = respect_get_balance($targetId);
$rank = rank_for_level((int) $target['level']);
$xpNeed = xp_for_level((int) $target['level'] + 1);
$power = combat_power($target['id']);
$crew = $target['crew_id'] ? fetch('SELECT * FROM crews WHERE id = ?', [$target['crew_id']]) : null;
$achievements = fetch_all('SELECT a.*, ua.unlocked_at FROM achievements a LEFT JOIN user_achievements ua ON ua.achievement_id = a.id AND ua.user_id = ? WHERE a.id IS NOT NULL', [$targetId]);
$unlockedCount = 0; foreach ($achievements as $a) if ($a['unlocked_at']) $unlockedCount++;
$equipped = fetch_all('SELECT ui.*, i.name, i.type, i.attack, i.defense, i.cost, i.rarity FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.equipped = 1', [$targetId]);
?>
<div class="card">
  <div class="panel-heading"><?= e($target['username']) ?> <span class="tag tag-gold"><?= e($prestigeInfo['display']) ?></span></div>
  <div style="display:flex;gap:20px;flex-wrap:wrap;align-items:flex-start">
    <img src="<?= e($target['avatar']) ?>" alt="" class="avatar" style="width:80px;height:80px" onerror="this.src='<?= e(url('assets/img/avatar-default.svg')) ?>'">
    <div style="flex:1;min-width:200px">
      <div class="stat"><span>Rank</span><b><?= e($rank['name']) ?></b></div>
      <div class="stat"><span>Level</span><b><?= $prestigeInfo['display'] === 'L' . (int) $target['level'] ? (int) $target['level'] : '50 (Prestige ' . $prestigeInfo['prestige'] . ')' ?> (<?= (int) $target['xp'] ?> / <?= $xpNeed ?> XP)</b></div>
      <?php if ($prestigeInfo['prestige'] > 0): ?>
        <div class="stat"><span>Prestige Progress</span><b><?= (int) ($prestigeInfo['progress']['progress'] * 100) ?>% to P<?= $prestigeInfo['prestige'] + 1 ?></b></div>
        <div class="progress" style="max-width:300px"><i style="width:<?= min(100, round($prestigeInfo['progress']['progress'] * 100)) ?>%"></i></div>
        <div class="stat"><span>Prestige Coins</span><b><?= (int) $prestigeInfo['coins'] ?></b></div>
      <?php else: ?>
        <div class="progress" style="max-width:300px"><i style="width:<?= min(100, round((int) $target['xp'] / max(1, $xpNeed) * 100)) ?>%"></i></div>
      <?php endif; ?>
      <?php if ($crew): ?>
        <div class="stat" style="margin-top:8px"><span>Crew</span><b><a href="<?= e(url('crew.php')) ?>"><?= e($crew['name']) ?></a> [<?= e($crew['tag']) ?>] — <?= e($target['crew_rank']) ?></b></div>
      <?php endif; ?>
      <div class="stat"><span>District</span><b><?= e(fetch('SELECT name FROM districts WHERE id = ?', [$target['district_id']])['name'] ?? '—') ?></b></div>
      <div class="stat"><span>Respect</span><b class="<?= $netRespect >= 0 ? '' : 'text-red' ?>"><?= (int) $netRespect ?></b></div>
      <div class="stat"><span>Joined</span><b><?= date('M j, Y', strtotime($target['created_at'])) ?></b></div>
      <div class="stat"><span>Last Active</span><b><?= date('M j, Y H:i', strtotime($target['last_active'])) ?></b></div>
    </div>
  </div>
  <?php if ($target['bio']): ?>
    <div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line)"><small class="muted">"<?= e($target['bio']) ?>"</small></div>
  <?php endif; ?>
</div>

<div class="grid grid-3" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Stats</div>
    <div class="stat"><span>Kills</span><b><?= (int) $target['kills'] ?></b></div>
    <div class="stat"><span>Deaths</span><b><?= (int) $target['deaths'] ?></b></div>
    <div class="stat"><span>Wins</span><b><?= (int) $target['wins'] ?></b></div>
    <div class="stat"><span>Losses</span><b><?= (int) $target['losses'] ?></b></div>
    <div class="stat"><span>Missions</span><b><?= (int) $target['missions_done'] ?></b></div>
    <div class="stat"><span>Crimes</span><b><?= (int) $target['crimes_done'] ?></b></div>
    <div class="stat"><span>Boss Kills</span><b><?= (int) $target['boss_kills'] ?></b></div>
  </div>
  <div class="card">
    <div class="panel-heading">Base Stats</div>
    <div class="stat"><span>Strength</span><b><?= (int) $target['strength'] ?></b></div>
    <div class="stat"><span>Speed</span><b><?= (int) $target['speed'] ?></b></div>
    <div class="stat"><span>Defense</span><b><?= (int) $target['defense'] ?></b></div>
    <div class="stat"><span>IQ</span><b><?= (int) $target['iq'] ?></b></div>
    <div class="stat"><span>Total ATK</span><b><?= $power['attack'] ?></b></div>
    <div class="stat"><span>Total DEF</span><b><?= $power['defense'] ?></b></div>
  </div>
  <div class="card">
    <div class="panel-heading">Equipped Gear</div>
    <?php if (!$equipped): ?>
      <p class="muted">Nothing equipped.</p>
    <?php else: foreach ($equipped as $eq): ?>
      <div class="stat"><span><?= e($eq['name']) ?></span><b>ATK +<?= (int) $eq['attack'] ?> DEF +<?= (int) $eq['defense'] ?></b></div>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php if ($isSelf): ?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Edit Profile</div>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="edit_profile">
    <label>Bio <textarea name="bio" maxlength="255"><?= e($target['bio']) ?></textarea></label>
    <label>Avatar URL <input type="text" name="avatar" value="<?= e($target['avatar']) ?>" placeholder="https://... or /assets/..."></label>
    <button class="btn btn-gold" type="submit">Save</button>
  </form>
</div>
<?php else: ?>
<!-- Send Respect Form -->
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Send Respect</div>
  <p class="muted small">Daily limit: <?= respect_get_daily_limit($u['id']) ?> points. Used today: <?= respect_get_sent_today($u['id']) ?>.</p>
  <form method="post" style="display:flex;flex-direction:column;gap:10px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="send_respect">
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <label style="flex:1;min-width:120px">Amount <input type="number" name="amount" min="1" max="<?= respect_get_daily_limit($u['id']) - respect_get_sent_today($u['id']) ?>" value="1" required></label>
      <label style="flex:1;min-width:140px">
        Type
        <select name="type" style="width:100%">
          <option value="respect">Respect (+)</option>
          <option value="disrespect">Disrespect (-)</option>
        </select>
      </label>
    </div>
    <label style="display:flex;align-items:center;gap:8px">
      <input type="checkbox" name="anonymous" value="1"> Anonymous
    </label>
    <label>Message (optional) <textarea name="message" maxlength="255" rows="2" placeholder="Why do they deserve this?"></textarea></label>
    <button class="btn btn-gold" type="submit">Send</button>
  </form>
</div>

<!-- Received Respect Log -->
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Recent Respect Received</div>
  <?php $received = respect_get_received($targetId, 10);
  if (!$received): ?>
    <p class="muted">No respect received yet.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>From</th><th>Type</th><th>Amount</th><th>Message</th><th>Time</th></tr>
      <?php foreach ($received as $r): ?>
        <tr>
          <td><?= $r['anonymous'] ? '<span class="muted">Anonymous</span>' : '<a href="'.e(url('profile.php?id='.$r['from_user_id'])).'">'.e($r['from_name']).'</a>' ?></td>
          <td><span class="tag tag-<?= $r['type'] === 'respect' ? 'legendary' : 'error' ?>"><?= ucfirst($r['type']) ?></span></td>
          <td class="<?= $r['amount'] > 0 ? 'text-green' : 'text-red' ?>"><?= (int) $r['amount'] ?></td>
          <td><?= e($r['message']) ?></td>
          <td><?= date('M j H:i', strtotime($r['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php endif; ?>

<h2 style="margin-top:24px">Achievements (<?= $unlockedCount ?>/<?= count($achievements) ?>)</h2>
<div class="card">
  <div class="grid grid-4">
    <?php foreach ($achievements as $a):
      $unlocked = !empty($a['unlocked_at']);
      $progress = 0;
      if ($a['metric'] === 'kills') $progress = (int) $target['kills'];
      elseif ($a['metric'] === 'missions_done') $progress = (int) $target['missions_done'];
      elseif ($a['metric'] === 'boss_kills') $progress = (int) $target['boss_kills'];
      elseif ($a['metric'] === 'crimes_done') $progress = (int) $target['crimes_done'];
      elseif ($a['metric'] === 'money') $progress = (int) $target['money'] + (int) $target['bank'];
      elseif ($a['metric'] === 'level') $progress = (int) $target['level'];
      $pct = $a['target'] > 0 ? min(100, round($progress / $a['target'] * 100)) : 100;
    ?>
      <div class="tile" style="opacity:<?= $unlocked ? 1 : 0.6 ?>">
        <b><?= e($a['name']) ?></b><br>
        <small class="muted"><?= e($a['description']) ?></small>
        <div class="progress" style="margin:6px 0"><i style="width:<?= $pct ?>%"></i></div>
        <small class="muted"><?= $unlocked ? 'Unlocked' : "$progress / {$a['target']}" ?></small>
        <?php if ($unlocked): ?><span class="tag tag-legendary" style="margin-top:6px;display:inline-block">✓</span><?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>