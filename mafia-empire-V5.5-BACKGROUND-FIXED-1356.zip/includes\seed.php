<?php
/**
 * Mafia Empire - schema loader + content seeder (shared by install.php and tests).
 *
 * Extracted from install.php (ROADMAP Phase 6) so the automated test suite can
 * build a clean database without executing the installer's CLI/web side effects.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/event_seed.php';

function run_schema(): void
{
    $sql = file_get_contents(__DIR__ . '/../sql/schema.sql');
    // Strip comments then split statements.
    $sql = preg_replace('/^--.*$/m', '', $sql);
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        db()->exec($stmt);
    }
}

function seed(int $adminId = 0): void
{
    if ((int) fetch_one('SELECT COUNT(*) FROM ranks') === 0) {
        $tiers = [
            1 => 'Associate', 5 => 'Soldier', 10 => 'Made Man', 15 => 'Capo',
            20 => 'Underboss', 30 => 'Consigliere', 40 => 'Street Boss',
            50 => 'Crime Lord', 60 => 'Don', 70 => 'Boss of Bosses',
            80 => 'Kingpin', 90 => 'Godfather', 100 => 'Syndicate Legend',
        ];
        $last = 'Associate';
        for ($lvl = 1; $lvl <= 100; $lvl++) {
            if (isset($tiers[$lvl])) {
                $last = $tiers[$lvl];
            }
            insert('ranks', ['level' => $lvl, 'name' => $last]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM districts') === 0) {
        $d = [
            ['Downtown', 'Neon-lit streets and cheap scores for rookies.', 1, 0],
            ['The Docks', 'Shipping crates hide more than cargo.', 5, 10],
            ['Little Italy', 'Old money, old grudges, old friends.', 10, 20],
            ['Wall Street', 'Where the real empire is built.', 20, 35],
        ];
        foreach ($d as $row) {
            insert('districts', ['name' => $row[0], 'description' => $row[1], 'unlock_level' => $row[2], 'income_bonus' => $row[3]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM missions') === 0) {
        $missions = [
            [1, 'Shake Down a Corner Store', 'Collect protection money from a stubborn shopkeeper.', 3, 1, 250, 8, 0, 10],
            [1, 'Steal a Purse', 'Quick cash from an unsuspecting mark.', 2, 1, 120, 4, 0, 15],
            [1, 'Vandalize a Rival Bar', 'Send a message the old fashioned way.', 5, 2, 500, 18, 0, 25],
            [1, 'Hijack a Delivery Van', 'Intercept a shipment before it reaches its destination.', 8, 4, 1400, 40, 1, 35],
            [2, 'Smuggle Cargo Off the Docks', 'Move crates past the night watch.', 6, 5, 900, 26, 0, 30],
            [2, 'Bribe a Dock Inspector', 'Money opens gates.', 4, 6, 600, 15, 0, 10],
            [2, 'Sink a Rival Boat', 'No witnesses, no cargo.', 10, 8, 2200, 55, 1, 45],
            [2, 'Rob the Fish Market', 'A messy but profitable score.', 8, 7, 1600, 42, 0, 35],
            [3, 'Collect From a Bookie', 'Debts must be paid.', 7, 10, 2100, 50, 1, 35],
            [3, 'Rig a Card Game', 'Stack the deck against a wealthy target.', 9, 12, 3000, 70, 1, 40],
            [3, 'Torch a Rival Restaurant', 'Insurance fraud and territory in one.', 12, 14, 4200, 95, 2, 50],
            [3, 'Kidnap a Businessman', 'Hold for ransom. Keep it clean.', 14, 16, 5500, 120, 2, 55],
            [4, 'Hack the Exchange', 'Digital money is still money.', 12, 20, 7000, 150, 3, 45],
            [4, 'Launder a Fortune', 'Turn dirty cash into clean assets.', 15, 24, 9000, 190, 3, 50],
            [4, 'Take Over a Hedge Fund', 'The ultimate hostile acquisition.', 20, 30, 15000, 300, 5, 60],
            [4, 'Assassinate a CEO', 'The board will understand.', 25, 40, 25000, 500, 8, 70],
        ];
        foreach ($missions as $m) {
            insert('missions', [
                'district_id' => $m[0], 'name' => $m[1], 'description' => $m[2],
                'energy_cost' => $m[3], 'min_level' => $m[4], 'reward_money' => $m[5],
                'reward_xp' => $m[6], 'reward_points' => $m[7], 'risk' => $m[8],
                'story' => $m[2],
            ]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM gyms') === 0) {
        $gyms = [
            ['Iron Warehouse', 'strength', 250, 1, 5, 1],
            ['Speed Bag Gym', 'speed', 250, 1, 5, 1],
            ['Boxing Ring', 'defense', 400, 1, 6, 3],
            ['Backroom Library', 'iq', 400, 1, 6, 3],
        ];
        foreach ($gyms as $g) {
            insert('gyms', ['name' => $g[0], 'stat' => $g[1], 'cost' => $g[2], 'gain' => $g[3], 'energy_cost' => $g[4], 'min_level' => $g[5]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM bosses') === 0) {
        $bosses = [
            [1, 'Tommy "Two Fingers" Russo', 'A small-time thug who runs the corner rackets.', 200, 20, 8, 1, 15, 3000, 100, 3, null],
            [2, 'Captain Vinnie Marlow', 'Corrupt dock captain with a private army.', 500, 40, 18, 5, 20, 12000, 300, 8, null],
            [3, 'Don Salvatore Moretti', 'The old lion of Little Italy.', 1200, 75, 35, 10, 25, 35000, 800, 15, null],
            [4, 'The Broker', 'A ghost in a suit who owns half the city.', 3000, 130, 60, 20, 30, 100000, 2000, 30, null],
        ];
        foreach ($bosses as $b) {
            insert('bosses', ['district_id' => $b[0], 'name' => $b[1], 'description' => $b[2], 'hp' => $b[3], 'attack' => $b[4], 'defense' => $b[5], 'min_level' => $b[6], 'energy_cost' => $b[7], 'reward_money' => $b[8], 'reward_xp' => $b[9], 'reward_points' => $b[10], 'reward_item_id' => $b[11]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM criminal_jobs') === 0) {
        $jobs = [
            ['Pickpocket', 'Lift a wallet in a crowd.', 2, 1, 40, 120, 4, 15],
            ['Graffiti Run', 'Tag up rival turf.', 3, 1, 80, 200, 6, 12],
            ['Shoplift', 'Five-finger discount.', 4, 2, 150, 350, 8, 18],
            ['Car Break-In', 'Smash and grab.', 5, 3, 250, 600, 12, 22],
            ['Gas Station Robbery', 'Fast cash, high heat.', 8, 5, 700, 1500, 22, 30],
            ['Armored Truck Job', 'Big risk, bigger payout.', 12, 10, 2500, 5000, 45, 38],
            ['Jewelry Heist', 'A clean crew makes it look easy.', 16, 15, 6000, 12000, 80, 45],
            ['Bank Job', 'The classic.', 20, 20, 15000, 30000, 130, 50],
        ];
        foreach ($jobs as $j) {
            insert('criminal_jobs', ['name' => $j[0], 'description' => $j[1], 'nerve_cost' => $j[2], 'min_level' => $j[3], 'payout_min' => $j[4], 'payout_max' => $j[5], 'xp' => $j[6], 'fail_risk' => $j[7]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM abilities') === 0) {
        $ab = [
            ['Iron Grip', '+5 Strength permanently.', 10, 1, 'stat', 5, 'strength'],
            ['Quick Draw', '+5 Speed permanently.', 10, 1, 'stat', 5, 'speed'],
            ['Tough Skin', '+5 Defense permanently.', 10, 1, 'stat', 5, 'defense'],
            ['Street Smarts', '+5 IQ permanently.', 10, 1, 'stat', 5, 'iq'],
            ['Second Wind', 'Heal 25 health instantly.', 8, 3, 'heal', 25, ''],
            ['Energizer', 'Restore 20 energy instantly.', 12, 5, 'energy', 20, ''],
            ['Nerve of Steel', 'Restore 10 nerve instantly.', 15, 5, 'nerve', 10, ''],
            ['Bullet Magnet', 'Gain 50 bullets instantly.', 10, 3, 'bullets', 50, ''],
        ];
        foreach ($ab as $a) {
            insert('abilities', ['name' => $a[0], 'description' => $a[1], 'cost_points' => $a[2], 'min_level' => $a[3], 'effect_type' => $a[4], 'effect_value' => $a[5], 'stat' => $a[6]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM drugs') === 0) {
        $drugs = [
            ['Weed', 'Cheap and cheerful gateway stash.', 100, 150, 1, '', 0, 0],
            ['Pills', 'Uppers for a long night.', 250, 380, 3, 'energy', 10, 10],
            ['Cocaine', 'Glittering white profit.', 800, 1200, 6, 'speed', 3, 20],
            ['Heroin', 'Nasty business, healthy margin.', 1500, 2300, 10, 'health', 15, 25],
            ['Meth', 'Cooked in a trailer, sold on the corner.', 2000, 3100, 12, 'strength', 4, 30],
            ['Fentanyl', 'Dangerous and lucrative.', 4000, 6200, 18, '', 0, 35],
            ['Designer X', 'Exclusive party supply.', 9000, 14000, 24, 'iq', 6, 30],
        ];
        foreach ($drugs as $d) {
            insert('drugs', ['name' => $d[0], 'description' => $d[1], 'buy_price' => $d[2], 'sell_price' => $d[3], 'min_level' => $d[4], 'effect_stat' => $d[5], 'effect_amount' => $d[6], 'od_risk' => $d[7]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM items') === 0) {
        $items = [
            ['Baseball Bat', 'Classic street persuasion.', 'weapon', 4, 0, 500, 1, 'common'],
            ['Switchblade', 'Quick and quiet.', 'weapon', 8, 0, 2000, 3, 'common'],
            ['9mm Pistol', 'Reliable sidearm.', 'weapon', 15, 2, 8000, 5, 'uncommon'],
            ['Sawn-Off Shotgun', 'Room clearing power.', 'weapon', 26, 3, 25000, 10, 'rare'],
            ['AK-47', 'Serious firepower.', 'weapon', 45, 5, 90000, 18, 'epic'],
            ['Leather Jacket', 'Tougher than it looks.', 'armor', 0, 5, 800, 1, 'common'],
            ['Kevlar Vest', 'Stops the small stuff.', 'armor', 0, 14, 6000, 5, 'uncommon'],
            ['Bulletproof Suit', 'Style and survival.', 'armor', 1, 28, 30000, 12, 'rare'],
            ['Riot Gear', 'Military surplus.', 'armor', 2, 50, 120000, 20, 'epic'],
            ['Beaten-Up Sedan', 'Gets you there.', 'vehicle', 0, 3, 3000, 2, 'common'],
            ['Armored SUV', 'Travel in safety.', 'vehicle', 2, 12, 20000, 8, 'uncommon'],
            ['Speedboat', 'For cargo and getaways.', 'vehicle', 3, 18, 60000, 15, 'rare'],
        ];
        foreach ($items as $i) {
            insert('items', ['name' => $i[0], 'description' => $i[1], 'type' => $i[2], 'attack' => $i[3], 'defense' => $i[4], 'cost' => $i[5], 'min_level' => $i[6], 'rarity' => $i[7]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM points_store') === 0) {
        $store = [
            ['$25,000 Cash', 'Straight cash, no questions.', 10, 'money', 25000, null],
            ['$100,000 Cash', 'A serious injection of capital.', 35, 'money', 100000, null],
            ['250 Bullets', 'Restock the arsenal.', 15, 'bullets', 250, null],
            ['50 Energy Refill', 'Keep grinding.', 12, 'energy', 50, null],
            ['25 Nerve Refill', 'For the risky business.', 20, 'nerve', 25, null],
            ['Full Heal', 'Patch yourself up.', 8, 'heal', 999, null],
        ];
        foreach ($store as $s) {
            insert('points_store', ['name' => $s[0], 'description' => $s[1], 'cost_points' => $s[2], 'kind' => $s[3], 'amount' => $s[4], 'item_id' => $s[5]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM forum_categories') === 0) {
        $cats = [
            ['Announcements', 'Official news from the family.', 1],
            ['General Discussion', 'Talk about anything.', 2],
            ['Strategy & Tips', 'Share your builds and tactics.', 3],
            ['Crews & Recruitment', 'Find a crew or recruit members.', 4],
            ['Off Topic', 'Everything else.', 5],
        ];
        foreach ($cats as $c) {
            insert('forum_categories', ['name' => $c[0], 'description' => $c[1], 'sort_order' => $c[2]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM achievements') === 0) {
        $ach = [
            ['first_blood', 'First Blood', 'Kill your first target.', 10, 1, 'kills'],
            ['hitman', 'Hitman', 'Kill 10 players.', 25, 10, 'kills'],
            ['mission_10', 'Errand Boy', 'Complete 10 missions.', 15, 10, 'missions_done'],
            ['mission_100', 'Gone Pro', 'Complete 100 missions.', 50, 100, 'missions_done'],
            ['boss_slayer', 'Boss Slayer', 'Defeat your first boss.', 20, 1, 'boss_kills'],
            ['rich', 'Money Bags', 'Hold $1,000,000 in cash.', 30, 1000000, 'money'],
            ['level_10', 'Up and Comer', 'Reach level 10.', 20, 10, 'level'],
            ['level_50', 'Crime Lord', 'Reach level 50.', 100, 50, 'level'],
            ['criminal', 'Career Criminal', 'Complete 50 criminal jobs.', 30, 50, 'crimes_done'],
            ['veteran', 'Veteran', 'Reach level 25.', 40, 25, 'level'],
        ];
        foreach ($ach as $a) {
            insert('achievements', ['code' => $a[0], 'name' => $a[1], 'description' => $a[2], 'reward_points' => $a[3], 'target' => $a[4], 'metric' => $a[5]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM stickers') === 0) {
        $stickers = [
            ['tommy_gun', 'Tommy Gun', 'common'],
            ['fedora', 'Fedora', 'common'],
            ['lucky_cat', 'Lucky Cat', 'common'],
            ['cigar', 'Fat Cigar', 'uncommon'],
            ['diamond', 'Diamond', 'uncommon'],
            ['racehorse', 'Racehorse', 'uncommon'],
            ['gold_bar', 'Gold Bar', 'rare'],
            ['vintage_car', 'Vintage Cadillac', 'rare'],
            ['tommy_gun_gold', 'Golden Tommy Gun', 'epic'],
            ['crime_boss', 'Crime Boss', 'epic'],
            ['phoenix', 'The Phoenix', 'legendary'],
            ['godfather', 'The Godfather', 'legendary'],
        ];
        foreach ($stickers as $s) {
            insert('stickers', ['code' => $s[0], 'name' => $s[1], 'rarity' => $s[2]]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM bullet_factories') === 0) {
        foreach ([1, 2, 3, 4] as $did) {
            insert('bullet_factories', ['district_id' => $did, 'price' => 1000000 * $did, 'production' => 25 * $did]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM lottery_draws') === 0) {
        insert('lottery_draws', ['draw_date' => date('Y-m-d'), 'pot' => 25000, 'status' => 'open']);
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM faqs') === 0) {
        $faqs = [
            ['How do I make money?', 'Run missions, commit criminal jobs, gamble, trade, or collect from a bullet factory you own.'],
            ['What is energy for?', 'Energy is spent on missions, the gym and boss fights. It regenerates over time and from the Points Store.'],
            ['What is nerve for?', 'Nerve is spent on criminal jobs and crimes. It regenerates every 10 minutes.'],
            ['How do I level up?', 'Earn XP from missions, jobs, bosses and kills. Higher levels unlock new districts, gear and abilities.'],
            ['What happens when I die?', 'You go to the hospital for a while and lose a portion of your cash. Health regenerates over time.'],
            ['How do crews work?', 'Create or join a crew, pool money and bullets, and fight together for territory.'],
            ['How do referrals work?', 'Share your referral code. When new players sign up with it you earn points.'],
            ['How do I get points?', 'Points come from achievements, daily rewards, referrals, the lottery and real-money packages.'],
        ];
        foreach ($faqs as $f) {
            insert('faqs', ['question' => $f[0], 'answer' => $f[1], 'sort_order' => 1]);
        }
    }

    if ((int) fetch_one('SELECT COUNT(*) FROM settings') === 0) {
        foreach ([['site_name', SITE_NAME], ['version', GAME_VERSION]] as $s) {
            insert('settings', ['k' => $s[0], 'v' => $s[1]]);
        }
    }

    if ($adminId > 0 && (int) fetch_one('SELECT COUNT(*) FROM updates') === 0 && (int) fetch_one('SELECT COUNT(*) FROM users') > 1) {
        insert('updates', ['title' => 'Welcome to ' . SITE_NAME, 'body' => "The city is yours for the taking.\n\nStart with missions, hit the gym, and work your way up to the Empire. Good luck.", 'user_id' => $adminId]);
    }

    // Events subsystem: create tables (fresh installs run seed() before
    // migrations) and seed the built-in daily/weekly/seasonal events.
    event_seed_defaults();
}

function create_admin(string $user, string $email, string $pass): int
{
    if (fetch('SELECT id FROM users WHERE username = ?', [$user])) {
        return 0;
    }
    return insert('users', [
        'username'      => $user,
        'email'         => $email,
        'password_hash' => password_hash($pass, PASSWORD_DEFAULT),
        'is_admin'      => 1,
        'referral_code' => strtoupper(substr(bin2hex(random_bytes(4)), 0, 8)),
    ]);
}
