<?php

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/social.php';

class SocialHelpersTest extends TestCase
{
    public function testInsertIgnoreHelper(): void
    {
        $this->assertTrue(function_exists('insert_ignore'));
    }

    public function testTradeCreateHelper(): void
    {
        $this->assertTrue(function_exists('trade_create'));
    }

    public function testCrewMessageSendHelper(): void
    {
        $this->assertTrue(function_exists('crew_message_send'));
    }

    public function testHitlistAddHelper(): void
    {
        $this->assertTrue(function_exists('hitlist_add'));
    }

    public function testBountyCreateHelper(): void
    {
        $this->assertTrue(function_exists('bounty_create'));
    }
}
