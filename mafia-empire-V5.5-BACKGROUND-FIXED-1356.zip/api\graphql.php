<?php
/**
 * Mafia Empire - GraphQL endpoint.
 *
 * POST executes a query. A plain GET renders the interactive playground in
 * development so the endpoint can be explored from a browser.
 */
define('GRAPHQL_PLAYGROUND', true); // Enable playground in dev
require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/graphql.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    graphql_handle_request();
} else {
    graphql_playground();
}