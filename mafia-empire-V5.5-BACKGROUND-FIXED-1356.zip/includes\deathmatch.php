<?php
/**
 * Eye Of The Mafia - Deathmatch System
 * Final week of each round: escalating XP, rule changes, free cash finale.
 */

require_once __DIR__ . '/init.php';

/**
 * Deathmatch day configurations (Day 1-7)
 */
const DEATHMATCH_DAYS = [
    1 => [
        'xp_multiplier' => 2.0,
        'changes' => [],
    ],
    2 => [
        'xp_multiplier' => 2.0,
        'changes' => [
            'detective_interval' => 20, // minutes
            'detective_range' => 15,
            'scratch_tickets_multiplier' => 2,
            'find_gangsters_shows_city' => true,
            'prison_bribe_limit_increased' => true,
            'prison_bribe_cost_reduced' => true,
        ],
    ],
    3 => [
        'xp_multiplier' => 3.0,
        'changes' => [
            'detective_range' => 20,
            'airport_wait_halved' => true,
            'new_player_start_cash' => 250000,
        ],
    ],
    4 => [
        'xp_multiplier' => 4.0,
        'changes' => [
            'detective_interval' => 15,
            'detective_range' => 25,
            'bullet_store_price' => 50,
            'bullet_store_limit' => 500, // per minute
            'bullet_store_bulk_limit' => 1500,
        ],
    ],
    5 => [
        'xp_multiplier' => 5.0,
        'changes' => [
            'detective_range' => 30,
            'blackmarket_bribe_price' => 100,
        ],
    ],
    6 => [
        'xp_multiplier' => 6.0,
        'changes' => [
            'detective_interval' => 10,
            'detective_range' => 35,
            'airport_wait_third' => true,
            'firearm_upgrade_discount' => 0.10, // 10% of normal
            'silencer_discount' => 0.10,
            'scratch_tickets_multiplier' => 4,
            'small_crimes_success_100' => true,
            'vehicle_theft_success_90' => true,
        ],
    ],
    7 => [
        'xp_multiplier' => 7.0,
        'changes' => [
            'detective_range' => 40,
            'detective_complete_2min' => true,
            'airport_wait_10min' => true,
            'bullet_store_price' => 10,
            'bullet_store_limit' => 2000,
            'bullet_store_bulk_limit' => 6000,
            'free_cash_every_5min' => true,
            'butchie_silence' => true,
        ],
    ],
];

// Final 2 hours overlay
const DEATHMATCH_FINALE = [
    'xp_multiplier' => 25.0,
    'free_cash_per_minute' => 5000000,
    'free_cash_max' => 250000000,
];

/**
 * Check if Deathmatch is currently active
 * Deathmatch = last 7 days of round
 */
function deathmatch_is_active(): bool
{
    $roundEnd = (int) fetch_one("SELECT v FROM settings WHERE k = 'round_end_timestamp'", [], 0);
    if ($roundEnd === 0) return false;
    $now = time();
    return ($now >= ($roundEnd - 7 * 86400)) && ($now < $roundEnd);
}

/**
 * Get current Deathmatch day (1-7) or null if not active
 */
function deathmatch_get_current_day(): ?int
{
    if (!deathmatch_is_active()) return null;

    $roundEnd = (int) fetch_one("SELECT v FROM settings WHERE k = 'round_end_timestamp'", [], 0);
    $now = time();
    $daysRemaining = ceil(($roundEnd - $now) / 86400);
    $day = 8 - $daysRemaining; // Day 1 = 7 days left, Day 7 = 1 day left
    return max(1, min(7, $day));
}

/**
 * Check if we're in the final 2 hours
 */
function deathmatch_is_finale(): bool
{
    if (!deathmatch_is_active()) return false;
    $roundEnd = (int) fetch_one("SELECT v FROM settings WHERE k = 'round_end_timestamp'", [], 0);
    return (time() >= ($roundEnd - 2 * 3600));
}

/**
 * Get Deathmatch config for current day (or finale)
 */
function deathmatch_get_config(): array
{
    if (deathmatch_is_finale()) {
        $config = DEATHMATCH_FINALE;
        $config['day'] = 7;
        $config['finale'] = true;
        return $config;
    }

    $day = deathmatch_get_current_day();
    if (!$day) return [];

    $config = DEATHMATCH_DAYS[$day] ?? [];
    $config['day'] = $day;
    $config['finale'] = false;
    return $config;
}

/**
 * Get the effective XP multiplier (combines deathmatch + weekend + city policy)
 */
function deathmatch_get_xp_multiplier(): float
{
    $config = deathmatch_get_config();
    return $config['xp_multiplier'] ?? 1.0;
}

/**
 * Get Deathmatch status for display
 */
function deathmatch_get_status(): array
{
    if (!deathmatch_is_active()) return ['active' => false];

    $roundEnd = (int) fetch_one("SELECT v FROM settings WHERE k = 'round_end_timestamp'", [], 0);
    $day = deathmatch_get_current_day();
    $finale = deathmatch_is_finale();

    return [
        'active' => true,
        'day' => $day,
        'finale' => $finale,
        'round_ends_at' => date('Y-m-d H:i:s', $roundEnd),
        'remaining_seconds' => max(0, $roundEnd - time()),
        'config' => deathmatch_get_config(),
    ];
}

/**
 * Announce Deathmatch start/day change
 */
function deathmatch_announce(string $message): void
{
    $tickerKey = 'ticker:deathmatch';
    $existing = cache_get($tickerKey) ?? [];
    array_unshift($existing, $message);
    if (count($existing) > 3) $existing = array_slice($existing, 0, 3);
    cache_set($tickerKey, $existing, 86400);

    if (function_exists('discord_notify')) {
        try { discord_notify("💀 **DEATHMATCH**\n$message"); } catch (Throwable $e) {}
    }

    $users = fetch_all('SELECT id FROM users WHERE is_banned = 0');
    foreach ($users as $u) {
        notify((int) $u['id'], $message, 'play.php');
    }
}

/**
 * Daily cron task: announce Deathmatch start/day progression
 */
function deathmatch_cron(): array
{
    $result = ['announced' => false, 'day' => null, 'finale' => false];

    if (!deathmatch_is_active()) return $result;

    $day = deathmatch_get_current_day();
    $roundEnd = (int) fetch_one("SELECT v FROM settings WHERE k = 'round_end_timestamp'", [], 0);
    $lastAnnouncedDay = (int) fetch_one("SELECT v FROM settings WHERE k = 'deathmatch_last_announced_day'", [], 0);

    if ($day !== $lastAnnouncedDay) {
        $messages = [
            1 => '💀 DEATHMATCH BEGINS! 2x XP. Protection capped at 24h. Bullet Stores restock 250k/hr.',
            2 => '💀 Deathmatch Day 2: 2x XP. Detectives 20min intervals, 15 level range. 2x Scratch tickets.',
            3 => '💀 Deathmatch Day 3: 3x XP. Detectives 20 level range. Airport wait halved. New players start with $250k.',
            4 => '💀 Deathmatch Day 4: 4x XP. Detectives 15min intervals, 25 level range. Bullets $50, limit 500/min.',
            5 => '💀 Deathmatch Day 5: 5x XP. Detectives 30 level range. Black Market bribes $100.',
            6 => '💀 Deathmatch Day 6: 6x XP. Detectives 10min intervals, 35 level range. Firearms 10% price. Small crimes 100% success. Vehicle theft 90%.',
            7 => '💀 Deathmatch Day 7: 7x XP. Detectives 2min complete, 40 level range. Airport 10min. Bullets $10, limit 2000/min. Free cash every 5min!',
        ];

        if (isset($messages[$day])) {
            deathmatch_announce($messages[$day]);
            q("INSERT INTO settings (k, v) VALUES ('deathmatch_last_announced_day', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) $day]);
            $result['announced'] = true;
            $result['day'] = $day;
        }
    }

    // Check for finale (last 2 hours)
    $finale = deathmatch_is_finale();
    $finaleAnnounced = (bool) fetch_one("SELECT v FROM settings WHERE k = 'deathmatch_finale_announced'", [], 0);
    if ($finale && !$finaleAnnounced) {
        deathmatch_announce('💀💀 FINAL 2 HOURS! 25x XP! $5,000,000 free cash per minute! Max $250M!');
        q("INSERT INTO settings (k, v) VALUES ('deathmatch_finale_announced', '1') ON DUPLICATE KEY UPDATE v = VALUES(v)");
        $result['finale'] = true;
    }

    return $result;
}

/**
 * Apply Deathmatch modifications to game systems
 * Called from various places to get current modifiers
 */

// Bullet store restock: 250k/hour during deathmatch
function deathmatch_get_bullet_restock_amount(): int
{
    if (!deathmatch_is_active()) return 0;
    return 250000;
}

// Bullet store price override
function deathmatch_get_bullet_store_price(): ?int
{
    $config = deathmatch_get_config();
    return $config['changes']['bullet_store_price'] ?? null;
}

// Bullet store purchase limit
function deathmatch_get_bullet_store_limit(): ?int
{
    $config = deathmatch_get_config();
    return $config['changes']['bullet_store_limit'] ?? null;
}
function deathmatch_get_bullet_store_bulk_limit(): ?int
{
    $config = deathmatch_get_config();
    return $config['changes']['bullet_store_bulk_limit'] ?? null;
}

// Detective interval
function deathmatch_get_detective_interval(): ?int
{
    $config = deathmatch_get_config();
    return $config['changes']['detective_interval'] ?? null;
}
// Detective level range
function deathmatch_get_detective_range(): ?int
{
    $config = deathmatch_get_config();
    return $config['changes']['detective_range'] ?? null;
}
// Airport wait multiplier
function deathmatch_get_airport_wait_multiplier(): float
{
    $config = deathmatch_get_config();
    if (isset($config['changes']['airport_wait_halved']) && $config['changes']['airport_wait_halved']) return 0.5;
    if (isset($config['changes']['airport_wait_third']) && $config['changes']['airport_wait_third']) return 1/3;
    if (isset($config['changes']['airport_wait_10min']) && $config['changes']['airport_wait_10min']) return 10; // special: absolute 10 min
    return 1.0;
}
// Firearm upgrade discount
function deathmatch_get_firearm_upgrade_discount(): float
{
    $config = deathmatch_get_config();
    return $config['changes']['firearm_upgrade_discount'] ?? 1.0;
}
// Silencer discount
function deathmatch_get_silencer_discount(): float
{
    $config = deathmatch_get_config();
    return $config['changes']['silencer_discount'] ?? 1.0;
}
// Scratch tickets multiplier
function deathmatch_get_scratch_tickets_multiplier(): int
{
    $config = deathmatch_get_config();
    return $config['changes']['scratch_tickets_multiplier'] ?? 1;
}
// Small crimes 100% success
function deathmatch_small_crimes_guaranteed(): bool
{
    $config = deathmatch_get_config();
    return isset($config['changes']['small_crimes_success_100']) && $config['changes']['small_crimes_success_100'];
}
// Vehicle theft 90% success
function deathmatch_vehicle_theft_fixed_90(): bool
{
    $config = deathmatch_get_config();
    return isset($config['changes']['vehicle_theft_success_90']) && $config['changes']['vehicle_theft_success_90'];
}
// Black market bribe price
function deathmatch_get_bribe_price(): ?int
{
    $config = deathmatch_get_config();
    return $config['changes']['blackmarket_bribe_price'] ?? null;
}
// New player start cash
function deathmatch_get_new_player_cash(): ?int
{
    $config = deathmatch_get_config();
    return $config['changes']['new_player_start_cash'] ?? null;
}
// Prison bribe modifications
function deathmatch_prison_bribe_modified(): bool
{
    $config = deathmatch_get_config();
    return isset($config['changes']['prison_bribe_limit_increased']) && $config['changes']['prison_bribe_limit_increased'];
}
// Find gangsters shows city
function deathmatch_find_gangsters_shows_city(): bool
{
    $config = deathmatch_get_config();
    return isset($config['changes']['find_gangsters_shows_city']) && $config['changes']['find_gangsters_shows_city'];
}
// Butchie silence
function deathmatch_butchie_silence(): bool
{
    $config = deathmatch_get_config();
    return isset($config['changes']['butchie_silence']) && $config['changes']['butchie_silence'];
}

// Free cash distribution (finale only)
function deathmatch_distribute_finale_cash(): void
{
    if (!deathmatch_is_finale()) return;

    $users = fetch_all('SELECT id, money, bank FROM users WHERE is_banned = 0 AND hospital_until IS NULL AND jail_until IS NULL');
    $cashPerUser = DEATHMATCH_FINALE['free_cash_per_minute'];
    $maxHold = DEATHMATCH_FINALE['free_cash_max'];

    foreach ($users as $u) {
        $total = (int) $u['money'] + (int) $u['bank'];
        if ($total >= $maxHold) continue;
        $add = min($cashPerUser, $maxHold - $total);
        if ($add > 0) {
            add_money((int) $u['id'], $add, 'Deathmatch finale free cash');
        }
    }
}

/**
 * Admin: set round end timestamp (triggers Deathmatch 7 days before)
 */
function deathmatch_set_round_end(int $timestamp): void
{
    q("INSERT INTO settings (k, v) VALUES ('round_end_timestamp', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) $timestamp]);
    // Clear announcement flags
    q("DELETE FROM settings WHERE k IN ('deathmatch_last_announced_day', 'deathmatch_finale_announced')");
}

/**
 * Admin: manually trigger round end (for testing)
 */
function deathmatch_trigger_round_end(): void
{
    $timestamp = time() + 7 * 86400; // 7 days from now
    deathmatch_set_round_end($timestamp);
}

/**
 * Get round end timestamp
 */
function deathmatch_get_round_end(): int
{
    return (int) fetch_one("SELECT v FROM settings WHERE k = 'round_end_timestamp'", [], 0);
}

/**
 * Get days until round end
 */
function deathmatch_get_days_remaining(): int
{
    $roundEnd = deathmatch_get_round_end();
    if ($roundEnd === 0) return 0;
    return max(0, (int) ceil(($roundEnd - time()) / 86400));
}