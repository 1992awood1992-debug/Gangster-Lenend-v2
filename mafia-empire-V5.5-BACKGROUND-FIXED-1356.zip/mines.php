<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$state = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'mines']);
$state = $state ? json_decode($state['state'], true) : null;

function new_mines_game(int $mines = 5): array
{
    $positions = range(0, 24);
    shuffle($positions);
    $minePos = array_slice($positions, 0, $mines);
    return ['mines' => $minePos, 'revealed' => [], 'multiplier' => 1.0];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'start') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('mines.php'); }
        add_money($u['id'], -$stake, 'Mines bet');
        $game = new_mines_game(5);
        $state = ['stake' => $stake] + $game;
    } elseif ($action === 'reveal' && $state && isset($_POST['tile'])) {
        $tile = (int) $_POST['tile'];
        if (in_array($tile, $state['revealed'])) { redirect('mines.php'); }
        $state['revealed'][] = $tile;
        if (in_array($tile, $state['mines'])) {
            // Hit mine
            $result = "Hit a mine on tile " . ($tile + 1) . "!";
            flash($result, 'error');
            insert('casino_bets', ['user_id' => $u['id'], 'game' => 'mines', 'stake' => $state['stake'], 'payout' => 0, 'detail' => $result]);
            q('DELETE FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'mines']);
            $state = null;
        } else {
            // Safe
            $safeCount = count($state['revealed']);
            $state['multiplier'] = round(1.0 + $safeCount * 0.15, 2); // increases each safe
        }
    } elseif ($action === 'cashout' && $state) {
        $payout = (int) round($state['stake'] * $state['multiplier']);
        add_money($u['id'], $payout, 'Mines cashout');
        event_track('casino_won', (int) $payout);
        $result = "Cashed out at {$state['multiplier']}x after " . count($state['revealed']) . " safe tiles.";
        flash($result . " Won " . money($payout), 'success');
        insert('casino_bets', ['user_id' => $u['id'], 'game' => 'mines', 'stake' => $state['stake'], 'payout' => $payout, 'detail' => $result]);
        q('DELETE FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'mines']);
        $state = null;
    }
    if ($state) {
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'mines', json_encode($state)]);
    }
    redirect('mines.php');
}

$page_title = 'Mines';
require __DIR__ . '/includes/header.php';
$u = current_user();
?>
<div class="card">
  <div class="panel-heading">Mines</div>
  <p class="muted small">5x5 grid with 5 hidden mines. Reveal safe tiles to increase the multiplier. Cash out before you hit a mine.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<?php if (!$state): ?>
<div class="card">
  <form method="post" style="max-width:300px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="start">
    <label>Bet (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="50" required></label>
    <button class="btn btn-gold btn-block" type="submit">Start Game</button>
  </form>
</div>
<?php else: ?>
<div class="card">
  <div class="panel-heading">Multiplier: <?= number_format($state['multiplier'], 2) ?>x — Safe: <?= count($state['revealed']) ?> / 20 — Potential: <?= money((int) round($state['stake'] * $state['multiplier'])) ?></div>
  <div class="slot-grid" style="grid-template-columns:repeat(5,1fr);max-width:320px;margin:14px auto">
    <?php for ($i = 0; $i < 25; $i++): $revealed = in_array($i, $state['revealed']); $isMine = in_array($i, $state['mines']); ?>
      <?php if ($revealed): ?>
        <div style="aspect-ratio:1;display:flex;align-items:center;justify-content:center;background:<?= $isMine ? '#c00000' : '#2a8020' ?>;border-radius:8px;font-size:1.5rem"><?= $isMine ? '💣' : '✓' ?></div>
      <?php else: ?>
        <form method="post" data-offline-queue data-offline-label="Mines Reveal" style="margin:0;display:block">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="reveal">
          <input type="hidden" name="tile" value="<?= $i ?>">
          <button type="submit" style="width:100%;height:100%;background:linear-gradient(180deg,var(--panel),var(--bg-2));border:1px solid var(--accent-2);border-radius:8px;font-size:1.5rem;color:var(--muted);cursor:pointer">?</button>
        </form>
      <?php endif; ?>
    <?php endfor; ?>
  </div>
  <div style="text-align:center;margin-top:10px">
    <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="cashout"><button class="btn btn-gold" type="submit">Cash Out</button></form>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>