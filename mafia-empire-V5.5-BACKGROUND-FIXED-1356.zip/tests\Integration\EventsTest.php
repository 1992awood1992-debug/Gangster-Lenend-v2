<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Regression coverage for the events subsystem.
 *
 * The events tables used to be created by an orphaned seed script, so fresh
 * installs fataled on events.php. They are now part of the schema pipeline and
 * seeded idempotently; these tests pin both the seeding and the reward flow.
 */
final class EventsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        require_once dirname(__DIR__, 2) . '/includes/event_seed.php';
        require_once dirname(__DIR__, 2) . '/includes/events.php';
    }

    /** The daily challenge that counts completed missions. */
    private function dailyMissionChallenge(): array
    {
        $c = fetch("
            SELECT ec.* FROM event_challenges ec
            JOIN events e ON e.id = ec.event_id
            WHERE e.type = 'daily' AND ec.metric = 'missions_done'
            ORDER BY ec.sort_order LIMIT 1
        ");
        $this->assertNotNull($c, 'a daily missions_done challenge should be seeded');
        return $c;
    }

    public function testDefaultEventsAreSeededIdempotently(): void
    {
        event_seed_defaults();
        $events = (int) fetch_one('SELECT COUNT(*) FROM events');
        $challenges = (int) fetch_one('SELECT COUNT(*) FROM event_challenges');
        $this->assertGreaterThan(0, $events);
        $this->assertGreaterThan(0, $challenges);

        // Re-running must not duplicate anything.
        event_seed_defaults();
        $this->assertSame($events, (int) fetch_one('SELECT COUNT(*) FROM events'));
        $this->assertSame($challenges, (int) fetch_one('SELECT COUNT(*) FROM event_challenges'));

        // Recurring + seasonal buckets are all represented.
        $this->assertSame(1, (int) fetch_one("SELECT COUNT(*) FROM events WHERE type = 'daily'"));
        $this->assertSame(1, (int) fetch_one("SELECT COUNT(*) FROM events WHERE type = 'weekly'"));
        $this->assertGreaterThan(0, (int) fetch_one("SELECT COUNT(*) FROM events WHERE type = 'seasonal'"));
    }

    public function testTrackingMetricAdvancesAndCompletesChallenge(): void
    {
        $user = $this->makeUser();
        $challenge = $this->dailyMissionChallenge();

        event_track_metric((int) $user['id'], 'missions_done', (int) $challenge['target_value']);

        $row = fetch(
            'SELECT * FROM user_event_progress WHERE user_id = ? AND challenge_id = ?',
            [$user['id'], $challenge['id']]
        );
        $this->assertNotNull($row, 'tracking should create a progress row');
        $this->assertSame((int) $challenge['target_value'], (int) $row['current_value']);
        $this->assertSame(1, (int) $row['completed']);
    }

    public function testClaimRewardGrantsRewardsAndMarksClaimed(): void
    {
        $user = $this->makeUser(['money' => 1000]);
        $challenge = $this->dailyMissionChallenge();
        $progressId = insert('user_event_progress', [
            'user_id'       => $user['id'],
            'event_id'      => (int) $challenge['event_id'],
            'challenge_id'  => (int) $challenge['id'],
            'current_value' => (int) $challenge['target_value'],
            'completed'     => 1,
            'claimed'       => 0,
        ]);

        $_SESSION['uid'] = (int) $user['id'];
        unset($GLOBALS['__current_user']);

        try {
            $result = event_claim_reward((int) $challenge['id']);
            $this->assertTrue($result['ok'], $result['error'] ?? 'claim failed');
        } finally {
            unset($GLOBALS['__current_user'], $_SESSION['uid']);
        }

        $this->assertSame(1, (int) fetch('SELECT claimed FROM user_event_progress WHERE id = ?', [$progressId])['claimed']);
        $this->assertGreaterThan(1000, (int) fetch('SELECT money FROM users WHERE id = ?', [$user['id']])['money']);
        $this->assertGreaterThan(0, (int) fetch_one('SELECT COUNT(*) FROM event_rewards_log WHERE user_id = ?', [$user['id']], 0));

        // Claiming twice is rejected.
        $_SESSION['uid'] = (int) $user['id'];
        unset($GLOBALS['__current_user']);
        try {
            $again = event_claim_reward((int) $challenge['id']);
        } finally {
            unset($GLOBALS['__current_user'], $_SESSION['uid']);
        }
        $this->assertFalse($again['ok']);
    }

    public function testClaimRewardGrantsItemRewards(): void
    {
        $itemId = (int) fetch_one('SELECT id FROM items ORDER BY id ASC LIMIT 1', [], 0);
        if ($itemId <= 0) {
            $this->markTestSkipped('no items seeded');
        }

        $user = $this->makeUser();
        $challenge = $this->dailyMissionChallenge();
        $originalRewards = $challenge['reward_items'];

        try {
            q('UPDATE event_challenges SET reward_items = ? WHERE id = ?', [
                json_encode([['item_id' => $itemId, 'qty' => 3, 'chance' => 1.0]]),
                (int) $challenge['id'],
            ]);

            insert('user_event_progress', [
                'user_id'       => $user['id'],
                'event_id'      => (int) $challenge['event_id'],
                'challenge_id'  => (int) $challenge['id'],
                'current_value' => (int) $challenge['target_value'],
                'completed'     => 1,
                'claimed'       => 0,
            ]);

            $_SESSION['uid'] = (int) $user['id'];
            unset($GLOBALS['__current_user']);
            try {
                $result = event_claim_reward((int) $challenge['id']);
            } finally {
                unset($GLOBALS['__current_user'], $_SESSION['uid']);
            }

            $this->assertTrue($result['ok'], $result['error'] ?? 'claim failed');
            $this->assertSame(
                3,
                (int) fetch_one('SELECT qty FROM user_items WHERE user_id = ? AND item_id = ?', [(int) $user['id'], $itemId], 0)
            );
        } finally {
            q('UPDATE event_challenges SET reward_items = ? WHERE id = ?', [$originalRewards, (int) $challenge['id']]);
        }
    }
}
