<?php
/**
 * Eye Of The Mafia - Social Features
 * Trading, Crew Chat, Hitlist, Bounties
 *
 * Column names here follow sql/migrations/5.sql (the live contract):
 *   hitlist          -> reward_money / reward_points / reward_bullets, status 'open'
 *   bounties         -> creator_id, reward_money, reason, status 'open'
 *   crew_messages    -> sender_id (not user_id)
 *   social_notif.    -> type (enum) + related_type + related_id
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/game.php';

/**
 * Does a player hold at least the requested quantity of each item?
 *
 * @param array<int,array{item_id:int,qty:int}> $items
 */
function user_owns_items(int $userId, array $items): bool
{
    foreach ($items as $entry) {
        if (!is_array($entry)) continue;
        $itemId = (int) ($entry['item_id'] ?? 0);
        $qty = (int) ($entry['qty'] ?? 0);
        if ($itemId <= 0 || $qty <= 0) continue;
        $owned = (int) fetch_one('SELECT COALESCE(SUM(qty), 0) FROM user_items WHERE user_id = ? AND item_id = ?', [$userId, $itemId], 0);
        if ($owned < $qty) return false;
    }
    return true;
}

/**
 * Human-readable summary of a trade's item list, e.g. "Revolver x2, Knife x1".
 */
function trade_items_summary(array $items): string
{
    $parts = [];
    foreach ($items as $entry) {
        if (!is_array($entry)) continue;
        $itemId = (int) ($entry['item_id'] ?? 0);
        $qty = (int) ($entry['qty'] ?? 0);
        if ($itemId <= 0 || $qty <= 0) continue;
        $name = fetch_one('SELECT name FROM items WHERE id = ?', [$itemId]);
        $parts[] = ($name ?: ('Item #' . $itemId)) . ' x' . $qty;
    }
    return implode(', ', $parts);
}

/**
 * Create a trade between sender and recipient
 */
function trade_create(int $senderId, int $recipientId, array $senderItems, int $senderMoney, int $senderBullets, array $recipientItems, int $recipientMoney, int $recipientBullets): ?int
{
    // Validate users exist
    $sender = fetch('SELECT id FROM users WHERE id = ?', [$senderId]);
    $recipient = fetch('SELECT id FROM users WHERE id = ?', [$recipientId]);
    if (!$sender || !$recipient || $senderId === $recipientId) {
        return null;
    }

    // The sender can only offer what they actually hold.
    if (!user_owns_items($senderId, $senderItems)) {
        return null;
    }

    $tradeId = insert('trades', [
        'sender_id' => $senderId,
        'recipient_id' => $recipientId,
        'status' => 'pending',
        'sender_items' => json_encode($senderItems),
        'sender_money' => max(0, $senderMoney),
        'sender_bullets' => max(0, $senderBullets),
        'recipient_items' => json_encode($recipientItems),
        'recipient_money' => max(0, $recipientMoney),
        'recipient_bullets' => max(0, $recipientBullets),
        'created_at' => date('Y-m-d H:i:s'),
        'expires_at' => date('Y-m-d H:i:s', time() + 86400), // 24 hours
    ]);

    // Create notification
    social_notify($recipientId, 'Trade Offer', 'You received a trade offer from another player.', 'trade_request', $tradeId, 'trade');

    return $tradeId;
}

/**
 * Get trade by ID with user permissions
 */
function trade_get(int $tradeId, int $userId): ?array
{
    $trade = fetch('SELECT t.*, u1.username as sender_name, u2.username as recipient_name
                   FROM trades t
                   LEFT JOIN users u1 ON t.sender_id = u1.id
                   LEFT JOIN users u2 ON t.recipient_id = u2.id
                   WHERE t.id = ?', [$tradeId]);
    if (!$trade) return null;
    if ((int)$trade['sender_id'] !== $userId && (int)$trade['recipient_id'] !== $userId) {
        return null;
    }
    $trade['sender_items'] = json_decode($trade['sender_items'] ?? '[]', true);
    $trade['recipient_items'] = json_decode($trade['recipient_items'] ?? '[]', true);
    return $trade;
}

/**
 * Move a list of inventory items between two players.
 *
 * Each entry is ["item_id" => <items.id>, "qty" => <n>]. Returns false (without
 * committing anything on its own) when the source no longer holds enough; the
 * caller runs inside a transaction and rolls back on a false return.
 */
function trade_transfer_items(int $fromUser, int $toUser, array $items): bool
{
    foreach ($items as $entry) {
        if (!is_array($entry)) continue;
        $itemId = (int) ($entry['item_id'] ?? 0);
        $qty = (int) ($entry['qty'] ?? 0);
        if ($itemId <= 0 || $qty <= 0) continue;

        $owned = (int) fetch_one('SELECT COALESCE(SUM(qty), 0) FROM user_items WHERE user_id = ? AND item_id = ?', [$fromUser, $itemId], 0);
        if ($owned < $qty) return false;

        // Take from unequipped stacks first, then equipped ones if needed.
        $rows = fetch_all('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ? ORDER BY equipped ASC, id ASC', [$fromUser, $itemId]);
        $remaining = $qty;
        foreach ($rows as $row) {
            if ($remaining <= 0) break;
            $take = min($remaining, (int) $row['qty']);
            $left = (int) $row['qty'] - $take;
            if ($left <= 0) {
                q('DELETE FROM user_items WHERE id = ?', [(int) $row['id']]);
            } else {
                q('UPDATE user_items SET qty = ? WHERE id = ?', [$left, (int) $row['id']]);
            }
            $remaining -= $take;
        }
        if ($remaining > 0) return false;

        // Merge into the recipient's existing unequipped stack when possible.
        $dest = fetch('SELECT id FROM user_items WHERE user_id = ? AND item_id = ? AND equipped = 0 ORDER BY id ASC LIMIT 1', [$toUser, $itemId]);
        if ($dest) {
            q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [$qty, (int) $dest['id']]);
        } else {
            insert('user_items', ['user_id' => $toUser, 'item_id' => $itemId, 'qty' => $qty, 'equipped' => 0]);
        }
    }
    return true;
}

/**
 * Accept a trade (recipient only). Settles cash, bullets and inventory so each
 * side receives exactly what the other offered.
 */
function trade_accept(int $tradeId, int $userId): bool
{
    $trade = trade_get($tradeId, $userId);
    if (!$trade || (int) $trade['recipient_id'] !== $userId) return false;
    if ($trade['status'] !== 'pending') return false;

    // An offer past its expiry may not be accepted.
    if (strtotime((string) $trade['expires_at']) < time()) {
        q('UPDATE trades SET status = "expired" WHERE id = ?', [$tradeId]);
        return false;
    }

    $senderId = (int) $trade['sender_id'];
    $recipientId = (int) $trade['recipient_id'];
    $senderMoney = max(0, (int) $trade['sender_money']);
    $senderBullets = max(0, (int) $trade['sender_bullets']);
    $recipientMoney = max(0, (int) $trade['recipient_money']);
    $recipientBullets = max(0, (int) $trade['recipient_bullets']);
    $senderItems = is_array($trade['sender_items']) ? $trade['sender_items'] : [];
    $recipientItems = is_array($trade['recipient_items']) ? $trade['recipient_items'] : [];

    $sender = fetch('SELECT money, bullets FROM users WHERE id = ?', [$senderId]);
    $recipient = fetch('SELECT money, bullets FROM users WHERE id = ?', [$recipientId]);
    if (!$sender || !$recipient) return false;

    // Both parties must still hold what they put on the table.
    if ((int) $sender['money'] < $senderMoney || (int) $sender['bullets'] < $senderBullets) return false;
    if ((int) $recipient['money'] < $recipientMoney || (int) $recipient['bullets'] < $recipientBullets) return false;
    if (!user_owns_items($senderId, $senderItems) || !user_owns_items($recipientId, $recipientItems)) return false;

    db()->beginTransaction();
    try {
        if (!trade_transfer_items($senderId, $recipientId, $senderItems)) { db()->rollBack(); return false; }
        if (!trade_transfer_items($recipientId, $senderId, $recipientItems)) { db()->rollBack(); return false; }

        // Sender pays out, then receives the recipient's offer.
        q('UPDATE users SET money = money - ?, bullets = bullets - ? WHERE id = ?', [$senderMoney, $senderBullets, $senderId]);
        q('UPDATE users SET money = money + ?, bullets = bullets + ? WHERE id = ?', [$recipientMoney, $recipientBullets, $senderId]);
        // Recipient pays out, then receives the sender's offer.
        q('UPDATE users SET money = money - ?, bullets = bullets - ? WHERE id = ?', [$recipientMoney, $recipientBullets, $recipientId]);
        q('UPDATE users SET money = money + ?, bullets = bullets + ? WHERE id = ?', [$senderMoney, $senderBullets, $recipientId]);

        q('UPDATE trades SET status = "accepted", updated_at = NOW(), completed_at = NOW() WHERE id = ?', [$tradeId]);
        db()->commit();
    } catch (Exception $e) {
        db()->rollBack();
        return false;
    }

    social_notify($senderId, 'Trade Accepted', 'Your trade offer was accepted and settled.', 'trade_accepted', $tradeId, 'trade');
    return true;
}

/**
 * Expire stale social contracts and refund any escrowed value.
 *
 * Runs from cron. Idempotent: each row settles once because its status flips to
 * "expired". Returns a per-category summary.
 *
 * @return array<string,int>
 */
function social_cleanup_expired(): array
{
    $hitsRefunded = 0;
    foreach (fetch_all("SELECT id, placer_id, reward_money, reward_points, reward_bullets FROM hitlist WHERE status = 'open' AND expires_at < NOW()") as $h) {
        if ((int) $h['reward_money'] > 0) add_money((int) $h['placer_id'], (int) $h['reward_money'], 'Hitlist expired: refund');
        if ((int) $h['reward_points'] > 0) add_points((int) $h['placer_id'], (int) $h['reward_points']);
        if ((int) $h['reward_bullets'] > 0) q('UPDATE users SET bullets = bullets + ? WHERE id = ?', [(int) $h['reward_bullets'], (int) $h['placer_id']]);
        q("UPDATE hitlist SET status = 'expired' WHERE id = ?", [(int) $h['id']]);
        notify((int) $h['placer_id'], 'Your hitlist contract expired. The reward was returned to you.', 'hitlist.php');
        $hitsRefunded++;
    }

    $bountiesRefunded = 0;
    foreach (fetch_all("SELECT id, creator_id, reward_money, reward_points, reward_bullets FROM bounties WHERE status = 'open' AND expires_at < NOW()") as $b) {
        if ((int) $b['reward_money'] > 0) add_money((int) $b['creator_id'], (int) $b['reward_money'], 'Bounty expired: refund');
        if ((int) $b['reward_points'] > 0) add_points((int) $b['creator_id'], (int) $b['reward_points']);
        if ((int) $b['reward_bullets'] > 0) q('UPDATE users SET bullets = bullets + ? WHERE id = ?', [(int) $b['reward_bullets'], (int) $b['creator_id']]);
        q("UPDATE bounties SET status = 'expired' WHERE id = ?", [(int) $b['id']]);
        notify((int) $b['creator_id'], 'Your bounty expired. The reward was returned to you.', 'bounties.php');
        $bountiesRefunded++;
    }

    $tradesExpired = q("UPDATE trades SET status = 'expired' WHERE status = 'pending' AND expires_at < NOW()")->rowCount();

    return ['hitlist_refunded' => $hitsRefunded, 'bounties_refunded' => $bountiesRefunded, 'trades_expired' => $tradesExpired];
}

/**
 * Decline/cancel a trade
 */
function trade_decline(int $tradeId, int $userId): bool
{
    $trade = trade_get($tradeId, $userId);
    if (!$trade) return false;
    if ((int)$trade['recipient_id'] !== $userId && (int)$trade['sender_id'] !== $userId) return false;
    if ($trade['status'] !== 'pending') return false;

    q('UPDATE trades SET status = "declined", updated_at = NOW() WHERE id = ?', [$tradeId]);
    $notifyUser = ((int)$trade['recipient_id'] === $userId) ? (int)$trade['sender_id'] : (int)$trade['recipient_id'];
    social_notify($notifyUser, 'Trade Declined', 'Your trade offer was declined.', 'trade_declined', $tradeId, 'trade');
    return true;
}

/**
 * Get pending trades for user
 */
function trades_get_pending(int $userId): array
{
    $rows = fetch_all('SELECT t.*, u1.username as sender_name
                   FROM trades t
                   LEFT JOIN users u1 ON t.sender_id = u1.id
                   WHERE t.recipient_id = ? AND t.status = "pending" AND t.expires_at > NOW()
                   ORDER BY t.created_at DESC', [$userId]);
    $trades = [];
    foreach ($rows as $t) {
        $t['sender_items'] = json_decode($t['sender_items'] ?? '[]', true);
        $trades[] = $t;
    }
    return $trades;
}

/**
 * Send a message to a crew's chat.
 */
function crew_message_send(int $userId, int $crewId, string $message): ?int
{
    // Must be a member of the crew.
    $member = fetch('SELECT user_id FROM crew_members WHERE user_id = ? AND crew_id = ?', [$userId, $crewId]);
    if (!$member) {
        return null;
    }
    $message = trim($message);
    if ($message === '') {
        return null;
    }

    $messageId = insert('crew_messages', [
        'crew_id' => $crewId,
        'sender_id' => $userId,
        'message' => $message,
        'created_at' => date('Y-m-d H:i:s'),
    ]);

    if ($messageId) {
        crew_message_notify_mentions($userId, $crewId, $message, (int) $messageId);
    }

    return $messageId;
}

/**
 * Notify crew members mentioned as @username in a chat message.
 *
 * Only current members of the same crew are notified, and never the sender.
 *
 * @return int number of members notified
 */
function crew_message_notify_mentions(int $senderId, int $crewId, string $message, ?int $messageId = null): int
{
    if (!preg_match_all('/@([A-Za-z0-9_]{3,20})/', $message, $m)) {
        return 0;
    }
    $names = array_values(array_unique($m[1]));
    if (!$names) return 0;

    $sender = fetch('SELECT username FROM users WHERE id = ?', [$senderId]);
    $senderName = $sender['username'] ?? 'A crewmate';
    $excerpt = substr($message, 0, 120);

    $notified = 0;
    foreach ($names as $name) {
        $member = fetch('
            SELECT u.id
            FROM users u
            JOIN crew_members cm ON cm.user_id = u.id
            WHERE cm.crew_id = ? AND u.username = ? AND u.id <> ?
            LIMIT 1', [$crewId, $name, $senderId]);
        if (!$member) continue;
        social_notify((int) $member['id'], 'Crew mention', $senderName . ' mentioned you in crew chat: ' . $excerpt, 'chat_mention', $messageId, 'chat');
        $notified++;
    }
    return $notified;
}

/**
 * Get a crew's messages in chronological order.
 */
function crew_messages_get(int $crewId, int $limit = 50, int $offset = 0): array
{
    $rows = fetch_all('SELECT cm.*, u.username
                   FROM crew_messages cm
                   LEFT JOIN users u ON cm.sender_id = u.id
                   WHERE cm.crew_id = ?
                   ORDER BY cm.created_at DESC
                   LIMIT ? OFFSET ?', [$crewId, $limit, $offset]);
    return array_reverse($rows); // Chronological order
}

/**
 * Mark messages as read (used for unread badges).
 */
function crew_messages_mark_read(int $userId, int $crewId, array $messageIds): void
{
    foreach ($messageIds as $mid) {
        try {
            insert_ignore('crew_message_reads', [
                'user_id' => $userId,
                'crew_id' => $crewId,
                'message_id' => $mid,
                'read_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (Exception $e) {}
    }
}

/**
 * Count unread crew chat messages across every crew the user belongs to.
 */
function crew_messages_unread_count(int $userId): int
{
    try {
        return (int) fetch_one('
            SELECT COUNT(*)
            FROM crew_messages cm
            JOIN crew_members cmem ON cmem.crew_id = cm.crew_id AND cmem.user_id = ?
            LEFT JOIN crew_message_reads r ON r.message_id = cm.id AND r.user_id = ?
            WHERE cm.sender_id <> ? AND r.id IS NULL', [$userId, $userId, $userId], 0);
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Place a hit (a bounty on the hitlist). Deducts the reward from the placer.
 */
function hitlist_add(int $placerId, int $targetId, int $bounty): ?int
{
    if ($placerId === $targetId || $bounty <= 0) return null;
    $target = fetch('SELECT id FROM users WHERE id = ?', [$targetId]);
    if (!$target) return null;

    $placer = fetch('SELECT money FROM users WHERE id = ?', [$placerId]);
    if (!$placer || (int)$placer['money'] < $bounty) return null;

    db()->beginTransaction();
    try {
        q('UPDATE users SET money = money - ? WHERE id = ?', [$bounty, $placerId]);

        $hitId = insert('hitlist', [
            'placer_id' => $placerId,
            'target_id' => $targetId,
            'reward_money' => $bounty,
            'status' => 'open',
            'created_at' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', time() + 172800), // 48 hours
        ]);

        db()->commit();
        social_notify($targetId, 'Hit Placed', 'A bounty has been placed on your head!', 'hitlist_placed', $hitId, 'hitlist');
        return $hitId;
    } catch (Exception $e) {
        db()->rollBack();
        return null;
    }
}

/**
 * Claim a hit (pay the reward to the claimer).
 */
function hitlist_claim(int $claimerId, int $hitId): bool
{
    $hit = fetch('SELECT * FROM hitlist WHERE id = ?', [$hitId]);
    if (!$hit || $hit['status'] !== 'open') return false;
    if ((int)$hit['target_id'] === $claimerId) return false; // can't claim your own hit

    db()->beginTransaction();
    try {
        q('UPDATE users SET money = money + ? WHERE id = ?', [(int)$hit['reward_money'], $claimerId]);
        q('UPDATE hitlist SET status = "claimed", claimed_by = ?, claimed_at = NOW() WHERE id = ?', [$claimerId, $hitId]);
        db()->commit();
        social_notify((int)$hit['placer_id'], 'Hit Claimed', 'Your hit has been collected!', 'hitlist_claimed', $hitId, 'hitlist');
        return true;
    } catch (Exception $e) {
        db()->rollBack();
        return false;
    }
}

/**
 * Get the open hitlist, richest first.
 */
function hitlist_get_active(): array
{
    return fetch_all('SELECT h.*, t.username as target_name, p.username as placer_name
                  FROM hitlist h
                  LEFT JOIN users t ON h.target_id = t.id
                  LEFT JOIN users p ON h.placer_id = p.id
                  WHERE h.status = "open" AND h.expires_at > NOW()
                  ORDER BY h.reward_money DESC, h.created_at DESC', []);
}

/**
 * Create a bounty on the board. Escrows the reward from the placer and returns
 * the new bounty id, or null when the request is invalid (self-target, unknown
 * target, or insufficient funds).
 */
function bounty_create(int $targetId, int $amount, int $placerId, string $reason = ''): ?int
{
    if ($amount <= 0 || $targetId === $placerId) return null;
    $target = fetch('SELECT id FROM users WHERE id = ?', [$targetId]);
    if (!$target) return null;

    $placer = fetch('SELECT money FROM users WHERE id = ?', [$placerId]);
    if (!$placer || (int) $placer['money'] < $amount) return null;

    db()->beginTransaction();
    try {
        q('UPDATE users SET money = money - ? WHERE id = ?', [$amount, $placerId]);

        $bountyId = insert('bounties', [
            'target_id' => $targetId,
            'creator_id' => $placerId,
            'reward_money' => $amount,
            'reason' => substr($reason, 0, 255),
            'status' => 'open',
            'created_at' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', time() + 172800),
        ]);

        db()->commit();
        social_notify($targetId, 'Bounty Placed', 'A bounty has been placed on your head!', 'bounty_placed', $bountyId, 'bounty');
        return $bountyId;
    } catch (Exception $e) {
        db()->rollBack();
        return null;
    }
}

/**
 * Get active bounties, richest first.
 */
function bounties_get_active(): array
{
    return fetch_all('SELECT b.*, t.username as target_name, p.username as creator_name
                  FROM bounties b
                  LEFT JOIN users t ON b.target_id = t.id
                  LEFT JOIN users p ON b.creator_id = p.id
                  WHERE b.status = "open" AND b.expires_at > NOW()
                  ORDER BY b.reward_money DESC, b.created_at DESC', []);
}

/**
 * Claim a bounty (pay the reward to the claimer).
 */
function bounty_claim(int $claimerId, int $bountyId): bool
{
    $bounty = fetch('SELECT * FROM bounties WHERE id = ?', [$bountyId]);
    if (!$bounty || $bounty['status'] !== 'open') return false;
    if ((int)$bounty['target_id'] === $claimerId) return false; // can't claim your own bounty

    db()->beginTransaction();
    try {
        q('UPDATE users SET money = money + ? WHERE id = ?', [(int)$bounty['reward_money'], $claimerId]);
        q('UPDATE bounties SET status = "claimed", claimed_by = ?, claimed_at = NOW() WHERE id = ?', [$claimerId, $bountyId]);
        db()->commit();
        social_notify((int)$bounty['creator_id'], 'Bounty Claimed', 'Your bounty has been collected!', 'bounty_claimed', $bountyId, 'bounty');
        return true;
    } catch (Exception $e) {
        db()->rollBack();
        return false;
    }
}

/**
 * Create a social notification.
 *
 * @param string $type       one of the social_notifications.type enum values
 * @param string $relatedType free-form origin: trade | hitlist | bounty | chat
 */
function social_notify(int $userId, string $title, string $message, string $type = 'trade_request', ?int $referenceId = null, string $relatedType = ''): ?int
{
    return insert('social_notifications', [
        'user_id' => $userId,
        'type' => $type,
        'title' => $title,
        'message' => $message,
        'related_type' => $relatedType,
        'related_id' => $referenceId,
        'is_read' => 0,
        'created_at' => date('Y-m-d H:i:s'),
    ]);
}

/**
 * Get user notifications
 */
function social_notifications_get(int $userId, int $limit = 20): array
{
    return fetch_all('SELECT * FROM social_notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?', [$userId, $limit]);
}

/**
 * Mark notification as read
 */
function social_notification_mark_read(int $notificationId, int $userId): void
{
    q('UPDATE social_notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [$notificationId, $userId]);
}

/**
 * Get unread notification count
 */
function social_notifications_unread_count(int $userId): int
{
    return (int) fetch_one('SELECT COUNT(*) FROM social_notifications WHERE user_id = ? AND is_read = 0', [$userId], 0);
}

/**
 * Mark every social notification for a user as read.
 */
function social_notifications_mark_all_read(int $userId): void
{
    q('UPDATE social_notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0', [$userId]);
}

/**
 * Resolve the page a social notification should link to, based on its type.
 */
function social_notification_link(array $notification): string
{
    switch ($notification['type'] ?? '') {
        case 'trade_request':
        case 'trade_accepted':
        case 'trade_declined':
        case 'trade_completed':
            return 'trades.php';
        case 'bounty_placed':
        case 'bounty_claimed':
            return 'bounties.php';
        case 'hitlist_placed':
        case 'hitlist_claimed':
            return 'hitlist.php';
        case 'chat_mention':
            return 'crew_chat.php';
        default:
            return 'notifications.php';
    }
}

/* --------------------------- Crew War Functions -------------------------- */

if (!function_exists('crew_level')) {
/**
 * Compute crew level from total XP minus spent XP.
 */
function crew_level(int $xp, int $xpSpent): int
{
    return max(1, (int) floor(sqrt(max(0, $xp - $xpSpent) / 100)) + 1);
}
}

if (!function_exists('crew_relation')) {
/**
 * Check if two crews have a diplomatic relation (allied / NAP).
 */
function crew_relation(int $crewId1, int $crewId2): ?array
{
    return null;
}
}

if (!function_exists('active_war_between')) {
/**
 * Check if there is an active war between two crews.
 */
function active_war_between(int $crewId1, int $crewId2): ?array
{
    return null;
}
}

if (!function_exists('add_crew_xp')) {
/**
 * Add XP to a crew (no-op if crews table is absent).
 */
function add_crew_xp(int $crewId, int $xp): void
{
    try {
        q('UPDATE crews SET xp = xp + ? WHERE id = ?', [$xp, $crewId]);
    } catch (Throwable $e) {}
}
}

if (!function_exists('notify_crew')) {
/**
 * Send a notification to every member of a crew.
 */
function notify_crew(int $crewId, string $message, string $link = ''): void
{
    try {
        $members = fetch_all('SELECT user_id FROM crew_members WHERE crew_id = ?', [$crewId]);
        foreach ($members as $m) {
            notify((int) $m['user_id'], 'Crew Alert', $message, $link);
        }
    } catch (Throwable $e) {}
}
}

if (!function_exists('score_war_kill')) {
/**
 * Record a kill for crew war scoring. Updates the active war score between
 * the attacker's and victim's crews.
 */
function score_war_kill(int $attackerId, int $victimId): void
{
    try {
        $attacker = fetch('SELECT crew_id FROM users WHERE id = ?', [$attackerId]);
        $victim = fetch('SELECT crew_id FROM users WHERE id = ?', [$victimId]);
        if (!$attacker || !$victim) {
            return;
        }
        if ((int) $attacker['crew_id'] <= 0 || (int) $victim['crew_id'] <= 0) {
            return;
        }
        if ((int) $attacker['crew_id'] === (int) $victim['crew_id']) {
            return;
        }
        $war = fetch('SELECT id, attacker_id, defender_id, attacker_score, defender_score FROM crew_wars WHERE status IN ("declared","active") AND ((attacker_id = ? AND defender_id = ?) OR (attacker_id = ? AND defender_id = ?)) LIMIT 1', [(int) $attacker['crew_id'], (int) $victim['crew_id'], (int) $victim['crew_id'], (int) $attacker['crew_id']]);
        if (!$war) {
            return;
        }
        $newScore = (int) ($war['attacker_id'] === $attacker['crew_id'] ? $war['attacker_score'] : $war['defender_score']) + 1;
        if ((int) $war['attacker_id'] === (int) $attacker['crew_id']) {
            q('UPDATE crew_wars SET attacker_score = ? WHERE id = ?', [$newScore, (int) $war['id']]);
        } else {
            q('UPDATE crew_wars SET defender_score = ? WHERE id = ?', [$newScore, (int) $war['id']]);
        }
    } catch (Throwable $e) {}
}
}

if (!function_exists('finish_expired_wars')) {
/**
 * Finish expired crew wars and record wins/losses.
 */
function finish_expired_wars(): int
{
    try {
        $wars = fetch_all('SELECT id, attacker_id, defender_id, attacker_score, defender_score FROM crew_wars WHERE status IN ("declared","active") AND ends_at < NOW()');
        foreach ($wars as $w) {
            $winnerId = null;
            if ((int) $w['attacker_score'] > (int) $w['defender_score']) {
                $winnerId = (int) $w['attacker_id'];
                q('UPDATE crews SET wars_won = wars_won + 1 WHERE id = ?', [$winnerId]);
                q('UPDATE crews SET wars_lost = wars_lost + 1 WHERE id = ?', [(int) $w['defender_id']]);
            } elseif ((int) $w['defender_score'] > (int) $w['attacker_score']) {
                $winnerId = (int) $w['defender_id'];
                q('UPDATE crews SET wars_won = wars_won + 1 WHERE id = ?', [$winnerId]);
                q('UPDATE crews SET wars_lost = wars_lost + 1 WHERE id = ?', [(int) $w['attacker_id']]);
            }
            q('UPDATE crew_wars SET status = "finished", winner_id = ? WHERE id = ?', [$winnerId, (int) $w['id']]);
        }
        return count($wars);
    } catch (Throwable $e) {
        return 0;
    }
}
}

if (!function_exists('crew_has_perk')) {
/**
 * Check if a crew has purchased a perk.
 */
function crew_has_perk(int $crewId, string $perk): bool
{
    return false;
}
}

if (!function_exists('crew_max_members')) {
/**
 * Maximum crew size.
 */
function crew_max_members(int $crewId): int
{
    return 50;
}
}

/**
 * Helper for INSERT IGNORE
 */
function insert_ignore(string $table, array $data): int
{
    $cols = array_keys($data);
    $placeholders = array_fill(0, count($cols), '?');
    $sql = 'INSERT IGNORE INTO ' . $table . ' (' . implode(',', $cols) . ') VALUES (' . implode(',', $placeholders) . ')';
    $stmt = db()->prepare($sql);
    $stmt->execute(array_values($data));
    return (int) db()->lastInsertId();
}
