<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Discord response builders and signature verification (pure parts).
 */
final class DiscordTest extends TestCase
{
    public function testPingResponseIsTypeOne(): void
    {
        $this->assertSame(['type' => 1], discord_ping_response());
    }

    public function testMessageResponseIsTypeFour(): void
    {
        $this->assertSame(4, discord_message_response('hi')['type']);
        $this->assertSame('hi', discord_message_response('hi')['data']['content']);
        $this->assertArrayNotHasKey('flags', discord_message_response('hi')['data']);
        $this->assertSame(64, discord_message_response('hi', true)['data']['flags']);
    }

    public function testEmbedResponseCarriesBrandColour(): void
    {
        $r = discord_embed_response('Title', [['name' => 'A', 'value' => 'B']], 'desc');
        $this->assertSame(4, $r['type']);
        $embed = $r['data']['embeds'][0];
        $this->assertSame('Title', $embed['title']);
        $this->assertSame(0xD9A441, $embed['color']);
        $this->assertSame('desc', $embed['description']);
        $this->assertSame('B', $embed['fields'][0]['value']);
    }

    public function testSignatureVerificationRejectsGarbage(): void
    {
        $this->assertFalse(discord_verify_signature('123', 'body', 'deadbeef'));
        $this->assertFalse(discord_verify_signature('', '', ''));
    }

    public function testNotifyFailsCleanlyWhenUnconfigured(): void
    {
        // DISCORD_WEBHOOK_URL is empty unless supplied via the environment.
        if (discord_webhook_url() === '') {
            [$ok, $code] = discord_notify('hello');
            $this->assertFalse($ok);
            $this->assertSame(0, $code);
        } else {
            $this->assertTrue(discord_enabled());
        }
    }

    public function testAdminAllowListDefaultsToEmpty(): void
    {
        $this->assertIsArray(discord_admin_ids());
    }
}
