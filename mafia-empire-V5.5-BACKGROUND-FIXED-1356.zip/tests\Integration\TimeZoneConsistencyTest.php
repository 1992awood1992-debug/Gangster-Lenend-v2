<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * The database layer aligns MySQL's session clock with PHP's, so the app's
 * now() helper and SQL NOW() always refer to the same instant. Several game
 * rules (crew wars, cooldowns, prune tasks) compare SQL NOW() against
 * PHP-generated timestamps, so a skew here would silently break them.
 */
final class TimeZoneConsistencyTest extends TestCase
{
    public function testSqlNowMatchesPhpNow(): void
    {
        $sqlNow = strtotime((string) fetch_one('SELECT NOW()'));
        $phpNow = strtotime(now());

        $this->assertNotFalse($sqlNow);
        $this->assertNotFalse($phpNow);
        $this->assertLessThanOrEqual(2, abs($sqlNow - $phpNow), 'SQL NOW() and now() must agree within a couple of seconds');
    }

    public function testDatedIntervalIsAlreadyExpired(): void
    {
        $expired = fetch_one("SELECT (NOW() - INTERVAL 60 SECOND) <= NOW() AS expired");
        $this->assertSame('1', (string) $expired);
    }
}
