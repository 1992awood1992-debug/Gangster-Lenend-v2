<?php
/**
 * Eye Of The Mafia - Marketplace / Auction House
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/market.php';

$u = require_login();

// POST handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'list') {
        $result = market_create_listing(
            $u['id'],
            $_POST['item_type'] ?? '',
            (int) ($_POST['item_id'] ?? 0),
            (int) ($_POST['qty'] ?? 1),
            (int) ($_POST['buyout_price'] ?? 0),
            (int) ($_POST['bid_price'] ?? 0),
            (int) ($_POST['min_bid'] ?? 0),
            (int) ($_POST['duration_hours'] ?? 24)
        );
        flash($result['error'] ?? 'Listing created!', $result['ok'] ? 'success' : 'error');
    } elseif ($action === 'bid') {
        $result = market_bid($u['id'], (int) ($_POST['listing_id'] ?? 0), (int) ($_POST['amount'] ?? 0));
        flash($result['error'] ?? 'Bid placed!', $result['ok'] ? 'success' : 'error');
    } elseif ($action === 'buyout') {
        $result = market_buyout($u['id'], (int) ($_POST['listing_id'] ?? 0));
        flash($result['error'] ?? 'Purchase complete!', $result['ok'] ? 'success' : 'error');
    } elseif ($action === 'cancel') {
        $result = market_cancel($u['id'], (int) ($_POST['listing_id'] ?? 0));
        flash($result['error'] ?? 'Listing cancelled.', $result['ok'] ? 'success' : 'error');
    }
    redirect('market.php');
}

$page_title = 'Marketplace';
require __DIR__ . '/includes/header.php';

$categories = market_get_categories();
$stats = market_get_stats();
$myListings = market_get_user_listings($u['id'], 'active');
$myBids = market_get_user_bids($u['id']);
$history = market_get_user_listings($u['id'], 'sold');

?>

<div class="card">
  <div class="panel-heading">Marketplace <span class="tag tag-gold"><?= $stats['active'] ?> Active</span></div>
  <p class="muted small">Buy and sell items, vehicles, drugs, and blueprints. Auctions with buyout option.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
  <div class="stat"><span>Bullets</span><b><?= number_format((int) $u['bullets']) ?></b></div>
  <div class="stat"><span>Active Listings</span><b><?= count($myListings) ?></b></div>
  <div class="stat"><span>Volume</span><b><?= money($stats['volume']) ?></b></div>
</div>

<h2>Create Listing</h2>
<div class="card">
  <form method="post" style="display:grid;gap:12px;max-width:500px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="list">
    
    <div>
      <label class="muted small">Type</label>
      <select name="item_type" required style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
        <?php foreach (['item'=>'Items','vehicle'=>'Vehicles','drug'=>'Drugs','blueprint'=>'Blueprints'] as $k => $v): ?>
          <option value="<?= $k ?>"><?= $v ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    
    <div>
      <label class="muted small">Item</label>
      <select name="item_id" required style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
        <optgroup label="Items">
          <?php $items = fetch_all('SELECT id, name FROM items ORDER BY name'); foreach ($items as $i): ?>
            <option value="<?= (int) $i['id'] ?>" data-type="item"><?= e($i['name']) ?></option>
          <?php endforeach; ?>
        </optgroup>
        <optgroup label="Vehicles">
          <?php $vehicles = fetch_all('SELECT id, name FROM items WHERE type = \'vehicle\' ORDER BY name'); foreach ($vehicles as $v): ?>
            <option value="<?= (int) $v['id'] ?>" data-type="vehicle"><?= e($v['name']) ?></option>
          <?php endforeach; ?>
        </optgroup>
        <optgroup label="Drugs">
          <?php $drugs = fetch_all('SELECT id, name FROM drugs ORDER BY name'); foreach ($drugs as $d): ?>
            <option value="<?= (int) $d['id'] ?>" data-type="drug"><?= e($d['name']) ?></option>
          <?php endforeach; ?>
        </optgroup>
      </select>
    </div>
    
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div>
        <label class="muted small">Quantity</label>
        <input type="number" name="qty" value="1" min="1" required style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
      </div>
      <div>
        <label class="muted small">Duration (hours)</label>
        <input type="number" name="duration_hours" value="24" min="1" max="168" required style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
      </div>
    </div>
    
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div>
        <label class="muted small">Starting Bid</label>
        <input type="number" name="bid_price" value="0" min="0" style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
      </div>
      <div>
        <label class="muted small">Minimum Bid</label>
        <input type="number" name="min_bid" value="0" min="0" style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
      </div>
    </div>
    
    <div>
      <label class="muted small">Buyout Price (0 = no buyout)</label>
      <input type="number" name="buyout_price" value="0" min="0" style="width:100%;padding:8px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
    </div>
    
    <button class="btn btn-gold btn-block" type="submit">Create Listing</button>
  </form>
</div>

<h2 style="margin-top:24px">Active Listings <span class="tag tag-gold"><?= $stats['active'] ?></span></h2>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px">
  <?php 
  $listings = market_get_listings();
  if ($listings): foreach ($listings as $l): 
    $isOwner = (int) $l['seller_id'] === $u['id'];
    $hasBids = (int) $l['bid_price'] > 0;
    $timeLeft = $l['auction_end'] ? max(0, strtotime($l['auction_end']) - time()) : null;
  ?>
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
      <b><?= e($l['item_name']) ?></b>
      <span class="tag tag-<?= $l['item_type'] === 'vehicle' ? 'legendary' : ($l['item_type'] === 'drug' ? 'rare' : 'gold') ?>">
        <?= ucfirst($l['item_type_name'] ?? $l['item_type']) ?>
      </span>
    </div>
    <div class="muted small">Seller: <?= e($l['seller_name']) ?> | Qty: <?= (int) $l['qty'] ?></div>
    <?php if (isset($l['attack'])): ?>
      <div class="muted small">ATK: <?= (int) $l['attack'] ?> | DEF: <?= (int) $l['defense'] ?></div>
    <?php endif; ?>
    <?php if (isset($l['drug_buy_price'])): ?>
      <div class="muted small">Shop Price: <?= money($l['drug_buy_price']) ?></div>
    <?php endif; ?>
    
    <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">
      <?php if ((int) $l['buyout_price'] > 0): ?>
        <div class="stat"><span>Buyout</span><b><?= money($l['buyout_price']) ?></b></div>
      <?php endif; ?>
      <?php if ((int) $l['bid_price'] > 0): ?>
        <div class="stat"><span>Current Bid</span><b><?= money($l['bid_price']) ?></b></div>
      <?php else: ?>
        <div class="stat"><span>Starting Bid</span><b><?= money($l['bid_price']) ?: 'None' ?></b></div>
      <?php endif; ?>
      <?php if ($timeLeft !== null): ?>
        <div class="stat"><span>Time Left</span><b><?= floor($timeLeft/3600) ?>h <?= floor(($timeLeft%3600)/60) ?>m</b></div>
      <?php endif; ?>
    </div>
    
    <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
      <?php if (!$isOwner): ?>
        <?php if ((int) $l['buyout_price'] > 0): ?>
          <form method="post" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="buyout">
            <input type="hidden" name="listing_id" value="<?= (int) $l['id'] ?>">
            <button class="btn btn-gold btn-sm" type="submit">💰 Buyout for <?= money($l['buyout_price']) ?></button>
          </form>
        <?php endif; ?>
        
        <form method="post" style="display:inline">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="bid">
          <input type="hidden" name="listing_id" value="<?= (int) $l['id'] ?>">
          <input type="number" name="amount" placeholder="Your bid" min="<?= max(1, (int) $l['min_bid'] ?: 1) ?>" required style="width:100px;padding:4px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin-right:4px">
          <button class="btn btn-gold btn-sm" type="submit">💸 Bid</button>
        </form>
      <?php else: ?>
        <form method="post" style="display:inline" onsubmit="return confirm('Cancel this listing?')">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="cancel">
          <input type="hidden" name="listing_id" value="<?= (int) $l['id'] ?>">
          <button class="btn btn-sm btn-danger" type="submit">✕ Cancel</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php else: ?>
  <div class="card"><p class="muted">No active listings. Be the first to list something!</p></div>
<?php endif; ?>

<?php if ($myListings): ?>
<h2 style="margin-top:24px">Your Active Listings</h2>
<div class="table-wrap"><table>
  <tr><th>Item</th><th>Type</th><th>Qty</th><th>Bid</th><th>Buyout</th><th>Ends</th><th>Status</th><th></th></tr>
  <?php foreach ($myListings as $l): 
    $timeLeft = $l['auction_end'] ? max(0, strtotime($l['auction_end']) - time()) : null;
  ?>
  <tr>
    <td><?= e($l['item_name'] ?? 'Unknown') ?></td>
    <td><?= ucfirst($l['item_type']) ?></td>
    <td><?= (int) $l['qty'] ?></td>
    <td><?= money($l['bid_price']) ?: '—' ?></td>
    <td><?= (int) $l['buyout_price'] ? money($l['buyout_price']) : '—' ?></td>
    <td><?= $timeLeft ? floor($timeLeft/3600) . 'h ' . floor(($timeLeft%3600)/60) . 'm' : 'No end' ?></td>
    <td><span class="tag tag-<?= $l['status'] ?>"><?= ucfirst($l['status']) ?></span></td>
    <td>
      <form method="post" style="display:inline" onsubmit="return confirm('Cancel this listing?')">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="cancel">
        <input type="hidden" name="listing_id" value="<?= (int) $l['id'] ?>">
        <button class="btn btn-sm btn-danger" type="submit">✕ Cancel</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php endif; ?>

<?php if ($myBids): ?>
<h2 style="margin-top:24px">Your Bids</h2>
<div class="table-wrap"><table>
  <tr><th>Item</th><th>Your Bid</th><th>Current Bid</th><th>Status</th><th></th></tr>
  <?php foreach ($myBids as $b): ?>
  <tr class="<?= $b['status'] === 'outbid' ? 'error' : '' ?>">
    <td><?= e($b['item_name']) ?></td>
    <td><?= money($b['amount']) ?></td>
    <td><?= money($b['bid_price'] ?? 0) ?></td>
    <td><span class="tag tag-<?= $b['status'] === 'won' ? 'legendary' : ($b['status'] === 'lost' ? 'common' : ($b['status'] === 'outbid' ? 'error' : 'gold')) ?>"><?= ucfirst($b['status']) ?></span></td>
    <td>
      <?php if ($b['status'] === 'active'): ?>
        <form method="post" style="display:inline">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="bid">
          <input type="hidden" name="listing_id" value="<?= (int) $b['listing_id'] ?>">
          <input type="number" name="amount" placeholder="New bid" min="<?= max(1, ((int) $b['bid_price'] ?? 0) + 1) ?>" required style="width:80px;padding:4px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg);margin-right:4px">
          <button class="btn btn-gold btn-sm" type="submit">Rebid</button>
        </form>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php endif; ?>

<?php if ($history): ?>
<h2 style="margin-top:24px">Sales History</h2>
<div class="table-wrap"><table>
  <tr><th>Item</th><th>Buyer</th><th>Sold For</th><th>Date</th></tr>
  <?php foreach ($history as $h): ?>
  <tr>
    <td><?= e($h['item_name']) ?></td>
    <td><?= e($h['buyer_name'] ?? 'Unknown') ?></td>
    <td><?= money($h['final_price'] ?? 0) ?></td>
    <td><?= $h['sold_at'] ? date('M j H:i', strtotime($h['sold_at'])) : '—' ?></td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>