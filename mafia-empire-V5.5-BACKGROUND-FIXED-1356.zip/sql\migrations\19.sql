-- Mini Events (Phase 18) ----------------------------------------------------
CREATE TABLE IF NOT EXISTS mini_events (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    instance_code VARCHAR(64) NOT NULL UNIQUE,
    type ENUM('drug_surge','bullet_restock','safe_deposit','jackpot_boost') NOT NULL,
    name VARCHAR(100) NOT NULL,
    rarity ENUM('common','rare') NOT NULL DEFAULT 'common',
    weight INT UNSIGNED NOT NULL DEFAULT 100,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    city_id INT UNSIGNED NULL,
    params JSON NULL,
    started_at DATETIME NULL,
    ends_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_active (is_active),
    KEY idx_schedule (started_at, ends_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Global settings for mini-events scheduling
INSERT INTO settings (k, v) VALUES
    ('mini_event_next_run', '0'),
    ('mini_event_min_hours', '1'),
    ('mini_event_max_hours', '12')
ON DUPLICATE KEY UPDATE v = v;

-- Seasonal events calendar
CREATE TABLE IF NOT EXISTS seasonal_events (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    holiday_code VARCHAR(50) NOT NULL,
    year INT UNSIGNED NOT NULL,
    start_at DATETIME NOT NULL,
    end_at DATETIME NOT NULL,
    config JSON NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_holiday_year (holiday_code, year),
    KEY idx_dates (start_at, end_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Weekend events schedule (per round week)
CREATE TABLE IF NOT EXISTS weekend_events (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    event_type ENUM('double_xp','bullet_rush','looting_spree','motor_madness','crush_rush') NOT NULL,
    week INT UNSIGNED NOT NULL,
    start_at DATETIME NOT NULL,
    end_at DATETIME NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_week (week),
    KEY idx_dates (start_at, end_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Respect system
CREATE TABLE IF NOT EXISTS respect_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    from_user_id INT UNSIGNED NOT NULL,
    to_user_id INT UNSIGNED NOT NULL,
    amount INT NOT NULL,
    type ENUM('respect','disrespect') NOT NULL,
    anonymous TINYINT(1) NOT NULL DEFAULT 0,
    message VARCHAR(255) DEFAULT '',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_from (from_user_id),
    KEY idx_to (to_user_id),
    KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE users
    ADD COLUMN IF NOT EXISTS prestige_level INT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS prestige_coins INT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS net_respect INT NOT NULL DEFAULT 0;

-- Mini Event type definitions are in MINI_EVENT_TYPES constant in includes/mini_events.php
-- No seed rows needed - events are created as instances at runtime

-- Seed Weekend Event schedule (weeks 2-12, repeating)
-- Start times relative to round start; admin can adjust per-round via admin UI
INSERT INTO weekend_events (event_type, week, start_at, end_at) VALUES
    ('looting_spree', 2, '2026-01-01 19:00:00', '2026-01-03 19:00:00'),
    ('double_xp', 3, '2026-01-08 19:00:00', '2026-01-10 23:00:00'),
    ('bullet_rush', 4, '2026-01-15 19:00:00', '2026-01-17 19:00:00'),
    ('motor_madness', 5, '2026-01-22 19:00:00', '2026-01-24 19:00:00'),
    ('crush_rush', 6, '2026-01-29 19:00:00', '2026-01-31 19:00:00'),
    ('double_xp', 7, '2026-02-05 19:00:00', '2026-02-07 19:00:00'),
    ('looting_spree', 8, '2026-02-12 19:00:00', '2026-02-14 19:00:00'),
    ('bullet_rush', 9, '2026-02-19 19:00:00', '2026-02-21 19:00:00'),
    ('crush_rush', 10, '2026-02-26 19:00:00', '2026-02-28 19:00:00'),
    ('double_xp', 11, '2026-03-05 19:00:00', '2026-03-07 19:00:00'),
    ('motor_madness', 12, '2026-03-12 19:00:00', '2026-03-14 19:00:00')
ON DUPLICATE KEY UPDATE event_type = VALUES(event_type), start_at = VALUES(start_at), end_at = VALUES(end_at);

-- Seasonal events 2026
INSERT INTO seasonal_events (holiday_code, year, start_at, end_at, config) VALUES
    ('valentines', 2026, '2026-02-14 00:00:00', '2026-02-15 23:59:59',
     '{"vehicle":"Love Bug","theft_chance":100,"mission":"Double Trouble","respray":"Cupid Coat"}'),
    ('easter', 2026, '2026-04-03 00:00:00', '2026-04-06 23:59:59',
     '{"vehicle":"Bunny Buggy","theft_chance":50,"loot_item":"Easter Egg","respray":"Bunny Drip"}'),
    ('independence', 2026, '2026-07-03 00:00:00', '2026-07-05 23:59:59',
     '{"loot_item":"Mini Flag","mission":"Uncle Sam\'s Errand","respray":"Liberty Gloss"}'),
    ('halloween', 2026, '2026-10-15 00:00:00', '2026-10-31 23:59:59',
     '{"currency":"Candy","heist":"Trick or Treat","perk":"Skeleton Key","vehicle":"Death Wagon","respray":"Blood Drip"}'),
    ('christmas', 2026, '2026-12-01 00:00:00', '2026-12-25 23:59:59',
     '{"daily_giveaway":true,"vehicle":"Santa\'s Sleigh 5000","respray":"Mistlechrome"}')
ON DUPLICATE KEY UPDATE start_at = VALUES(start_at), end_at = VALUES(end_at), config = VALUES(config);

-- Bump schema version
UPDATE settings SET v = '19' WHERE k = 'schema_version';