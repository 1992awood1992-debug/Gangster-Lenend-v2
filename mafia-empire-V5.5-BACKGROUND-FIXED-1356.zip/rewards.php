<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: claim daily
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if ((int) $u['last_daily'] !== 0 && $u['last_daily'] === date('Y-m-d')) {
        flash('Already claimed today.', 'error');
    } else {
        $prizes = [
            ['cash', 5000, 40],
            ['cash', 15000, 25],
            ['bullets', 50, 15],
            ['points', 5, 10],
            ['cash', 50000, 5],
            ['points', 20, 3],
            ['bullets', 200, 2],
        ];
        $roll = mt_rand(1, 100);
        $cum = 0;
        $won = null;
        foreach ($prizes as $p) {
            $cum += $p[2];
            if ($roll <= $cum) { $won = $p; break; }
        }
        $streak = ($u['last_daily'] === date('Y-m-d', strtotime('-1 day'))) ? (int) $u['daily_streak'] + 1 : 1;
        $bonus = min(5, $streak - 1);
        
        q('UPDATE users SET last_daily = ?, daily_streak = ? WHERE id = ?', [date('Y-m-d'), $streak, $u['id']]);
        
        if ($won[0] === 'cash') {
            $amt = $won[1] + $bonus * 1000;
            add_money($u['id'], $amt, 'Daily reward');
            flash("Daily reward claimed! Won " . money($amt) . ($bonus ? " + streak bonus" : "") . ".", 'success');
        } elseif ($won[0] === 'bullets') {
            $amt = $won[1] + $bonus * 10;
            add_bullets($u['id'], $amt);
            flash("Daily reward claimed! Won " . number_format($amt) . " bullets.", 'success');
        } elseif ($won[0] === 'points') {
            $amt = $won[1] + $bonus;
            add_points($u['id'], $amt);
            flash("Daily reward claimed! Won " . $amt . " points.", 'success');
        }
    }
    redirect('rewards.php');
}

$page_title = 'Rewards';
require __DIR__ . '/includes/header.php';

$u = current_user();
$claimedToday = (int) $u['last_daily'] !== 0 && $u['last_daily'] === date('Y-m-d');
$streak = (int) $u['daily_streak'];
$nextMidnight = strtotime('tomorrow 00:00:00');
?>
<div class="card">
  <div class="panel-heading">Daily Reward</div>
  <p class="muted small">Claim once per day. Streak increases rewards!</p>
  <div class="stat"><span>Current Streak</span><b><?= $streak ?> day<?= $streak !== 1 ? 's' : '' ?></b></div>
  <div class="stat"><span>Next Reset</span><b><span data-until="<?= date('Y-m-d H:i:s', $nextMidnight) ?>"></span></b></div>
  
  <div style="margin-top:14px">
    <b>7-Day Streak:</b>
    <div class="pill-row" style="margin-top:8px">
      <?php for ($d = 1; $d <= 7; $d++): $active = $d <= $streak; ?>
        <span class="pill<?= $active ? ' on' : '' ?>">Day <?= $d ?></span>
      <?php endfor; ?>
    </div>
  </div>
  
  <?php if (!$claimedToday): ?>
    <form method="post" style="margin-top:14px">
      <?= csrf_field() ?>
      <button class="btn btn-gold btn-block btn-lg" type="submit">Claim Daily Reward</button>
    </form>
  <?php else: ?>
    <div class="alert alert-success" style="margin-top:14px">✓ Already claimed today! Come back tomorrow.</div>
  <?php endif; ?>
</div>

<div class="card" style="margin-top:18px">
  <div class="panel-heading">Possible Rewards</div>
  <div class="table-wrap"><table>
    <tr><th>Prize</th><th>Base Amount</th><th>Chance</th></tr>
    <tr><td>$5,000</td><td>Cash</td><td>40%</td></tr>
    <tr><td>$15,000</td><td>Cash</td><td>25%</td></tr>
    <tr><td>50 Bullets</td><td>Bullets</td><td>15%</td></tr>
    <tr><td>5 Points</td><td>Points</td><td>10%</td></tr>
    <tr><td>$50,000</td><td>Cash</td><td>5%</td></tr>
    <tr><td>20 Points</td><td>Points</td><td>3%</td></tr>
    <tr><td>200 Bullets</td><td>Bullets</td><td>2%</td></tr>
  </table></div>
  <p class="muted small">Streak bonus: +$1,000 cash / +10 bullets / +1 point per streak day (max +5 days).</p>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>