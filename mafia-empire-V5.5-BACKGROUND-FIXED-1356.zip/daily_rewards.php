<?php
/**
 * Eye Of The Mafia - Daily Login Rewards
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/login_rewards.php';

$u = require_login();

// POST: claim daily reward
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (($_POST['action'] ?? '') === 'claim') {
        $result = login_claim_reward($u['id']);
        if (!empty($result['ok'])) {
            $msg = 'Claimed: ' . implode(', ', $result['reward']);
            if (!empty($result['is_milestone'])) {
                $msg .= ' — <strong>MILESTONE: ' . e($result['milestone_label']) . '</strong>';
            }
            flash($msg, 'success');
        } else {
            flash($result['error'] ?? 'Could not claim reward.', 'error');
        }
    }
    redirect('daily_rewards.php');
}

$page_title = 'Daily Rewards';
require __DIR__ . '/includes/header.php';

$stats = login_get_stats($u['id']);
$upcoming = login_get_upcoming_rewards($u['id'], 14);
$todayReward = login_reward_get($stats['reward_day']);
?>

<div class="card">
  <div class="panel-heading">Daily Login Rewards</div>
  <p class="muted small">Log in daily to build your streak. Milestone rewards on days 5, 7, 14, 15, 20, 21, 26, 28, 30. Streak resets if you miss a day.</p>
</div>

<div class="stats-grid">
  <div class="stat-card">
    <span class="stat-label">Current Streak</span>
    <b class="stat-value"><?= (int) $stats['current_streak'] ?> days</b>
  </div>
  <div class="stat-card">
    <span class="stat-label">Longest Streak</span>
    <b class="stat-value"><?= (int) $stats['longest_streak'] ?> days</b>
  </div>
  <div class="stat-card">
    <span class="stat-label">Total Logins</span>
    <b class="stat-value"><?= number_format((int) $stats['total_logins']) ?></b>
  </div>
  <div class="stat-card">
    <span class="stat-label">Next Reward</span>
    <b class="stat-value">Day <?= (int) $stats['reward_day'] ?></b>
  </div>
</div>

<?php if ($stats['can_claim_today'] && $todayReward): ?>
<div class="card" style="margin-top:16px; border-left:4px solid var(--green);">
  <div class="panel-heading">Today's Reward <span class="tag tag-gold">READY TO CLAIM</span></div>
  <div class="reward-preview">
    <div class="reward-main">
      <div class="reward-icon-large" aria-hidden="true">
        <?php
        $icons = ['money'=>'&#36;','points'=>'&#9733;','xp'=>'&#9670;','bullets'=>'&#9679;','energy'=>'&#9889;','nerve'=>'&#9875;','item'=>'&#10026;'];
        echo $icons[$todayReward['reward_type']] ?? '&#9670;';
        ?>
      </div>
      <div class="reward-details">
        <h3><?= ucfirst($todayReward['reward_type']) ?> <?= $todayReward['reward_value'] ? $todayReward['reward_value'] : '' ?></h3>
        <?php if ($todayReward['is_milestone']): ?>
          <span class="tag tag-legendary">MILESTONE: <?= e($todayReward['milestone_label']) ?></span>
        <?php endif; ?>
        <div class="muted small">Day <?= (int) $stats['reward_day'] ?> of your streak</div>
      </div>
    </div>
    <form method="post" style="margin-top:12px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="claim">
      <button class="btn btn-gold btn-block" type="submit">
        <span aria-hidden="true">&#128187;</span> Claim Reward
      </button>
    </form>
  </div>
</div>
<?php elseif ($todayReward && !$stats['can_claim_today']): ?>
<div class="card" style="margin-top:16px; border-left:4px solid var(--gold);">
  <div class="panel-heading">Today's Reward <span class="tag tag-common">ALREADY CLAIMED</span></div>
  <div class="reward-preview">
    <div class="reward-main">
      <div class="reward-icon-large" aria-hidden="true" style="opacity:.5">
        <?php
        $icons = ['money'=>'&#36;','points'=>'&#9733;','xp'=>'&#9670;','bullets'=>'&#9679;','energy'=>'&#9889;','nerve'=>'&#9875;','item'=>'&#10026;'];
        echo $icons[$todayReward['reward_type']] ?? '&#9670;';
        ?>
      </div>
      <div class="reward-details">
        <h3><?= ucfirst($todayReward['reward_type']) ?> <?= $todayReward['reward_value'] ? $todayReward['reward_value'] : '' ?></h3>
        <?php if ($todayReward['is_milestone']): ?>
          <span class="tag tag-legendary">MILESTONE: <?= e($todayReward['milestone_label']) ?></span>
        <?php endif; ?>
        <div class="muted small">Day <?= (int) $stats['reward_day'] ?> — Come back tomorrow for the next reward!</div>
      </div>
    </div>
  </div>
</div>
<?php else: ?>
<div class="card" style="margin-top:16px; border-left:4px solid var(--muted);">
  <div class="panel-heading">Daily Rewards</div>
  <p class="muted">No reward data available. Please contact an administrator.</p>
</div>
<?php endif; ?>

<div class="card" style="margin-top:16px">
  <div class="panel-heading">Upcoming Rewards (Next 14 Days)</div>
  <div class="rewards-carousel">
    <?php foreach ($upcoming as $i => $r): ?>
      <?php
        $isCurrent = ($i === 0 && $stats['can_claim_today']);
        $icons = ['money'=>'&#36;','points'=>'&#9733;','xp'=>'&#9670;','bullets'=>'&#9679;','energy'=>'&#9889;','nerve'=>'&#9875;','item'=>'&#10026;'];
        $icon = $icons[$r['reward']['reward_type']] ?? '&#9670;';
        $milestone = $r['reward']['is_milestone'] ? ' <span class="tag tag-legendary">MILESTONE</span>' : '';
      ?>
      <div class="reward-card <?= $isCurrent ? 'current' : '' ?> <?= $r['reward']['is_milestone'] ? 'milestone' : '' ?>">
        <div class="reward-day-badge">Day <?= (int) $r['day'] ?></div>
        <div class="reward-icon" aria-hidden="true"><?= $icon ?></div>
        <div class="reward-info">
          <div class="reward-type"><?= ucfirst($r['reward']['reward_type']) ?> <?= $r['reward']['reward_value'] ? $r['reward']['reward_value'] : '' ?><?= $milestone ?></div>
        </div>
        <?php if ($isCurrent): ?>
          <span class="tag tag-gold">Claim Now</span>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
  <p class="muted small" style="margin-top:8px">Rewards cycle every 30 days. Miss a day and your streak resets to 1.</p>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>