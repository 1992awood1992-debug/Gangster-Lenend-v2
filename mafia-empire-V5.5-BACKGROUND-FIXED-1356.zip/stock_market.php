<?php
/**
 * Eye Of The Mafia - Stock Market
 * Buy/sell shares of in-game companies, earn dividends, speculate on value changes.
 */

require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'Stock Market';
require __DIR__ . '/includes/header.php';

$portfolio = fetch_all("
    SELECT ps.*, s.name, s.ticker, s.current_price, s.sector, s.dividend_yield
    FROM player_stocks ps
    JOIN stocks s ON s.id = ps.stock_id
    WHERE ps.user_id = ? AND ps.shares > 0
    ORDER BY s.ticker
", [$u['id']]);

$stocks = fetch_all("
    SELECT * FROM stocks WHERE is_active = 1 ORDER BY ticker
");

$history = fetch_all("
    SELECT sh.*, s.ticker
    FROM stock_history sh
    JOIN stocks s ON s.id = sh.stock_id
    WHERE sh.user_id = ?
    ORDER BY sh.created_at DESC
    LIMIT 50
", [$u['id']]);

$dividends = fetch_all("
    SELECT * FROM stock_dividends WHERE user_id = ? ORDER BY created_at DESC LIMIT 20
", [$u['id']]);

?>
<div class="card">
  <div class="panel-heading">Stock Market</div>
  <p class="muted small">Buy shares, collect dividends, speculate on price movements. Prices update every tick.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
  <div class="stat"><span>Portfolio Value</span><b><?= money((int) fetch_one("SELECT COALESCE(SUM(ps.shares * s.current_price), 0) FROM player_stocks ps JOIN stocks s ON s.id = ps.stock_id WHERE ps.user_id = ?", [$u['id']], 0)) ?></b></div>
  <div class="stat"><span>Total Dividends</span><b><?= money((int) fetch_one("SELECT COALESCE(SUM(amount), 0) FROM stock_dividends WHERE user_id = ?", [$u['id']], 0)) ?></b></div>
</div>

<div class="grid grid-2" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Available Stocks</div>
    <div class="table-wrap"><table>
      <tr><th>Ticker</th><th>Company</th><th>Sector</th><th>Price</th><th>Change</th><th>Div. Yield</th><th>Vol</th><th></th></tr>
      <?php foreach ($stocks as $s):
        $change = (int) $s['current_price'] - (int) $s['prev_price'];
        $pct = (int) $s['prev_price'] > 0 ? round($change / (int) $s['prev_price'] * 100, 2) : 0;
        $cls = $change >= 0 ? 'text-green' : 'text-red';
      ?>
      <tr>
        <td><b><?= e($s['ticker']) ?></b></td>
        <td><?= e($s['name']) ?></td>
        <td><?= e($s['sector']) ?></td>
        <td><?= money($s['current_price']) ?></td>
        <td class="<?= $cls ?>"><?= $change >= 0 ? '+' : '' ?><?= $change ?> (<?= $pct ?>%)</td>
        <td><?= $s['dividend_yield'] ?>%</td>
        <td><?= number_format((int) $s['volume']) ?></td>
        <td>
          <form method="post" style="display:flex;gap:4px;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="buy">
            <input type="hidden" name="stock_id" value="<?= (int) $s['id'] ?>">
            <input type="number" name="shares" min="1" max="1000" value="1" style="width:60px" required>
            <button class="btn btn-green btn-sm" type="submit">Buy</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  </div>

  <div class="card">
    <div class="panel-heading">Your Portfolio</div>
    <?php if (!$portfolio): ?>
      <p class="muted">No shares owned. Start investing!</p>
    <?php else: ?>
      <div class="table-wrap"><table>
        <tr><th>Ticker</th><th>Company</th><th>Shares</th><th>Avg Cost</th><th>Current</th><th>P/L</th><th></th></tr>
        <?php foreach ($portfolio as $p):
          $value = (int) $p['shares'] * (int) $p['current_price'];
          $cost = (int) $p['shares'] * (int) $p['avg_price'];
          $pl = $value - $cost;
          $plCls = $pl >= 0 ? 'text-green' : 'text-red';
        ?>
        <tr>
          <td><b><?= e($p['ticker']) ?></b></td>
          <td><?= e($p['name']) ?></td>
          <td><?= number_format((int) $p['shares']) ?></td>
          <td><?= money($p['avg_price']) ?></td>
          <td><?= money($p['current_price']) ?></td>
          <td class="<?= $plCls ?>"><?= $pl >= 0 ? '+' : '' ?><?= money($pl) ?></td>
          <td>
            <form method="post" style="display:flex;gap:4px;flex-wrap:wrap">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="sell">
              <input type="hidden" name="stock_id" value="<?= (int) $p['stock_id'] ?>">
              <input type="number" name="shares" min="1" max="<?= (int) $p['shares'] ?>" value="1" style="width:60px" required>
              <button class="btn btn-danger btn-sm" type="submit">Sell</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </table></div>
    <?php endif; ?>
  </div>
</div>

<div class="grid grid-2" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Transaction History</div>
    <?php if (!$history): ?>
      <p class="muted">No trades yet.</p>
    <?php else: ?>
      <div class="table-wrap"><table>
        <tr><th>Time</th><th>Ticker</th><th>Type</th><th>Shares</th><th>Price</th><th>Total</th></tr>
        <?php foreach ($history as $h): ?>
        <tr>
          <td><?= date('M j H:i', strtotime($h['created_at'])) ?></td>
          <td><b><?= e($h['ticker']) ?></b></td>
          <td><span class="tag tag-<?= $h['type'] === 'buy' ? 'legendary' : 'error' ?>"><?= ucfirst($h['type']) ?></span></td>
          <td><?= number_format((int) $h['shares']) ?></td>
          <td><?= money($h['price']) ?></td>
          <td><?= money($h['total']) ?></td>
        </tr>
        <?php endforeach; ?>
      </table></div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="panel-heading">Dividends Received</div>
    <?php if (!$dividends): ?>
      <p class="muted">No dividends yet. Hold dividend-paying stocks.</p>
    <?php else: ?>
      <div class="table-wrap"><table>
        <tr><th>Date</th><th>Ticker</th><th>Shares</th><th>Per Share</th><th>Total</th></tr>
        <?php foreach ($dividends as $d): ?>
        <tr>
          <td><?= date('M j', strtotime($d['created_at'])) ?></td>
          <td><?= e($d['ticker']) ?></td>
          <td><?= number_format((int) $d['shares']) ?></td>
          <td><?= money($d['per_share']) ?></td>
          <td><b><?= money($d['amount']) ?></b></td>
        </tr>
        <?php endforeach; ?>
      </table></div>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>