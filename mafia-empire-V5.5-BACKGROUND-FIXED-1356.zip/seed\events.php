<?php
/**
 * Eye Of The Mafia - Events System seeder (CLI / manual re-seed).
 *
 * The actual schema + seed data now lives in includes/event_seed.php so the
 * installer and test bootstrap get the events tables automatically. Run this
 * file directly to (re-)seed events on demand:
 *
 *     php seed/events.php
 */

require_once __DIR__ . '/../includes/event_seed.php';

event_seed_defaults();

$eventCount = (int) fetch_one('SELECT COUNT(*) FROM events');
$challengeCount = (int) fetch_one('SELECT COUNT(*) FROM event_challenges');

echo "Events system ready.\n";
echo "  events:     {$eventCount}\n";
echo "  challenges: {$challengeCount}\n";
