<?php
/**
 * Mafia Empire - scheduled background tasks.
 *
 * Each task_* function returns an associative array summary that the cron
 * dispatcher (cron/run.php) logs. Tasks are idempotent and safe to re-run.
 */

/**
 * Frequent task (every few minutes):
 *  - regenerate energy/nerve/health for every player (including offline ones)
 *  - settle any crew war whose end time has passed
 *
 * @return array<string,int>
 */
function task_tick(): array
{
    $usersTicked = 0;
    $ids = array_column(fetch_all('SELECT id FROM users'), 'id');
    foreach (array_chunk($ids, 500) as $chunk) {
        foreach ($chunk as $id) {
            $u = fetch('SELECT * FROM users WHERE id = ?', [(int) $id]);
            if ($u) {
                tick_user($u);
                $usersTicked++;
            }
        }
    }

    $warsFinished = finish_expired_wars();

    // Advance scheduled tournaments (auto-start due events, resolve matches,
    // cancel stale events, seed upcoming ones).
    if (!function_exists('tournament_sweep_run')) {
        require_once __DIR__ . '/tournaments.php';
    }
    $tournaments = tournament_sweep_run();

    // Settle marketplace auctions whose end time has passed.
    if (!function_exists('market_cleanup_expired')) {
        require_once __DIR__ . '/market.php';
    }
    $marketExpired = market_cleanup_expired();

    // Refund expired hitlist/bounty escrow and expire stale trade offers.
    if (!function_exists('social_cleanup_expired')) {
        require_once __DIR__ . '/social.php';
    }
    $social = social_cleanup_expired();

    // Run street races: create, start, settle, and refund stale waiters.
    if (!function_exists('race_cron')) {
        require_once __DIR__ . '/racing.php';
    }
    $racing = race_cron();

    // Run Mini Events: schedule/start/expire random world events.
    if (!function_exists('mini_event_cron')) {
        require_once __DIR__ . '/mini_events.php';
    }
    $miniEvents = mini_event_cron();

    return [
        'users_ticked' => $usersTicked,
        'wars_finished' => $warsFinished,
        'tournaments_started' => $tournaments['started'],
        'tournaments_cancelled' => $tournaments['cancelled'],
        'tournaments_resolved' => $tournaments['resolved'],
        'tournaments_completed' => $tournaments['completed'],
        'tournaments_created' => $tournaments['created'],
        'market_expired' => $marketExpired,
        'hitlist_refunded' => $social['hitlist_refunded'],
        'bounties_refunded' => $social['bounties_refunded'],
        'trades_expired' => $social['trades_expired'],
        'races_created' => $racing['races_created'],
        'races_started' => $racing['races_started'],
        'races_finished' => $racing['races_finished'],
        'races_cancelled' => $racing['races_cancelled'],
        'mini_events_started' => $miniEvents['started'],
        'mini_events_expired' => $miniEvents['expired'],
    ];
}

/**
 * Daily task (e.g. 00:05):
 *  - draw any open lottery whose draw date has passed and pay winners
 *  - ensure a fresh open draw exists
 *  - prune read notifications older than the retention window
 *
 * @return array<string,int>
 */
function task_daily(): array
{
    $drawn = 0;
    $opened = 0;
    $oldDraws = fetch_all('SELECT * FROM lottery_draws WHERE status = ? AND draw_date < CURDATE()', ['open']);
    foreach ($oldDraws as $od) {
        $winning = mt_rand(0, 999);
        q('UPDATE lottery_draws SET winning_number = ?, status = ? WHERE id = ?', [$winning, 'drawn', $od['id']]);
        $winners = fetch_all('SELECT * FROM lottery_tickets WHERE draw_id = ? AND number = ?', [$od['id'], $winning]);
        if ($winners) {
            $split = (int) floor((int) $od['pot'] / count($winners));
            if ($split > 0) {
                foreach ($winners as $w) {
                    add_money((int) $w['user_id'], $split, 'Lottery win');
                    notify((int) $w['user_id'], 'Your lottery ticket matched! You won ' . money($split) . '.', 'lottery.php');
                }
            }
        }
        $drawn++;
    }

    $open = fetch('SELECT id FROM lottery_draws WHERE status = ? ORDER BY draw_date DESC LIMIT 1', ['open']);
    if (!$open) {
        insert('lottery_draws', ['draw_date' => date('Y-m-d'), 'pot' => 25000, 'status' => 'open']);
        $opened++;
    }

    $pruned = q('DELETE FROM notifications WHERE is_read = 1 AND created_at < (NOW() - INTERVAL 30 DAY)')->rowCount();

    // Advance the mayor election cycle (open nominations, run votes, install a mayor).
    if (!function_exists('politics_advance_elections')) {
        require_once __DIR__ . '/politics.php';
    }
    $politics = politics_advance_elections();

    // Analytics: prune raw event rows older than 30 days (only if the table + helper exist)
    $analyticsPruned = 0;
    try {
        if (function_exists('analytics_prune')) {
            $analyticsPruned = analytics_prune(30);
        }
    } catch (Throwable $e) {
        $analyticsPruned = -1;
    }

    // Weekend Events: activate/expire per schedule
    if (!function_exists('weekend_event_cron')) {
        require_once __DIR__ . '/weekend_events.php';
    }
    $weekendEvents = weekend_event_cron();

    // Seasonal Events: activate/expire per calendar
    if (!function_exists('seasonal_event_cron')) {
        require_once __DIR__ . '/seasonal_events.php';
    }
    $seasonalEvents = seasonal_event_cron();

    // Deathmatch: final week of round
    if (!function_exists('deathmatch_cron')) {
        require_once __DIR__ . '/deathmatch.php';
    }
    $deathmatch = deathmatch_cron();

    // Deathmatch finale cash distribution (runs daily but only acts in final 2 hours)
    if (!function_exists('deathmatch_distribute_finale_cash')) {
        require_once __DIR__ . '/deathmatch.php';
    }
    deathmatch_distribute_finale_cash();

    // Respect System: prune old logs
    if (!function_exists('respect_cron')) {
        require_once __DIR__ . '/respect.php';
    }
    $respect = respect_cron();

    // Prestige System: check level ups for all users (handles XP jumps)
    if (!function_exists('prestige_check_level_up')) {
        require_once __DIR__ . '/prestige.php';
    }
    $prestigeUps = 0;
    $ids = array_column(fetch_all('SELECT id FROM users WHERE prestige_level > 0'), 'id');
    foreach ($ids as $id) {
        $prestigeUps += prestige_check_level_up((int) $id);
    }

    return ['lottery_drawn' => $drawn, 'lottery_opened' => $opened, 'notifications_pruned' => $pruned, 'analytics_pruned' => $analyticsPruned,
            'elections_to_voting' => $politics['to_voting'], 'elections_finished' => $politics['finished'], 'elections_started' => $politics['started'],
            'weekend_events_activated' => $weekendEvents['activated'], 'weekend_events_expired' => $weekendEvents['expired'],
            'seasonal_events_activated' => $seasonalEvents['activated'], 'seasonal_events_expired' => $seasonalEvents['expired'],
            'deathmatch_announced' => $deathmatch['announced'], 'deathmatch_day' => $deathmatch['day'], 'deathmatch_finale' => $deathmatch['finale'],
            'respect_pruned' => $respect['pruned'], 'prestige_level_ups' => $prestigeUps];
}

/**
 * Weekly task (e.g. Sunday 03:00):
 *  - prune old audit/log rows to keep the database lean
 *  - expire stale open marketplace listings and escrow offers
 *
 * @return array<string,int>
 */
function task_weekly(): array
{
    return [
        'event_log_pruned'         => q('DELETE FROM event_log WHERE created_at < (NOW() - INTERVAL 90 DAY)')->rowCount(),
        'kill_log_pruned'          => q('DELETE FROM kill_log WHERE created_at < (NOW() - INTERVAL 90 DAY)')->rowCount(),
        'casino_bets_pruned'       => q('DELETE FROM casino_bets WHERE created_at < (NOW() - INTERVAL 60 DAY)')->rowCount(),
        'bank_tx_pruned'           => q('DELETE FROM bank_transactions WHERE created_at < (NOW() - INTERVAL 180 DAY)')->rowCount(),
        'market_expired'           => q("UPDATE market_listings SET status = 'expired' WHERE status = 'active' AND auction_end IS NOT NULL AND auction_end < (NOW() - INTERVAL 30 DAY)")->rowCount(),
        'escrow_expired'           => q("UPDATE escrow SET status = 'cancelled' WHERE status = 'open' AND created_at < (NOW() - INTERVAL 30 DAY)")->rowCount(),
        'api_requests_pruned'      => q('DELETE FROM api_requests WHERE created_at < (NOW() - INTERVAL 30 DAY)')->rowCount(),
        'webhook_deliveries_pruned'=> q("DELETE FROM webhook_deliveries WHERE status = 'delivered' AND created_at < (NOW() - INTERVAL 14 DAY)")->rowCount(),
        'api_rate_pruned'          => q('DELETE FROM api_rate WHERE window_start < (? - 3600)', [time()])->rowCount(),
    ];
}

/**
 * Frequent task: flush the webhook delivery queue and retry failures.
 *
 * @return array<string,int>
 */
function task_webhooks(): array
{
    return webhook_deliver_pending(50);
}

/**
 * Daily task: post a digest of the previous day's activity to Discord.
 * No-op (and harmless) when DISCORD_WEBHOOK_URL is not configured.
 *
 * @return array<string,int|bool|string>
 */
function task_discord_digest(): array
{
    if (!discord_enabled()) {
        return ['sent' => 0, 'reason' => 'discord-not-configured'];
    }

    $newPlayers = (int) fetch_one('SELECT COUNT(*) FROM users WHERE created_at >= (NOW() - INTERVAL 1 DAY)', [], 0);
    $kills      = (int) fetch_one('SELECT COUNT(*) FROM kill_log WHERE created_at >= (NOW() - INTERVAL 1 DAY)', [], 0);
    $cash       = (int) fetch_one('SELECT COALESCE(SUM(amount), 0) FROM bank_transactions WHERE amount > 0 AND created_at >= (NOW() - INTERVAL 1 DAY)', [], 0);
    $top        = fetch('SELECT username, level FROM users WHERE is_banned = 0 ORDER BY level DESC, xp DESC LIMIT 1');
    $total      = (int) fetch_one('SELECT COUNT(*) FROM users', [], 0);

    $embed = [[
        'title'   => '🌆 ' . SITE_NAME . ' — daily digest',
        'color'   => 0xD9A441,
        'fields'  => [
            ['name' => 'New players', 'value' => (string) $newPlayers, 'inline' => true],
            ['name' => 'Kills',       'value' => (string) $kills,      'inline' => true],
            ['name' => 'Cash earned', 'value' => money($cash),         'inline' => true],
            ['name' => 'Top player',  'value' => $top ? $top['username'] . ' (Lv ' . (int) $top['level'] . ')' : '—', 'inline' => true],
            ['name' => 'Total players', 'value' => (string) $total,    'inline' => true],
        ],
    ]];
    [$ok, $code, $err] = discord_notify('Daily activity for ' . SITE_NAME, $embed);

    return ['sent' => $ok ? 1 : 0, 'status' => $code, 'error' => $err];
}

/**
 * Frequent task: flush the Web Push outbox to every subscribed device.
 * No-op (and harmless) when VAPID keys are not configured.
 *
 * @return array<string,int|string>
 */
function task_push(): array
{
    if (!push_available()) {
        return ['sent' => 0, 'reason' => 'push-not-configured'];
    }
    $rows = fetch_all('SELECT * FROM push_outbox ORDER BY id ASC LIMIT ' . (int) PUSH_MAX_PER_TICK);
    $sent = 0;
    foreach ($rows as $r) {
        $sent += push_send_user((int) $r['user_id'], (string) $r['title'], (string) $r['body'], (string) $r['url']);
        q('DELETE FROM push_outbox WHERE id = ?', [$r['id']]);
    }
    // Prune endpoints the push service has repeatedly rejected.
    q('DELETE FROM push_subscriptions WHERE fail_count >= 10');
    return ['queued' => count($rows), 'sent' => $sent];
}
