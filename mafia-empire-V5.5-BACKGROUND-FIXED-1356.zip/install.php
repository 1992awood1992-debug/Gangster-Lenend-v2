<?php
/**
 * Mafia Empire - installer / seeder.
 * Web:  http://localhost/mafia-empire/install.php
 * CLI:  php install.php
 */
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$isCli = (php_sapi_name() === 'cli');

require_once __DIR__ . '/includes/seed.php';


if ($isCli) {
    run_schema();
    $id = create_admin('admin', 'admin@mafia-empire.test', 'mafia123');
    // Ensure an admin exists to own the welcome post.
    $adminId = $id ?: (int) fetch_one('SELECT id FROM users WHERE is_admin = 1 ORDER BY id LIMIT 1', [], 1);
    seed($adminId);
    echo "Installed.\nAdmin user: admin   Password: mafia123\n";
    exit(0);
}

// --- Web installer -----------------------------------------------------
$done = false;
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        run_schema();
        $id = create_admin(trim($_POST['username'] ?: 'admin'), trim($_POST['email'] ?: 'admin@example.com'), $_POST['password'] ?: 'mafia123');
        $adminId = $id ?: (int) fetch_one('SELECT id FROM users WHERE is_admin = 1 ORDER BY id LIMIT 1', [], 1);
        seed($adminId);
        $done = true;
    } catch (Throwable $ex) {
        $error = $ex->getMessage();
    }
}
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Install Mafia Empire</title>
<link rel="stylesheet" href="assets/style.css"></head>
<body class="auth-body"><div class="auth-card">
<h1><?= e(SITE_NAME) ?></h1>
<?php if ($done): ?>
  <p class="alert alert-success">Installation complete! Your game is ready.</p>
  <p><a class="btn btn-gold" href="<?= e(url('login.php')) ?>">Go to login</a></p>
<?php else: ?>
  <?php if ($error): ?><p class="alert alert-error"><?= e($error) ?></p><?php endif; ?>
  <p>Create the first administrator account. The database <strong><?= e(DB_NAME) ?></strong> will be created automatically.</p>
  <form method="post">
    <label>Username <input name="username" value="admin" required></label>
    <label>Email <input type="email" name="email" value="admin@example.com" required></label>
    <label>Password <input type="text" name="password" value="mafia123" required></label>
    <button class="btn btn-gold" type="submit">Install</button>
  </form>
<?php endif; ?>
</div></body></html>
