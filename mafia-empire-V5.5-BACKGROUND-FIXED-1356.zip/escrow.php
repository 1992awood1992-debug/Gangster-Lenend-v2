<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: create, accept, release, cancel
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if (action_on_cooldown($u['id'], 'escrow')) {
        $cd = action_on_cooldown($u['id'], 'escrow');
        flash('Escrow on cooldown. Try again in ' . $cd . '.', 'error');
        redirect('escrow.php');
    }
    if ($action === 'create') {
        $amt = max(1, (int) ($_POST['amount'] ?? 0));
        $terms = trim($_POST['terms'] ?? '');
        $counterpartyName = trim($_POST['counterparty'] ?? '');
        if ($amt > $u['money']) {
            flash('Not enough cash.', 'error');
        } else {
            $cpId = null;
            if ($counterpartyName !== '') {
                $cp = fetch('SELECT id FROM users WHERE username = ?', [$counterpartyName]);
                if (!$cp) {
                    flash('Counterparty not found.', 'error');
                } elseif ((int) $cp['id'] === $u['id']) {
                    flash('Cannot escrow with yourself.', 'error');
                } else {
                    $cpId = (int) $cp['id'];
                }
            }
            if (!$cpId || !isset($cp)) {
                add_money($u['id'], -$amt, 'Escrow created');
                insert('escrow', ['creator_id' => $u['id'], 'counterparty_id' => $cpId, 'amount' => $amt, 'terms' => $terms, 'status' => 'open']);
                set_action_cooldown($u['id'], 'escrow');
                flash('Escrow created for ' . money($amt) . ($cpId ? ' with ' . e($counterpartyName) : ' (open to anyone)') . '.', 'success');
            }
        }
    } elseif ($action === 'accept') {
        $escrowId = (int) ($_POST['escrow_id'] ?? 0);
        $esc = fetch('SELECT * FROM escrow WHERE id = ? AND status = ? AND creator_id != ?', [$escrowId, 'open', $u['id']]);
        if (!$esc) {
            flash('Escrow not available.', 'error');
        } else {
            q('UPDATE escrow SET counterparty_id = ?, status = ? WHERE id = ?', [$u['id'], 'accepted', $escrowId]);
            notify((int) $esc['creator_id'], $u['username'] . ' accepted your escrow of ' . money($esc['amount']) . '.', 'escrow.php');
            set_action_cooldown($u['id'], 'escrow');
            flash('Escrow accepted.', 'success');
        }
    } elseif ($action === 'release') {
        $escrowId = (int) ($_POST['escrow_id'] ?? 0);
        $esc = fetch('SELECT * FROM escrow WHERE id = ? AND status = ? AND (creator_id = ? OR counterparty_id = ?)', [$escrowId, 'accepted', $u['id'], $u['id']]);
        if (!$esc) {
            flash('Cannot release this escrow.', 'error');
        } else {
            $recipient = (int) $esc['counterparty_id'];
            add_money($recipient, (int) $esc['amount'], 'Escrow released');
            q('UPDATE escrow SET status = ? WHERE id = ?', ['released', $escrowId]);
            notify((int) $esc['creator_id'], 'Escrow released to ' . fetch('SELECT username FROM users WHERE id = ?', [$recipient])['username'] . '.', 'escrow.php');
            notify($recipient, 'Escrow of ' . money($esc['amount']) . ' was released to you.', 'escrow.php');
            set_action_cooldown($u['id'], 'escrow');
            flash('Funds released.', 'success');
        }
    } elseif ($action === 'cancel') {
        $escrowId = (int) ($_POST['escrow_id'] ?? 0);
        $esc = fetch('SELECT * FROM escrow WHERE id = ? AND creator_id = ? AND status IN (?, ?)', [$escrowId, $u['id'], 'open', 'accepted']);
        if (!$esc) {
            flash('Cannot cancel this escrow.', 'error');
        } else {
            add_money($u['id'], (int) $esc['amount'], 'Escrow cancelled');
            q('UPDATE escrow SET status = ? WHERE id = ?', ['cancelled', $escrowId]);
            if ($esc['counterparty_id']) {
                notify((int) $esc['counterparty_id'], 'Escrow with ' . $u['username'] . ' was cancelled.', 'escrow.php');
            }
            set_action_cooldown($u['id'], 'escrow');
            flash('Escrow cancelled, funds returned.', 'success');
        }
    }
    redirect('escrow.php');
}

$page_title = 'Escrow';
require __DIR__ . '/includes/header.php';

$openEscrows = fetch_all('SELECT e.*, u.username AS creator_name FROM escrow e JOIN users u ON u.id = e.creator_id WHERE e.status = ? AND e.creator_id != ? ORDER BY e.created_at DESC', ['open', $u['id']]);
$myEscrows = fetch_all('SELECT e.*, u.username AS other_name FROM escrow e LEFT JOIN users u ON u.id = CASE WHEN e.creator_id = ? THEN e.counterparty_id ELSE e.creator_id END WHERE (e.creator_id = ? OR e.counterparty_id = ?) ORDER BY e.created_at DESC', [$u['id'], $u['id'], $u['id']]);
?>
<div class="card">
  <div class="panel-heading">Create Escrow</div>
  <form method="post" style="display:grid;gap:10px;max-width:500px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">
    <label>Amount <input type="number" name="amount" min="1" max="<?= (int) $u['money'] ?>" required></label>
    <label>Terms <textarea name="terms" placeholder="Describe the deal..." required></textarea></label>
    <label>Counterparty Username (optional) <input type="text" name="counterparty" placeholder="Leave empty for open escrow"></label>
    <button class="btn btn-gold" type="submit">Create</button>
  </form>
</div>

<div class="card">
  <div class="panel-heading">Open Escrows (you can accept)</div>
  <?php if (!$openEscrows): ?>
    <p class="muted">No open escrows.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Creator</th><th>Amount</th><th>Terms</th><th>Status</th><th></th></tr>
      <?php foreach ($openEscrows as $e): ?>
        <tr>
          <td><?= e($e['creator_name']) ?></td>
          <td><?= money($e['amount']) ?></td>
          <td><?= e($e['terms']) ?></td>
          <td><span class="tag tag-uncommon">Open</span></td>
          <td>
            <form method="post" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="accept">
              <input type="hidden" name="escrow_id" value="<?= (int) $e['id'] ?>">
              <button class="btn btn-green btn-sm" type="submit">Accept</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="panel-heading">Your Escrows</div>
  <?php if (!$myEscrows): ?>
    <p class="muted">No escrows yet.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Other Party</th><th>Amount</th><th>Terms</th><th>Status</th><th>Date</th><th></th></tr>
      <?php foreach ($myEscrows as $e): $role = $e['creator_id'] == $u['id'] ? 'creator' : 'counterparty'; ?>
        <tr>
          <td><?= e($e['other_name'] ?? '—') ?></td>
          <td><?= money($e['amount']) ?></td>
          <td><?= e($e['terms']) ?></td>
          <td>
            <?php
            $badge = ['open' => 'tag-uncommon', 'accepted' => 'tag-legendary', 'released' => 'tag-common', 'cancelled' => 'tag-common'];
            echo '<span class="tag ' . ($badge[$e['status']] ?? '') . '">' . e($e['status']) . '</span>';
            ?>
          </td>
          <td><?= date('M j, H:i', strtotime($e['created_at'])) ?></td>
          <td>
            <?php if ($e['status'] === 'accepted' && $role === 'creator'): ?>
              <form method="post" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="release">
                <input type="hidden" name="escrow_id" value="<?= (int) $e['id'] ?>">
                <button class="btn btn-green btn-sm" type="submit">Release</button>
              </form>
            <?php elseif (($e['status'] === 'open' || $e['status'] === 'accepted') && $role === 'creator'): ?>
              <form method="post" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="cancel">
                <input type="hidden" name="escrow_id" value="<?= (int) $e['id'] ?>">
                <button class="btn btn-sm" type="submit" data-confirm="Cancel and refund?">Cancel</button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>