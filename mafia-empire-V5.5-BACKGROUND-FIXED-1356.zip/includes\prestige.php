<?php
/**
 * Eye Of The Mafia - Prestige System
 * Unlimited post-50 progression: prestige levels, prestige coins, level 50 equivalence for combat.
 */

require_once __DIR__ . '/init.php';

/**
 * XP required for each prestige level: P1=1,000, P2=2,000, P3=3,000... P100=100,000
 * Total XP at Prestige N = 100,000 + sum(1000*i) for i=1 to N
 */
function prestige_xp_for_level(int $prestigeLevel): int
{
    if ($prestigeLevel <= 0) return 0;
    // Sum of 1000 * i from 1 to prestigeLevel = 1000 * prestigeLevel * (prestigeLevel + 1) / 2
    return 1000 * $prestigeLevel * ($prestigeLevel + 1) / 2;
}

/**
 * Get total XP for a given prestige level (including base 100,000)
 */
function prestige_total_xp(int $prestigeLevel): int
{
    return 100000 + prestige_xp_for_level($prestigeLevel);
}

/**
 * Calculate prestige level from total XP
 */
function prestige_calculate_level(int $totalXp): int
{
    if ($totalXp < 100000) return 0; // Not yet prestige

    $prestigeXp = $totalXp - 100000;
    // Solve: 1000 * n * (n + 1) / 2 = prestigeXp
    // n^2 + n - (2 * prestigeXp / 1000) = 0
    $discriminant = 1 + 8 * $prestigeXp / 1000;
    if ($discriminant < 0) return 0;
    $n = (int) floor((-1 + sqrt($discriminant)) / 2);
    return max(0, $n);
}

/**
 * Get XP progress within current prestige level
 */
function prestige_get_progress(int $userId): array
{
    $u = fetch('SELECT xp, prestige_level FROM users WHERE id = ?', [(int) $userId]);
    if (!$u) return ['level' => 0, 'current_xp' => 0, 'required_xp' => 0, 'progress' => 0];

    $totalXp = (int) $u['xp'];
    $prestige = (int) $u['prestige_level'];

    if ($prestige === 0 && $totalXp < 100000) {
        return ['level' => 0, 'current_xp' => $totalXp, 'required_xp' => 100000, 'progress' => $totalXp / 100000];
    }

    $nextLevelXp = prestige_total_xp($prestige + 1);
    $currentLevelXp = prestige_total_xp($prestige);
    $intoLevel = $totalXp - $currentLevelXp;
    $neededForNext = $nextLevelXp - $currentLevelXp;

    return [
        'level' => $prestige,
        'current_xp' => $intoLevel,
        'required_xp' => $neededForNext,
        'progress' => $neededForNext > 0 ? $intoLevel / $neededForNext : 1,
    ];
}

/**
 * Check and apply prestige level up
 * Returns levels gained (usually 1, but handles XP jumps)
 */
function prestige_check_level_up(int $userId): int
{
    $u = fetch('SELECT xp, prestige_level FROM users WHERE id = ?', [(int) $userId]);
    if (!$u) return 0;

    $totalXp = (int) $u['xp'];
    $currentPrestige = (int) $u['prestige_level'];
    $newPrestige = prestige_calculate_level($totalXp);

    if ($newPrestige > $currentPrestige) {
        $gained = $newPrestige - $currentPrestige;
        $newCoins = (int) fetch_one('SELECT prestige_coins FROM users WHERE id = ?', [$userId], 0) + $gained;

        q('UPDATE users SET prestige_level = ?, prestige_coins = ? WHERE id = ?',
            [$newPrestige, $newCoins, $userId]);

        // Notify
        for ($i = 1; $i <= $gained; $i++) {
            $level = $currentPrestige + $i;
            notify($userId, "You reached Prestige {$level}! +1 Prestige Coin added to your balance.", 'profile.php');
        }

        return $gained;
    }
    return 0;
}

/**
 * Get effective level for combat/shooting (Prestige = Level 50)
 */
function prestige_get_effective_level(int $userId): int
{
    $u = fetch('SELECT level, prestige_level FROM users WHERE id = ?', [(int) $userId]);
    if (!$u) return 1;

    $level = (int) $u['level'];
    $prestige = (int) $u['prestige_level'];

    if ($prestige > 0) return 50;
    return $level;
}

/**
 * Get user's prestige coin balance
 */
function prestige_get_coins(int $userId): int
{
    return (int) fetch_one('SELECT prestige_coins FROM users WHERE id = ?', [(int) $userId], 0);
}

/**
 * Spend prestige coins (returns true on success)
 */
function prestige_spend_coins(int $userId, int $amount): bool
{
    if ($amount <= 0) return false;
    $current = prestige_get_coins($userId);
    if ($current < $amount) return false;

    q('UPDATE users SET prestige_coins = prestige_coins - ? WHERE id = ?', [$amount, $userId]);
    return true;
}

/**
 * Add prestige coins (admin or reward)
 */
function prestige_add_coins(int $userId, int $amount): void
{
    if ($amount <= 0) return;
    q('UPDATE users SET prestige_coins = prestige_coins + ? WHERE id = ?', [$amount, $userId]);
}

/**
 * Get prestige leaderboard
 */
function prestige_get_leaderboard(int $limit = 20): array
{
    return fetch_all("
        SELECT u.id, u.username, u.level, u.prestige_level, u.prestige_coins, u.xp
        FROM users u
        WHERE u.is_banned = 0
        ORDER BY u.prestige_level DESC, u.xp DESC
        LIMIT ?
    ", [$limit]);
}

/**
 * Admin: set user's prestige level and coins
 */
function prestige_admin_set(int $userId, int $prestigeLevel, int $coins = -1): array
{
    $u = fetch('SELECT id FROM users WHERE id = ?', [(int) $userId]);
    if (!$u) return ['ok' => false, 'error' => 'User not found'];

    if ($prestigeLevel < 0) $prestigeLevel = 0;
    if ($coins < 0) $coins = 0;

    q('UPDATE users SET prestige_level = ?, prestige_coins = ? WHERE id = ?',
        [$prestigeLevel, $coins, $userId]);

    // Update XP to match prestige level minimum
    $minXp = prestige_total_xp($prestigeLevel);
    q('UPDATE users SET xp = GREATEST(xp, ?) WHERE id = ?', [$minXp, $userId]);

    return ['ok' => true, 'prestige_level' => $prestigeLevel, 'prestige_coins' => $coins];
}

/**
 * Admin: grant prestige levels (adds XP to reach next levels)
 */
function prestige_admin_grant(int $userId, int $levels): array
{
    if ($levels <= 0) return ['ok' => false, 'error' => 'Invalid levels'];

    $u = fetch('SELECT xp, prestige_level FROM users WHERE id = ?', [(int) $userId]);
    if (!$u) return ['ok' => false, 'error' => 'User not found'];

    $targetPrestige = (int) $u['prestige_level'] + $levels;
    $targetXp = prestige_total_xp($targetPrestige);
    $newCoins = (int) $u['prestige_coins'] + $levels;

    q('UPDATE users SET xp = ?, prestige_level = ?, prestige_coins = ? WHERE id = ?',
        [$targetXp, $targetPrestige, $newCoins, $userId]);

    return ['ok' => true, 'new_prestige' => $targetPrestige, 'new_coins' => $newCoins, 'xp_added' => $targetXp - (int) $u['xp']];
}

/**
 * Format prestige display: "P15" or "L50"
 */
function prestige_format(int $userId): string
{
    $u = fetch('SELECT level, prestige_level FROM users WHERE id = ?', [(int) $userId]);
    if (!$u) return 'L1';

    $level = (int) $u['level'];
    $prestige = (int) $u['prestige_level'];

    if ($prestige > 0) return 'P' . $prestige;
    return 'L' . $level;
}

/**
 * Get prestige info for profile display
 */
function prestige_get_profile_info(int $userId): array
{
    $u = fetch('SELECT level, prestige_level, prestige_coins, xp FROM users WHERE id = ?', [(int) $userId]);
    if (!$u) return ['display' => 'L1', 'level' => 1, 'prestige' => 0, 'coins' => 0, 'progress' => 0];

    $level = (int) $u['level'];
    $prestige = (int) $u['prestige_level'];
    $coins = (int) $u['prestige_coins'];
    $totalXp = (int) $u['xp'];

    if ($prestige > 0) {
        $progress = prestige_get_progress($userId);
        return [
            'display' => 'P' . $prestige,
            'level' => $level,
            'prestige' => $prestige,
            'coins' => $coins,
            'total_xp' => $totalXp,
            'progress' => $progress,
            'effective_level' => 50,
        ];
    } else {
        // Main level progress (use existing level_for_xp logic)
        $nextLevel = $level + 1;
        $nextXp = level_for_xp($nextLevel) ?? 100000;
        $currentXp = level_for_xp($level) ?? 0;
        return [
            'display' => 'L' . $level,
            'level' => $level,
            'prestige' => 0,
            'coins' => $coins,
            'total_xp' => $totalXp,
            'progress' => [
                'level' => 0,
                'current_xp' => $totalXp - $currentXp,
                'required_xp' => $nextXp - $currentXp,
                'progress' => ($totalXp - $currentXp) / max(1, $nextXp - $currentXp),
            ],
            'effective_level' => $level,
        ];
    }
}