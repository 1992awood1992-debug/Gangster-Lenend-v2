<?php
require_once __DIR__ . '/../includes/init.php';
$u = require_login();
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'method']);
    exit;
}
csrf_verify();
$flashId = (int) ($_POST['flash_id'] ?? 0);
if (!$flashId) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'missing flash_id']);
    exit;
}
db_dismiss_flash((int) $u['id'], $flashId);
echo json_encode(['ok' => true]);
