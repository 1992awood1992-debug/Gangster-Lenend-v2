<?php
/**
 * Mafia Empire - Enhanced Flash Messaging System (V4.6)
 * Database-driven flash announcements + rich client-side effects.
 */

if (!function_exists('db_get_flashes')) {
    /**
     * Get active flash messages visible to a user.
     */
    function db_get_flashes(int $uid): array
    {
        $now = date('Y-m-d H:i:s');
        $flashes = fetch_all("
            SELECT fm.*
            FROM flash_messages fm
            WHERE fm.active = 1
              AND (fm.starts_at IS NULL OR fm.starts_at <= ?)
              AND (fm.expires_at IS NULL OR fm.expires_at >= ?)
              AND (
                    fm.target_type = 'all'
                 OR (fm.target_type = 'user' AND fm.target_value = ?)
                 OR (fm.target_type = 'admin' AND (SELECT is_admin FROM users WHERE id = ?) = 1)
                 OR (fm.target_type = 'level_min' AND fm.min_level IS NOT NULL AND (SELECT level FROM users WHERE id = ?) >= fm.min_level)
              )
            ORDER BY fm.created_at DESC
        ", [$now, $now, $uid, $uid, $uid]);

        $out = [];
        foreach ($flashes as $f) {
            $dismissed = (int) fetch_one(
                "SELECT COUNT(*) FROM user_flash_dismissals WHERE user_id = ? AND flash_id = ?",
                [$uid, (int) $f['id']], 0
            );
            if ($dismissed) continue;
            $out[] = $f;
        }
        return $out;
    }
}

if (!function_exists('db_create_flash')) {
    function db_create_flash(array $data): ?int
    {
        $defaults = [
            'title' => '',
            'message' => '',
            'type' => 'info',
            'target_type' => 'all',
            'target_value' => null,
            'min_level' => null,
            'starts_at' => null,
            'expires_at' => null,
            'dismissible' => 1,
            'show_once' => 0,
            'created_by' => null,
            'active' => 1,
        ];
        $d = array_merge($defaults, $data);
        return insert('flash_messages', [
            'title' => $d['title'],
            'message' => $d['message'],
            'type' => $d['type'],
            'target_type' => $d['target_type'],
            'target_value' => $d['target_value'] ?? null,
            'min_level' => $d['min_level'] ?? null,
            'starts_at' => $d['starts_at'] ?? null,
            'expires_at' => $d['expires_at'] ?? null,
            'dismissible' => (int) $d['dismissible'],
            'show_once' => (int) $d['show_once'],
            'created_by' => $d['created_by'] ?? null,
            'active' => (int) $d['active'],
        ]);
    }
}

if (!function_exists('db_dismiss_flash')) {
    function db_dismiss_flash(int $uid, int $flashId): void
    {
        insert('user_flash_dismissals', [
            'user_id' => $uid,
            'flash_id' => $flashId,
        ], true);
    }
}

if (!function_exists('db_dismiss_all_flashes')) {
    function db_dismiss_all_flashes(int $uid): void
    {
        $flashes = db_get_flashes($uid);
        foreach ($flashes as $f) {
            db_dismiss_flash($uid, (int) $f['id']);
        }
    }
}

if (!function_exists('db_list_flashes')) {
    function db_list_flashes(): array
    {
        return fetch_all("
            SELECT fm.*, u.username AS creator_name
            FROM flash_messages fm
            LEFT JOIN users u ON u.id = fm.created_by
            ORDER BY fm.id DESC
        ");
    }
}

if (!function_exists('db_toggle_flash')) {
    function db_toggle_flash(int $id, int $active): void
    {
        q("UPDATE flash_messages SET active = ? WHERE id = ?", [$active, $id]);
    }
}

if (!function_exists('db_delete_flash')) {
    function db_delete_flash(int $id): void
    {
        q("DELETE FROM flash_messages WHERE id = ?", [$id]);
        q("DELETE FROM user_flash_dismissals WHERE flash_id = ?", [$id]);
    }
}

if (!function_exists('db_seed_default_flashes')) {
    function db_seed_default_flashes(): void
    {
        $count = (int) fetch_one("SELECT COUNT(*) FROM flash_messages", [], 0);
        if ($count > 0) return;
        $now = date('Y-m-d H:i:s');
        $plus7 = date('Y-m-d H:i:s', strtotime('+7 days'));
        insert('flash_messages', [
            'title' => 'Welcome to Eye Of The Mafia v4.6',
            'message' => 'The city is yours for the taking. Build your empire, buy businesses, collect daily bonuses, and rule the streets.',
            'type' => 'gold',
            'target_type' => 'all',
            'starts_at' => $now,
            'expires_at' => $plus7,
            'dismissible' => 1,
            'show_once' => 1,
            'created_by' => null,
            'active' => 1,
        ]);
    }
}
