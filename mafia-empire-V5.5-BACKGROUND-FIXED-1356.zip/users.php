<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'Users';
require __DIR__ . '/includes/header.php';

$search = trim($_GET['search'] ?? '');
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 30;

$where = 'WHERE is_banned = 0';
$params = [];
if ($search !== '') {
    $where .= ' AND username LIKE ?';
    $params[] = '%' . $search . '%';
}
$total = (int) fetch_one("SELECT COUNT(*) FROM users $where", $params, 0);
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$list = fetch_all("SELECT * FROM users $where ORDER BY level DESC, xp DESC LIMIT ? OFFSET ?", array_merge($params, [$perPage, $offset]));
?>
<div class="card">
  <div class="panel-heading">Player Directory</div>
  <form method="get" style="display:flex;gap:8px;margin-bottom:14px">
    <input type="text" name="search" placeholder="Search username..." value="<?= e($search) ?>" style="flex:1;max-width:300px">
    <button class="btn btn-gold" type="submit">Search</button>
  </form>
</div>

<div class="card">
  <?php if (!$list): ?>
    <p class="muted">No players found.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Avatar</th><th>Player</th><th>Level</th><th>Rank</th><th>Kills</th><th>Last Active</th><th>Online</th></tr>
      <?php foreach ($list as $p):
        $rank = rank_for_level((int) $p['level']);
        $online = strtotime($p['last_active']) > time() - 300;
      ?>
        <tr>
          <td><img src="<?= e($p['avatar']) ?>" alt="" class="avatar" onerror="this.src='<?= e(url('assets/img/avatar-default.svg')) ?>'"></td>
          <td><a href="<?= e(url('profile.php?id=' . (int) $p['id'])) ?>"><b><?= e($p['username']) ?></b></a></td>
          <td><?= (int) $p['level'] ?></td>
          <td><?= e($rank['name']) ?></td>
          <td><?= (int) $p['kills'] ?></td>
          <td><?= date('M j, H:i', strtotime($p['last_active'])) ?></td>
          <td><?= $online ? '<span class="tag tag-uncommon">Online</span>' : '<span class="tag tag-common">Offline</span>' ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    
    <?php if ($pages > 1): ?>
      <div class="pill-row" style="justify-content:center;margin-top:14px">
        <?php for ($p = max(1, $page - 2); $p <= min($pages, $page + 2); $p++): ?>
          <a class="pill<?= $p === $page ? ' on' : '' ?>" href="<?= e(url('users.php?page=' . $p . ($search ? '&search=' . urlencode($search) : ''))) ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>