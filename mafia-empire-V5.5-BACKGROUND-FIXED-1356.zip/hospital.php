<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: buy treatment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'treat') {
        if (!is_hospitalized($u)) {
            flash('You are not hospitalized.', 'error');
        } elseif (action_on_cooldown($u['id'], 'hospital')) {
            $cd = action_on_cooldown($u['id'], 'hospital');
            flash('Hospital on cooldown. Try again in ' . $cd . '.', 'error');
        } else {
            $cost = 50000; // £50,000 for 1% health
            if ((int) $u['money'] < $cost) {
                flash('Not enough cash. Need ' . money($cost) . '.', 'error');
            } else {
                add_money($u['id'], -$cost, 'Hospital treatment: 1% health');
                $newHealth = min((int) $u['health_max'], (int) $u['health'] + 1);
                q('UPDATE users SET health = ? WHERE id = ?', [$newHealth, $u['id']]);
                set_action_cooldown($u['id'], 'hospital');
                flash('Treatment purchased. You gained 1% health (' . $newHealth . '/' . (int) $u['health_max'] . ').', 'success');
            }
        }
        redirect('hospital.php');
    } elseif ($action === 'full_recovery') {
        if (!is_hospitalized($u)) {
            flash('You are not hospitalized.', 'error');
        } else {
            // Wait 1 day for full recovery - set hospital_until to 1 day from now
            $releaseTime = date('Y-m-d H:i:s', time() + 86400); // 1 day
            q('UPDATE users SET hospital_until = ? WHERE id = ?', [$releaseTime, $u['id']]);
            flash('You will rest and recover fully in 1 day.', 'success');
            redirect('hospital.php');
        }
    }
}

$page_title = 'Hospital';
require __DIR__ . '/includes/header.php';

$u = current_user();
$hospitalized = is_hospitalized($u);
$recent = fetch_all('SELECT * FROM event_log WHERE user_id = ? AND (type = ? OR text LIKE ?) ORDER BY created_at DESC LIMIT 10', [$u['id'], 'hospital', '%hospital%']);
$others = fetch_all('SELECT id, username, level, hospital_until, hospital_reason FROM users WHERE hospital_until > NOW() ORDER BY hospital_until LIMIT 15');
?>
<div class="card">
  <div class="panel-heading">Hospital</div>
  <?php if ($hospitalized): ?>
    <div style="margin-bottom:14px">
      <div class="stat"><span>Reason</span><b><?= e($u['hospital_reason']) ?></b></div>
      <div class="stat"><span>Released</span><b><span data-until="<?= e($u['hospital_until']) ?>"></span></b></div>
      <div class="stat"><span>Health</span><b><?= (int) $u['health'] ?> / <?= (int) $u['health_max'] ?></b></div>
    </div>
    
    <div style="display:flex; gap:12px; flex-wrap:wrap; margin-bottom:16px">
      <form method="post" style="flex:1; min-width:200px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="treat">
        <button class="btn btn-gold" type="submit" style="width:100%">
          Pay <?= money(50000) ?> for +1% Health
        </button>
        <small class="muted">Costs £50,000 • Gains 1% health</small>
      </form>
      
      <form method="post" style="flex:1; min-width:200px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="full_recovery">
        <button class="btn btn-green" type="submit" style="width:100%">
          Wait 1 Day for Full Recovery
        </button>
        <small class="muted">Free • Full health in 24 hours</small>
      </form>
    </div>
  <?php else: ?>
    <div class="stat"><span>Status</span><b style="color:var(--green)">Healthy</b></div>
    <div class="stat"><span>Health</span><b><?= (int) $u['health'] ?> / <?= (int) $u['health_max'] ?></b></div>
    <p class="muted small">Health regenerates automatically over time. Visit the gym to increase max health.</p>
  <?php endif; ?>
</div>

<div class="card" style="margin-top:18px">
  <div class="panel-heading">Recent Hospitalizations</div>
  <?php if (!$recent): ?>
    <p class="muted">No recent hospital visits.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Event</th><th>Amount</th><th>Date</th></tr>
      <?php foreach ($recent as $r): ?>
        <tr>
          <td><?= e($r['text']) ?></td>
          <td><?= money($r['amount']) ?></td>
          <td><?= date('M j, H:i', strtotime($r['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<div class="card" style="margin-top:18px">
  <div class="panel-heading">Currently Hospitalized Players</div>
  <?php if (!$others): ?>
    <p class="muted">No one in the hospital right now.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Player</th><th>Level</th><th>Reason</th><th>Release</th></tr>
      <?php foreach ($others as $o): ?>
        <tr>
          <td><a href="<?= e(url('profile.php?id=' . (int) $o['id'])) ?>"><?= e($o['username']) ?></a></td>
          <td><?= (int) $o['level'] ?></td>
          <td><?= e($o['hospital_reason']) ?></td>
          <td><span data-until="<?= e($o['hospital_until']) ?>"></span></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>