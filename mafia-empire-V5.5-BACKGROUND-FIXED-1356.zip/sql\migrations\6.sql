-- Migration 6: Rate limiting table
CREATE TABLE IF NOT EXISTS rate_limits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_key_created (`key`, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;