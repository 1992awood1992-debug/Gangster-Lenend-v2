<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Combat power, fight resolution and kill payouts (the PvP core).
 */
final class CombatTest extends TestCase
{
    public function testCombatPowerSumsBaseStats(): void
    {
        $u = $this->makeUser(['strength' => 10, 'speed' => 5, 'defense' => 3, 'iq' => 2]);
        $power = combat_power((int) $u['id']);
        $this->assertSame(15, $power['attack']);   // strength + speed
        $this->assertSame(5, $power['defense']);   // defense + iq
    }

    public function testCombatPowerIncludesEquippedItems(): void
    {
        $u = $this->makeUser(['strength' => 10, 'speed' => 5, 'defense' => 3, 'iq' => 2]);
        $item = fetch('SELECT * FROM items ORDER BY attack DESC LIMIT 1');
        insert('user_items', ['user_id' => $u['id'], 'item_id' => $item['id'], 'qty' => 1, 'equipped' => 1]);

        $power = combat_power((int) $u['id']);
        $this->assertSame(15 + (int) $item['attack'], $power['attack']);
        $this->assertSame(5 + (int) $item['defense'], $power['defense']);
    }

    public function testUnequippedItemsDoNotCount(): void
    {
        $u = $this->makeUser(['strength' => 10, 'speed' => 5, 'defense' => 3, 'iq' => 2]);
        $item = fetch('SELECT * FROM items ORDER BY attack DESC LIMIT 1');
        insert('user_items', ['user_id' => $u['id'], 'item_id' => $item['id'], 'qty' => 1, 'equipped' => 0]);

        $power = combat_power((int) $u['id']);
        $this->assertSame(15, $power['attack']);
        $this->assertSame(5, $power['defense']);
    }

    public function testResolveFightProducesWinnerAndLog(): void
    {
        mt_srand(1234);
        $a = $this->makeUser(['health' => 50, 'health_max' => 50]);
        $b = $this->makeUser(['health' => 50, 'health_max' => 50]);

        $result = resolve_fight($a, $b);

        $this->assertContains($result['winner'], [(int) $a['id'], (int) $b['id']]);
        $this->assertNotEmpty($result['log']);
        $this->assertGreaterThanOrEqual(1, $result['rounds']);
        $this->assertLessThanOrEqual(20, $result['rounds']);
    }

    public function testAwardKillTransfersCashAndHospitalizesVictim(): void
    {
        mt_srand(7);
        $attacker = $this->makeUser(['money' => 1000, 'level' => 5]);
        $victim   = $this->makeUser(['money' => 1000, 'level' => 3]);

        $result = award_kill($attacker, $victim);

        $this->assertSame(150, $result['steal']); // 15% of 1000, min 100

        $af = $this->freshUser((int) $attacker['id']);
        $vf = $this->freshUser((int) $victim['id']);

        $this->assertSame(1150, (int) $af['money']);
        $this->assertSame(1, (int) $af['kills']);
        $this->assertSame(1, (int) $af['wins']);
        $this->assertGreaterThan(0, (int) $af['xp']);

        $this->assertSame(1, (int) $vf['deaths']);
        $this->assertSame(900, (int) $vf['money']); // 10% hospital bill
        $this->assertNotNull($vf['hospital_until']);
        $this->assertGreaterThan(time(), strtotime($vf['hospital_until']));
        $this->assertNotEmpty(fetch_all('SELECT * FROM notifications WHERE user_id = ?', [$victim['id']]));
    }
}
