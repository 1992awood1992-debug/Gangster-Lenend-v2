<?php
/**
 * Eye Of The Mafia - Workbench (Crafting)
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/crafting.php';

$u = require_login();

// POST: attempt craft
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'craft') {
        $result = crafting_craft($u['id'], (int) ($_POST['recipe_id'] ?? 0));
        if (!empty($result['ok'])) {
            flash($result['message'], 'success');
        } else {
            flash($result['error'] ?? 'Crafting failed.', 'error');
        }
    } elseif ($action === 'discover') {
        $result = crafting_discover($u['id'], (int) ($_POST['recipe_id'] ?? 0));
        if (!empty($result['ok'])) {
            flash('Learned new recipe: ' . e($result['recipe']), 'success');
        } else {
            flash($result['error'] ?? 'Could not learn recipe.', 'error');
        }
    } elseif ($action === 'use_blueprint') {
        $result = crafting_use_blueprint($u['id'], (int) ($_POST['item_id'] ?? 0));
        if (!empty($result['ok'])) {
            flash('Learned new recipe: ' . e($result['recipe']), 'success');
        } else {
            flash($result['error'] ?? 'No recipe for that blueprint.', 'error');
        }
    } elseif (action_on_cooldown($u['id'], 'workbench')) {
        $cd = action_on_cooldown($u['id'], 'workbench');
        flash('Workbench on cooldown. Try again in ' . $cd . '.', 'error');
    }
    redirect('crafting.php');
}

$page_title = 'Workbench';
require __DIR__ . '/includes/header.php';

$categories = crafting_get_categories();
$availableRecipes = crafting_get_available_recipes($u['id']);
$knownRecipes = crafting_get_known($u['id']);
$history = crafting_get_history($u['id'], 20);

?>

<div class="card">
  <div class="panel-heading">Workbench</div>
  <p class="muted small">Combine items and drugs to craft upgraded gear. Discover new recipes from blueprints.</p>
  <div class="stat"><span>Energy</span><b><?= (int) $u['energy'] ?> / <?= (int) $u['energy_max'] ?></b></div>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
  <div class="stat"><span>Known Recipes</span><b><?= count($knownRecipes) ?> / <?= count($availableRecipes) ?></b></div>
</div>

<?php if ($knownRecipes): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Discovered Blueprints <span class="tag tag-gold"><?= count($knownRecipes) ?></span></div>
  <div class="table-wrap"><table>
    <tr><th>Recipe</th><th>Category</th><th>Level</th><th>Energy</th><th>Cost</th><th>Success</th><th></th></tr>
    <?php foreach ($knownRecipes as $r): $can = crafting_can_craft($u['id'], (int) $r['id']); $ingredients = json_decode($r['ingredients'], true); ?>
    <tr>
      <td>
        <b><?= e($r['name']) ?></b><br>
        <small class="muted"><?= e($r['description']) ?></small>
      </td>
      <td><?= e(ucfirst($r['category'])) ?></td>
      <td><?= (int) $r['min_level'] ?></td>
      <td><?= (int) $r['energy_cost'] ?></td>
      <td><?= money($r['money_cost']) ?></td>
      <td><?= (int) $r['success_chance'] ?>%</td>
      <td>
        <?php if ($can['ok']): ?>
          <form method="post" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="craft">
            <input type="hidden" name="recipe_id" value="<?= (int) $r['id'] ?>">
            <button class="btn btn-green btn-sm" type="submit">Craft</button>
          </form>
        <?php else: ?>
          <span class="tag tag-common" title="<?= e($can['error']) ?>">Missing</span>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<?php 
// Show discoverable recipes not yet known
$undiscovered = array_filter($availableRecipes, function($r) use ($knownRecipes) {
    return !array_filter($knownRecipes, fn($k) => $k['id'] == $r['id']);
});
if ($undiscovered): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Discoverable Recipes <span class="tag tag-legendary"><?= count($undiscovered) ?></span></div>
  <p class="muted small">These recipes are available to craft once you meet the requirements.</p>
  <div class="table-wrap"><table>
    <tr><th>Recipe</th><th>Category</th><th>Level</th><th>Energy</th><th>Cost</th><th>Success</th><th>Ingredients</th></tr>
    <?php foreach ($undiscovered as $r): $ingredients = json_decode($r['ingredients'], true); ?>
    <tr>
      <td>
        <b><?= e($r['name']) ?></b><br>
        <small class="muted"><?= e($r['description']) ?></small>
      </td>
      <td><?= e(ucfirst($r['category'])) ?></td>
      <td><?= (int) $r['min_level'] ?></td>
      <td><?= (int) $r['energy_cost'] ?></td>
      <td><?= money($r['money_cost']) ?></td>
      <td><?= (int) $r['success_chance'] ?>%</td>
      <td>
        <small>
        <?php foreach ($ingredients as $ing): 
          $name = '';
          if ($ing['type'] === 'item') $name = fetch_one('SELECT name FROM items WHERE id = ?', [(int) $ing['id']], 'Unknown');
          elseif ($ing['type'] === 'drug') $name = fetch_one('SELECT name FROM drugs WHERE id = ?', [(int) $ing['id']], 'Unknown');
        ?>
          <?= (int) $ing['qty'] ?>x <?= e($name) ?><br>
        <?php endforeach; ?>
        </small>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<?php if ($history): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Crafting History</div>
  <div class="table-wrap"><table>
    <tr><th>Time</th><th>Recipe</th><th>Result</th></tr>
    <?php foreach ($history as $h): ?>
    <tr class="<?= $h['success'] ? 'success' : 'error' ?>">
      <td><?= date('M j H:i', strtotime($h['created_at'])) ?></td>
      <td><?= e($h['name']) ?></td>
      <td>
        <?php if ($h['success']): ?>
          <span class="tag tag-legendary">✓ Success</span>
        <?php else: ?>
          <span class="tag tag-common">✗ Failed<?= $h['ingredients_lost'] ? ' (ingredients lost)' : '' ?></span>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<div class="card" style="margin-top:16px">
  <div class="panel-heading">How It Works</div>
  <ul class="muted small" style="line-height:1.8">
    <li>Crafting consumes <strong>energy</strong>, <strong>cash</strong>, and <strong>ingredients</strong> (items/drugs).</li>
    <li>Success chance varies by recipe. Failed crafts may lose ingredients.</li>
    <li>Discoverable recipes appear automatically when you meet level requirements.</li>
    <li>Hidden recipes require <strong>blueprint items</strong> (found in missions, bosses, market).</li>
    <li>Crafted gear can have better stats than store-bought equivalents.</li>
    <li>Every successful craft grants <strong>XP</strong> based on recipe level.</li>
  </ul>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>