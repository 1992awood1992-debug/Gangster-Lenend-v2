<?php
/**
 * Eye Of The Mafia - Daily/Weekly Login Rewards
 * Streak-based rewards with milestone bonuses.
 */

require_once __DIR__ . '/init.php';

/**
 * Get the login reward definition for a given day number.
 * Cycles after day 30.
 */
function login_reward_get(int $day): ?array
{
    $day = (($day - 1) % 30) + 1; // Cycle 1-30
    return fetch('SELECT * FROM login_rewards WHERE day_number = ?', [$day]);
}

/**
 * Get or create a user's login streak record.
 */
function login_streak_get(int $userId): array
{
    $streak = fetch('SELECT * FROM user_login_streaks WHERE user_id = ?', [$userId]);
    if (!$streak) {
        insert('user_login_streaks', ['user_id' => $userId]);
        $streak = fetch('SELECT * FROM user_login_streaks WHERE user_id = ?', [$userId]);
    }
    return $streak;
}

/**
 * Check if user has already claimed today's reward.
 */
function login_reward_claimed_today(int $userId): bool
{
    $streak = login_streak_get($userId);
    if (!$streak['last_claim_date']) return false;
    return $streak['last_claim_date'] === date('Y-m-d');
}

/**
 * Check if user can claim a reward (new day since last login).
 */
function login_can_claim(int $userId): bool
{
    $streak = login_streak_get($userId);
    $today = date('Y-m-d');
    
    if (!$streak['last_login_date']) return true; // First login ever
    if ($streak['last_login_date'] === $today) return false; // Already logged in today
    
    // Check if streak continues (yesterday) or breaks
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    return true; // Can always claim on a new day
}

/**
 * Process daily login: update streak, determine reward day, return reward info.
 * Returns array with reward details and streak info.
 */
function login_process_daily(int $userId): array
{
    $streak = login_streak_get($userId);
    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    
    $isNewDay = $streak['last_login_date'] !== $today;
    $streakContinued = $streak['last_login_date'] === $yesterday;
    
    if ($isNewDay) {
        // New login day
        if ($streakContinued) {
            $streak['current_streak'] = (int) $streak['current_streak'] + 1;
        } else {
            $streak['current_streak'] = 1; // Streak broken, restart
        }
        
        if ((int) $streak['current_streak'] > (int) $streak['longest_streak']) {
            $streak['longest_streak'] = $streak['current_streak'];
        }
        
        $streak['last_login_date'] = $today;
        $streak['total_logins'] = (int) $streak['total_logins'] + 1;
        
        q('UPDATE user_login_streaks SET current_streak = ?, longest_streak = ?, last_login_date = ?, total_logins = ? WHERE user_id = ?',
            [$streak['current_streak'], $streak['longest_streak'], $streak['last_login_date'], $streak['total_logins'], $userId]);
    }
    
    // Determine reward day (based on current streak, cycles every 30)
    $rewardDay = (int) $streak['current_streak'];
    $reward = login_reward_get($rewardDay);
    
    return [
        'streak' => (int) $streak['current_streak'],
        'longest_streak' => (int) $streak['longest_streak'],
        'total_logins' => (int) $streak['total_logins'],
        'reward_day' => $rewardDay,
        'reward' => $reward,
        'already_claimed' => $streak['last_claim_date'] === $today,
        'can_claim' => $streak['last_claim_date'] !== $today,
        'is_new_day' => $isNewDay,
    ];
}

/**
 * Claim the daily login reward.
 * Returns ['ok' => true, 'reward' => [...]] or ['ok' => false, 'error' => '...']
 */
function login_claim_reward(int $userId): array
{
    $info = login_process_daily($userId);
    
    if ($info['already_claimed']) {
        return ['ok' => false, 'error' => 'Already claimed today'];
    }
    if (!$info['can_claim']) {
        return ['ok' => false, 'error' => 'Not eligible to claim'];
    }
    
    $reward = $info['reward'];
    if (!$reward) {
        return ['ok' => false, 'error' => 'No reward configured'];
    }
    
    // Grant the reward
    $granted = [];
    
    switch ($reward['reward_type']) {
        case 'money':
            add_money($userId, (int) $reward['reward_value'], 'Daily login reward');
            $granted[] = money($reward['reward_value']) . ' Cash';
            break;
        case 'points':
            add_points($userId, (int) $reward['reward_value']);
            $granted[] = number_format((int) $reward['reward_value']) . ' Points';
            break;
        case 'xp':
            grant_xp($userId, (int) $reward['reward_value']);
            $granted[] = number_format((int) $reward['reward_value']) . ' XP';
            break;
        case 'bullets':
            add_bullets($userId, (int) $reward['reward_value']);
            $granted[] = number_format((int) $reward['reward_value']) . ' Bullets';
            break;
        case 'energy':
            q('UPDATE users SET energy = LEAST(energy + ?, energy_max) WHERE id = ?', [(int) $reward['reward_value'], $userId]);
            $granted[] = number_format((int) $reward['reward_value']) . ' Energy';
            break;
        case 'nerve':
            q('UPDATE users SET nerve = LEAST(nerve + ?, nerve_max) WHERE id = ?', [(int) $reward['reward_value'], $userId]);
            $granted[] = number_format((int) $reward['reward_value']) . ' Nerve';
            break;
        case 'item':
            if ($reward['reward_item_id']) {
                $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$userId, $reward['reward_item_id']]);
                if ($existing) {
                    q('UPDATE user_items SET qty = qty + 1 WHERE id = ?', [(int) $existing['id']]);
                } else {
                    insert('user_items', ['user_id' => $userId, 'item_id' => $reward['reward_item_id'], 'qty' => 1, 'equipped' => 0]);
                }
                $item = fetch('SELECT name FROM items WHERE id = ?', [$reward['reward_item_id']]);
                $granted[] = $item['name'] ?? 'Item';
            }
            break;
    }
    
    // Log the claim
    $today = date('Y-m-d');
    q('UPDATE user_login_streaks SET last_claim_date = ? WHERE user_id = ?', [$today, $userId]);
    
    insert('user_login_reward_log', [
        'user_id' => $userId,
        'day_number' => $info['reward_day'],
        'reward_type' => $reward['reward_type'],
        'reward_value' => (string) $reward['reward_value'],
        'claimed_at' => date('Y-m-d H:i:s'),
    ]);
    
    // Analytics
    analytics_track('login_reward_claim', $userId, [
        'streak_day' => $info['reward_day'],
        'reward_type' => $reward['reward_type'],
        'reward_value' => (int) $reward['reward_value'],
        'is_milestone' => (bool) $reward['is_milestone'],
    ]);
    
    return [
        'ok' => true,
        'reward' => $granted,
        'streak' => $info['streak'],
        'reward_day' => $info['reward_day'],
        'is_milestone' => (bool) $reward['is_milestone'],
        'milestone_label' => $reward['milestone_label'] ?? null,
    ];
}

/**
 * Get the next 7 upcoming rewards for preview.
 */
function login_get_upcoming_rewards(int $userId, int $count = 7): array
{
    $info = login_process_daily($userId);
    $currentStreak = $info['streak'];
    $upcoming = [];
    
    for ($i = 1; $i <= $count; $i++) {
        $day = $currentStreak + $i;
        $r = login_reward_get($day);
        if ($r) {
            $upcoming[] = [
                'day' => $day,
                'reward' => $r,
                'is_current' => ($i === 1 && !$info['already_claimed']),
            ];
        }
    }
    return $upcoming;
}

/**
 * Get user's streak stats for display.
 */
function login_get_stats(int $userId): array
{
    $streak = login_streak_get($userId);
    $info = login_process_daily($userId);
    return [
        'current_streak' => $info['streak'],
        'longest_streak' => $info['longest_streak'],
        'total_logins' => $info['total_logins'],
        'last_login' => $streak['last_login_date'],
        'last_claim' => $streak['last_claim_date'],
        'can_claim_today' => $info['can_claim'] && !$info['already_claimed'],
        'reward_day' => $info['reward_day'],
    ];
}

/**
 * Render a reward preview card (for the upcoming rewards carousel).
 */
function login_render_reward_card(array $reward, bool $isCurrent = false): string
{
    $icons = [
        'money' => '&#36;',
        'points' => '&#9733;',
        'xp' => '&#9670;',
        'bullets' => '&#9679;',
        'energy' => '&#9889;',
        'nerve' => '&#9875;',
        'item' => '&#10026;',
    ];
    $icon = $icons[$reward['reward_type']] ?? '&#9670;';
    
    $label = $reward['milestone_label'] ? " — {$reward['milestone_label']}" : '';
    $value = $reward['reward_value'] ? " {$reward['reward_value']}" : '';
    $typeLabel = ucfirst($reward['reward_type']);
    
    $css = $isCurrent ? 'reward-card current' : 'reward-card';
    
    return <<<HTML
    <div class="$css" data-day="{$reward['day_number']}">
      <div class="reward-icon" aria-hidden="true">$icon</div>
      <div class="reward-info">
        <div class="reward-type">$typeLabel$value$label</div>
        <div class="reward-day">Day {$reward['day_number']}</div>
      </div>
      $isCurrent: <span class="tag tag-gold">Available Now</span>
    </div>
HTML;
}