<?php
/**
 * Eye Of The Mafia - Properties / Safehouses
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/properties.php';

$u = require_login();

// POST handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'buy') {
        $result = property_buy($u['id'], (int) ($_POST['property_type_id'] ?? 0));
        flash($result['error'] ?? 'Property purchased!', $result['ok'] ? 'success' : 'error');
    } elseif ($action === 'upgrade') {
        $result = property_upgrade($u['id'], (int) ($_POST['property_id'] ?? 0), (int) ($_POST['target_level'] ?? 0));
        flash($result['error'] ?? 'Property upgraded!', $result['ok'] ? 'success' : 'error');
    } elseif ($action === 'collect') {
        $result = property_collect($u['id'], (int) ($_POST['property_id'] ?? 0));
        if ($result['ok']) {
            $parts = [];
            if ($result['money']) $parts[] = money($result['money']);
            if ($result['bullets']) $parts[] = number_format($result['bullets']) . ' bullets';
            if ($result['points']) $parts[] = number_format($result['points']) . ' pts';
            flash('Collected: ' . implode(', ', $parts) . " ({$result['hours']}h accrued)", 'success');
        } else {
            flash($result['error'], 'error');
        }
    } elseif ($action === 'collect_all') {
        $result = property_collect_all($u['id']);
        $parts = [];
        if ($result['money']) $parts[] = money($result['money']);
        if ($result['bullets']) $parts[] = number_format($result['bullets']) . ' bullets';
        if ($result['points']) $parts[] = number_format($result['points']) . ' pts';
        flash('Collected from all: ' . implode(', ', $parts), 'success');
    } elseif ($action === 'rename') {
        $result = property_rename($u['id'], (int) ($_POST['property_id'] ?? 0), (string) ($_POST['nickname'] ?? ''));
        flash($result['error'] ?? 'Renamed!', $result['ok'] ? 'success' : 'error');
    } elseif ($action === 'sell') {
        $result = property_sell($u['id'], (int) ($_POST['property_id'] ?? 0));
        flash($result['error'] ?? 'Property sold for ' . money($result['sale_price']), $result['ok'] ? 'success' : 'error');
    }
    redirect('properties.php');
}

$page_title = 'Properties';
require __DIR__ . '/includes/header.php';

$types = property_get_types();
$myProps = property_get_user($u['id']);

?>

<div class="card">
  <div class="panel-heading">Properties & Safehouses</div>
  <p class="muted small">Buy properties to generate passive income and increase storage. Upgrade to boost production.</p>
  
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
  <div class="stat"><span>Bullets</span><b><?= number_format((int) $u['bullets']) ?></b></div>
  <div class="stat"><span>Points</span><b><?= number_format((int) $u['points']) ?></b></div>
</div>

<h2>Available Properties</h2>
<div class="grid grid-2">
  <?php foreach ($types as $t): 
    $owned = false;
    foreach ($myProps as $mp) if ((int) $mp['property_type_id'] === (int) $t['id']) $owned = true;
    $canAfford = (int) $u['money'] >= (int) $t['base_price'];
    $levelReq = 5;
    $locked = (int) $u['level'] < $levelReq;
  ?>
  <div class="card">
    <b><?= e($t['name']) ?></b>
    <br><small class="muted"><?= e($t['description']) ?></small>
    <div class="stat"><span>Base Cost</span><b><?= money($t['base_price']) ?></b></div>
    <div class="stat"><span>Hourly Income (Lv 1)</span><b><?= money($t['income_money_per_hour']) ?> | <?= (int) $t['income_bullets_per_hour'] ?> bullets | <?= (int) $t['income_points_per_hour'] ?> pts</b></div>
    <div class="stat"><span>Storage</span><b><?= (int) $t['storage_items'] ?> items | <?= (int) $t['storage_drugs'] ?> drugs | <?= number_format($t['storage_bullets']) ?> bullets</b></div>
    <div class="stat"><span>Max Level</span><b><?= (int) $t['max_level'] ?></b></div>
    <?php if ($owned): ?>
      <span class="tag tag-legendary">OWNED</span>
    <?php elseif ($locked): ?>
      <span class="tag tag-common">Locked (Lvl <?= $levelReq ?>+)</span>
    <?php elseif (!$canAfford): ?>
      <span class="tag tag-common">Can't afford</span>
    <?php else: ?>
      <form method="post" style="margin-top:8px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="buy">
        <input type="hidden" name="property_type_id" value="<?= (int) $t['id'] ?>">
        <button class="btn btn-gold btn-block btn-sm" type="submit">Buy for <?= money($t['base_price']) ?></button>
      </form>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<?php if ($myProps): ?>
<h2 style="margin-top:24px">Your Properties</h2>
<?php foreach ($myProps as $p): 
  $preview = property_get_income_preview($p);
  $nextLevel = (int) $p['level'] + 1;
  $canUpgrade = (int) $p['level'] < (int) $p['max_level'];
  $upgradeCost = $canUpgrade ? property_upgrade_cost($p, (int) $p['level'] + 1) : null;
  $canAffordUpgrade = $canUpgrade && $upgradeCost['ok'] && (int) $u['money'] >= $upgradeCost['money'] && (int) $u['bullets'] >= $upgradeCost['bullets'] && (int) $u['points'] >= $upgradeCost['points'];
?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">
    <span><?= e($p['nickname'] ? $p['nickname'] : $p['name']) ?></span>
    <span class="tag tag-<?= $p['is_active'] ? 'legendary' : 'common' ?>">Lv <?= (int) $p['level'] ?></span>
  </div>
  
  <div class="grid grid-3" style="margin:8px 0">
    <div class="stat"><span>Hourly</span><b><?= money($preview['per_hour']['money']) ?> | <?= $preview['per_hour']['bullets'] ?> 🔫 | <?= $preview['per_hour']['points'] ?> ⭐</b></div>
    <div class="stat"><span>Daily</span><b><?= money($preview['per_day']['money']) ?> | <?= $preview['per_day']['bullets'] ?> 🔫 | <?= $preview['per_day']['points'] ?> ⭐</b></div>
    <div class="stat"><span>Storage</span><b><?= (int) $p['storage_items'] ?> items | <?= (int) $p['storage_drugs'] ?> drugs | <?= number_format($p['storage_bullets']) ?> 🔫</b></div>
  </div>
  
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
    <form method="post" style="display:inline">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="collect">
      <input type="hidden" name="property_id" value="<?= (int) $p['id'] ?>">
      <button class="btn btn-green btn-sm" type="submit">💰 Collect</button>
    </form>
    
    <?php if ($canUpgrade): ?>
      <form method="post" style="display:inline">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="upgrade">
        <input type="hidden" name="property_id" value="<?= (int) $p['id'] ?>">
        <input type="hidden" name="target_level" value="<?= (int) $p['level'] + 1 ?>">
        <button class="btn btn-sm <?= $canAffordUpgrade ? 'btn-gold' : 'btn-disabled' ?>" type="submit" <?= !$canAffordUpgrade ? 'disabled' : '' ?>>
          ⬆ Upgrade to Lv <?= $nextLevel ?> (<?= money($upgradeCost['money']) ?> + <?= $upgradeCost['bullets'] ?> 🔫 + <?= $upgradeCost['points'] ?> ⭐)
        </button>
      </form>
    <?php else: ?>
      <span class="tag tag-legendary">MAX LEVEL</span>
    <?php endif; ?>
    
    <form method="post" style="display:inline;flex:1;text-align:center">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="rename">
      <input type="hidden" name="property_id" value="<?= (int) $p['id'] ?>">
      <input type="text" name="nickname" placeholder="Nickname (optional)" value="<?= e($p['nickname'] ?? '') ?>" style="width:120px;padding:4px 8px;margin:0 4px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
      <button class="btn btn-sm" type="submit">✏ Rename</button>
    </form>
    
    <form method="post" style="display:inline" onsubmit="return confirm('Sell this property for 50% value?')">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="sell">
      <input type="hidden" name="property_id" value="<?= (int) $p['id'] ?>">
      <button class="btn btn-sm btn-danger" type="submit">💸 Sell (50%)</button>
    </form>
  </div>
</div>
<?php endforeach; ?>

<div style="margin-top:16px">
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="collect_all">
    <button class="btn btn-gold btn-block" type="submit">💰 Collect All Properties</button>
  </form>
</div>
<?php else: ?>
<div class="card" style="margin-top:16px;text-align:center">
  <p class="muted">No properties owned yet. Buy one above to start earning passive income!</p>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>