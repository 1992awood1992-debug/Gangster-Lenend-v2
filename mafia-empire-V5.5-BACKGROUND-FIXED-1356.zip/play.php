<?php
require_once __DIR__ . '/includes/header.php';
require_login();

$rank = rank_for_level((int) $u['level']);
$district = fetch('SELECT * FROM districts WHERE id = ?', [$u['district_id']]);
$notifs = fetch_all('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 6', [$u['id']]);
$events = fetch_all('SELECT * FROM event_log WHERE user_id = ? ORDER BY created_at DESC LIMIT 8', [$u['id']]);
$xpNeed = xp_for_level((int) $u['level'] + 1);
?>
<div class="card">
  <div class="panel-heading">The City &mdash; <?= e($district['name'] ?? 'Downtown') ?></div>
  <div class="grid grid-4">
    <div class="center"><div class="big"><?= (int) $u['energy'] ?></div><div class="muted small">Energy</div></div>
    <div class="center"><div class="big"><?= (int) $u['nerve'] ?></div><div class="muted small">Nerve</div></div>
    <div class="center"><div class="big"><?= (int) $u['health'] ?></div><div class="muted small">Health</div></div>
    <div class="center"><div class="big"><?= (int) $u['bullets'] ?></div><div class="muted small">Bullets</div></div>
  </div>
  <div style="margin-top:14px">
    <div class="muted small" style="display:flex;justify-content:space-between"><span><?= e($rank['name']) ?> &middot; Level <?= (int) $u['level'] ?></span><span><?= (int) $u['xp'] ?> / <?= $xpNeed ?> XP</span></div>
    <div class="progress"><i style="width:<?= min(100, round((int) $u['xp'] / max(1, $xpNeed) * 100)) ?>%"></i></div>
  </div>
  <?php if (function_exists('heat_info')): $heat = heat_info($u['id']); ?>
  <div style="margin-top:14px;padding:8px 12px;border-radius:6px;background:rgba(0,0,0,.4);border:1px solid var(--line);display:flex;align-items:center;gap:12px">
    <span style="font-size:1.4rem"><?= $heat['icon'] ?></span>
    <div style="flex:1">
      <div style="font-size:.85rem;color:<?= e($heat['color']) ?>;font-weight:700"><?= e($heat['name']) ?> &middot; Level <?= (int)$heat['level'] ?></div>
      <div class="progress" style="margin-top:4px"><i style="width:<?= (int)($heat['level'] * 20) ?>%;background:<?= e($heat['color']) ?>"></i></div>
    </div>
    <span style="font-size:.8rem;color:var(--muted)">Earnings: <?= (int) round($heat['multiplier'] * 100) ?>%</span>
  </div>
  <?php endif; ?>
</div>
<div class="grid grid-4">
  <?php
  $tiles = [
      ['Missions', 'Spend energy, gain cash', 'missions.php', '&#128373;'],
      ['Criminal Jobs', 'Spend nerve for profit', 'criminal_jobs.php', '&#128274;'],
      ['The Gym', 'Raise your stats', 'gym.php', '&#127947;'],
      ['Bosses', 'Big rewards, big risk', 'bosses.php', '&#128128;'],
      ['Kill', 'Hunt another player', 'kill.php', '&#128299;'],
      ['The Empire', 'Manage your holdings', 'empire.php', '&#127984;'],
      ['Drugs', 'Buy low, sell high', 'drugs.php', '&#128138;'],
      ['Districts', 'Travel the city', 'districts.php', '&#127961;'],
      ['Bank', 'Keep your money safe', 'bank.php', '&#127974;'],
      ['Black Market', 'Player marketplace', 'black-market.php', '&#127982;'],
      ['Equipment', 'Arm yourself', 'equipment.php', '&#9876;'],
      ['Casino', 'Try your luck', 'casino.php', '&#127920;'],
  ];
  foreach ($tiles as $t): ?>
    <a class="tile" href="<?= e(url($t[2])) ?>"><span class="ico"><?= $t[3] ?></span><b><?= e($t[0]) ?></b><small><?= e($t[1]) ?></small></a>
  <?php endforeach; ?>
</div>

<div class="grid grid-2" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Notifications</div>
    <?php if (!$notifs): ?><p class="muted">Nothing new.</p><?php endif; ?>
    <?php foreach ($notifs as $n): ?>
      <div class="stat"><span><?= e($n['text']) ?><br><small class="muted"><?= date('M j, H:i', strtotime($n['created_at'])) ?></small></span><?= $n['is_read'] ? '' : '<span class="tag tag-legendary">new</span>' ?></div>
    <?php endforeach; ?>
    <p><a href="<?= e(url('notifications.php')) ?>">All notifications &raquo;</a></p>
  </div>
  <div class="card">
    <div class="panel-heading">Recent Activity</div>
    <?php if (!$events): ?><p class="muted">No activity yet. Get out there!</p><?php endif; ?>
    <?php foreach ($events as $ev): ?>
      <div class="stat"><span><?= e($ev['text']) ?><br><small class="muted"><?= date('M j, H:i', strtotime($ev['created_at'])) ?></small></span>
      <?php if ((int) $ev['amount']): ?><b><?= money($ev['amount']) ?></b><?php endif; ?></div>
    <?php endforeach; ?>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
