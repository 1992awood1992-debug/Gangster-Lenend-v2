# Deploying Mafia Empire

This document covers running the game beyond a local XAMPP box: scheduled
tasks, backups, the Docker stack, TLS, and monitoring.

## 1. Requirements

- PHP 8.2+ with `pdo_mysql` (and `mbstring` recommended)
- MariaDB 10.11+ / MySQL 8
- A web server (Apache or nginx) pointed at the project root
- Optional: Redis (reserved for future caching/queues), Docker + Compose

## 2. Configuration

Database credentials are read from environment variables first, then fall back
to the local defaults in `config.php`:

| Variable  | Default        |
|-----------|----------------|
| `DB_HOST` | `127.0.0.1`    |
| `DB_PORT` | `3306`         |
| `DB_NAME` | `mafia_empire` |
| `DB_USER` | `root`         |
| `DB_PASS` | *(empty)*      |

On first visit the game redirects to `install.php`, which creates the schema and
seed data. Schema upgrades are applied automatically via
`sql/migrations/<N>.sql` (tracked by `SCHEMA_VERSION` in `config.php`, currently
**8**). Migrations 5 (social features), 6 (rate limiting), 7 (analytics) and 8
(content expansion) add the tables for trading, crew chat, hitlist/bounties,
social notifications, auth rate limiting, analytics/telemetry events, and two
new districts with missions, bosses, jobs and legendary items.

> Note: auth endpoints (login/register) are rate-limited per IP (5 attempts /
> 15 minutes by default). Behind a load balancer/reverse proxy, ensure
> `REMOTE_ADDR` reflects the real client IP (e.g. `X-Forwarded-For`) or the
> limiter will apply per-proxy-IP.

## 3. Scheduled tasks (cron)

`cron/run.php` is the single dispatcher. Run it from the system crontab:

```cron
# every 5 minutes - offline regeneration + expired crew wars
*/5 * * * *  cd /var/www/mafia-empire && php cron/run.php tick    >> /var/log/mafia-cron.log 2>&1

# daily at 00:05 - lottery draw + open next draw + prune notifications
5 0 * * *    cd /var/www/mafia-empire && php cron/run.php daily   >> /var/log/mafia-cron.log 2>&1

# weekly Sunday 03:00 - prune old logs, expire stale listings
0 3 * * 0    cd /var/www/mafia-empire && php cron/run.php weekly  >> /var/log/mafia-cron.log 2>&1
```

Tasks are idempotent and guarded by a per-task file lock, so overlapping runs
are skipped safely. `php cron/run.php all` runs every task once (handy after a
deploy).

> On Windows, register the same commands with **Task Scheduler** using
> `C:\xampp\php\php.exe C:\path\to\mafia-empire\cron\run.php tick`.

## 4. Backups

```bash
./scripts/backup.sh                 # gzipped dump -> ./backups, prunes >14 days
./scripts/restore.sh backups/mafia_empire_YYYYMMDD_HHMMSS.sql.gz
```

Windows equivalents: `scripts\backup.bat` and `scripts\restore.bat`.

Suggested cron entry (daily at 02:30):

```cron
30 2 * * *  cd /var/www/mafia-empire && RETENTION_DAYS=14 ./scripts/backup.sh >> /var/log/mafia-backup.log 2>&1
```

Store backups off-box (S3, rsync, another volume). A backup you cannot restore
is not a backup - test `restore.sh` periodically.

## 5. Docker stack

The repository ships a production-oriented stack: **nginx + PHP-FPM + MariaDB +
Redis** (plus an optional certbot sidecar).

```bash
cp .env.example .env          # edit the passwords
docker compose up -d --build
docker compose exec php php cron/run.php migrate
```

Then open `http://localhost:8080` and complete `install.php`.

- Code is bind-mounted into both `php` and `web` for convenience. For immutable
  production images, drop the `volumes: ./:/var/www/html` lines and rely on the
  `COPY` baked into the `Dockerfile`.
- The nginx config (`docker/nginx/default.conf`) ships with gzip compression and
  long-lived cache headers for static assets; no extra setup required.
- Add the cron commands above to the host (they call `docker compose exec -T php
  php cron/run.php ...`) or run a dedicated scheduler container.
- The MariaDB data lives in the `db_data` volume; back it up with
  `docker compose exec db mariadb-dump ...` or by running `scripts/backup.sh`
  against the exposed database.

## 6. TLS / Let's Encrypt

1. Point `DOMAIN` at your server and ensure port 80 is reachable.
2. Obtain certificates:

   ```bash
   DOMAIN=game.example.com CERTBOT_EMAIL=admin@example.com ./scripts/ssl-init.sh
   ```

3. Mount `docker/certbot/conf` into the `web` service, uncomment the HTTPS
   server block in `docker/nginx/default.conf`, and reload:

   ```bash
   docker compose exec web nginx -s reload
   ```

4. The `certbot` service renews certificates every 12 hours (enable it with
   `docker compose --profile tls up -d`).

## 7. Monitoring & health checks

`GET /health.php` returns JSON and an HTTP status code:

- `200` - healthy
- `503` - database unavailable, schema out of date, not installed, or low disk

```json
{
  "status": "ok",
  "time": "2026-10-11T12:00:00+00:00",
  "checks": {
    "database": { "ok": true, "schema_version": 2 },
    "installed": true,
    "disk": { "ok": true, "free_bytes": 1234567890 }
  }
}
```

Wire it into your uptime monitor, Kubernetes liveness probe, or an nginx/
`docker healthcheck`. Logs to watch: the web server error log, MySQL slow
query log, and `mafia-cron.log`.

## 8. CI/CD

`.github/workflows/ci.yml` runs on every push/PR:

1. **lint** - `php -l` across the tree.
2. **smoke** - boots a MySQL service, loads `sql/schema.sql`, runs migrations +
   a task, starts the built-in server and asserts `/health.php` returns 200.
3. **tests** - runs PHPUnit once `composer.json` + `tests/` exist (Phase 6).
