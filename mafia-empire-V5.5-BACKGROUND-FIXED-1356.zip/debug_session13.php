<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'C:/Users/ash/Documents/Default Project/mafia-empire/config.php';
require 'C:/Users/ash/Documents/Default Project/mafia-empire/includes/db.php';

echo "Before init_secure_session:\n";
echo "Session status: " . session_status() . "\n";

require_once __DIR__ . '/includes/security.php';

echo "\nAfter init_secure_session:\n";
echo "Session status: " . session_status() . "\n";
echo "Session ID: " . session_id() . "\n";
echo "Session cookie params: ";
print_r(session_get_cookie_params());