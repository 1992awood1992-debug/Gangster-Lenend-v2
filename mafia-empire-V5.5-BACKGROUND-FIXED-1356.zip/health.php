<?php
/**
 * Mafia Empire - health check endpoint.
 *
 * Intended for load-balancer / uptime-monitor / Docker healthchecks.
 * Deliberately does NOT load init.php (no session, no redirect) and never
 * reveals credentials. Returns 200 when healthy, 503 otherwise.
 *
 *   GET /health.php
 */
require_once __DIR__ . '/includes/db.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$ok = true;
$checks = [];

// --- Database -----------------------------------------------------------
try {
    $schemaVersion = (int) fetch_one('SELECT v FROM settings WHERE k = ?', ['schema_version'], 0);
    $checks['database'] = ['ok' => true, 'schema_version' => $schemaVersion];
    $expected = defined('SCHEMA_VERSION') ? SCHEMA_VERSION : null;
    if ($expected !== null && $schemaVersion < $expected) {
        $checks['database']['ok'] = false;
        $checks['database']['error'] = 'schema out of date (expected ' . $expected . ')';
        $ok = false;
    }
} catch (Throwable $e) {
    $ok = false;
    $checks['database'] = ['ok' => false, 'error' => 'database unavailable'];
}

// --- Installation -------------------------------------------------------
$checks['installed'] = db_installed();
if (!$checks['installed']) {
    $ok = false;
}

// --- Disk space (require 50 MB free) ------------------------------------
$free = @disk_free_space(__DIR__);
$checks['disk'] = [
    'ok'         => $free === false ? false : $free > 50 * 1024 * 1024,
    'free_bytes' => $free === false ? null : (int) $free,
];
if (!$checks['disk']['ok']) {
    $ok = false;
}

http_response_code($ok ? 200 : 503);
echo json_encode([
    'status' => $ok ? 'ok' : 'fail',
    'time'   => date('c'),
    'checks' => $checks,
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), "\n";
