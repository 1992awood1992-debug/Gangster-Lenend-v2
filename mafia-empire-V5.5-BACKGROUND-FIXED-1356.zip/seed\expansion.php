<?php
/**
 * Mafia Empire - Content Expansion (ROADMAP Phase 2).
 *
 * Idempotent: safe to run any number of times - every insert is
 * guarded by a name/code existence check.
 *
 *   CLI:  php seed/expansion.php
 *   Web:  disabled (admin only / not exposed)
 */
require_once __DIR__ . '/../includes/db.php';

$isCli = (php_sapi_name() === 'cli');
if (!$isCli) {
    // Deliberately require admin session for web access.
    require_once __DIR__ . '/../includes/init.php';
    $u = current_user();
    if (!$u || empty($u['is_admin'])) {
        http_response_code(403);
        exit('Forbidden. Run from CLI: php seed/expansion.php');
    }
}

function ensure_id(string $table, string $col, string $value, array $data): int
{
    $row = fetch("SELECT id FROM $table WHERE $col = ?", [$value]);
    if ($row) {
        return (int) $row['id'];
    }
    return insert($table, $data);
}

$counts = array_fill_keys(['missions', 'items', 'bosses', 'jobs', 'drugs', 'abilities', 'achievements', 'stickers', 'points_store'], 0);

/* ------------------------------- MISSIONS (+50) ------------------------------- */
$missions = [
    // Downtown - rookie era
    [1, 'Collect Money for the Boss', 'Knock on doors and collect the weekly vig.', 3, 1, 180, 6, 0, 10],
    [1, 'Steal a Case of Whiskey', 'Grab the bathtub gin before the Feds do.', 3, 1, 220, 7, 0, 12],
    [1, 'Run the Numbers', 'The bookie needs his slips counted, swift and quiet.', 4, 2, 280, 9, 0, 14],
    [1, 'Fix a Horse Race', 'A little lead in the favorite\'s feed bag.', 4, 2, 320, 10, 0, 18],
    [1, 'Shake Down a Speakeasy', 'Two-bit joints pay for protection too.', 5, 3, 420, 13, 0, 20],
    [1, 'Burn a Rival Still', 'Cut their supply, take their customers.', 5, 3, 460, 14, 0, 22],
    [1, 'Deliver a Warning', 'A baseball bat makes excellent spelling.', 6, 4, 520, 16, 0, 22],
    [1, 'Hijack a Beer Truck', 'The brewery owes the family a truckload.', 7, 4, 680, 20, 0, 28],
    [1, 'Crash a Poker Den', 'Take the pot and send a message.', 6, 5, 600, 18, 0, 24],
    [1, 'Slice of the Union Hall', 'Union dues are for everyone. Especially us.', 8, 6, 800, 24, 1, 30],
    // The Docks - mid
    [2, 'Grease the Boathouse Guard', 'A folded bill opens any gate.', 6, 6, 700, 20, 0, 18],
    [2, 'Steal a Crate Off Pier 7', 'Some cargo was never meant for customs.', 7, 7, 850, 24, 0, 24],
    [2, 'Sink a Rum Runner\'s Sloop', 'No witnesses, no cargo, no problem.', 9, 8, 1100, 30, 1, 32],
    [2, 'Smuggle Cigarettes Inland', 'Contraband in, cash out.', 8, 8, 1000, 28, 0, 26],
    [2, 'Rob the Payroll Barge', 'All hands on deck. Literally.', 9, 9, 1300, 34, 1, 30],
    [2, 'Blackmail the Dockmaster', 'Everyone has a secret. Find his.', 8, 9, 1150, 30, 0, 24],
    [2, 'Torch the Warehouse', 'Insurance money is still money.', 10, 10, 1500, 38, 1, 34],
    [2, 'Slip a Marker Into Customs', 'One crate marked "special" for the family.', 9, 10, 1350, 32, 0, 26],
    [2, 'Hijack the Night Ferry', 'The ferry runs, and so do we.', 11, 11, 1700, 42, 1, 36],
    [2, 'Bust a Strike', 'Scabs get paid. So do we.', 12, 12, 2000, 48, 1, 38],
    // Little Italy - upper mid
    [3, 'Collect From a Rival Capo', 'Debts are paid in person. Or else.', 10, 12, 2200, 50, 1, 30],
    [3, 'Rig the Feast Day Brawl', 'The saint loves a winner, wink wink.', 10, 13, 2100, 48, 0, 28],
    [3, 'Corner the Olive Oil Import', 'Crude oil is fine. Olive oil is better.', 11, 13, 2600, 55, 1, 32],
    [3, 'Steal a Don\'s Briefcase', 'What\'s inside stays inside the family.', 12, 14, 2900, 60, 1, 34],
    [3, 'Bomb a Cop\'s Car', 'A loud message for the Commission.', 13, 14, 3100, 64, 2, 38],
    [3, 'Take Over the Bread Factory', 'Bread is subsidized. Loyalty is not.', 12, 15, 3000, 62, 1, 32],
    [3, 'Kidnap a Rival\'s Cousin', 'Business is personal tonight.', 14, 15, 3500, 70, 2, 38],
    [3, 'Burn the Mortgage Ledger', 'Debt is a paper tiger. Burn it.', 13, 16, 3200, 66, 1, 34],
    [3, 'Crash a Mob Wedding', 'All the families. One very bad night.', 15, 16, 3800, 76, 2, 40],
    [3, 'Whack a Crooked Union Boss', 'He skimmed from his own brothers.', 16, 17, 4500, 88, 2, 44],
    // Wall Street - elite
    [4, 'Pump and Dump a Shell Company', 'The ticker says buy. The family says sell.', 14, 22, 6000, 110, 2, 34],
    [4, 'Launder Through a Charity Gala', 'Champagne, doves, and clean money.', 15, 22, 6500, 118, 2, 36],
    [4, 'Rig a Judge\'s Portfolio', 'The gavel follows the gold.', 16, 24, 7500, 130, 3, 38],
    [4, 'Steal the Vault Keys', 'One set of keys. A very long night.', 18, 25, 9000, 150, 3, 42],
    [4, 'Take Over the Railroad Shares', 'Whoever owns the rails owns the city.', 18, 26, 9500, 156, 3, 40],
    [4, 'Blackmail the Senator', 'The Republic has a price. We paid it.', 20, 28, 11000, 175, 4, 44],
    [4, 'Crash the Exchange Floor', 'Panic is our favorite market.', 22, 30, 14000, 210, 4, 48],
    [4, 'Buy the Election', 'Votes are just shares in the company.', 20, 30, 12000, 190, 4, 42],
    [4, 'Rob the Reserve Teller', 'The government keeps our money. Rude.', 24, 32, 16000, 235, 5, 50],
    [4, 'Disappear the Auditor', 'The numbers must never reach the DA.', 26, 35, 20000, 280, 5, 54],
    [4, 'Snatch the Governor', 'We\'ll make him an offer he can\'t refuse.', 25, 35, 18500, 265, 5, 50],
    [4, 'Print Ration Cards', 'Everyone gets fed. At our prices.', 24, 36, 17000, 250, 4, 44],
    [4, 'Sell the Court Records', 'Evidence for sale. Low mileage.', 26, 37, 19000, 275, 5, 46],
    [4, 'Empty the Mint Warehouse', 'It\'s just a warehouse, boss.', 28, 38, 22000, 310, 6, 52],
    [4, 'Sink a Bullion Ship', 'Gold sleeps at the bottom. We can wait.', 30, 40, 26000, 360, 6, 56],
    [4, 'Frame a Rival Kingpin', 'He\'ll see the inside of a cell, not our businesses.', 28, 40, 24000, 340, 6, 50],
    [4, 'Host a Secret Summit', 'Five families, one room, no arrests.', 28, 42, 23000, 330, 5, 44],
    [4, 'Brokers\' Blood Bath', 'The floor runs red. Call it a correction.', 32, 45, 30000, 410, 8, 58],
    [4, 'The Heist of the Century', 'Everyone says no. That\'s why we say yes.', 35, 48, 38000, 500, 10, 62],
    [4, 'Rule the Underworld', 'The last kingpin standing writes history.', 40, 50, 50000, 650, 12, 66],
];
foreach ($missions as $m) {
    if (!fetch('SELECT id FROM missions WHERE name = ?', [$m[1]])) {
        insert('missions', [
            'district_id' => $m[0], 'name' => $m[1], 'description' => $m[2],
            'energy_cost' => $m[3], 'min_level' => $m[4], 'reward_money' => $m[5],
            'reward_xp' => $m[6], 'reward_points' => $m[7], 'risk' => $m[8],
            'story' => $m[2],
        ]);
        $counts['missions']++;
    }
}

/* ------------------------------- ITEMS (+33) ------------------------------- */
$items = [
    ['Brass Knuckles', 'Polished and persuasive.', 'weapon', 3, 0, 300, 1, 'common'],
    ['Ice Pick', 'Quiet in the tight spots.', 'weapon', 9, 0, 3500, 5, 'common'],
    ['Trench Knife', 'Great for close work in the trenches.', 'weapon', 14, 0, 9000, 7, 'uncommon'],
    ['Revolver .38', 'A gentleman\'s sidearm.', 'weapon', 18, 2, 12000, 8, 'uncommon'],
    ['Garrote Wire', 'You never see it coming.', 'weapon', 22, 1, 26000, 12, 'rare'],
    ['Double-Barrel Shotgun', 'Two chances to say hello.', 'weapon', 30, 3, 40000, 14, 'rare'],
    ['Thompson .45', 'The roaring twenties\' love letter.', 'weapon', 42, 5, 120000, 22, 'epic'],
    ['Machine Pistol', 'Small, loud, and very final.', 'weapon', 34, 4, 70000, 24, 'rare'],
    ['Sniper Rifle', 'Business from a safe distance.', 'weapon', 55, 4, 260000, 35, 'epic'],
    ['Flamethrower', 'For the whole block at once.', 'weapon', 70, 8, 520000, 48, 'legendary'],
    ['Fedora', 'Every mobster needs the silhouette.', 'armor', 0, 2, 400, 1, 'common'],
    ['Wool Overcoat', 'Warm wool, hidden pockets.', 'armor', 0, 4, 1300, 3, 'common'],
    ['Hideout Helmet', 'Keeps the juice out of your eyes.', 'armor', 0, 7, 3000, 4, 'uncommon'],
    ['Three-Piece Suit', 'Style is armor too.', 'armor', 0, 10, 5200, 6, 'uncommon'],
    ['Chainmail Undershirt', 'Old armor never goes out of style.', 'armor', 0, 22, 24000, 13, 'rare'],
    ['Plate Carrier Vest', 'Pots-and-pans protection that works.', 'armor', 1, 34, 90000, 26, 'epic'],
    ["Gangster's Duster", 'Long enough to hide the hardware.', 'armor', 2, 44, 220000, 34, 'epic'],
    ['Pinstripe Long Coat', 'The pinstripes say it all.', 'armor', 2, 60, 350000, 45, 'legendary'],
    ['Model-T Ford', 'The essential mob vehicle.', 'vehicle', 0, 4, 5000, 3, 'common'],
    ['Packard Limousine', 'Arrive like you own the town.', 'vehicle', 1, 14, 28000, 10, 'uncommon'],
    ['Speakeasy Van', 'Disguised delivery. Perfect cover.', 'vehicle', 1, 20, 70000, 16, 'rare'],
    ['Bulletproof Cadillac', 'Windows up, enemies out.', 'vehicle', 2, 26, 90000, 18, 'rare'],
    ['Stutz Bearcat', 'Speed for the getaway of a lifetime.', 'vehicle', 3, 36, 180000, 28, 'epic'],
    ['Armored Truck', 'A vault on wheels.', 'vehicle', 2, 45, 250000, 30, 'epic'],
    ['Rolls-Royce Phantom', 'The crown jewel of the fleet.', 'vehicle', 4, 70, 600000, 50, 'legendary'],
    ['Brass Spittoon', 'Lucky piece from the old speakeasy.', 'misc', 0, 2, 800, 2, 'common'],
    ['Silver Fob Watch', 'Keeps time and old promises.', 'misc', 2, 3, 2800, 8, 'uncommon'],
    ['Winning Lottery Ticket', 'It says "winner". We\'ll see.', 'misc', 0, 5, 6000, 12, 'rare'],
    ['Drum Magazine', 'A gift for any Tommy gun.', 'misc', 8, 0, 15000, 15, 'rare'],
    ['Dealer\'s Shoe', 'You deal, we say what seven means.', 'misc', 4, 4, 22000, 20, 'rare'],
    ['Golden Cufflinks', 'Tasteful. Expensive. Threatening.', 'misc', 3, 9, 45000, 25, 'epic'],
    ['Diamond Stickpin', 'Wear the family fortune.', 'misc', 5, 10, 90000, 32, 'epic'],
    ['The Boss\'s Medal', 'Only earned. Never given.', 'misc', 8, 14, 200000, 40, 'legendary'],
];
$itemIds = [];
foreach ($items as $i) {
    $existing = fetch('SELECT id FROM items WHERE name = ?', [$i[0]]);
    if ($existing) {
        $itemIds[$i[0]] = (int) $existing['id'];
        continue;
    }
    $itemIds[$i[0]] = insert('items', [
        'name' => $i[0], 'description' => $i[1], 'type' => $i[2],
        'attack' => $i[3], 'defense' => $i[4], 'cost' => $i[5],
        'min_level' => $i[6], 'rarity' => $i[7],
    ]);
    $counts['items']++;
}

/* ------------------------------- BOSSES (+10) ------------------------------- */
$bosses = [
    [2, 'Big Louie the Wharfinger', 'Runs every dock from here to the shipyards.', 600, 55, 22, 7, 22, 15000, 380, 10, 'Garrote Wire'],
    [2, 'Captain Sadie "Screws" Malone', 'The only woman who scares the dock rats.', 900, 75, 30, 11, 26, 26000, 550, 14, 'Double-Barrel Shotgun'],
    [2, 'Rum Baron Otto Kessler', 'Imports the finest illegal bottles in the state.', 1500, 90, 42, 14, 30, 42000, 850, 20, 'Speakeasy Van'],
    [3, 'Bishop "Gentleman" Adriano', 'Runs the church and the rackets equally well.', 1800, 110, 48, 16, 30, 52000, 1000, 22, 'Thompson .45'],
    [3, 'Signora Lucia "The Widow"', 'Took over her husband\'s territory the old way.', 2600, 140, 60, 19, 34, 80000, 1500, 28, "Gangster's Duster"],
    [3, 'Deaf Mickey the Barber', 'He never hears a word. He catches everything.', 3400, 170, 75, 22, 38, 110000, 1900, 32, 'Golden Cufflinks'],
    [4, 'Judge "Hanging" Harlan Beck', 'A judge who sentences first and buys the rope.', 4500, 200, 95, 25, 40, 140000, 2300, 38, 'Sniper Rifle'],
    [4, 'Madame Zara the Contessa', 'Runs a casino empire and an information service.', 6000, 240, 110, 28, 44, 190000, 3000, 42, 'Armored Truck'],
    [4, 'Commissioner Aldous Grim', 'The city\'s top cop. On our payroll since 1911.', 8500, 300, 140, 34, 50, 260000, 4200, 55, 'Flamethrower'],
    [4, 'Vittorio "Il Vecchio"', 'The Grandfather. The last word. The end.', 12000, 380, 180, 40, 60, 400000, 6500, 75, 'Rolls-Royce Phantom'],
];
foreach ($bosses as $b) {
    if (!fetch('SELECT id FROM bosses WHERE name = ?', [$b[1]])) {
        insert('bosses', [
            'district_id' => $b[0], 'name' => $b[1], 'description' => $b[2],
            'hp' => $b[3], 'attack' => $b[4], 'defense' => $b[5], 'min_level' => $b[6],
            'energy_cost' => $b[7], 'reward_money' => $b[8], 'reward_xp' => $b[9],
            'reward_points' => $b[10], 'reward_item_id' => $itemIds[$b[11]] ?? null,
        ]);
        $counts['bosses']++;
    }
}

/* ------------------------------- CRIMINAL JOBS (+12) ------------------------------- */
$jobs = [
    ['Run a Speakeasy Errand', 'A quick job for the bootleggers.', 2, 1, 60, 140, 5, 12],
    ['Sell Bootleg Tickets', 'Fake tickets, real money.', 3, 2, 120, 300, 8, 15],
    ['Pack the Numbers Slips', 'The bookie\'s paperwork never sleeps.', 3, 3, 180, 420, 9, 14],
    ['Tip Off the Squad', 'Sell a location. Keep the friend.', 4, 4, 300, 650, 12, 25],
    ['Steal a Raid Map', 'Know where they\'ll hit. Hit them first.', 5, 6, 550, 1200, 18, 30],
    ['Fence Stolen Jewelry', 'A pawnshop that never asks questions.', 6, 8, 900, 1900, 26, 28],
    ['Rig a Cock Fight', 'Feathers, blood, and fixed odds.', 5, 7, 700, 1500, 20, 20],
    ['Cut a Rival\'s Grapevines', 'Their wine trade dries up tonight.', 6, 9, 1300, 2800, 32, 26],
    ['Deliver the Death Notice', 'The envelope says everything.', 7, 11, 2000, 4200, 44, 34],
    ['Break a Policeman\'s Knees', 'A pension with a limp.', 8, 12, 2600, 5400, 50, 40],
    ['Sell Falsified Bonds', 'Pieces of paper worth a fortune.', 9, 16, 6000, 12500, 90, 42],
    ['The Great Train Robbery', 'The big one. Literally.', 14, 30, 40000, 80000, 260, 60],
];
foreach ($jobs as $j) {
    if (!fetch('SELECT id FROM criminal_jobs WHERE name = ?', [$j[0]])) {
        insert('criminal_jobs', [
            'name' => $j[0], 'description' => $j[1], 'nerve_cost' => $j[2], 'min_level' => $j[3],
            'payout_min' => $j[4], 'payout_max' => $j[5], 'xp' => $j[6], 'fail_risk' => $j[7],
        ]);
        $counts['jobs']++;
    }
}

/* ------------------------------- DRUGS (+15) ------------------------------- */
$drugs = [
    ['Moonshine', 'Bathtub special. Tastes like sin.', 150, 230, 1, '', 0, 5],
    ['Laudanum', 'The doctor\'s secret formula.', 400, 600, 2, '', 0, 12],
    ['Benzedrine', 'Uppers for the long nights.', 550, 850, 3, 'speed', 2, 15],
    ['Coca Tooth Drops', 'Soothing. Addictive. Profitable.', 1400, 2100, 5, 'speed', 3, 22],
    ['Morphine Syrette', 'Sweet dreams and open veins.', 2400, 3600, 8, '', 0, 20],
    ['Boat Powder', 'Sneaks through any port.', 3200, 4800, 10, 'iq', 4, 25],
    ['Smack Brown', 'Old smokehouse recipe.', 4500, 6800, 12, 'defense', 3, 28],
    ['Pink Pills', 'For stamina the boss insists on.', 6000, 9000, 14, 'strength', 4, 25],
    ['Opiate Elixir', 'A symphony in a bottle.', 8500, 13000, 16, '', 0, 30],
    ['Psychotrine Extract', 'Science fiction in a syringe.', 11000, 17000, 18, 'iq', 6, 32],
    ['Angel Dust', 'The wings come with a price.', 15000, 23000, 20, 'speed', 6, 35],
    ['Black Tar Syrup', 'Sticky, dark, and extremely final.', 20000, 31000, 22, 'strength', 6, 38],
    ['Chloroform Rag', 'For the quiet end of negotiations.', 26000, 40000, 24, 'defense', 5, 30],
    ["Alchemist's Cocaine", 'Perfected by a mad chemist.', 40000, 62000, 28, 'iq', 10, 40],
    ["The Devil's Brew", 'One drink and you\'ll see God. Or meet him.', 75000, 115000, 35, '', 0, 45],
];
foreach ($drugs as $d) {
    if (!fetch('SELECT id FROM drugs WHERE name = ?', [$d[0]])) {
        insert('drugs', [
            'name' => $d[0], 'description' => $d[1], 'buy_price' => $d[2], 'sell_price' => $d[3],
            'min_level' => $d[4], 'effect_stat' => $d[5], 'effect_amount' => $d[6], 'od_risk' => $d[7],
        ]);
        $counts['drugs']++;
    }
}

/* ------------------------------- ABILITIES (+22) ------------------------------- */
$abilities = [
    ['Herculean Grip', '+10 Strength permanently.', 25, 10, 'stat', 10, 'strength'],
    ['Cat Burglar', '+5 Speed permanently.', 15, 5, 'stat', 5, 'speed'],
    ['Chrome Spine', '+5 Defense permanently.', 15, 5, 'stat', 5, 'defense'],
    ['Ivory Tower', '+5 IQ permanently.', 15, 5, 'stat', 5, 'iq'],
    ['Sledge Fist', '+10 Strength permanently.', 45, 20, 'stat', 10, 'strength'],
    ['Scarlet Pimpernel', '+10 Speed permanently.', 45, 20, 'stat', 10, 'speed'],
    ['Elephant Hide', '+10 Defense permanently.', 45, 20, 'stat', 10, 'defense'],
    ['Mastermind', '+10 IQ permanently.', 45, 20, 'stat', 10, 'iq'],
    ['Old Timer\'s Grit', '+8 Strength permanently.', 30, 15, 'stat', 8, 'strength'],
    ['Shadow Method', '+8 Speed permanently.', 32, 18, 'stat', 8, 'speed'],
    ['Stone Wall', '+8 Defense permanently.', 38, 25, 'stat', 8, 'defense'],
    ["Gambler's Luck", '+8 IQ permanently.', 35, 22, 'stat', 8, 'iq'],
    ['Laid on the Table', 'Full heal when you need it most.', 15, 10, 'heal', 999, ''],
    ['Double Espresso', 'Instantly restore 50 energy.', 20, 12, 'energy', 50, ''],
    ['Fifth of Courage', 'Instantly restore 25 nerve.', 25, 15, 'nerve', 25, ''],
    ['Ammo Crate', 'Instantly gain 250 bullets.', 25, 10, 'bullets', 250, ''],
    ['Cold Hard Cash', 'Instantly gain $25,000.', 30, 15, 'money', 25000, ''],
    ['Slush Fund', 'Instantly gain $100,000.', 60, 25, 'money', 100000, ''],
    ['Work Ethic', 'Instantly gain 500 XP.', 25, 20, 'xp', 500, ''],
    ['The Windfall', 'Instantly gain 2,500 XP.', 55, 30, 'xp', 2500, ''],
    ['Armory Pass', 'Instantly gain 1,000 bullets.', 50, 30, 'bullets', 1000, ''],
    ['Five-Star Generale', 'Instantly gain $500,000.', 100, 40, 'money', 500000, ''],
];
foreach ($abilities as $a) {
    if (!fetch('SELECT id FROM abilities WHERE name = ?', [$a[0]])) {
        insert('abilities', [
            'name' => $a[0], 'description' => $a[1], 'cost_points' => $a[2], 'min_level' => $a[3],
            'effect_type' => $a[4], 'effect_value' => $a[5], 'stat' => $a[6],
        ]);
        $counts['abilities']++;
    }
}

/* ------------------------------- ACHIEVEMENTS (+40) ------------------------------- */
$achievements = [
    ['hits_25', 'Professional', 'Kill 25 players.', 30, 25, 'kills'],
    ['hits_50', 'Cold Killer', 'Kill 50 players.', 60, 50, 'kills'],
    ['hits_100', 'Platinum Shooter', 'Kill 100 players.', 100, 100, 'kills'],
    ['hits_250', 'Murder Inc.', 'Kill 250 players.', 200, 250, 'kills'],
    ['hits_500', 'Angel of Death', 'Kill 500 players.', 400, 500, 'kills'],
    ['hits_1000', 'Bringer of the End', 'Kill 1,000 players.', 800, 1000, 'kills'],
    ['missions_250', 'Workhorse', 'Complete 250 missions.', 60, 250, 'missions_done'],
    ['missions_500', 'Town Drudge', 'Complete 500 missions.', 120, 500, 'missions_done'],
    ['missions_1000', 'Empire Builder', 'Complete 1,000 missions.', 250, 1000, 'missions_done'],
    ['missions_2500', 'Corporate Syndicate', 'Complete 2,500 missions.', 500, 2500, 'missions_done'],
    ['crimes_100', 'Habitual Offender', 'Complete 100 criminal jobs.', 50, 100, 'crimes_done'],
    ['crimes_250', 'Career Crook', 'Complete 250 criminal jobs.', 110, 250, 'crimes_done'],
    ['crimes_500', 'Most Wanted', 'Complete 500 criminal jobs.', 220, 500, 'crimes_done'],
    ['crimes_1000', 'Public Menace', 'Complete 1,000 criminal jobs.', 450, 1000, 'crimes_done'],
    ['boss_5', 'Boss Hunter', 'Defeat 5 bosses.', 40, 5, 'boss_kills'],
    ['boss_10', 'Underboss Overlord', 'Defeat 10 bosses.', 80, 10, 'boss_kills'],
    ['boss_25', 'Capo Killer', 'Defeat 25 bosses.', 180, 25, 'boss_kills'],
    ['boss_50', 'Number One', 'Defeat 50 bosses.', 350, 50, 'boss_kills'],
    ['boss_100', 'Legendary Slayer', 'Defeat 100 bosses.', 700, 100, 'boss_kills'],
    ['rich_5', 'Millionaire', 'Hold $5,000,000 in cash and bank.', 60, 5000000, 'money'],
    ['rich_25', 'Multimillionaire', 'Hold $25,000,000 in cash and bank.', 150, 25000000, 'money'],
    ['rich_100', 'Nine Figures', 'Hold $100,000,000 in cash and bank.', 400, 100000000, 'money'],
    ['rich_500', 'Half a Billionaire', 'Hold $500,000,000 in cash and bank.', 900, 500000000, 'money'],
    ['level_75', 'Old Guard', 'Reach level 75.', 150, 75, 'level'],
    ['level_100', 'Living Legend', 'Reach level 100.', 350, 100, 'level'],
    ['level_150', 'Immortal', 'Reach level 150.', 700, 150, 'level'],
    ['wins_50', 'Winner', 'Win 50 fights.', 40, 50, 'wins'],
    ['wins_200', 'Champion', 'Win 200 fights.', 150, 200, 'wins'],
    ['death_10', 'Resurrection Man', 'Survive 10 deaths.', 20, 10, 'deaths'],
    ['death_50', 'Back For More', 'Keep it going after 50 deaths.', 60, 50, 'deaths'],
    ['points_250', 'Point Hoarder', 'Hold 250 unspent points.', 40, 250, 'points'],
    ['points_1000', 'Point Baron', 'Hold 1,000 unspent points.', 150, 1000, 'points'],
    ['bullets_1000', 'Well Armed', 'Hold 1,000 bullets.', 30, 1000, 'bullets'],
    ['bullets_10000', 'Walking Arsenal', 'Hold 10,000 bullets.', 150, 10000, 'bullets'],
    ['str_50', 'Bulldozer', 'Reach 50 Strength.', 60, 50, 'strength'],
    ['speed_50', 'The Blur', 'Reach 50 Speed.', 60, 50, 'speed'],
    ['def_50', 'Fortress', 'Reach 50 Defense.', 60, 50, 'defense'],
    ['iq_50', 'Master Planner', 'Reach 50 IQ.', 60, 50, 'iq'],
    ['str_100', 'Sledgehammer', 'Reach 100 Strength.', 200, 100, 'strength'],
    ['streak_7', 'Every Day Counts', 'Keep a 7-day daily streak.', 40, 7, 'daily_streak'],
    ['streak_30', 'Devoted', 'Keep a 30-day daily streak.', 150, 30, 'daily_streak'],
];
foreach ($achievements as $a) {
    if (!fetch('SELECT id FROM achievements WHERE code = ?', [$a[0]])) {
        insert('achievements', [
            'code' => $a[0], 'name' => $a[1], 'description' => $a[2],
            'reward_points' => $a[3], 'target' => $a[4], 'metric' => $a[5],
        ]);
        $counts['achievements']++;
    }
}

/* ------------------------------- STICKERS (+20) ------------------------------- */
$stickers = [
    // Speakeasy set
    ['brass_knuckles', 'Brass Knuckles', 'common'],
    ['fedora_grey', 'Grey Fedora', 'common'],
    ['martini', 'Dry Martini', 'uncommon'],
    ['gin_bottle', 'Bootleg Gin', 'uncommon'],
    ['zoot_suit', 'Zoot Suit', 'rare'],
    ['saxophone', 'Saxophone Solo', 'rare'],
    ['moonshine_jar', 'Bathtub Moonshine', 'epic'],
    // Casino set
    ['ace_of_spades', 'Ace of Spades', 'common'],
    ['loaded_dice', 'Loaded Dice', 'common'],
    ['chips_stack', 'Chip Stack', 'uncommon'],
    ['one_armed_bandit', 'One-Armed Bandit', 'epic'],
    ['royal_flush', 'Royal Flush', 'legendary'],
    // Waterfront set
    ['anchor_tattoo', 'Anchor Tattoo', 'common'],
    ['smuggle_crate', 'Smuggled Crate', 'uncommon'],
    ['tugboat', 'River Tugboat', 'rare'],
    ['lighthouse', 'The Lighthouse', 'epic'],
    // Boss set
    ['white_gloves', 'White Gloves', 'rare'],
    ['tommy_drum', 'Tommy Gun Drum', 'legendary'],
    // Legends set
    ['black_cat', 'The Black Cat', 'legendary'],
    ['king_city', 'King of the City', 'legendary'],
];
foreach ($stickers as $s) {
    if (!fetch('SELECT id FROM stickers WHERE code = ?', [$s[0]])) {
        insert('stickers', ['code' => $s[0], 'name' => $s[1], 'rarity' => $s[2]]);
        $counts['stickers']++;
    }
}

/* ------------------------------- POINTS STORE (+6) ------------------------------- */
$store = [
    ['$250,000 Cash', 'Corporate money. Nobody asks.', 80, 'money', 250000, null],
    ['1,000 Bullets', 'The armory, unlocked.', 50, 'bullets', 1000, null],
    ['5,000 XP Boost', 'Instant progress, paid in advance.', 45, 'xp', 5000, null],
    ['25,000 XP Boost', 'Skip straight to the top.', 200, 'xp', 25000, null],
    ['Thompson .45', 'The classic. Right now.', 90, 'item', 0, $itemIds['Thompson .45'] ?? null],
    ['Armored Truck', 'Roll in style and safety.', 180, 'item', 0, $itemIds['Armored Truck'] ?? null],
];
foreach ($store as $s) {
    if (!fetch('SELECT id FROM points_store WHERE name = ?', [$s[0]])) {
        insert('points_store', [
            'name' => $s[0], 'description' => $s[1], 'cost_points' => $s[2],
            'kind' => $s[3], 'amount' => $s[4], 'item_id' => $s[5],
        ]);
        $counts['points_store']++;
    }
}

if ($isCli) {
    echo "Content expansion complete.\n";
    foreach ($counts as $k => $v) {
        echo str_pad($k . ':', 16) . $v . " added (new).\n";
    }
    echo "Totals now: " .
        "missions=" . fetch_one('SELECT COUNT(*) FROM missions') . " " .
        "items=" . fetch_one('SELECT COUNT(*) FROM items') . " " .
        "bosses=" . fetch_one('SELECT COUNT(*) FROM bosses') . " " .
        "jobs=" . fetch_one('SELECT COUNT(*) FROM criminal_jobs') . " " .
        "drugs=" . fetch_one('SELECT COUNT(*) FROM drugs') . " " .
        "abilities=" . fetch_one('SELECT COUNT(*) FROM abilities') . " " .
        "achievements=" . fetch_one('SELECT COUNT(*) FROM achievements') . " " .
        "stickers=" . fetch_one('SELECT COUNT(*) FROM stickers') . "\n";
}