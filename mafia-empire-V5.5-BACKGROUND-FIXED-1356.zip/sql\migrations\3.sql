-- Phase 7: REST API, Webhooks & Integrations

-- API keys. Only a hash is stored; the plaintext is shown once at creation.
CREATE TABLE IF NOT EXISTS api_keys (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  name VARCHAR(60) NOT NULL DEFAULT 'API key',
  prefix VARCHAR(16) NOT NULL,
  key_hash CHAR(64) NOT NULL,
  scopes VARCHAR(120) NOT NULL DEFAULT 'read',
  rate_limit INT NOT NULL DEFAULT 60,
  request_count BIGINT NOT NULL DEFAULT 0,
  last_used_at DATETIME NULL DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_prefix (prefix),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Fixed-window rate limit counters (one row per key).
CREATE TABLE IF NOT EXISTS api_rate (
  key_id INT UNSIGNED NOT NULL,
  window_start INT UNSIGNED NOT NULL,
  hits INT NOT NULL DEFAULT 0,
  PRIMARY KEY (key_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- API request log (analytics + abuse review).
CREATE TABLE IF NOT EXISTS api_requests (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  key_id INT UNSIGNED NULL DEFAULT NULL,
  user_id INT UNSIGNED NULL DEFAULT NULL,
  method VARCHAR(8) NOT NULL,
  path VARCHAR(190) NOT NULL,
  status INT NOT NULL DEFAULT 200,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_key (key_id),
  KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Outbound webhook subscriptions owned by players.
CREATE TABLE IF NOT EXISTS webhooks (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  url VARCHAR(500) NOT NULL,
  secret VARCHAR(64) NOT NULL,
  events VARCHAR(190) NOT NULL DEFAULT '*',
  active TINYINT(1) NOT NULL DEFAULT 1,
  failures INT NOT NULL DEFAULT 0,
  last_status INT NULL DEFAULT NULL,
  last_called_at DATETIME NULL DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id),
  KEY idx_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Webhook delivery queue / history.
CREATE TABLE IF NOT EXISTS webhook_deliveries (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  webhook_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  event VARCHAR(40) NOT NULL,
  payload MEDIUMTEXT NOT NULL,
  status ENUM('pending','delivered','failed') NOT NULL DEFAULT 'pending',
  attempts INT NOT NULL DEFAULT 0,
  response_code INT NULL DEFAULT NULL,
  error VARCHAR(255) NOT NULL DEFAULT '',
  next_attempt_at DATETIME NULL DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  delivered_at DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY idx_status (status),
  KEY idx_webhook (webhook_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
