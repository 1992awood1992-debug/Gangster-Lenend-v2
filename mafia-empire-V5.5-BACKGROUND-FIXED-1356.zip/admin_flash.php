<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/security.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        db_create_flash([
            'title' => trim($_POST['title'] ?? ''),
            'message' => trim($_POST['message'] ?? ''),
            'type' => $_POST['type'] ?? 'info',
            'target_type' => $_POST['target_type'] ?? 'all',
            'target_value' => $_POST['target_value'] ?? null,
            'min_level' => $_POST['min_level'] ?? null,
            'starts_at' => $_POST['starts_at'] ?? null,
            'expires_at' => $_POST['expires_at'] ?? null,
            'dismissible' => isset($_POST['dismissible']) ? 1 : 0,
            'show_once' => isset($_POST['show_once']) ? 1 : 0,
            'created_by' => (int) ($_SESSION['uid'] ?? 0),
            'active' => 1,
        ]);
        flash('Flash message created.', 'success');
    } elseif ($action === 'toggle') {
        db_toggle_flash((int) ($_POST['id'] ?? 0), (int) ($_POST['active'] ?? 0));
        flash('Flash updated.', 'success');
    } elseif ($action === 'delete') {
        db_delete_flash((int) ($_POST['id'] ?? 0));
        flash('Flash deleted.', 'success');
    }
    redirect('admin_flash.php');
}
$page_title = 'Manage Flash Messages';
require __DIR__ . '/includes/header.php';
$flashes = db_list_flashes();
?>
<div class="card"><div class="panel-heading">Manage Flash Messages</div><p class="muted small">Create persistent flash announcements shown to users.</p></div>

<div class="card" style="margin-top:14px">
  <div class="panel-heading">Create Flash</div>
  <form method="post" class="auth-form" style="max-width:700px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">
    <div class="form-group"><label>Title <input type="text" name="title" placeholder="Welcome to the city"></label></div>
    <div class="form-group"><label>Message <textarea name="message" rows="3" placeholder="Announcement text..."></textarea></label></div>
    <div class="grid grid-3" style="margin-top:10px">
      <div class="form-group"><label>Type <select name="type"><option>info</option><option>success</option><option>warning</option><option>error</option><option>gold</option></select></label></div>
      <div class="form-group"><label>Target <select name="target_type"><option>all</option><option>user</option><option>crew</option><option>level_min</option><option>admin</option></select></label></div>
      <div class="form-group"><label>Target Value <input type="number" name="target_value" placeholder="user_id or level"></label></div>
    </div>
    <div class="grid grid-3" style="margin-top:10px">
      <div class="form-group"><label>Min Level <input type="number" name="min_level" placeholder="e.g. 10"></label></div>
      <div class="form-group"><label>Starts At <input type="datetime-local" name="starts_at"></label></div>
      <div class="form-group"><label>Expires At <input type="datetime-local" name="expires_at"></label></div>
    </div>
    <div style="margin-top:10px;display:flex;gap:12px;align-items:center">
      <label><input type="checkbox" name="dismissible" checked> Dismissible</label>
      <label><input type="checkbox" name="show_once"> Show Once</label>
    </div>
    <button class="btn btn-gold" type="submit">Create Flash</button>
  </form>
</div>

<div class="card" style="margin-top:14px">
  <div class="panel-heading">All Flashes</div>
  <?php if (!$flashes): ?>
    <p class="muted">No flash messages.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>ID</th><th>Title</th><th>Type</th><th>Target</th><th>Level</th><th>Active</th><th>Created</th><th>Actions</th></tr>
      <?php foreach ($flashes as $f): ?>
        <tr>
          <td><?= (int) $f['id'] ?></td>
          <td><?= e($f['title']) ?></td>
          <td><span class="tag tag-<?= e($f['type']) ?>"><?= ucfirst(e($f['type'])) ?></span></td>
          <td><?= e($f['target_type']) . ($f['target_value'] ? ' #' . (int) $f['target_value'] : '') ?></td>
          <td><?= $f['min_level'] ?? '-' ?></td>
          <td>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $f['id'] ?>"><input type="hidden" name="active" value="<?= (int) $f['active'] === 0 ? 1 : 0 ?>"><button class="btn btn-sm" type="submit"><?= (int) $f['active'] ? 'Pause' : 'Enable' ?></button></form>
          </td>
          <td><?= e(date('M j, g:i a', strtotime($f['created_at']))) ?></td>
          <td>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete this flash?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $f['id'] ?>"><button class="btn btn-sm" type="submit">Delete</button></form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
