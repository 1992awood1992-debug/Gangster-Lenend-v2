<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'People';
require __DIR__ . '/includes/header.php';

$u = current_user();
$minLvl = max(1, (int) $u['level'] - 3);
$maxLvl = (int) $u['level'] + 3;

$list = fetch_all('SELECT * FROM users WHERE id != ? AND is_banned = 0 AND level BETWEEN ? AND ? ORDER BY level DESC, xp DESC LIMIT 30', [$u['id'], $minLvl, $maxLvl]);
$random = fetch('SELECT * FROM users WHERE id != ? AND is_banned = 0 ORDER BY RAND() LIMIT 1', [$u['id']]);
?>
<div class="card">
  <div class="panel-heading">People Near Your Level</div>
  <p class="muted small">Players within 3 levels of you (Lvl <?= $minLvl ?>-<?= $maxLvl ?>).</p>
</div>

<div class="grid grid-3">
  <?php if (!$list): ?>
    <p class="muted">No players in range.</p>
  <?php else: foreach ($list as $p):
    $rank = rank_for_level((int) $p['level']);
    $online = strtotime($p['last_active']) > time() - 300;
  ?>
    <a class="tile" href="<?= e(url('profile.php?id=' . (int) $p['id'])) ?>">
      <img src="<?= e($p['avatar']) ?>" alt="" class="avatar" style="margin:0 auto 8px" onerror="this.src='<?= e(url('assets/img/avatar-default.svg')) ?>'">
      <b><?= e($p['username']) ?></b>
      <small>Lvl <?= (int) $p['level'] ?> · <?= e($rank['name']) ?> <?= $online ? '🟢' : '' ?></small>
    </a>
  <?php endforeach; endif; ?>
</div>

<?php if ($random): ?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Random Encounter</div>
  <div style="display:flex;align-items:center;gap:14px">
    <img src="<?= e($random['avatar']) ?>" alt="" class="avatar" onerror="this.src='<?= e(url('assets/img/avatar-default.svg')) ?>'">
    <div style="flex:1">
      <b><a href="<?= e(url('profile.php?id=' . (int) $random['id'])) ?>"><?= e($random['username']) ?></a></b>
      <br><small class="muted">Lvl <?= (int) $random['level'] ?> · <?= e(rank_for_level((int) $random['level'])['name']) ?></small>
    </div>
    <a class="btn btn-danger" href="<?= e(url('kill.php')) ?>" data-confirm="Attack <?= e($random['username']) ?>?">Attack</a>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>