<?php
/**
 * Eye Of The Mafia - Bounty Board
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/social.php';

$u = require_login();
$page_title = 'Bounties';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create') {
        $target = trim($_POST['target'] ?? '');
        $amount = (int)($_POST['amount'] ?? 0);
        $targetUser = fetch('SELECT id FROM users WHERE username = ?', [$target]);
        if (!$targetUser) {
            $error = 'Player not found.';
        } elseif ((int) $targetUser['id'] === (int) $u['id']) {
            $error = 'You cannot place a bounty on yourself.';
        } elseif ($amount <= 0) {
            $error = 'Amount must be greater than 0.';
        } else {
            // bounty_create() escrows the reward from the placer's wallet.
            $bountyId = bounty_create((int) $targetUser['id'], $amount, (int) $u['id']);
            if ($bountyId) {
                $success = 'Bounty placed. ' . money($amount) . ' is held in escrow until it is claimed.';
            } else {
                $error = 'Insufficient funds.';
            }
        }
    } elseif ($action === 'claim') {
        $bid = (int)($_POST['bounty_id'] ?? 0);
        if (bounty_claim($u['id'], $bid)) {
            $success = 'Bounty claimed!';
        } else {
            $error = 'Failed to claim bounty.';
        }
    }
}

$bounties = bounties_get_active();

require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <div class="panel-heading">Bounty Board</div>
  <p class="muted small">Place bounties on players. Collect rewards for eliminating targets.</p>
</div>

<?php if ($error): ?><div class="alert alert-error" style="margin-top:12px"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success" style="margin-top:12px"><?= e($success) ?></div><?php endif; ?>

<div class="card" style="margin-top:12px">
  <div class="panel-heading">Place a Bounty</div>
  <form method="post" action="bounties.php">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">
    <div class="form-row">
      <label>Target Username</label>
      <input type="text" name="target" class="input" required>
    </div>
    <div class="form-row">
      <label>Reward Amount ($)</label>
      <input type="number" name="amount" class="input" min="1" required>
    </div>
    <div style="margin-top:10px">
      <button class="btn btn-gold" type="submit">Place Bounty</button>
    </div>
  </form>
</div>

<div class="card" style="margin-top:12px">
  <div class="panel-heading">Active Bounties</div>
  <?php if (empty($bounties)): ?>
    <p class="muted small">No active bounties.</p>
  <?php else: ?>
    <div style="overflow-x:auto">
      <table class="table">
        <thead>
          <tr>
            <th>Target</th>
            <th>Reward</th>
            <th>Placed By</th>
            <th>Expires</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($bounties as $b): ?>
            <tr>
              <td><?= e($b['target_name']) ?></td>
              <td><?= money((int)$b['reward_money']) ?></td>
              <td><?= e($b['creator_name'] ?? 'Anonymous') ?></td>
              <td class="muted small"><?= e($b['expires_at']) ?></td>
              <td>
                <?php if ((int)$b['target_id'] !== $u['id']): ?>
                  <form method="post" action="bounties.php" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="claim">
                    <input type="hidden" name="bounty_id" value="<?= (int)$b['id'] ?>">
                    <button class="btn btn-sm" type="submit">Claim</button>
                  </form>
                <?php else: ?>
                  <span class="muted small">On your head</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
