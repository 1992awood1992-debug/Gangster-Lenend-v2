<?php
/**
 * Eye Of The Mafia - Tournament System
 *
 * Scheduled competitive events. Supports four formats (elimination,
 * round robin, swiss, ladder) across six game types (pvp, racing, heist,
 * mission speedrun, kill race, casino).
 *
 * Lifecycle: draft -> registration -> in_progress -> completed (or cancelled).
 */

require_once __DIR__ . '/init.php';

/* ------------------------------------------------------------------ */
/* Reference data                                                      */
/* ------------------------------------------------------------------ */

function tournament_types(): array
{
    return ['elimination', 'round_robin', 'swiss', 'ladder'];
}

function tournament_game_types(): array
{
    return ['pvp', 'racing', 'heist', 'mission_speedrun', 'kill_race', 'casino'];
}

function tournament_type_label(string $t): string
{
    $map = [
        'elimination' => 'Elimination',
        'round_robin' => 'Round Robin',
        'swiss'       => 'Swiss',
        'ladder'      => 'Ladder',
    ];
    return $map[$t] ?? ucwords(str_replace('_', ' ', $t));
}

function tournament_game_label(string $g): string
{
    $map = [
        'pvp'              => 'PvP Combat',
        'racing'           => 'Racing',
        'heist'            => 'Heist',
        'mission_speedrun' => 'Mission Speedrun',
        'kill_race'        => 'Kill Race',
        'casino'           => 'Casino',
    ];
    return $map[$g] ?? ucwords(str_replace('_', ' ', $g));
}

function tournament_status_label(string $s): string
{
    $map = [
        'draft'        => 'Draft',
        'registration' => 'Registration Open',
        'in_progress'  => 'In Progress',
        'completed'    => 'Completed',
        'cancelled'    => 'Cancelled',
    ];
    return $map[$s] ?? ucfirst($s);
}

/* ------------------------------------------------------------------ */
/* Read helpers                                                        */
/* ------------------------------------------------------------------ */

function tournament_payout(array $t): array
{
    $p = json_decode((string) ($t['payout_structure'] ?? '[]'), true);
    return is_array($p) ? $p : [];
}

function tournament_get(int $id): ?array
{
    $t = fetch('SELECT * FROM tournaments WHERE id = ?', [$id]);
    if ($t) {
        $t['payout'] = tournament_payout($t);
        $t['prize_items_decoded'] = json_decode((string) ($t['prize_items'] ?? '[]'), true) ?: [];
    }
    return $t;
}

function tournament_get_by_code(string $code): ?array
{
    $t = fetch('SELECT * FROM tournaments WHERE code = ?', [$code]);
    if ($t) {
        $t['payout'] = tournament_payout($t);
        $t['prize_items_decoded'] = json_decode((string) ($t['prize_items'] ?? '[]'), true) ?: [];
    }
    return $t;
}

function tournament_get_all(?string $status = null, ?string $gameType = null, int $limit = 60, int $offset = 0): array
{
    $sql = 'SELECT * FROM tournaments WHERE 1=1';
    $params = [];
    if ($status !== null && $status !== '') {
        $sql .= ' AND status = ?';
        $params[] = $status;
    }
    if ($gameType !== null && $gameType !== '') {
        $sql .= ' AND game_type = ?';
        $params[] = $gameType;
    }
    $sql .= " ORDER BY FIELD(status,'in_progress','registration','draft','completed','cancelled'),
              starts_at ASC, id ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $rows = fetch_all($sql, $params);
    foreach ($rows as &$r) {
        $r['payout'] = tournament_payout($r);
        $r['participant_count'] = tournament_participant_count((int) $r['id']);
    }
    unset($r);
    return $rows;
}

function tournament_active_participants(int $tid): array
{
    return fetch_all(
        "SELECT * FROM tournament_participants
         WHERE tournament_id = ? AND status NOT IN ('withdrawn','disqualified')
         ORDER BY seed IS NULL, seed, id",
        [$tid]
    );
}

function tournament_participants(int $tid, ?string $status = null): array
{
    $sql = 'SELECT tp.*, u.username, u.level, u.avatar, u.crew_id
            FROM tournament_participants tp
            LEFT JOIN users u ON u.id = tp.user_id
            WHERE tp.tournament_id = ?';
    $params = [$tid];
    if ($status !== null) {
        $sql .= ' AND tp.status = ?';
        $params[] = $status;
    }
    $sql .= ' ORDER BY tp.final_position IS NULL, tp.final_position,
              tp.points DESC, tp.wins DESC, tp.total_score DESC,
              tp.best_time_ms IS NULL, tp.best_time_ms, tp.registered_at, tp.id';
    return fetch_all($sql, $params);
}

function tournament_participant_count(int $tid): int
{
    return (int) fetch_one(
        "SELECT COUNT(*) FROM tournament_participants
         WHERE tournament_id = ? AND status NOT IN ('withdrawn','disqualified')",
        [$tid],
        0
    );
}

function tournament_get_participant(int $tid, int $userId): ?array
{
    return fetch('SELECT * FROM tournament_participants WHERE tournament_id = ? AND user_id = ?', [$tid, $userId]);
}

function tournament_matches(int $tid, ?int $round = null): array
{
    $sql = 'SELECT tm.*,
                   p1.user_id AS p1_user, u1.username AS p1_name,
                   p2.user_id AS p2_user, u2.username AS p2_name,
                   pw.user_id AS winner_user, uw.username AS winner_name
            FROM tournament_matches tm
            LEFT JOIN tournament_participants p1 ON p1.id = tm.participant1_id
            LEFT JOIN users u1 ON u1.id = p1.user_id
            LEFT JOIN tournament_participants p2 ON p2.id = tm.participant2_id
            LEFT JOIN users u2 ON u2.id = p2.user_id
            LEFT JOIN tournament_participants pw ON pw.id = tm.winner_id
            LEFT JOIN users uw ON uw.id = pw.user_id
            WHERE tm.tournament_id = ?';
    $params = [$tid];
    if ($round !== null) {
        $sql .= ' AND tm.round_number = ?';
        $params[] = $round;
    }
    $sql .= ' ORDER BY tm.round_number, tm.match_number';
    return fetch_all($sql, $params);
}

function tournament_matches_by_round(int $tid): array
{
    $out = [];
    foreach (tournament_matches($tid) as $m) {
        $out[(int) $m['round_number']][] = $m;
    }
    return $out;
}

function tournament_standings(int $tid): array
{
    return tournament_participants($tid);
}

/* ------------------------------------------------------------------ */
/* Registration                                                        */
/* ------------------------------------------------------------------ */

function tournament_can_register(array $t, array $u): array
{
    $fail = static function (string $msg): array {
        return ['ok' => false, 'error' => $msg];
    };

    if (($t['status'] ?? '') !== 'registration') {
        return $fail('Registration is not open for this tournament.');
    }
    $now = now();
    if (!empty($t['registration_opens_at']) && $now < $t['registration_opens_at']) {
        return $fail('Registration has not opened yet.');
    }
    if (!empty($t['registration_closes_at']) && $now > $t['registration_closes_at']) {
        return $fail('Registration has closed.');
    }

    $level = (int) $u['level'];
    if ($level < (int) $t['min_level']) {
        return $fail('Minimum level ' . (int) $t['min_level'] . ' required.');
    }
    if (!empty($t['max_level']) && $level > (int) $t['max_level']) {
        return $fail('This tournament is capped at level ' . (int) $t['max_level'] . '.');
    }
    if ((int) $t['crew_only'] === 1 && empty($u['crew_id'])) {
        return $fail('You must be in a crew to enter this tournament.');
    }

    $existing = tournament_get_participant((int) $t['id'], (int) $u['id']);
    if ($existing && !in_array((string) $existing['status'], ['withdrawn', 'disqualified'], true)) {
        return $fail('You are already registered.');
    }

    if (tournament_participant_count((int) $t['id']) >= (int) $t['max_participants']) {
        return $fail('This tournament is full.');
    }

    if ((int) $t['entry_fee_money'] > 0 && (int) $u['money'] < (int) $t['entry_fee_money']) {
        return $fail('You need ' . money((int) $t['entry_fee_money']) . ' to enter.');
    }
    if ((int) $t['entry_fee_points'] > 0 && (int) $u['points'] < (int) $t['entry_fee_points']) {
        return $fail('You need ' . number_format((int) $t['entry_fee_points']) . ' points to enter.');
    }
    if (!empty($t['entry_fee_item_id'])) {
        $itemId = (int) $t['entry_fee_item_id'];
        $have = (int) fetch_one('SELECT COALESCE(SUM(qty),0) FROM user_items WHERE user_id = ? AND item_id = ?', [(int) $u['id'], $itemId], 0);
        if ($have < 1) {
            $item = fetch('SELECT name FROM items WHERE id = ?', [$itemId]);
            return $fail('You need 1x ' . ($item['name'] ?? 'entry item') . ' to enter.');
        }
    }

    return ['ok' => true];
}

function tournament_register(int $tid, int $userId): array
{
    $t = tournament_get($tid);
    if (!$t) {
        return ['ok' => false, 'error' => 'Tournament not found.'];
    }
    $u = fetch('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$u) {
        return ['ok' => false, 'error' => 'User not found.'];
    }

    $check = tournament_can_register($t, $u);
    if (empty($check['ok'])) {
        return $check;
    }

    if ((int) $t['entry_fee_money'] > 0) {
        add_money($userId, -(int) $t['entry_fee_money'], 'Tournament entry: ' . $t['name']);
        q('UPDATE tournaments SET prize_pool_money = prize_pool_money + ? WHERE id = ?', [(int) $t['entry_fee_money'], $tid]);
    }
    if ((int) $t['entry_fee_points'] > 0) {
        add_points($userId, -(int) $t['entry_fee_points']);
        q('UPDATE tournaments SET prize_pool_points = prize_pool_points + ? WHERE id = ?', [(int) $t['entry_fee_points'], $tid]);
    }
    if (!empty($t['entry_fee_item_id'])) {
        $itemId = (int) $t['entry_fee_item_id'];
        q('UPDATE user_items SET qty = qty - 1 WHERE user_id = ? AND item_id = ? AND qty > 0 LIMIT 1', [$userId, $itemId]);
        q('DELETE FROM user_items WHERE user_id = ? AND item_id = ? AND qty <= 0', [$userId, $itemId]);
    }

    $existing = tournament_get_participant($tid, $userId);
    if ($existing) {
        q("UPDATE tournament_participants
           SET status = 'registered', seed = NULL, current_round = 0,
               wins = 0, losses = 0, draws = 0, points = 0, final_position = NULL,
               total_score = 0, best_time_ms = NULL, kills = 0,
               registered_at = NOW()
           WHERE id = ?", [(int) $existing['id']]);
        $pid = (int) $existing['id'];
    } else {
        $pid = insert('tournament_participants', [
            'tournament_id' => $tid,
            'user_id'       => $userId,
            'crew_id'       => !empty($u['crew_id']) ? (int) $u['crew_id'] : null,
            'status'        => 'registered',
        ]);
    }

    notify($userId, 'You registered for ' . $t['name'] . '.', 'tournaments.php?view=' . $tid);
    if (function_exists('analytics_track')) {
        analytics_track('tournament_register', $userId, ['tournament_id' => $tid, 'code' => $t['code']]);
    }

    return ['ok' => true, 'participant_id' => $pid];
}

function tournament_withdraw(int $tid, int $userId): array
{
    $t = tournament_get($tid);
    if (!$t) {
        return ['ok' => false, 'error' => 'Tournament not found.'];
    }
    if (!in_array((string) $t['status'], ['draft', 'registration'], true)) {
        return ['ok' => false, 'error' => 'You can no longer withdraw from this tournament.'];
    }
    $p = tournament_get_participant($tid, $userId);
    if (!$p) {
        return ['ok' => false, 'error' => 'You are not registered.'];
    }
    if (!in_array((string) $p['status'], ['registered', 'confirmed'], true)) {
        return ['ok' => false, 'error' => 'You cannot withdraw in your current state.'];
    }

    q("UPDATE tournament_participants SET status = 'withdrawn' WHERE id = ?", [(int) $p['id']]);

    if ((int) $t['entry_fee_money'] > 0) {
        add_money($userId, (int) $t['entry_fee_money'], 'Tournament withdrawal refund: ' . $t['name']);
        q('UPDATE tournaments SET prize_pool_money = GREATEST(prize_pool_money - ?, 0) WHERE id = ?', [(int) $t['entry_fee_money'], $tid]);
    }
    if ((int) $t['entry_fee_points'] > 0) {
        add_points($userId, (int) $t['entry_fee_points']);
        q('UPDATE tournaments SET prize_pool_points = GREATEST(prize_pool_points - ?, 0) WHERE id = ?', [(int) $t['entry_fee_points'], $tid]);
    }
    if (!empty($t['entry_fee_item_id'])) {
        insert('user_items', [
            'user_id'  => $userId,
            'item_id'  => (int) $t['entry_fee_item_id'],
            'qty'      => 1,
            'equipped' => 0,
        ]);
    }

    notify($userId, 'You withdrew from ' . $t['name'] . '.', 'tournaments.php');
    return ['ok' => true];
}

/**
 * Cancel a tournament and refund every confirmed/registered entrant.
 * Used when an event closes without enough competitors, or by admins.
 */
function tournament_cancel(int $tid, string $reason = ''): array
{
    $t = tournament_get($tid);
    if (!$t) {
        return ['ok' => false, 'error' => 'Tournament not found.'];
    }
    if ((string) $t['status'] === 'cancelled') {
        return ['ok' => true, 'already' => true, 'refunded' => 0];
    }
    if ((string) $t['status'] === 'completed') {
        return ['ok' => false, 'error' => 'A completed tournament cannot be cancelled.'];
    }

    $participants = fetch_all(
        "SELECT id, user_id FROM tournament_participants
         WHERE tournament_id = ? AND status IN ('registered','confirmed','checked_in')",
        [$tid]
    );

    foreach ($participants as $p) {
        $uid = (int) $p['user_id'];
        if ($uid < 1) {
            continue;
        }
        if ((int) $t['entry_fee_money'] > 0) {
            add_money($uid, (int) $t['entry_fee_money'], 'Tournament cancelled refund: ' . $t['name']);
        }
        if ((int) $t['entry_fee_points'] > 0) {
            add_points($uid, (int) $t['entry_fee_points']);
        }
        if (!empty($t['entry_fee_item_id'])) {
            insert('user_items', [
                'user_id'  => $uid,
                'item_id'  => (int) $t['entry_fee_item_id'],
                'qty'      => 1,
                'equipped' => 0,
            ]);
        }
        q("UPDATE tournament_participants SET status = 'withdrawn' WHERE id = ?", [(int) $p['id']]);
        notify($uid, $t['name'] . ' was cancelled' . ($reason !== '' ? ' (' . $reason . ')' : '') . '. Entry fees refunded.', 'tournaments.php');
    }

    q("UPDATE tournaments SET status = 'cancelled' WHERE id = ?", [$tid]);

    return ['ok' => true, 'refunded' => count($participants)];
}

/* ------------------------------------------------------------------ */
/* Starting & bracket generation                                       */
/* ------------------------------------------------------------------ */

function tournament_start(int $tid): array
{
    $t = tournament_get($tid);
    if (!$t) {
        return ['ok' => false, 'error' => 'Tournament not found.'];
    }
    if ((string) $t['status'] !== 'registration') {
        return ['ok' => false, 'error' => 'This tournament cannot be started from its current state.'];
    }

    $active = tournament_active_participants($tid);
    if (count($active) < max(1, (int) $t['min_participants'])) {
        return ['ok' => false, 'error' => 'Not enough participants to start (need ' . max(1, (int) $t['min_participants']) . ').'];
    }

    shuffle($active);
    $seed = 1;
    foreach ($active as $p) {
        q("UPDATE tournament_participants SET seed = ?, status = 'confirmed' WHERE id = ?", [$seed++, (int) $p['id']]);
    }

    q("UPDATE tournaments SET status = 'in_progress' WHERE id = ?", [$tid]);

    if ((string) $t['type'] === 'elimination') {
        tournament_generate_elimination_round($tid, 1);
    } elseif ((string) $t['type'] === 'round_robin') {
        tournament_generate_round_robin($tid);
    } elseif ((string) $t['type'] === 'swiss') {
        tournament_generate_swiss_round($tid, 1);
    }

    foreach ($active as $p) {
        if (!empty($p['user_id'])) {
            notify((int) $p['user_id'], $t['name'] . ' has begun. Good luck!', 'tournaments.php?view=' . $tid);
        }
    }
    if (function_exists('analytics_track')) {
        analytics_track('tournament_start', null, ['tournament_id' => $tid, 'participants' => count($active)]);
    }

    tournament_progress($tid);

    return ['ok' => true, 'participants' => count($active)];
}

function tournament_generate_elimination_round(int $tid, int $round, ?array $participantIds = null): void
{
    if ($participantIds === null) {
        $participantIds = array_map(static fn($r) => (int) $r['id'], tournament_active_participants($tid));
    }
    $participantIds = array_values($participantIds);
    $n = count($participantIds);
    if ($n < 2) {
        return;
    }

    $matchNo = 1;
    for ($i = 0; $i < $n; $i += 2) {
        $p1 = $participantIds[$i];
        $p2 = $participantIds[$i + 1] ?? null;
        if ($p2 === null) {
            insert('tournament_matches', [
                'tournament_id'   => $tid,
                'round_number'    => $round,
                'match_number'    => $matchNo++,
                'participant1_id' => $p1,
                'participant2_id' => null,
                'winner_id'       => $p1,
                'status'          => 'walkover',
                'completed_at'    => now(),
            ]);
        } else {
            insert('tournament_matches', [
                'tournament_id'   => $tid,
                'round_number'    => $round,
                'match_number'    => $matchNo++,
                'participant1_id' => $p1,
                'participant2_id' => $p2,
                'status'          => 'pending',
            ]);
        }
    }
}

function tournament_generate_round_robin(int $tid): void
{
    $rows = tournament_active_participants($tid);
    $ids = array_map(static fn($r) => (int) $r['id'], $rows);
    $n = count($ids);
    if ($n < 2) {
        tournament_complete($tid);
        return;
    }

    if ($n % 2 === 1) {
        $ids[] = 0;
        $n++;
    }
    $half = intdiv($n, 2);
    $rounds = $n - 1;
    $arr = $ids;

    for ($r = 1; $r <= $rounds; $r++) {
        $matchNo = 1;
        for ($i = 0; $i < $half; $i++) {
            $a = $arr[$i];
            $b = $arr[$n - 1 - $i];
            if ($a === 0 || $b === 0) {
                continue;
            }
            insert('tournament_matches', [
                'tournament_id'   => $tid,
                'round_number'    => $r,
                'match_number'    => $matchNo++,
                'participant1_id' => $a,
                'participant2_id' => $b,
                'status'          => 'pending',
            ]);
        }
        $fixed = $arr[0];
        $rest = array_slice($arr, 1);
        array_unshift($rest, array_pop($rest));
        $arr = array_merge([$fixed], $rest);
    }
}

function tournament_swiss_round_target(int $tid): int
{
    $t = tournament_get($tid);
    if ($t && !empty($t['max_rounds'])) {
        return (int) $t['max_rounds'];
    }
    $n = max(2, tournament_participant_count($tid));
    return max(1, (int) ceil(log($n, 2)));
}

function tournament_generate_swiss_round(int $tid, int $round): void
{
    if ($round === 1) {
        $rows = tournament_active_participants($tid);
        $ids = array_map(static fn($r) => (int) $r['id'], $rows);
    } else {
        $rows = fetch_all(
            "SELECT id FROM tournament_participants
             WHERE tournament_id = ? AND status NOT IN ('withdrawn','disqualified','eliminated')
             ORDER BY points DESC, wins DESC, seed IS NULL, seed, id",
            [$tid]
        );
        $ids = array_map(static fn($r) => (int) $r['id'], $rows);
    }

    $played = [];
    foreach (tournament_matches($tid) as $m) {
        if ((int) $m['participant1_id'] > 0 && (int) $m['participant2_id'] > 0) {
            $played[(int) $m['participant1_id']][(int) $m['participant2_id']] = true;
            $played[(int) $m['participant2_id']][(int) $m['participant1_id']] = true;
        }
    }

    $pairs = tournament_swiss_pair($ids, $played);
    if (!$pairs) {
        return;
    }
    $matchNo = 1;
    foreach ($pairs as $pair) {
        [$a, $b] = [$pair[0], $pair[1] ?? 0];
        if ($b === 0 || $b === null) {
            insert('tournament_matches', [
                'tournament_id'   => $tid,
                'round_number'    => $round,
                'match_number'    => $matchNo++,
                'participant1_id' => $a,
                'participant2_id' => null,
                'winner_id'       => $a,
                'status'          => 'walkover',
                'completed_at'    => now(),
            ]);
        } else {
            insert('tournament_matches', [
                'tournament_id'   => $tid,
                'round_number'    => $round,
                'match_number'    => $matchNo++,
                'participant1_id' => $a,
                'participant2_id' => $b,
                'status'          => 'pending',
            ]);
        }
    }
}

function tournament_swiss_pair(array $ids, array $played): array
{
    $pairs = [];
    $remaining = array_values($ids);
    while (count($remaining) >= 2) {
        $a = array_shift($remaining);
        $chosen = null;
        foreach ($remaining as $i => $b) {
            if (empty($played[$a][$b])) {
                $chosen = $i;
                break;
            }
        }
        if ($chosen === null) {
            $chosen = 0;
        }
        $b = $remaining[$chosen];
        array_splice($remaining, $chosen, 1);
        $pairs[] = [$a, $b];
    }
    if (count($remaining) === 1) {
        $pairs[] = [$remaining[0], 0];
    }
    return $pairs;
}

/* ------------------------------------------------------------------ */
/* Match results & progression                                         */
/* ------------------------------------------------------------------ */

function tournament_order_by_seed(array $participantIds): array
{
    if (!$participantIds) {
        return [];
    }
    $in = implode(',', array_fill(0, count($participantIds), '?'));
    $rows = fetch_all(
        "SELECT id FROM tournament_participants WHERE id IN ($in) ORDER BY seed IS NULL, seed, id",
        array_values($participantIds)
    );
    return array_map(static fn($r) => (int) $r['id'], $rows);
}

function tournament_all_matches_complete(int $tid): bool
{
    $total = (int) fetch_one('SELECT COUNT(*) FROM tournament_matches WHERE tournament_id = ?', [$tid], 0);
    if ($total === 0) {
        return false;
    }
    $pending = (int) fetch_one(
        "SELECT COUNT(*) FROM tournament_matches
         WHERE tournament_id = ? AND status IN ('pending','in_progress')",
        [$tid],
        0
    );
    return $pending === 0;
}

function tournament_round_complete(int $tid, int $round): bool
{
    $total = (int) fetch_one('SELECT COUNT(*) FROM tournament_matches WHERE tournament_id = ? AND round_number = ?', [$tid, $round], 0);
    if ($total === 0) {
        return false;
    }
    $pending = (int) fetch_one(
        "SELECT COUNT(*) FROM tournament_matches
         WHERE tournament_id = ? AND round_number = ? AND status IN ('pending','in_progress')",
        [$tid, $round],
        0
    );
    return $pending === 0;
}

function tournament_round_winners(int $tid, int $round): array
{
    $rows = fetch_all(
        "SELECT winner_id FROM tournament_matches
         WHERE tournament_id = ? AND round_number = ? AND winner_id IS NOT NULL
         ORDER BY match_number",
        [$tid, $round]
    );
    return array_map(static fn($r) => (int) $r['winner_id'], $rows);
}

function tournament_record_result(int $matchId, ?int $winnerParticipantId, int $score1 = 0, int $score2 = 0, bool $isDraw = false, array $details = []): array
{
    $m = fetch('SELECT * FROM tournament_matches WHERE id = ?', [$matchId]);
    if (!$m) {
        return ['ok' => false, 'error' => 'Match not found.'];
    }
    if (in_array((string) $m['status'], ['completed', 'cancelled'], true)) {
        return ['ok' => false, 'error' => 'This match has already been resolved.'];
    }
    $tid = (int) $m['tournament_id'];
    $p1 = $m['participant1_id'] !== null ? (int) $m['participant1_id'] : null;
    $p2 = $m['participant2_id'] !== null ? (int) $m['participant2_id'] : null;

    if ($isDraw) {
        if (!$p1 || !$p2) {
            return ['ok' => false, 'error' => 'A bye cannot end in a draw.'];
        }
        $winner = null;
        $loser = null;
    } else {
        if ($winnerParticipantId === null) {
            return ['ok' => false, 'error' => 'A winner is required.'];
        }
        if ($winnerParticipantId !== $p1 && $winnerParticipantId !== $p2) {
            return ['ok' => false, 'error' => 'Winner must be one of the match participants.'];
        }
        $winner = $winnerParticipantId;
        $loser = ($winner === $p1) ? $p2 : $p1;
    }

    q("UPDATE tournament_matches
       SET winner_id = ?, loser_id = ?, is_draw = ?, score1 = ?, score2 = ?,
           details = ?, status = 'completed', completed_at = NOW()
       WHERE id = ?",
        [$winner, $loser, $isDraw ? 1 : 0, $score1, $score2, json_encode($details), $matchId]);

    $round = (int) $m['round_number'];
    foreach ([$p1, $p2] as $pid) {
        if ($pid) {
            q('UPDATE tournament_participants SET current_round = GREATEST(current_round, ?) WHERE id = ?', [$round, $pid]);
        }
    }

    if ($isDraw) {
        foreach ([$p1, $p2] as $pid) {
            if ($pid) {
                q('UPDATE tournament_participants SET draws = draws + 1, points = points + 1 WHERE id = ?', [$pid]);
            }
        }
    } else {
        if ($winner) {
            q('UPDATE tournament_participants SET wins = wins + 1, points = points + 3 WHERE id = ?', [$winner]);
        }
        if ($loser) {
            q('UPDATE tournament_participants SET losses = losses + 1 WHERE id = ?', [$loser]);
        }
        $t = fetch('SELECT type FROM tournaments WHERE id = ?', [$tid]);
        if ($t && (string) $t['type'] === 'elimination' && $loser) {
            q("UPDATE tournament_participants SET status = 'eliminated' WHERE id = ?", [$loser]);
        }
    }

    if (!empty($details['kills']) && is_array($details['kills'])) {
        foreach ([[$p1, (int) ($details['kills'][0] ?? 0)], [$p2, (int) ($details['kills'][1] ?? 0)]] as $row) {
            if (!empty($row[0])) {
                q('UPDATE tournament_participants SET kills = kills + ?, total_score = total_score + ? WHERE id = ?', [$row[1], $row[1], (int) $row[0]]);
            }
        }
    }

    tournament_progress($tid);

    return ['ok' => true];
}

function tournament_submit_score(int $tid, int $userId, int $score, ?int $timeMs = null): array
{
    $t = tournament_get($tid);
    if (!$t) {
        return ['ok' => false, 'error' => 'Tournament not found.'];
    }
    if ((string) $t['status'] !== 'in_progress') {
        return ['ok' => false, 'error' => 'Tournament is not running.'];
    }
    $p = tournament_get_participant($tid, $userId);
    if (!$p || (string) $p['status'] !== 'confirmed') {
        return ['ok' => false, 'error' => 'You are not competing in this tournament.'];
    }

    if ((string) $t['game_type'] === 'mission_speedrun') {
        if ($timeMs === null || $timeMs <= 0) {
            return ['ok' => false, 'error' => 'A completion time is required for a speedrun.'];
        }
        if ($p['best_time_ms'] === null || $timeMs < (int) $p['best_time_ms']) {
            q('UPDATE tournament_participants SET best_time_ms = ? WHERE id = ?', [$timeMs, (int) $p['id']]);
        }
        q('UPDATE tournament_participants SET total_score = total_score + ? WHERE id = ?', [max(0, $score), (int) $p['id']]);
    } else {
        $kills = ((string) $t['game_type'] === 'kill_race') ? max(0, $score) : 0;
        q('UPDATE tournament_participants SET total_score = total_score + ?, kills = kills + ? WHERE id = ?', [max(0, $score), $kills, (int) $p['id']]);
    }

    if (function_exists('analytics_track')) {
        analytics_track('tournament_score', $userId, ['tournament_id' => $tid, 'score' => $score]);
    }
    return ['ok' => true];
}

/**
 * Report a gameplay result to any running tournament of the given game type
 * that the user is competing in. Safe to call from any gameplay path; it is a
 * no-op when there is no matching event, and never throws.
 */
function tournament_report_metric(string $gameType, int $userId, int $score = 1, ?int $timeMs = null): void
{
    if ($userId < 1) {
        return;
    }
    try {
        $rows = fetch_all(
            "SELECT id FROM tournaments
             WHERE status = 'in_progress' AND game_type = ?
             ORDER BY id DESC LIMIT 5",
            [$gameType]
        );
        foreach ($rows as $r) {
            $tid = (int) $r['id'];
            $p = tournament_get_participant($tid, $userId);
            if ($p && (string) $p['status'] === 'confirmed') {
                tournament_submit_score($tid, $userId, $score, $timeMs);
            }
        }
    } catch (Throwable $e) {
        // Reporting must never break gameplay.
    }
}

function tournament_progress(int $tid): void
{
    $t = tournament_get($tid);
    if (!$t || (string) $t['status'] !== 'in_progress') {
        return;
    }
    switch ((string) $t['type']) {
        case 'elimination':
            tournament_advance_elimination($tid);
            break;
        case 'round_robin':
            if (tournament_all_matches_complete($tid)) {
                tournament_complete($tid);
            }
            break;
        case 'swiss':
            tournament_advance_swiss($tid);
            break;
        default:
            break;
    }
}

function tournament_advance_elimination(int $tid): void
{
    $maxRound = (int) fetch_one('SELECT MAX(round_number) FROM tournament_matches WHERE tournament_id = ?', [$tid], 0);
    if ($maxRound < 1) {
        tournament_generate_elimination_round($tid, 1);
        return;
    }
    if (!tournament_round_complete($tid, $maxRound)) {
        return;
    }
    $winners = tournament_round_winners($tid, $maxRound);
    if (count($winners) <= 1) {
        tournament_complete($tid);
        return;
    }
    $winners = tournament_order_by_seed($winners);
    tournament_generate_elimination_round($tid, $maxRound + 1, $winners);
    tournament_advance_elimination($tid);
}

function tournament_advance_swiss(int $tid): void
{
    if (!tournament_all_matches_complete($tid)) {
        return;
    }
    $played = (int) fetch_one('SELECT COUNT(DISTINCT round_number) FROM tournament_matches WHERE tournament_id = ?', [$tid], 0);
    $target = tournament_swiss_round_target($tid);
    if ($played < $target) {
        tournament_generate_swiss_round($tid, $played + 1);
        return;
    }
    tournament_complete($tid);
}

/* ------------------------------------------------------------------ */
/* Completion & prizes                                                 */
/* ------------------------------------------------------------------ */

function tournament_rank_elimination(int $tid): void
{
    $rows = fetch_all(
        "SELECT id, status, current_round, seed
         FROM tournament_participants
         WHERE tournament_id = ? AND status NOT IN ('withdrawn','disqualified')",
        [$tid]
    );
    usort($rows, static function (array $a, array $b): int {
        $aChamp = (string) $a['status'] === 'confirmed' ? 1 : 0;
        $bChamp = (string) $b['status'] === 'confirmed' ? 1 : 0;
        if ($aChamp !== $bChamp) {
            return $bChamp <=> $aChamp;
        }
        if ((int) $a['current_round'] !== (int) $b['current_round']) {
            return (int) $b['current_round'] <=> (int) $a['current_round'];
        }
        return ((int) $a['seed']) <=> ((int) $b['seed']);
    });
    $pos = 1;
    foreach ($rows as $r) {
        q('UPDATE tournament_participants SET final_position = ? WHERE id = ?', [$pos++, (int) $r['id']]);
    }
}

function tournament_rank_by_points(int $tid): void
{
    $rows = fetch_all(
        "SELECT id FROM tournament_participants
         WHERE tournament_id = ? AND status NOT IN ('withdrawn','disqualified')
         ORDER BY points DESC, wins DESC, total_score DESC,
                  best_time_ms IS NULL, best_time_ms ASC, registered_at ASC, id ASC",
        [$tid]
    );
    $pos = 1;
    foreach ($rows as $r) {
        q('UPDATE tournament_participants SET final_position = ? WHERE id = ?', [$pos++, (int) $r['id']]);
    }
}

/**
 * Award prizes according to payout_structure. Returns a summary.
 */
function tournament_distribute_prizes(int $tid): array
{
    $t = tournament_get($tid);
    if (!$t) {
        return ['ok' => false, 'error' => 'Tournament not found.'];
    }

    $payout = tournament_payout($t);
    if (!$payout) {
        return ['ok' => true, 'awards' => 0];
    }

    $participants = fetch_all(
        'SELECT * FROM tournament_participants WHERE tournament_id = ? AND final_position IS NOT NULL',
        [$tid]
    );
    $byPlace = [];
    foreach ($participants as $p) {
        $byPlace[(int) $p['final_position']] = $p;
    }

    $poolMoney = (int) $t['prize_pool_money'];
    $poolPoints = (int) $t['prize_pool_points'];
    $poolXp = (int) $t['prize_pool_xp'];
    $awards = 0;

    foreach ($payout as $tier) {
        $place = (int) ($tier['place'] ?? 0);
        $pct = (float) ($tier['pct'] ?? 0);
        if ($place < 1 || $pct <= 0 || empty($byPlace[$place])) {
            continue;
        }
        $p = $byPlace[$place];
        $uid = (int) $p['user_id'];
        if ($uid <= 0) {
            continue;
        }
        $shareMoney = (int) round($poolMoney * $pct / 100);
        $sharePoints = (int) round($poolPoints * $pct / 100);
        $shareXp = (int) round($poolXp * $pct / 100);

        q('UPDATE tournament_participants
           SET prize_money = prize_money + ?, prize_points = prize_points + ?, prize_xp = prize_xp + ?
           WHERE id = ?', [$shareMoney, $sharePoints, $shareXp, (int) $p['id']]);

        if ($shareMoney > 0) {
            add_money($uid, $shareMoney, 'Tournament prize (place ' . $place . '): ' . $t['name']);
            insert('tournament_rewards_log', [
                'tournament_id'  => $tid,
                'participant_id' => (int) $p['id'],
                'user_id'        => $uid,
                'reward_type'    => 'money',
                'amount'         => $shareMoney,
                'place'          => $place,
            ]);
            $awards++;
        }
        if ($sharePoints > 0) {
            add_points($uid, $sharePoints);
            insert('tournament_rewards_log', [
                'tournament_id'  => $tid,
                'participant_id' => (int) $p['id'],
                'user_id'        => $uid,
                'reward_type'    => 'points',
                'amount'         => $sharePoints,
                'place'          => $place,
            ]);
            $awards++;
        }
        if ($shareXp > 0) {
            grant_xp($uid, $shareXp);
            insert('tournament_rewards_log', [
                'tournament_id'  => $tid,
                'participant_id' => (int) $p['id'],
                'user_id'        => $uid,
                'reward_type'    => 'xp',
                'amount'         => $shareXp,
                'place'          => $place,
            ]);
            $awards++;
        }
        notify($uid, $t['name'] . ': you finished #' . $place . ' and won prizes!', 'tournaments.php?view=' . $tid);
    }

    // Prize items tied to finishing places.
    foreach ($t['prize_items_decoded'] as $pi) {
        $place = (int) ($pi['place'] ?? 0);
        $itemId = (int) ($pi['item_id'] ?? 0);
        $qty = max(1, (int) ($pi['qty'] ?? 1));
        if ($place < 1 || $itemId < 1 || empty($byPlace[$place])) {
            continue;
        }
        $uid = (int) $byPlace[$place]['user_id'];
        if ($uid < 1) {
            continue;
        }
        insert('user_items', [
            'user_id'  => $uid,
            'item_id'  => $itemId,
            'qty'      => $qty,
            'equipped' => 0,
        ]);
        insert('tournament_rewards_log', [
            'tournament_id'  => $tid,
            'participant_id' => (int) $byPlace[$place]['id'],
            'user_id'        => $uid,
            'reward_type'    => 'item',
            'amount'         => $qty,
            'item_id'        => $itemId,
            'item_qty'       => $qty,
            'place'          => $place,
        ]);
        $awards++;
    }

    return ['ok' => true, 'awards' => $awards];
}

/* ------------------------------------------------------------------ */
/* Completion                                                          */
/* ------------------------------------------------------------------ */

function tournament_complete(int $tid): array
{
    $t = tournament_get($tid);
    if (!$t) {
        return ['ok' => false, 'error' => 'Tournament not found.'];
    }
    if ((string) $t['status'] === 'completed') {
        return ['ok' => true, 'already' => true];
    }

    if ((string) $t['type'] === 'elimination') {
        tournament_rank_elimination($tid);
    } else {
        tournament_rank_by_points($tid);
    }

    q("UPDATE tournaments SET status = 'completed', estimated_end_at = COALESCE(estimated_end_at, NOW()) WHERE id = ?", [$tid]);

    $result = tournament_distribute_prizes($tid);

    if (function_exists('analytics_track')) {
        analytics_track('tournament_complete', null, ['tournament_id' => $tid, 'type' => $t['type']]);
    }

    // Notify all participants of the final standings.
    foreach (fetch_all('SELECT user_id, final_position FROM tournament_participants WHERE tournament_id = ? AND user_id IS NOT NULL', [$tid]) as $p) {
        notify((int) $p['user_id'], $t['name'] . ' has concluded. Final place: #' . (int) $p['final_position'] . '.', 'tournaments.php?view=' . $tid);
    }

    return ['ok' => true] + (is_array($result) ? $result : []);
}

/* ------------------------------------------------------------------ */
/* Scheduled sweep                                                     */
/* ------------------------------------------------------------------ */

/**
 * Recurring tournament blueprints. One live event is kept per game type so
 * the lobby is never permanently empty on a fresh install.
 */
function tournament_blueprints(): array
{
    return [
        [
            'slug' => 'weekly_slugfest', 'name' => 'Weekly Slugfest',
            'description' => 'Straight elimination brawl. Last mobster standing takes the pot.',
            'type' => 'elimination', 'game_type' => 'pvp',
            'fee' => 5000, 'prize_money' => 15000, 'prize_points' => 20, 'prize_xp' => 500,
            'min' => 4, 'max' => 16, 'level' => 5, 'open_hours' => 3,
            'payout' => [['place' => 1, 'pct' => 60], ['place' => 2, 'pct' => 25], ['place' => 3, 'pct' => 15]],
        ],
        [
            'slug' => 'midnight_grand_prix', 'name' => 'Midnight Grand Prix',
            'description' => 'Round-robin street race championship. Fastest wheels in the city.',
            'type' => 'round_robin', 'game_type' => 'racing',
            'fee' => 10000, 'prize_money' => 30000, 'prize_points' => 35, 'prize_xp' => 900,
            'min' => 4, 'max' => 12, 'level' => 8, 'open_hours' => 4,
            'payout' => [['place' => 1, 'pct' => 55], ['place' => 2, 'pct' => 30], ['place' => 3, 'pct' => 15]],
        ],
        [
            'slug' => 'lucky_seven_cup', 'name' => 'Lucky Seven Casino Cup',
            'description' => 'High-stakes casino tournament. Only the luckiest gamblers survive.',
            'type' => 'round_robin', 'game_type' => 'casino',
            'fee' => 2500, 'prize_money' => 7500, 'prize_points' => 15, 'prize_xp' => 250,
            'min' => 4, 'max' => 50, 'level' => 1, 'open_hours' => 2,
            'payout' => [['place' => 1, 'pct' => 50], ['place' => 2, 'pct' => 30], ['place' => 3, 'pct' => 20]],
        ],
        [
            'slug' => 'swiss_kill_race', 'name' => 'Swiss Kill Race',
            'description' => 'Swiss-system tournament. Prove your body count over several rounds.',
            'type' => 'swiss', 'game_type' => 'kill_race',
            'fee' => 7500, 'prize_money' => 22500, 'prize_points' => 30, 'prize_xp' => 700,
            'min' => 4, 'max' => 16, 'level' => 10, 'open_hours' => 4,
            'payout' => [['place' => 1, 'pct' => 50], ['place' => 2, 'pct' => 30], ['place' => 3, 'pct' => 20]],
        ],
        [
            'slug' => 'heist_masters', 'name' => 'Heist Masters Invitational',
            'description' => 'Round-robin heist tournament. Only the boldest crews need apply.',
            'type' => 'round_robin', 'game_type' => 'heist',
            'fee' => 15000, 'prize_money' => 45000, 'prize_points' => 40, 'prize_xp' => 1200,
            'min' => 4, 'max' => 12, 'level' => 12, 'open_hours' => 5,
            'payout' => [['place' => 1, 'pct' => 60], ['place' => 2, 'pct' => 25], ['place' => 3, 'pct' => 15]],
        ],
        [
            'slug' => 'speedrun_open', 'name' => 'Speedrun Open',
            'description' => 'Mission speedrun tournament. Fastest completion time takes it.',
            'type' => 'swiss', 'game_type' => 'mission_speedrun',
            'fee' => 5000, 'prize_money' => 15000, 'prize_points' => 25, 'prize_xp' => 600,
            'min' => 4, 'max' => 20, 'level' => 6, 'open_hours' => 3,
            'payout' => [['place' => 1, 'pct' => 55], ['place' => 2, 'pct' => 30], ['place' => 3, 'pct' => 15]],
        ],
    ];
}

/**
 * Create a recurring tournament for each game type that has no live event
 * and has not run recently. Keeps at most one live event per game type.
 *
 * @return int number of tournaments created
 */
function tournament_auto_create(): int
{
    $created = 0;
    foreach (tournament_blueprints() as $bp) {
        $live = fetch_one(
            "SELECT id FROM tournaments
             WHERE game_type = ? AND status IN ('draft','registration','in_progress')
             LIMIT 1",
            [$bp['game_type']]
        );
        if ($live) {
            continue;
        }
        // Brief cooldown so a just-finished event is not instantly replaced.
        $recent = fetch_one(
            "SELECT id FROM tournaments
             WHERE game_type = ? AND updated_at >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
             LIMIT 1",
            [$bp['game_type']]
        );
        if ($recent) {
            continue;
        }

        $now = time();
        $opensAt  = date('Y-m-d H:i:s', $now);
        $closesAt = date('Y-m-d H:i:s', $now + (int) $bp['open_hours'] * 3600);
        $endsAt   = date('Y-m-d H:i:s', $now + ((int) $bp['open_hours'] + 4) * 3600);

        $id = insert('tournaments', [
            'code'                   => $bp['slug'] . '_' . date('YmdHis'),
            'name'                   => $bp['name'],
            'description'            => $bp['description'],
            'type'                   => $bp['type'],
            'game_type'              => $bp['game_type'],
            'registration_opens_at'  => $opensAt,
            'registration_closes_at' => $closesAt,
            'starts_at'              => $closesAt,
            'estimated_end_at'       => $endsAt,
            'min_participants'       => $bp['min'],
            'max_participants'       => $bp['max'],
            'min_level'              => $bp['level'],
            'max_level'              => 0,
            'crew_only'              => 0,
            'entry_fee_money'        => $bp['fee'],
            'entry_fee_points'       => 0,
            'prize_pool_money'       => $bp['prize_money'],
            'prize_pool_points'      => $bp['prize_points'],
            'prize_pool_xp'          => $bp['prize_xp'],
            'payout_structure'       => json_encode($bp['payout']),
            'status'                 => 'registration',
            'max_rounds'             => 4,
        ]);
        if ($id) {
            $created++;
        }
    }
    return $created;
}

/**
 * Resolve matches nobody reported a result for within the grace period.
 * Simulates an outcome weighted by each competitor's standing so scheduled
 * events always conclude. Cron job.
 *
 * @return int number of matches resolved
 */
function tournament_auto_resolve_matches(): int
{
    $rows = fetch_all(
        "SELECT tm.id, tm.tournament_id, tm.participant1_id, tm.participant2_id, t.game_type
         FROM tournament_matches tm
         JOIN tournaments t ON t.id = tm.tournament_id
         WHERE tm.status = 'pending'
           AND t.status = 'in_progress'
           AND tm.participant1_id IS NOT NULL
           AND tm.participant2_id IS NOT NULL
           AND tm.created_at <= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
         ORDER BY tm.tournament_id, tm.round_number, tm.match_number
         LIMIT 200"
    );

    $resolved = 0;
    foreach ($rows as $m) {
        $p1 = (int) $m['participant1_id'];
        $p2 = (int) $m['participant2_id'];

        $weights = [];
        foreach (fetch_all(
            'SELECT tp.id, tp.points, tp.wins, tp.total_score, COALESCE(u.level, 1) AS level
             FROM tournament_participants tp
             LEFT JOIN users u ON u.id = tp.user_id
             WHERE tp.id IN (?, ?)',
            [$p1, $p2]
        ) as $s) {
            $weights[(int) $s['id']] = max(1, (int) $s['level'] + (int) $s['points'] + (int) $s['wins'] * 3 + intdiv(max(0, (int) $s['total_score']), 5));
        }
        $w1 = $weights[$p1] ?? 1;
        $w2 = $weights[$p2] ?? 1;

        $winner = (random_int(1, $w1 + $w2) <= $w1) ? $p1 : $p2;
        $high = random_int(3, 12);
        $low  = random_int(0, max(0, $high - 1));
        $s1 = ($winner === $p1) ? $high : $low;
        $s2 = ($winner === $p2) ? $high : $low;

        $details = [];
        if ((string) $m['game_type'] === 'kill_race') {
            $details['kills'] = [$s1, $s2];
        }

        $res = tournament_record_result((int) $m['id'], $winner, $s1, $s2, false, $details);
        if (!empty($res['ok'])) {
            $resolved++;
        }
    }
    return $resolved;
}

function tournament_sweep_run(): array
{
    $stats = ['started' => 0, 'cancelled' => 0, 'resolved' => 0, 'completed' => 0, 'created' => 0];

    // Auto-start registration tournaments whose start time has arrived.
    $candidates = fetch_all(
        "SELECT id, min_participants FROM tournaments
         WHERE status = 'registration' AND registration_closes_at <= NOW() AND starts_at <= NOW()"
    );
    foreach ($candidates as $c) {
        if (tournament_participant_count((int) $c['id']) >= max(1, (int) $c['min_participants'])) {
            $res = tournament_start((int) $c['id']);
            if (!empty($res['ok'])) {
                $stats['started']++;
            }
        }
    }

    // Retire registration events that closed without enough competitors.
    foreach (fetch_all(
        "SELECT id FROM tournaments
         WHERE status = 'registration'
           AND GREATEST(registration_closes_at, starts_at) <= DATE_SUB(NOW(), INTERVAL 1 HOUR)"
    ) as $stale) {
        $res = tournament_cancel((int) $stale['id'], 'not enough competitors');
        if (!empty($res['ok']) && empty($res['already'])) {
            $stats['cancelled']++;
        }
    }

    // Resolve matches nobody reported after a grace period.
    $stats['resolved'] = tournament_auto_resolve_matches();

    // Auto-complete ladders whose window has closed.
    $ladders = fetch_all(
        "SELECT id FROM tournaments
         WHERE status = 'in_progress' AND type = 'ladder'
           AND estimated_end_at IS NOT NULL AND estimated_end_at <= NOW()"
    );
    foreach ($ladders as $l) {
        $res = tournament_complete((int) $l['id']);
        if (!empty($res['ok']) && empty($res['already'])) {
            $stats['completed']++;
        }
    }

    // Keep the lobby stocked with upcoming events.
    $stats['created'] = tournament_auto_create();

    return $stats;
}

/**
 * Run the sweep at most once per minute. Never throws.
 */
function tournament_sweep(): void
{
    try {
        $last = (int) fetch_one("SELECT v FROM settings WHERE k = 'tournament_last_sweep'", [], 0);
        if ($last > 0 && (time() - $last) < 60) {
            return;
        }
        q("INSERT INTO settings (k, v) VALUES ('tournament_last_sweep', ?)
           ON DUPLICATE KEY UPDATE v = VALUES(v)", [(string) time()]);
        tournament_sweep_run();
    } catch (Throwable $e) {
        // The sweep must never break a page.
    }
}
