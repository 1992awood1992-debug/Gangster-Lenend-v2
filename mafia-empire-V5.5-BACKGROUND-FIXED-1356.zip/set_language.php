<?php
require_once __DIR__ . '/includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
    exit;
}
csrf_verify();

$locale = trim((string)($_POST['locale'] ?? ''));
if (i18n_set_locale($locale)) {
    flash('Language updated.', 'success');
} else {
    flash('Invalid language selected.', 'error');
}

$back = $_SERVER['HTTP_REFERER'] ?? url('index.php');
$path = parse_url($back, PHP_URL_PATH) ?? '';
$host = parse_url($back, PHP_URL_HOST);
$selfHost = $_SERVER['HTTP_HOST'] ?? '';
if ($host && $selfHost && strtolower($host) !== strtolower($selfHost)) {
    $back = url('index.php');
} elseif ($path && basename($path) === 'set_language.php') {
    $back = url('index.php');
}
redirect($back);
exit;
