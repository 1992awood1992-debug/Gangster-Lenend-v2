<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * XP curve / level maths.
 */
final class GameMathTest extends TestCase
{
    public function testXpForLevelFormula(): void
    {
        // floor(100 * level^2 * 0.9)
        $this->assertSame(90, xp_for_level(1));
        $this->assertSame(360, xp_for_level(2));
        $this->assertSame(810, xp_for_level(3));
        $this->assertSame(9000, xp_for_level(10));
    }

    public function testXpCurveIsStrictlyIncreasing(): void
    {
        $previous = 0;
        for ($level = 1; $level <= 100; $level++) {
            $xp = xp_for_level($level);
            $this->assertGreaterThan($previous, $xp, "xp_for_level($level) must exceed the previous level");
            $previous = $xp;
        }
    }

    public function testLevelForXpBoundaries(): void
    {
        $this->assertSame(1, level_for_xp(0));
        $this->assertSame(1, level_for_xp(xp_for_level(2) - 1));
        $this->assertSame(2, level_for_xp(xp_for_level(2)));
        $this->assertSame(2, level_for_xp(xp_for_level(3) - 1));
        $this->assertSame(3, level_for_xp(xp_for_level(3)));
    }

    public function testLevelForXpRoundTrips(): void
    {
        for ($level = 1; $level <= 50; $level++) {
            $this->assertSame($level, level_for_xp(xp_for_level($level)));
        }
    }

    public function testLevelForXpCapsAtMaximum(): void
    {
        $this->assertLessThanOrEqual(200, level_for_xp(PHP_INT_MAX));
    }
}
