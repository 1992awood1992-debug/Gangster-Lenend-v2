/* ==========================================================================
   MAFIA EMPIRE V4.7 - SOUND EFFECTS SYSTEM
   ========================================================================== */
(function () {
  if (window.__mafiaSoundLoaded) return;
  window.__mafiaSoundLoaded = true;

  var AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return;
  var ctx = new AudioContext();

  var muted = localStorage.getItem('mafia-sound-muted') === '1';
  var sfxVolume = parseFloat(localStorage.getItem('mafia-sfx-volume') || '0.5');

  function resume() {
    if (ctx.state === 'suspended') ctx.resume();
  }

  function play(type) {
    if (muted || !ctx) return;
    resume();
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    var now = ctx.currentTime;
    var t = type || 'click';

    if (t === 'click') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(900, now + 0.08);
      gain.gain.setValueAtTime(sfxVolume * 0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc.start(now); osc.stop(now + 0.12);
    } else if (t === 'success') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523, now);
      osc.frequency.exponentialRampToValueAtTime(784, now + 0.1);
      osc.frequency.exponentialRampToValueAtTime(1046, now + 0.2);
      gain.gain.setValueAtTime(sfxVolume * 0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.start(now); osc.stop(now + 0.3);
    } else if (t === 'error') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.linearRampToValueAtTime(120, now + 0.15);
      gain.gain.setValueAtTime(sfxVolume * 0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.start(now); osc.stop(now + 0.25);
    } else if (t === 'gold') {
      osc.type = 'triangle';
      [523, 659, 784, 1046].forEach(function (f, i) {
        var o = ctx.createOscillator(); var g = ctx.createGain();
        o.type = 'sine'; o.frequency.value = f;
        o.connect(g); g.connect(ctx.destination);
        g.gain.setValueAtTime(sfxVolume * 0.15, now + i * 0.06);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.25);
        o.start(now + i * 0.06); o.stop(now + i * 0.06 + 0.25);
      });
    } else if (t === 'combat') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(150, now);
      osc.frequency.linearRampToValueAtTime(300, now + 0.05);
      gain.gain.setValueAtTime(sfxVolume * 0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.start(now); osc.stop(now + 0.15);
    } else if (t === 'levelup') {
      osc.type = 'triangle';
      [440, 554, 659, 880].forEach(function (f, i) {
        var o = ctx.createOscillator(); var g = ctx.createGain();
        o.type = 'sine'; o.frequency.value = f;
        o.connect(g); g.connect(ctx.destination);
        g.gain.setValueAtTime(sfxVolume * 0.2, now + i * 0.08);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.3);
        o.start(now + i * 0.08); o.stop(now + i * 0.08 + 0.3);
      });
    } else if (t === 'buy') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.1);
      gain.gain.setValueAtTime(sfxVolume * 0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now); osc.stop(now + 0.2);
    }
  }

  window.mafiaSound = {
    play: play,
    toggle: function () {
      muted = !muted;
      localStorage.setItem('mafia-sound-muted', muted ? '1' : '0');
      return !muted;
    },
    setVolume: function (v) {
      sfxVolume = Math.max(0, Math.min(1, v));
      localStorage.setItem('mafia-sfx-volume', String(sfxVolume));
    },
    isMuted: function () { return muted; }
  };

  // Auto resume on first interaction
  document.addEventListener('click', resume, { once: true });
  document.addEventListener('keydown', resume, { once: true });

  // Mute toggle button wiring
  var sbtn = document.getElementById('soundToggle');
  if (sbtn) {
    sbtn.setAttribute('data-muted', muted ? '1' : '0');
    sbtn.textContent = muted ? '&#128266;' : '&#127930;';
    sbtn.addEventListener('click', function () {
      var nowMuted = window.mafiaSound.toggle();
      sbtn.setAttribute('data-muted', nowMuted ? '1' : '0');
      sbtn.textContent = nowMuted ? '&#128266;' : '&#127930;';
      if (!nowMuted) window.mafiaSound.play('click');
    });
  }
})();
