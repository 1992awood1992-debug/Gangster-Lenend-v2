<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/security.php';
if (is_logged_in()) {
    redirect('play.php');
}

$errors = [];
$old = ['username' => '', 'email' => '', 'referral' => $_GET['ref'] ?? ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    auth_rate_limit('register', 5, 15);
    csrf_verify();
    $old['username'] = trim($_POST['username'] ?? '');
    $old['email']    = trim($_POST['email'] ?? '');
    $old['referral'] = trim($_POST['referral'] ?? '');
    $pass = $_POST['password'] ?? '';
    $pass2 = $_POST['password2'] ?? '';

    // Enhanced password strength
    $pwCheck = validate_password_strength($pass);
    if (!$pwCheck['valid']) {
        $errors = array_merge($errors, $pwCheck['errors']);
    }

    if (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $old['username'])) {
        $errors[] = 'Username must be 3-20 letters, numbers or underscores.';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }
    if (strlen($pass) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if ($pass !== $pass2) {
        $errors[] = 'Passwords do not match.';
    }
    if (!$errors && fetch('SELECT id FROM users WHERE username = ? OR email = ?', [$old['username'], $old['email']])) {
        $errors[] = 'That username or email is already registered.';
    }

    $referrer = null;
    if (!$errors && $old['referral'] !== '') {
        $referrer = fetch('SELECT id FROM users WHERE referral_code = ?', [$old['referral']]);
        if (!$referrer) {
            $errors[] = 'That referral code is not valid.';
        }
    }

    if (!$errors) {
        $uid = insert('users', [
            'username'      => $old['username'],
            'email'         => $old['email'],
            'password_hash' => password_hash($pass, PASSWORD_DEFAULT),
            'money'         => START_MONEY,
            'points'        => START_POINTS,
            'bullets'       => START_BULLETS,
            'referral_code' => strtoupper(substr(bin2hex(random_bytes(5)), 0, 8)),
            'referred_by'   => $referrer['id'] ?? null,
        ]);
        if ($referrer) {
            add_points((int) $referrer['id'], 10);
            insert('referral_rewards', ['referrer_id' => $referrer['id'], 'referred_id' => $uid, 'points' => 10]);
            // Also track in new system
            insert('referral_rewards_v2', [
                'referrer_id' => $referrer['id'],
                'referred_id' => $uid,
                'milestone' => 'signup',
                'reward_type' => 'points',
                'reward_amount' => (int)get_setting('referral_signup_bonus', 50),
                'status' => 'claimed',
                'claimed_at' => now(),
            ]);
            add_points($referrer['id'], (int)get_setting('referral_signup_bonus', 50));
            notify((int) $referrer['id'], 'You referred ' . $old['username'] . ' and earned ' . (int)get_setting('referral_signup_bonus', 50) . ' points!', 'referrals.php');
        }
        session_regenerate_id(true);
        $_SESSION['uid'] = $uid;
        auth_rate_limit_reset('register');
        analytics_track('register', $uid, ['referred' => $referrer ? (int) $referrer['id'] : null]);
        flash('Welcome to ' . SITE_NAME . ', ' . $old['username'] . '!', 'success');
        redirect('play.php');
    }
}
$page_title = 'Join';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-page">
  <div class="auth-container">
    <div class="auth-header">
      <div class="auth-logo" aria-hidden="true">&#9671;</div>
      <h1 class="auth-title">Join the Family</h1>
      <p class="auth-subtitle">Create your account and start your empire</p>
    </div>
    
    <div class="auth-card">
      <?php foreach ($errors as $err): ?>
        <div class="alert alert-error"><?= e($err) ?></div>
      <?php endforeach; ?>
      
      <form method="post" class="auth-form">
        <?= csrf_field() ?>
        
        <div class="form-group">
          <label>Username
            <input type="text" name="username" value="<?= e($old['username']) ?>" 
                   maxlength="20" required autofocus placeholder="Letters, numbers, underscore">
          </label>
        </div>
        
        <div class="form-group">
          <label>Email
            <input type="email" name="email" value="<?= e($old['email']) ?>" 
                   required placeholder="you@example.com">
          </label>
        </div>
        
        <div class="form-group">
          <label>Password
            <div class="input-with-toggle">
              <input type="password" name="password" id="regPassword" required 
                     placeholder="Create a strong password" autocomplete="new-password">
              <button type="button" class="input-toggle" aria-label="Toggle password visibility">
                <span aria-hidden="true">&#128065;</span>
              </button>
            </div>
          </label>
          <ul class="auth-password-reqs" id="pwReqs">
            <li class="req-met" data-req="length"><span class="req-icon"></span>At least 6 characters</li>
            <li class="req-met" data-req="upper"><span class="req-icon"></span>One uppercase letter</li>
            <li class="req-met" data-req="lower"><span class="req-icon"></span>One lowercase letter</li>
            <li class="req-met" data-req="number"><span class="req-icon"></span>One number</li>
            <li class="req-met" data-req="special"><span class="req-icon"></span>One special character</li>
          </ul>
        </div>
        
        <div class="form-group">
          <label>Confirm Password
            <div class="input-with-toggle">
              <input type="password" name="password2" required placeholder="Confirm your password" autocomplete="new-password">
              <button type="button" class="input-toggle" aria-label="Toggle password visibility">
                <span aria-hidden="true">&#128065;</span>
              </button>
            </div>
          </label>
        </div>
        
        <div class="form-group">
          <label>Referral Code <span class="muted small">(optional)</span>
            <input type="text" name="referral" value="<?= e($old['referral']) ?>" 
                   placeholder="Enter referral code" maxlength="8" style="text-transform:uppercase">
          </label>
        </div>
        
        <button class="btn btn-gold" type="submit">Create Account</button>
      </form>
      
      <div class="auth-links">
        <a href="<?= e(url('login.php')) ?>">Already made? Log in</a>
      </div>
    </div>
    
    <p class="auth-footer">&copy; <?= date('Y') ?> <?= e(SITE_NAME) ?>. All rights reserved.</p>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Password toggle buttons
  document.querySelectorAll('.input-toggle').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = this.previousElementSibling;
      if (input && (input.type === 'password' || input.type === 'text')) {
        if (input.type === 'password') {
          input.type = 'text';
          this.querySelector('span').textContent = '🙈';
        } else {
          input.type = 'password';
          this.querySelector('span').textContent = '👁';
        }
      }
    });
  });
  
  // Password strength meter
  const pwInput = document.getElementById('regPassword');
  const reqs = document.querySelectorAll('#pwReqs li');
  
  if (pwInput) {
    pwInput.addEventListener('input', function() {
      const val = this.value;
      let strength = 0;
      
      // Check requirements
      const checks = {
        length: val.length >= 6,
        upper: /[A-Z]/.test(val),
        lower: /[a-z]/.test(val),
        number: /[0-9]/.test(val),
        special: /[^A-Za-z0-9]/.test(val)
      };
      
      // Update requirement list
      reqs.forEach(li => {
        const req = li.dataset.req;
        if (checks[req]) {
          li.classList.add('req-met');
        } else {
          li.classList.remove('req-met');
        }
      });
      
      // Calculate strength
      if (checks.length) strength++;
      if (checks.upper) strength++;
      if (checks.lower) strength++;
      if (checks.number) strength++;
      if (checks.special) strength++;
      
      // Could add visual meter here
    });
  }
  
  // Auto-format referral code
  const refInput = document.querySelector('input[name="referral"]');
  if (refInput) {
    refInput.addEventListener('input', function() {
      this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
    });
  }
});
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>