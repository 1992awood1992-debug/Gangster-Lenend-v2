<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Functional;

use MafiaEmpire\Tests\Support\Http;
use MafiaEmpire\Tests\Support\TestCase;

/**
 * Boss fight "strike" over HTTP.
 *
 * Regression: bosses.php selected `bf.*, b.*`, so `$fight['id']` was the *boss*
 * id. The strike handler then ran `UPDATE boss_fights ... WHERE id = <boss id>`,
 * which either updated another player's fight or nothing at all. This test
 * asserts the active fight row itself is advanced.
 *
 * Skipped unless APP_URL points at a running instance.
 */
final class BossFightFlowTest extends TestCase
{
    private function requireServer(): void
    {
        if (!Http::configured()) {
            $this->markTestSkipped('Set APP_URL to a running instance to run the functional suite.');
        }
    }

    private function http(): Http
    {
        return new Http(Http::baseUrl());
    }

    public function testStrikeAdvancesTheActiveFightRow(): void
    {
        $this->requireServer();
        $user = $this->makeUser([
            'money'    => 0,
            'level'    => 1,
            'health'   => 100000,
            'health_max' => 100000,
            'strength' => 50,
            'speed'    => 50,
            'defense'  => 50,
            'iq'       => 50,
        ]);
        $boss = fetch('SELECT * FROM bosses ORDER BY id LIMIT 1');
        $this->assertNotNull($boss);

        $fightId = insert('boss_fights', [
            'user_id' => $user['id'],
            'boss_id' => $boss['id'],
            'boss_hp' => (int) $boss['hp'],
            'turns'   => 0,
            'active'  => 1,
        ]);

        $http = $this->http();
        $http->login($user['username'], 'testing123');
        $csrf = $http->csrfFrom('/bosses.php');
        $http->post('/bosses.php', ['csrf' => $csrf, 'action' => 'strike']);

        $fight = fetch('SELECT turns, boss_hp FROM boss_fights WHERE id = ?', [$fightId]);
        $this->assertSame(1, (int) $fight['turns'], 'strike must advance the active fight row');
        $this->assertLessThanOrEqual((int) $boss['hp'], (int) $fight['boss_hp']);
    }
}
