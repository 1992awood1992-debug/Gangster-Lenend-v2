<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/mini_events.php';
require_once __DIR__ . '/includes/weekend_events.php';
$u = require_login();

// POST: buy, collect, sell
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if (action_on_cooldown($u['id'], 'bullet_factory')) {
        $cd = action_on_cooldown($u['id'], 'bullet_factory');
        flash('Bullet Factory on cooldown. Try again in ' . $cd . '.', 'error');
        redirect('bullet_factory.php');
    }
    if ($action === 'buy') {
        $did = (int) ($_POST['district_id'] ?? 0);
        $bf = fetch('SELECT * FROM bullet_factories WHERE district_id = ?', [$did]);
        $district = fetch('SELECT * FROM districts WHERE id = ?', [$did]);
        if (!$bf || (int) $bf['owner_id'] !== 0) {
            flash('Factory not available.', 'error');
        } elseif ((int) $u['money'] < (int) $bf['price']) {
            flash('Not enough cash.', 'error');
        } else {
            add_money($u['id'], -(int) $bf['price'], 'Bought Bullet Factory in ' . $district['name']);
            q('UPDATE bullet_factories SET owner_id = ?, last_collect = ? WHERE district_id = ?', [$u['id'], now(), $did]);
            flash('Purchased the Bullet Factory in ' . e($district['name']) . '!', 'success');
        }
    } elseif ($action === 'collect') {
        $did = (int) ($_POST['district_id'] ?? 0);
        $bf = fetch('SELECT * FROM bullet_factories WHERE district_id = ? AND owner_id = ?', [$did, $u['id']]);
        $district = fetch('SELECT * FROM districts WHERE id = ?', [$did]);
        if (!$bf) {
            flash('You do not own this factory.', 'error');
        } else {
            $mult = mini_event_get_bullet_multiplier($did);
            $weekendMult = weekend_event_get_bullet_factory_multiplier();
            if ($weekendMult > 1.0) $mult *= $weekendMult;
            $last = $bf['last_collect'] ? strtotime($bf['last_collect']) : time();
            $hours = min(24, (time() - $last) / 3600);
            $gain = (int) floor((int) $bf['production'] * $hours * $mult);
            if ($gain <= 0) {
                flash('Nothing to collect yet.', 'error');
            } else {
                add_bullets($u['id'], $gain);
                q('UPDATE bullet_factories SET last_collect = ? WHERE district_id = ?', [now(), $did]);
                $msg = 'Collected ' . number_format($gain) . ' bullets from ' . e($district['name']);
                if ($mult > 1.0) $msg .= ' (🔫 Bullet Restock bonus!)';
                if ($weekendMult > 1.0) $msg .= ' (🔫 Bullet Rush weekend!)';
                flash($msg . '.', 'success');
            }
        }
    } elseif ($action === 'sell') {
        $did = (int) ($_POST['district_id'] ?? 0);
        $bf = fetch('SELECT * FROM bullet_factories WHERE district_id = ? AND owner_id = ?', [$did, $u['id']]);
        $district = fetch('SELECT * FROM districts WHERE id = ?', [$did]);
        if (!$bf) {
            flash('You do not own this factory.', 'error');
        } else {
            $refund = (int) floor((int) $bf['price'] * 0.5);
            add_money($u['id'], $refund, 'Sold Bullet Factory in ' . $district['name']);
            q('UPDATE bullet_factories SET owner_id = NULL, last_collect = NULL WHERE district_id = ?', [$did]);
                set_action_cooldown($u['id'], 'bullet_factory');
                flash('Sold the factory for ' . money($refund) . '.', 'success');
        }
    }
    redirect('bullet_factory.php');
}

$page_title = 'Bullet Factory';
require __DIR__ . '/includes/header.php';

$factories = fetch_all('SELECT bf.*, d.name AS district_name, d.unlock_level, u.username AS owner_name FROM bullet_factories bf JOIN districts d ON d.id = bf.district_id LEFT JOIN users u ON u.id = bf.owner_id ORDER BY d.id');

$bulletMultCity = (int) fetch_one("SELECT v FROM settings WHERE k = 'mini_event_bullet_city'", [], 0);
$bulletMult = $bulletMultCity ? mini_event_get_bullet_multiplier($bulletMultCity) : 1.0;
$weekendBulletMult = weekend_event_get_bullet_factory_multiplier();
?>
<div class="card">
  <div class="panel-heading">Bullet Factories</div>
  <p class="muted small">Each factory produces bullets every hour. Collect up to 24 hours of production at once.</p>
  <?php if ($bulletMult > 1.0 && $bulletMultCity): ?>
  <div class="card" style="border-color:var(--accent);background:var(--accent-dim);margin-top:8px">
    <b>🔫 Bullet Restock Active in District <?= $bulletMultCity ?>!</b> Factory output is <b><?= (int)($bulletMult * 100) ?>%</b> normal.
  </div>
  <?php endif; ?>
  <?php if ($weekendBulletMult > 1.0): ?>
  <div class="card" style="border-color:var(--accent);background:var(--accent-dim);margin-top:8px">
    <b>🔫 Bullet Rush Weekend!</b> All factory output is <b><?= (int)($weekendBulletMult * 100) ?>%</b> normal.
  </div>
  <?php endif; ?>
  <div class="table-wrap"><table>
    <tr><th>District</th><th>Owner</th><th>Production/hr</th><th>Price</th><th>Last Collect</th><th></th></tr>
    <?php foreach ($factories as $bf): $owned = (int) $bf['owner_id'] === $u['id']; $canAfford = (int) $u['money'] >= (int) $bf['price'];
        $prodMult = mini_event_get_bullet_multiplier((int) $bf['district_id']);
        if ($weekendBulletMult > 1.0) $prodMult *= $weekendBulletMult;
        $displayProd = (int) ceil((int) $bf['production'] * $prodMult); ?>
      <tr>
        <td><b><?= e($bf['district_name']) ?></b> <span class="tag tag-common">Lvl <?= (int) $bf['unlock_level'] ?>+</span></td>
        <td><?= $bf['owner_name'] ? e($bf['owner_name']) . ($owned ? ' (You)' : '') : '<span class="muted">Unowned</span>' ?></td>
        <td>
          <?= number_format($displayProd) ?> bullets
          <?php if ($prodMult > 1.0): ?>
            <span class="tag tag-gold">×<?= (int)($prodMult * 100) ?>%</span>
          <?php endif; ?>
        </td>
        <td><?= money($bf['price']) ?></td>
        <td><?= $bf['last_collect'] ? date('M j, H:i', strtotime($bf['last_collect'])) : 'Never' ?></td>
        <td>
          <?php if (!$bf['owner_id'] && (int) $u['level'] >= (int) $bf['unlock_level']): ?>
            <?php if ($canAfford): ?>
              <form method="post" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="buy">
                <input type="hidden" name="district_id" value="<?= (int) $bf['district_id'] ?>">
                <button class="btn btn-green btn-sm" type="submit">Buy</button>
              </form>
            <?php else: ?>
              <span class="tag tag-common">Too expensive</span>
            <?php endif; ?>
          <?php elseif ($owned): ?>
            <form method="post" style="display:inline-block">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="collect">
              <input type="hidden" name="district_id" value="<?= (int) $bf['district_id'] ?>">
              <button class="btn btn-gold btn-sm" type="submit">Collect</button>
            </form>
            <form method="post" style="display:inline-block;margin-left:4px">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="sell">
              <input type="hidden" name="district_id" value="<?= (int) $bf['district_id'] ?>">
              <button class="btn btn-sm" type="submit" data-confirm="Sell for <?= money((int) floor((int) $bf['price'] * 0.5)) ?>?">Sell</button>
            </form>
          <?php else: ?>
            <span class="muted small">Owned by <?= e($bf['owner_name']) ?></span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>