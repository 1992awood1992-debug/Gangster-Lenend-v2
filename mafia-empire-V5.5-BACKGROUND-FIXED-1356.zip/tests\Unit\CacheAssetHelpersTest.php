<?php

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/cache.php';

class CacheAssetHelpersTest extends TestCase
{
    public function testAssetReturnsUrlWithVersion(): void
    {
        $out = asset('assets/style.css');
        $this->assertStringContainsString('assets/style.css', $out);
        $this->assertStringContainsString('v=', $out);
    }

    public function testCacheSetGetRoundTrip(): void
    {
        cache_set('test:key', ['a' => 1, 'b' => 'two'], 30);
        $this->assertSame(['a' => 1, 'b' => 'two'], cache_get('test:key'));
    }

    public function testCacheDel(): void
    {
        cache_set('test:del', 'value', 30);
        cache_del('test:del');
        $this->assertNull(cache_get('test:del'));
    }

    public function testCacheRememberCallsLoaderOnMiss(): void
    {
        $calls = 0;
        $value = cache_remember('test:remember', 30, function () use (&$calls) {
            $calls++;
            return 'computed';
        });
        $this->assertSame('computed', $value);
        $this->assertSame(1, $calls);

        // Second read hits cache, loader not called again
        $value2 = cache_remember('test:remember', 30, function () use (&$calls) {
            $calls++;
            return 'computed';
        });
        $this->assertSame('computed', $value2);
        $this->assertSame(1, $calls);
    }
}