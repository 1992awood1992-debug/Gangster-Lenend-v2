<?php
/**
 * Eye Of The Mafia - configuration
 * Edit these values to match your MySQL server.
 */
// Values may be supplied via environment variables (Docker / production);
// otherwise they fall back to the local XAMPP defaults.
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_NAME', getenv('DB_NAME') ?: 'mafia_empire');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_PORT', getenv('DB_PORT') ?: '3306');

// Base URL of the game (no trailing slash). Leave empty to auto-detect.
define('BASE_URL', '');

define('SITE_NAME', 'Eye Of The Mafia');
define('GAME_VERSION', '5.0');
define('SCHEMA_VERSION', 31);
define('GAME_YEAR', 1356);

// Secret key used for signing WebSocket auth tokens and other cryptographic operations.
// In production, set this via the SECRET_KEY environment variable.
define('SECRET_KEY', getenv('SECRET_KEY') ?: 'eye-of-the-mafia-secret-key-change-in-production');

// CDN Configuration
define('CDN_BASE', getenv('CDN_BASE') ?: ''); // e.g., 'https://cdn.example.com'
define('CDN_PRELOAD_CRITICAL', true); // Enable preload headers for critical assets

// Game tuning
define('ENERGY_TICK_SECONDS', 300);   // 5 min per energy
define('NERVE_TICK_SECONDS', 600);    // 10 min per nerve
define('HEALTH_TICK_SECONDS', 600);   // 10 min per health point
define('MAX_ENERGY', 100);
define('MAX_NERVE', 50);
define('MAX_HEALTH', 100);
define('START_MONEY', 2500);
define('START_BULLETS', 50);
define('START_POINTS', 10);
define('HOSPITAL_PENALTY_RATIO', 0.10); // lose 10% cash when hospitalized

// --- Phase 7: REST API & integrations ------------------------------------
define('API_KEY_PREFIX', 'me_');          // prefix for every issued API key
define('API_DEFAULT_RATE_LIMIT', 60);     // requests per minute per key
define('API_MAX_RATE_LIMIT', 600);        // most a key may be granted
define('API_REQUEST_LOG', true);          // log requests to api_requests
define('WEBHOOK_TIMEOUT', 5);             // seconds per delivery attempt
define('WEBHOOK_MAX_ATTEMPTS', 5);        // then the delivery is marked failed

// Discord integration (optional; leave blank to disable).
define('DISCORD_PUBLIC_KEY', getenv('DISCORD_PUBLIC_KEY') ?: '');
define('DISCORD_APP_ID', getenv('DISCORD_APP_ID') ?: '');
define('DISCORD_WEBHOOK_URL', getenv('DISCORD_WEBHOOK_URL') ?: '');
define('DISCORD_ADMIN_IDS', getenv('DISCORD_ADMIN_IDS') ?: ''); // comma-separated Discord user ids

// Web Push / VAPID (optional; leave blank to disable push entirely).
// Generate a key pair with:  php cron/run.php vapid
define('PUSH_ENABLED', getenv('PUSH_ENABLED') === '1');
define('VAPID_PUBLIC_KEY', getenv('VAPID_PUBLIC_KEY') ?: '');
define('VAPID_PRIVATE_KEY', getenv('VAPID_PRIVATE_KEY') ?: ''); // PEM string, base64 PEM, or path to a PEM file
define('VAPID_SUBJECT', getenv('VAPID_SUBJECT') ?: 'mailto:admin@example.com');
define('PUSH_TIMEOUT', 6);          // seconds per outbound push request
define('PUSH_MAX_PER_TICK', 200);   // outbox rows flushed per cron tick
