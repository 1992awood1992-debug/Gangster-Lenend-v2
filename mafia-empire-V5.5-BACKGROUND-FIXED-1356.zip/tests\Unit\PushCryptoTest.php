<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Pure-PHP Web Push primitives: base64url, VAPID (ES256) JWT signing and
 * RFC 8291 aes128gcm payload encryption.
 */
final class PushCryptoTest extends TestCase
{
    public function testB64UrlRoundTrip(): void
    {
        $bin = random_bytes(40);
        $enc = push_b64url_encode($bin);
        $this->assertStringNotContainsString('+', $enc);
        $this->assertStringNotContainsString('/', $enc);
        $this->assertStringNotContainsString('=', $enc);
        $this->assertSame($bin, push_b64url_decode($enc));
    }

    public function testGenerateKeysProducesUsablePair(): void
    {
        $keys = push_generate_keys();
        $this->assertNotEmpty($keys);

        $point = push_b64url_decode($keys['public']);
        $this->assertSame(65, strlen($point));
        $this->assertSame("\x04", $point[0]);

        $priv = openssl_pkey_get_private($keys['private']);
        $this->assertNotFalse($priv);
        $det = openssl_pkey_get_details($priv);
        $this->assertSame($point, push_ec_point($det['ec']));
    }

    public function testDerToRawSignatureShape(): void
    {
        // Canonical minimal DER: r = 1, s = 2.
        $der = "\x30\x08\x02\x02\x00\x01\x02\x02\x00\x02";
        $raw = push_der_to_raw_sig($der);
        $this->assertSame(64, strlen($raw));
        $this->assertSame(str_repeat("\x00", 31) . "\x01", substr($raw, 0, 32));
        $this->assertSame(str_repeat("\x00", 31) . "\x02", substr($raw, 32, 32));
    }

    public function testVapidHeaderIsWellFormedAndVerifiable(): void
    {
        $keys = push_generate_keys();
        $GLOBALS['__push_keys_override'] = $keys + ['subject' => 'mailto:test@example.com'];
        try {
            $auth = push_vapid_authorization('https://push.example.com/send/abc');
            $this->assertNotNull($auth);
            $this->assertStringStartsWith('vapid t=', $auth);
            $this->assertStringContainsString(', k=' . $keys['public'], $auth);

            $this->assertSame(1, preg_match('/^vapid t=([^\s,]+), k=(\S+)$/', $auth, $m));
            $parts = explode('.', $m[1]);
            $this->assertCount(3, $parts);

            $header = json_decode(push_b64url_decode($parts[0]), true);
            $payload = json_decode(push_b64url_decode($parts[1]), true);
            $this->assertSame('ES256', $header['alg']);
            $this->assertSame('https://push.example.com', $payload['aud']);
            $this->assertSame('mailto:test@example.com', $payload['sub']);
            $this->assertGreaterThan(time(), $payload['exp']);

            $der = $this->rawToDer(push_b64url_decode($parts[2]));
            $pub = openssl_pkey_get_public(push_point_to_pem(push_b64url_decode($keys['public'])));
            $this->assertSame(1, openssl_verify($parts[0] . '.' . $parts[1], $der, $pub, OPENSSL_ALGO_SHA256));
        } finally {
            unset($GLOBALS['__push_keys_override']);
        }
    }

    public function testPayloadEncryptionRoundTrips(): void
    {
        require_once __DIR__ . '/../../includes/push.php';
        $ua = push_ec_key_new();
        if (!$ua) {
            $this->markTestSkipped('No EC key support');
        }
        $uaPem = '';
        $cfg = function_exists('push_openssl_config') ? push_openssl_config() : null;
        $ok = false;
        if ($cfg) {
            $ok = @openssl_pkey_export($ua, $uaPem, null, ['config' => $cfg]);
        } else {
            $ok = @openssl_pkey_export($ua, $uaPem);
        }
        if (!$ok || $uaPem === '') {
            $ok = @openssl_pkey_export($ua, $uaPem, null, ['config' => 'C:/xampp/php/extras/ssl/openssl.cnf']);
        }
        if (!$ok || $uaPem === '') {
            $this->markTestSkipped('Cannot export EC key in this environment');
        }
        $det = openssl_pkey_get_details($ua);
        $uaPub = push_b64url_encode(push_ec_point($det['ec']));
        $auth = random_bytes(16);

        $payload = json_encode(['title' => 'Eye Of The Mafia', 'body' => 'You were hospitalized.', 'url' => 'health.php']);
        $body = push_encrypt_payload($payload, $uaPub, push_b64url_encode($auth));
        $this->assertNotNull($body);

        $this->assertSame($payload, $this->decrypt($body, $uaPem, $auth));
    }

    public function testEncryptRejectsMalformedKeys(): void
    {
        $this->assertNull(push_encrypt_payload('x', 'not-base64!!', push_b64url_encode(random_bytes(16))));
        $this->assertNull(push_encrypt_payload('x', push_b64url_encode(random_bytes(10)), push_b64url_encode(random_bytes(16))));
    }

    /** Decrypt a single-record aes128gcm message (mirrors the browser). */
    private function decrypt(string $body, string $uaPem, string $auth): string
    {
        $salt = substr($body, 0, 16);
        $idlen = ord($body[20]);
        $asPoint = substr($body, 21, $idlen);
        $header = substr($body, 0, 21 + $idlen);
        $ct = substr($body, 21 + $idlen, -16);
        $tag = substr($body, -16);

        $asPub = openssl_pkey_get_public(push_point_to_pem($asPoint));
        $uaPriv = openssl_pkey_get_private($uaPem);
        $uaDet = openssl_pkey_get_details($uaPriv);
        $uaPoint = push_ec_point($uaDet['ec']);

        $ecdh = openssl_pkey_derive($asPub, $uaPriv, 32);
        $ikm = hash_hkdf('sha256', $ecdh, 32, "WebPush: info\x00" . $uaPoint . $asPoint, $auth);
        $cek = hash_hkdf('sha256', $ikm, 16, "Content-Encoding: aes128gcm\x00", $salt);
        $nonce = hash_hkdf('sha256', $ikm, 12, "Content-Encoding: nonce\x00", $salt);

        $pt = openssl_decrypt($ct, 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, $header);
        $this->assertIsString($pt);
        return substr($pt, 0, -1); // drop the single-record delimiter
    }

    private function intDer(string $v): string
    {
        $v = ltrim($v, "\x00");
        if ($v === '') {
            $v = "\x00";
        }
        if (ord($v[0]) & 0x80) {
            $v = "\x00" . $v;
        }
        return "\x02" . chr(strlen($v)) . $v;
    }

    /** Convert a raw 64-byte JWS signature back to DER for openssl_verify. */
    private function rawToDer(string $raw): string
    {
        $body = $this->intDer(substr($raw, 0, 32)) . $this->intDer(substr($raw, 32, 32));
        return "\x30" . chr(strlen($body)) . $body;
    }
}
