<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Functional;

use MafiaEmpire\Tests\Support\Http;
use MafiaEmpire\Tests\Support\TestCase;

/**
 * Contract test for the health endpoint (the app's public monitoring API).
 *
 * Skipped unless APP_URL points at a running instance.
 */
final class HealthContractTest extends TestCase
{
    public function testHealthEndpointReturnsOkContract(): void
    {
        if (!Http::configured()) {
            $this->markTestSkipped('Set APP_URL to a running instance to run the functional suite.');
        }

        $http = new Http(Http::baseUrl());
        [$status, $body] = $http->get('/health.php');

        $this->assertSame(200, $status);

        $json = json_decode($body, true);
        $this->assertIsArray($json, 'health.php must return JSON');
        $this->assertSame('ok', $json['status']);
        $this->assertArrayHasKey('time', $json);
        $this->assertArrayHasKey('checks', $json);

        $this->assertTrue($json['checks']['installed']);
        $this->assertTrue($json['checks']['database']['ok']);
        $this->assertArrayHasKey('schema_version', $json['checks']['database']);
        $this->assertTrue($json['checks']['disk']['ok']);
        $this->assertArrayHasKey('free_bytes', $json['checks']['disk']);
    }
}
