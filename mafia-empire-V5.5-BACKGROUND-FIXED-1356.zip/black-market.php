<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: buy, list, cancel
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if (action_on_cooldown($u['id'], 'black_market')) {
        $cd = action_on_cooldown($u['id'], 'black_market');
        flash('Black Market on cooldown. Try again in ' . $cd . '.', 'error');
        redirect('black-market.php');
    }
    if ($action === 'buy') {
        $listingId = (int) ($_POST['listing_id'] ?? 0);
        $listing = fetch('SELECT ml.*, i.name, i.type FROM market_listings ml JOIN items i ON i.id = ml.item_id WHERE ml.id = ? AND ml.status = ?', [$listingId, 'open']);
        if (!$listing) {
            flash('Listing not found or sold.', 'error');
        } elseif ((int) $listing['seller_id'] === $u['id']) {
            flash('You cannot buy your own listing.', 'error');
        } elseif ((int) $u['money'] < (int) $listing['price']) {
            flash('Not enough cash.', 'error');
        } else {
            // Atomic-ish: deduct, give item, pay seller, mark sold
            q('UPDATE users SET money = money - ? WHERE id = ?', [(int) $listing['price'], $u['id']]);
            q('UPDATE users SET money = money + ? WHERE id = ?', [(int) $listing['price'], $listing['seller_id']]);
            // Give item to buyer
            $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$u['id'], $listing['item_id']]);
            if ($existing) {
                q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [(int) $listing['qty'], (int) $existing['id']]);
            } else {
                insert('user_items', ['user_id' => $u['id'], 'item_id' => $listing['item_id'], 'qty' => (int) $listing['qty'], 'equipped' => 0]);
            }
            // Remove from seller inventory
            q('UPDATE user_items SET qty = qty - ? WHERE user_id = ? AND item_id = ? AND qty >= ?', [(int) $listing['qty'], $listing['seller_id'], $listing['item_id'], (int) $listing['qty']]);
            q('DELETE FROM user_items WHERE user_id = ? AND item_id = ? AND qty <= 0', [$listing['seller_id'], $listing['item_id']]);
            // Mark listing sold
            q('UPDATE market_listings SET status = ? WHERE id = ?', ['sold', $listingId]);
            notify((int) $listing['seller_id'], 'Your listing for ' . e($listing['name']) . ' sold for ' . money($listing['price']) . '.', 'black-market.php');
            set_action_cooldown($u['id'], 'black_market');
            flash('Purchased ' . (int) $listing['qty'] . 'x ' . e($listing['name']) . ' for ' . money($listing['price']) . '.', 'success');
        }
    } elseif ($action === 'list') {
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $qty = max(1, (int) ($_POST['qty'] ?? 0));
        $price = max(1, (int) ($_POST['price'] ?? 0));
        $owned = fetch('SELECT qty FROM user_items WHERE user_id = ? AND item_id = ?', [$u['id'], $itemId]);
        if (!$owned || $owned['qty'] < $qty) {
            flash('Not enough items in inventory.', 'error');
        } else {
            q('UPDATE user_items SET qty = qty - ? WHERE user_id = ? AND item_id = ?', [$qty, $u['id'], $itemId]);
            q('DELETE FROM user_items WHERE user_id = ? AND item_id = ? AND qty <= 0', [$u['id'], $itemId]);
            insert('market_listings', ['seller_id' => $u['id'], 'item_id' => $itemId, 'qty' => $qty, 'price' => $price, 'status' => 'open']);
            set_action_cooldown($u['id'], 'black_market');
            flash('Listed ' . $qty . 'x item for ' . money($price) . ' each.', 'success');
        }
    } elseif ($action === 'cancel') {
        $listingId = (int) ($_POST['listing_id'] ?? 0);
        $listing = fetch('SELECT * FROM market_listings WHERE id = ? AND seller_id = ? AND status = ?', [$listingId, $u['id'], 'open']);
        if (!$listing) {
            flash('Listing not found or cannot cancel.', 'error');
        } else {
            // Return items
            $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$u['id'], $listing['item_id']]);
            if ($existing) {
                q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [(int) $listing['qty'], (int) $existing['id']]);
            } else {
                insert('user_items', ['user_id' => $u['id'], 'item_id' => $listing['item_id'], 'qty' => (int) $listing['qty'], 'equipped' => 0]);
            }
            q('UPDATE market_listings SET status = ? WHERE id = ?', ['cancelled', $listingId]);
            set_action_cooldown($u['id'], 'black_market');
            flash('Listing cancelled, items returned.', 'success');
        }
    }
    redirect('black-market.php');
}

$page_title = 'Black Market';
require __DIR__ . '/includes/header.php';

$listings = fetch_all('SELECT ml.*, i.name, i.type, i.attack, i.defense, u.username FROM market_listings ml JOIN items i ON i.id = ml.item_id JOIN users u ON u.id = ml.seller_id WHERE ml.status = ? ORDER BY ml.created_at DESC', ['open']);
$myItems = fetch_all('SELECT ui.*, i.name, i.type, i.cost FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.qty > 0', [$u['id']]);
$myListings = fetch_all('SELECT ml.*, i.name FROM market_listings ml JOIN items i ON i.id = ml.item_id WHERE ml.seller_id = ? ORDER BY ml.created_at DESC', [$u['id']]);
?>
<div class="card">
  <div class="panel-heading">Market Listings</div>
  <?php if (!$listings): ?>
    <p class="muted">No listings at the moment.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Item</th><th>Type</th><th>Qty</th><th>Atk/Def</th><th>Seller</th><th>Price</th><th></th></tr>
      <?php foreach ($listings as $l): ?>
        <tr>
          <td><b><?= e($l['name']) ?></b></td>
          <td><span class="tag"><?= e($l['type']) ?></span></td>
          <td><?= (int) $l['qty'] ?></td>
          <td><?= (int) $l['attack'] > 0 ? '+' . (int) $l['attack'] . ' ATK' : '' ?><?= (int) $l['defense'] > 0 ? ' / +' . (int) $l['defense'] . ' DEF' : '' ?></td>
          <td><?= e($l['username']) ?></td>
          <td><?= money($l['price']) ?></td>
          <td>
            <form method="post" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="buy">
              <input type="hidden" name="listing_id" value="<?= (int) $l['id'] ?>">
              <button class="btn btn-green btn-sm" type="submit">Buy</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="panel-heading">List an Item</div>
  <form method="post" style="display:grid;gap:10px;max-width:500px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="list">
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
      <select name="item_id" required>
        <option value="">Select an item you own</option>
        <?php foreach ($myItems as $mi): ?>
          <option value="<?= (int) $mi['item_id'] ?>"><?= e($mi['name']) ?> (x<?= (int) $mi['qty'] ?>)</option>
        <?php endforeach; ?>
      </select>
      <input type="number" name="qty" min="1" placeholder="Quantity" required>
      <input type="number" name="price" min="1" placeholder="Price each" required>
    </div>
    <button class="btn btn-gold" type="submit">Create Listing</button>
  </form>
</div>

<div class="card">
  <div class="panel-heading">Your Listings</div>
  <?php if (!$myListings): ?>
    <p class="muted">No active or past listings.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Item</th><th>Qty</th><th>Price</th><th>Status</th><th>Date</th><th></th></tr>
      <?php foreach ($myListings as $ml): ?>
        <tr>
          <td><?= e($ml['name']) ?></td>
          <td><?= (int) $ml['qty'] ?></td>
          <td><?= money($ml['price']) ?></td>
          <td><span class="tag <?= $ml['status'] === 'open' ? 'tag-uncommon' : ($ml['status'] === 'sold' ? 'tag-legendary' : 'tag-common') ?>"><?= e($ml['status']) ?></span></td>
          <td><?= date('M j, H:i', strtotime($ml['created_at'])) ?></td>
          <td>
            <?php if ($ml['status'] === 'open'): ?>
              <form method="post" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="cancel">
                <input type="hidden" name="listing_id" value="<?= (int) $ml['id'] ?>">
                <button class="btn btn-sm" type="submit" data-confirm="Cancel this listing?">Cancel</button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>