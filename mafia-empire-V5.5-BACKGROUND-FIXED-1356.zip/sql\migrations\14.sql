-- Migration 14: Content Expansion + GraphQL API + Admin Tools
-- Idempotent: CREATE TABLE IF NOT EXISTS, safe to re-run.

-- ============================================================
-- NEW TABLES: GraphQL API (query complexity tracking)
-- ============================================================
CREATE TABLE IF NOT EXISTS api_graphql_complexity (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    api_key_id INT UNSIGNED NOT NULL,
    query_hash VARCHAR(64) NOT NULL,
    complexity INT UNSIGNED NOT NULL DEFAULT 0,
    depth INT UNSIGNED NOT NULL DEFAULT 0,
    fields_count INT UNSIGNED NOT NULL DEFAULT 0,
    duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
    status ENUM('success','error','rejected') NOT NULL,
    error_message TEXT NULL,
    executed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_apikey (api_key_id),
    KEY idx_date (executed_at),
    KEY idx_complexity (complexity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- NEW TABLES: Admin Audit Log
-- ============================================================
CREATE TABLE IF NOT EXISTS admin_audit_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    admin_id INT UNSIGNED NOT NULL,
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50) NULL,
    target_id INT UNSIGNED NULL,
    old_values JSON NULL,
    new_values JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_admin (admin_id),
    KEY idx_action (action),
    KEY idx_target (target_type, target_id),
    KEY idx_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- NEW TABLES: Structured Logging (for Loki/Elastic)
-- ============================================================
CREATE TABLE IF NOT EXISTS log_entries (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    level ENUM('debug','info','warning','error','critical') NOT NULL DEFAULT 'info',
    channel VARCHAR(50) NOT NULL DEFAULT 'app',
    message TEXT NOT NULL,
    context JSON NULL,
    user_id INT UNSIGNED NULL,
    ip_address VARCHAR(45) NULL,
    request_id VARCHAR(64) NULL,
    trace_id VARCHAR(64) NULL,
    span_id VARCHAR(64) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_level (level),
    KEY idx_channel (channel),
    KEY idx_user (user_id),
    KEY idx_date (created_at),
    KEY idx_trace (trace_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- CONTENT EXPANSION: More Missions
-- ============================================================
INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story) VALUES
(1, 'Shake Down a Pawn Shop', 'Quick cash from a desperate owner.', 3, 1, 300, 10, 1, 5, 'Quick cash from a desperate owner.'),
(1, 'Steal a Bike', 'Lightweight transport for quick getaways.', 2, 1, 200, 6, 0, 3, 'Lightweight transport for quick getaways.'),
(1, 'Tag a Building', 'Mark your territory with spray paint.', 4, 2, 450, 14, 1, 8, 'Mark your territory with spray paint.'),
(1, 'Intimidate a Witness', 'Silence before they talk.', 5, 3, 800, 22, 2, 15, 'Silence before they talk.'),
(2, 'Hijack a Cargo Container', 'Heavy cargo, heavy rewards.', 10, 6, 2000, 55, 3, 25, 'Heavy cargo, heavy rewards.'),
(2, 'Sabotage a Crane', 'Disrupt operations, send a message.', 8, 5, 1500, 40, 2, 20, 'Disrupt operations, send a message.'),
(2, 'Steal Dock Manifests', 'Knowledge is power on the waterfront.', 6, 4, 1000, 30, 1, 12, 'Knowledge is power on the waterfront.'),
(3, 'Bug a Restaurant', 'Wiretap a mob dinner.', 9, 8, 2500, 65, 3, 22, 'Wiretap a mob dinner.'),
(3, 'Steal a Recipe Book', 'Secret sauce worth killing for.', 7, 7, 1800, 48, 2, 18, 'Secret sauce worth killing for.'),
(3, 'Poison a Water Supply', 'Desperate times, desperate measures.', 12, 10, 4000, 110, 5, 30, 'Desperate times, desperate measures.'),
(4, 'Insider Trading Tip', 'Wall Street secrets for the taking.', 10, 15, 8000, 200, 4, 35, 'Wall Street secrets for the taking.'),
(4, 'Server Room Heist', 'Digital gold in the server room.', 14, 18, 12000, 300, 6, 42, 'Digital gold in the server room.'),
(5, 'Smuggle Exotic Animals', 'Rare beasts, rare profits.', 16, 25, 18000, 400, 8, 50, 'Rare beasts, rare profits.'),
(5, 'Art Gallery Heist', 'Culture for the cultured criminal.', 18, 28, 25000, 500, 10, 55, 'Culture for the cultured criminal.'),
(6, 'Cyber Heist', 'Hack the mainframe, steal the future.', 20, 30, 30000, 600, 12, 60, 'Hack the mainframe, steal the future.'),
(6, 'Satellite Uplink Hijack', 'Control the skies.', 22, 35, 40000, 800, 15, 65, 'Control the skies.')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- CONTENT EXPANSION: More Bosses
-- ============================================================
INSERT INTO bosses (district_id, name, description, hp, attack, defense, min_level, energy_cost, reward_money, reward_xp, reward_points, reward_item_id) VALUES
(1, 'Vinny "The Vise" Moretti', 'Crushes skulls for pocket change.', 500, 35, 15, 3, 15, 25000, 500, 15, NULL),
(2, 'Captain "Ironhook" Kowalski', 'Dock worker turned warlord.', 1200, 55, 30, 8, 25, 75000, 1500, 35, NULL),
(3, 'Don "Silver Tongue" Luciano', 'Words sharper than knives.', 2500, 80, 50, 15, 35, 200000, 4000, 70, NULL),
(4, 'The Algorithm', 'A ghost in the machine.', 5000, 120, 80, 25, 50, 500000, 10000, 150, NULL),
(5, 'El Diablo Blanco', 'The ghost of the desert.', 8000, 160, 100, 35, 70, 1000000, 20000, 250, NULL),
(6, 'The Architect', 'Built this city, owns the shadows.', 15000, 250, 180, 50, 100, 2500000, 50000, 500, NULL)
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- CONTENT EXPANSION: More Items
-- ============================================================
INSERT INTO items (name, description, type, attack, defense, cost, min_level, rarity) VALUES
('Brass Knuckles', 'Polished and persuasive.', 'weapon', 3, 0, 300, 1, 'common'),
('Switchblade', 'Quick and quiet.', 'weapon', 8, 0, 2000, 3, 'common'),
('9mm Pistol', 'Reliable sidearm.', 'weapon', 15, 2, 8000, 5, 'uncommon'),
('Sawn-Off Shotgun', 'Room clearing power.', 'weapon', 26, 3, 25000, 10, 'rare'),
('AK-47', 'Serious firepower.', 'weapon', 45, 5, 90000, 18, 'epic'),
('RPG-7', 'One shot, one kill.', 'weapon', 80, 10, 250000, 30, 'legendary'),
('Leather Jacket', 'Tougher than it looks.', 'armor', 0, 5, 800, 1, 'common'),
('Kevlar Vest', 'Stops the small stuff.', 'armor', 0, 14, 6000, 5, 'uncommon'),
('Bulletproof Suit', 'Style and survival.', 'armor', 1, 28, 30000, 12, 'rare'),
('Riot Gear', 'Military surplus.', 'armor', 2, 50, 120000, 20, 'epic'),
('Titanium Plate Carrier', 'Space-age protection.', 'armor', 3, 80, 500000, 35, 'legendary'),
('Beaten-Up Sedan', 'Gets you there.', 'vehicle', 0, 3, 3000, 2, 'common'),
('Armored SUV', 'Travel in safety.', 'vehicle', 2, 12, 20000, 8, 'uncommon'),
('Speedboat', 'For cargo and getaways.', 'vehicle', 3, 18, 60000, 15, 'rare'),
('Attack Helicopter', 'Air superiority.', 'vehicle', 10, 30, 500000, 25, 'epic'),
('Fighter Jet', 'Own the sky.', 'vehicle', 20, 50, 2000000, 40, 'legendary'),
('Crowbar', 'Opens doors and skulls.', 'weapon', 5, 1, 500, 2, 'common'),
('Molotov Cocktail', 'Fire in the hole.', 'weapon', 12, 0, 1500, 4, 'uncommon'),
('Sniper Rifle', 'One shot, one kill.', 'weapon', 35, 2, 45000, 15, 'rare'),
('Grenade Launcher', 'Area denial.', 'weapon', 40, 5, 150000, 22, 'epic'),
('Hazmat Suit', 'Chemical warfare ready.', 'armor', 1, 25, 40000, 15, 'rare'),
('Exoskeleton', 'Superhuman strength.', 'armor', 5, 40, 300000, 28, 'epic'),
('Submarine', 'Deep water ops.', 'vehicle', 5, 25, 200000, 20, 'epic'),
('Stealth Drone', 'Eyes in the sky.', 'vehicle', 1, 5, 100000, 20, 'rare')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- CONTENT EXPANSION: More Drugs
-- ============================================================
INSERT INTO drugs (name, description, min_level, buy_price, sell_price, effect_stat, effect_amount, od_risk) VALUES
('Weed', 'Cheap and cheerful gateway stash.', 1, 100, 150, '', 0, 0),
('Pills', 'Uppers for a long night.', 3, 250, 380, 'energy', 10, 10),
('Cocaine', 'Glittering white profit.', 6, 800, 1200, 'speed', 3, 20),
('Heroin', 'Nasty business, healthy margin.', 10, 1500, 2300, 'health', 15, 25),
('Meth', 'Cooked in a trailer, sold on the corner.', 12, 2000, 3100, 'strength', 4, 30),
('Fentanyl', 'Dangerous and lucrative.', 18, 4000, 6200, '', 0, 35),
('Designer X', 'Exclusive party supply.', 24, 9000, 14000, 'iq', 6, 30),
('Krokodil', 'Flesh-eating horror.', 30, 15000, 25000, 'strength', 10, 50),
('Blue Meth', '99.1% pure perfection.', 35, 25000, 40000, 'speed', 8, 40),
('Combat Stim', 'Military grade combat drug.', 25, 5000, 8000, 'strength', 15, 20),
('Focus X', 'Laser focus for snipers.', 20, 8000, 12000, 'iq', 10, 15),
('Adrenaline Shot', 'Instant combat boost.', 15, 3000, 5000, 'speed', 20, 25)
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- CONTENT EXPANSION: More Abilities
-- ============================================================
INSERT INTO abilities (name, description, cost_points, min_level, effect_type, effect_value, stat) VALUES
('Iron Grip', '+5 Strength permanently.', 10, 1, 'stat', 5, 'strength'),
('Quick Draw', '+5 Speed permanently.', 10, 1, 'stat', 5, 'speed'),
('Tough Skin', '+5 Defense permanently.', 10, 1, 'stat', 5, 'defense'),
('Street Smarts', '+5 IQ permanently.', 10, 1, 'stat', 5, 'iq'),
('Second Wind', 'Heal 25 health instantly.', 8, 3, 'heal', 25, ''),
('Energizer', 'Restore 20 energy instantly.', 12, 5, 'energy', 20, ''),
('Nerve of Steel', 'Restore 10 nerve instantly.', 15, 5, 'nerve', 10, ''),
('Bullet Magnet', 'Gain 50 bullets instantly.', 10, 3, 'bullets', 50, ''),
('Adrenaline Junkie', '+10% speed in combat.', 25, 10, 'combat_speed', 10, ''),
('Iron Will', 'Immune to fear effects.', 30, 15, 'fear_immune', 1, ''),
('Master Thief', '+20% mission rewards.', 40, 20, 'mission_bonus', 20, ''),
('Drug Lord', '+15% drug sell price.', 40, 25, 'drug_bonus', 15, ''),
('Armorer', 'Craft items 20% cheaper.', 35, 20, 'craft_discount', 20, ''),
('Diplomat', 'Crew diplomacy costs 30% less.', 30, 18, 'diplomacy_discount', 30, ''),
('Investor', 'Bank interest +50%.', 25, 12, 'bank_interest', 50, ''),
('Lucky Charm', '5% chance to double rewards.', 50, 30, 'luck', 5, ''),
('Shadow Step', '25% chance to dodge attacks.', 45, 25, 'dodge', 25, ''),
('Blood Money', 'Heal 50% of damage dealt.', 50, 30, 'lifesteal', 50, ''),
('Phoenix Down', 'Revive once per day with 50% HP.', 100, 40, 'revive', 1, ''),
('Time Warp', 'Reduce all cooldowns by 20%.', 60, 35, 'cooldown_reduction', 20, '')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- CONTENT EXPANSION: More Achievements
-- ============================================================
INSERT INTO achievements (code, name, description, reward_points, target, metric) VALUES
('first_blood', 'First Blood', 'Kill your first target.', 10, 1, 'kills'),
('hitman', 'Hitman', 'Kill 10 players.', 25, 10, 'kills'),
('serial_killer', 'Serial Killer', 'Kill 100 players.', 100, 100, 'kills'),
('mass_murderer', 'Mass Murderer', 'Kill 1000 players.', 500, 1000, 'kills'),
('mission_10', 'Errand Boy', 'Complete 10 missions.', 15, 10, 'missions_done'),
('mission_100', 'Gone Pro', 'Complete 100 missions.', 50, 100, 'missions_done'),
('mission_1000', 'Mission Master', 'Complete 1000 missions.', 200, 1000, 'missions_done'),
('boss_slayer', 'Boss Slayer', 'Defeat your first boss.', 20, 1, 'boss_kills'),
('boss_hunter', 'Boss Hunter', 'Defeat 10 bosses.', 50, 10, 'boss_kills'),
('boss_legend', 'Boss Legend', 'Defeat 100 bosses.', 200, 100, 'boss_kills'),
('rich', 'Money Bags', 'Hold $1,000,000 in cash.', 30, 1000000, 'money'),
('tycoon', 'Tycoon', 'Hold $100,000,000 in cash.', 200, 100000000, 'money'),
('level_10', 'Up and Comer', 'Reach level 10.', 20, 10, 'level'),
('level_50', 'Crime Lord', 'Reach level 50.', 100, 50, 'level'),
('level_100', 'Centurion', 'Reach level 100.', 500, 100, 'level'),
('criminal', 'Career Criminal', 'Complete 50 criminal jobs.', 30, 50, 'crimes_done'),
('master_criminal', 'Master Criminal', 'Complete 500 criminal jobs.', 150, 500, 'crimes_done'),
('veteran', 'Veteran', 'Reach level 25.', 40, 25, 'level'),
('heist_master', 'Heist Master', 'Complete 50 heists.', 100, 50, 'heists_done'),
('heist_legend', 'Heist Legend', 'Complete 500 heists.', 500, 500, 'heists_done'),
('property_mogul', 'Property Mogul', 'Own 5 properties.', 50, 5, 'properties_owned'),
('racing_champ', 'Racing Champion', 'Win 50 races.', 100, 50, 'race_wins'),
('market_mogul', 'Market Mogul', 'Sell 1000 items on market.', 150, 1000, 'market_sales'),
('mayor', 'Mayor', 'Win a mayoral election.', 200, 1, 'mayor_wins'),
('policy_maker', 'Policy Maker', 'Enact 10 city policies.', 100, 10, 'policies_enacted')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- CONTENT EXPANSION: More Stickers
-- ============================================================
INSERT INTO stickers (code, name, rarity) VALUES
('golden_gun', 'Golden Gun', 'legendary'),
('diamond_skull', 'Diamond Skull', 'legendary'),
('platinum_card', 'Platinum Card', 'epic'),
('golden_bullet', 'Golden Bullet', 'epic'),
('silver_dollar', 'Silver Dollar', 'rare'),
('bronze_medal', 'Bronze Medal', 'uncommon'),
('copper_penny', 'Copper Penny', 'common'),
('iron_cross', 'Iron Cross', 'uncommon'),
('steel_fist', 'Steel Fist', 'rare'),
('titanium_heart', 'Titanium Heart', 'epic'),
('adamantium_shield', 'Adamantium Shield', 'legendary'),
('mithril_coin', 'Mithril Coin', 'epic'),
('orichalcum_ring', 'Orichalcum Ring', 'legendary')
ON DUPLICATE KEY UPDATE name=VALUES(name);