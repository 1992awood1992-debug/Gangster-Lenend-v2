<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Functional;

use MafiaEmpire\Tests\Support\Http;
use MafiaEmpire\Tests\Support\TestCase;

/**
 * End-to-end contract tests for the v1 REST API, driven over HTTP against a
 * running instance (skipped unless APP_URL is set).
 *
 * Routes are addressed through the portable "?route=" form so they work on
 * the PHP built-in server, Apache and any host without rewrite rules.
 */
final class ApiEndpointTest extends TestCase
{
    private function http(): Http
    {
        if (!Http::configured()) {
            $this->markTestSkipped('Set APP_URL to a running instance to run the functional suite.');
        }
        return new Http(Http::baseUrl());
    }

    /** @return array{0:int,1:array} */
    private function apiGet(string $route, Http $http, array $headers = []): array
    {
        [$status, $body] = $http->get('api/index.php?route=' . $route, $headers);
        return [$status, ($json = json_decode($body, true)) === null ? [] : $json];
    }

    public function testHealthIsPublic(): void
    {
        $http = $this->http();
        [$status, $json] = $this->apiGet('v1/health', $http);
        $this->assertSame(200, $status);
        $this->assertTrue($json['ok']);
        $this->assertSame('ok', $json['data']['status']);
        $this->assertArrayHasKey('schema_version', $json['data']);
    }

    public function testLeaderboardsArePublic(): void
    {
        $http = $this->http();
        $this->makeUser(['level' => 9, 'xp' => 90000]);
        [$status, $json] = $this->apiGet('v1/leaderboards&board=level&limit=5', $http);
        $this->assertSame(200, $status);
        $this->assertTrue($json['ok']);
        $this->assertIsArray($json['data']);
        $this->assertSame('level', $json['meta']['board']);
    }

    public function testUnknownBoardIsRejected(): void
    {
        $http = $this->http();
        [$status, $json] = $this->apiGet('v1/leaderboards&board=bogus', $http);
        $this->assertSame(400, $status);
        $this->assertFalse($json['ok']);
        $this->assertSame('bad_request', $json['error']['code']);
    }

    public function testMarketIsPublic(): void
    {
        $http = $this->http();
        [$status, $json] = $this->apiGet('v1/market', $http);
        $this->assertSame(200, $status);
        $this->assertTrue($json['ok']);
        $this->assertIsArray($json['data']);
    }

    public function testPublicPlayerProfile(): void
    {
        $http = $this->http();
        $u = $this->makeUser(['level' => 3]);
        [$status, $json] = $this->apiGet('v1/players/' . (int) $u['id'], $http);
        $this->assertSame(200, $status);
        $this->assertSame($u['username'], $json['data']['username']);
        $this->assertArrayNotHasKey('money', $json['data']);
    }

    public function testMissingKeyIsUnauthorized(): void
    {
        $http = $this->http();
        [$status, $json] = $this->apiGet('v1/me', $http);
        $this->assertSame(401, $status);
        $this->assertSame('missing_key', $json['error']['code']);
    }

    public function testBadKeyIsUnauthorized(): void
    {
        $http = $this->http();
        [$status, $json] = $this->apiGet('v1/me', $http, ['X-API-Key' => 'me_deadbeef.nope']);
        $this->assertSame(401, $status);
        $this->assertSame('bad_key', $json['error']['code']);
    }

    public function testMeWithHeaderKey(): void
    {
        $http = $this->http();
        $u = $this->makeUser(['money' => 777]);
        $created = api_key_create((int) $u['id'], 'test', ['read'], 60);

        [$status, $json] = $this->apiGet('v1/me', $http, ['X-API-Key' => $created['plain']]);
        $this->assertSame(200, $status);
        $this->assertTrue($json['ok']);
        $this->assertSame($u['username'], $json['data']['username']);
        $this->assertSame(777, $json['data']['money']);
    }

    public function testMeWithBearerToken(): void
    {
        $http = $this->http();
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'bearer', ['read'], 60);

        [$status, $json] = $this->apiGet('v1/me', $http, ['Authorization' => 'Bearer ' . $created['plain']]);
        $this->assertSame(200, $status);
        $this->assertSame($u['username'], $json['data']['username']);
    }

    public function testNotificationsEndpoint(): void
    {
        $http = $this->http();
        $u = $this->makeUser();
        notify((int) $u['id'], 'Test alert', 'index.php');
        $created = api_key_create((int) $u['id'], 'notif', ['read'], 60);

        [$status, $json] = $this->apiGet('v1/me/notifications', $http, ['X-API-Key' => $created['plain']]);
        $this->assertSame(200, $status);
        $this->assertSame(1, $json['meta']['unread']);
        $this->assertSame('Test alert', $json['data'][0]['text']);
    }

    public function testRateLimitHeadersPresent(): void
    {
        $http = $this->http();
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'rl', ['read'], 30);

        [, , $headers] = $http->get('api/index.php?route=v1/me', ['X-API-Key' => $created['plain']]);
        $this->assertArrayHasKey('x-ratelimit-limit', $headers);
        $this->assertSame('30', $headers['x-ratelimit-limit']);
    }

    public function testRateLimitEnforced(): void
    {
        $http = $this->http();
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'rl2', ['read'], 1);
        $h = ['X-API-Key' => $created['plain']];

        [$first] = $this->apiGet('v1/me', $http, $h);
        [$second, $json] = $this->apiGet('v1/me', $http, $h);

        $this->assertSame(200, $first);
        $this->assertSame(429, $second);
        $this->assertSame('rate_limited', $json['error']['code']);
    }

    public function testScopeIsEnforced(): void
    {
        $http = $this->http();
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'ro', ['read'], 60);

        [$status, $json] = $http->get('api/index.php?route=v1/me', ['X-API-Key' => $created['plain']]);
        $this->assertSame(200, $status);

        [$status, $json] = $http->post('api/index.php?route=v1/webhooks/test', [], ['X-API-Key' => $created['plain']]);
        $json = json_decode($json, true);
        $this->assertSame(403, $status);
        $this->assertSame('insufficient_scope', $json['error']['code']);
    }

    public function testAdminStatsRequiresAdminScope(): void
    {
        $http = $this->http();
        $u = $this->makeUser();
        $read = api_key_create((int) $u['id'], 'ro', ['read'], 60);

        [$status, $json] = $this->apiGet('v1/admin/stats', $http, ['X-API-Key' => $read['plain']]);
        $this->assertSame(403, $status);
        $this->assertSame('insufficient_scope', $json['error']['code']);

        $admin = api_key_create((int) $u['id'], 'boss', ['admin'], 60);
        [$status, $json] = $this->apiGet('v1/admin/stats', $http, ['X-API-Key' => $admin['plain']]);
        $this->assertSame(200, $status);
        $this->assertArrayHasKey('players', $json['data']);
    }

    public function testUnknownVersionIsNotFound(): void
    {
        $http = $this->http();
        [$status, $json] = $this->apiGet('v2/me', $http);
        $this->assertSame(404, $status);
        $this->assertSame('not_found', $json['error']['code']);
    }

    public function testRootReturnsDiscoveryDocument(): void
    {
        $http = $this->http();
        [$status, $json] = $http->get('api/');
        $json = json_decode($json, true);
        $this->assertSame(200, $status);
        $this->assertSame('v1', $json['data']['api']);
        $this->assertNotEmpty($json['data']['endpoints']);
    }
}
