<?php
/**
 * Eye Of The Mafia - Two-Factor Authentication (2FA)
 * TOTP-based 2FA with QR codes, backup codes, and recovery
 */

declare(strict_types=1);

require_once __DIR__ . '/init.php';

/**
 * Generate a new TOTP secret (base32 encoded)
 */
function twofa_generate_secret(): string
{
    $bytes = random_bytes(20); // 160 bits
    return base32_encode($bytes);
}

/**
 * Encode binary data as base32 (RFC 4648)
 */
function base32_encode(string $data): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split($data) as $char) {
        $bits .= str_pad(decbin(ord($char)), 8, '0', STR_PAD_LEFT);
    }
    $bits = str_pad($bits, (int) ceil(strlen($bits) / 5) * 5, '0', STR_PAD_RIGHT);
    $output = '';
    for ($i = 0; $i < strlen($bits); $i += 5) {
        $chunk = substr($bits, $i, 5);
        $output .= $alphabet[bindec($chunk)];
    }
    return rtrim($output, '=');
}

/**
 * Decode base32 (RFC 4648)
 */
function base32_decode(string $encoded): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $encoded = strtoupper($encoded);
    $bits = '';
    foreach (str_split($encoded) as $char) {
        if ($char === '=') break;
        $val = strpos($alphabet, $char);
        if ($val === false) continue;
        $bits .= str_pad(decbin($val), 5, '0', STR_PAD_LEFT);
    }
    $output = '';
    for ($i = 0; $i < strlen($bits); $i += 8) {
        $byte = substr($bits, $i, 8);
        if (strlen($byte) === 8) {
            $output .= chr(bindec($byte));
        }
    }
    return $output;
}

/**
 * Generate TOTP code (RFC 6238)
 */
function twofa_generate_totp(string $secret, int $timeSlice = null, int $digits = 6, int $period = 30): string
{
    if ($timeSlice === null) {
        $timeSlice = floor(time() / $period);
    }
    
    $key = base32_decode($secret);
    $time = pack('N*', 0, $timeSlice);
    $hash = hash_hmac('sha1', $time, $key, true);
    $offset = ord($hash[-1]) & 0x0F;
    $code = (
        ((ord($hash[$offset]) & 0x7F) << 24) |
        ((ord($hash[$offset + 1]) & 0xFF) << 16) |
        ((ord($hash[$offset + 2]) & 0xFF) << 8) |
        (ord($hash[$offset + 3]) & 0xFF)
    ) % pow(10, $digits);
    
    return str_pad((string)$code, $digits, '0', STR_PAD_LEFT);
}

/**
 * Verify TOTP code with time drift tolerance
 */
function twofa_verify_totp(string $secret, string $code, int $tolerance = 1): bool
{
    $now = floor(time() / 30);
    
    for ($i = -$tolerance; $i <= $tolerance; $i++) {
        $expected = twofa_generate_totp($secret, $now + $i);
        if (hash_equals($expected, $code)) {
            return true;
        }
    }
    return false;
}

/**
 * Generate QR code URI for authenticator apps
 */
function twofa_get_qr_uri(string $secret, string $username, string $issuer = 'Eye Of The Mafia'): string
{
    $label = urlencode($issuer . ':' . $username);
    return "otpauth://totp/{$label}?secret={$secret}&issuer=" . urlencode($issuer) . '&digits=6&period=30';
}

/**
 * Generate backup/recovery codes
 */
function twofa_generate_backup_codes(int $count = 10, int $length = 8): array
{
    $codes = [];
    for ($i = 0; $i < $count; $i++) {
        $code = '';
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // No 0, O, I, 1, L
        for ($j = 0; $j < $length; $j++) {
            $code .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $codes[] = strtoupper(chunk_split($code, 4, ' '));
    }
    return $codes;
}

/**
 * Hash backup codes for storage
 */
function twofa_hash_backup_codes(array $codes): array
{
    return array_map(fn($code) => password_hash(str_replace(' ', '', $code), PASSWORD_ARGON2ID), $codes);
}

/**
 * Verify a backup code
 */
function twofa_verify_backup_code(int $userId, string $code): bool
{
    $code = strtoupper(str_replace(' ', '', $code));
    
    $recovery = fetch('SELECT id, code_hash FROM user_2fa_recovery WHERE user_id = ? AND used = 0', [(int) $userId]);
    if (!$recovery) {
        return false;
    }
    
    // Check all unused recovery codes
    $recoveryCodes = fetch_all('SELECT id, code_hash FROM user_2fa_recovery WHERE user_id = ? AND used = 0', [(int) $userId]);
    foreach ($recoveryCodes as $rc) {
        if (password_verify($code, $rc['code_hash'])) {
            // Mark as used
            q('UPDATE user_2fa_recovery SET used = 1, used_at = NOW() WHERE id = ?', [(int) $rc['id']]);
            return true;
        }
    }
    return false;
}

/**
 * Enable 2FA for a user
 */
function twofa_enable(int $userId, string $secret, array $backupCodes): array
{
    $hashedCodes = twofa_hash_backup_codes($backupCodes);
    
    // Store recovery codes
    foreach ($hashedCodes as $hash) {
        insert('user_2fa_recovery', [
            'user_id' => $userId,
            'code_hash' => $hash,
        ]);
    }
    
    // Enable 2FA
    q('UPDATE users SET twofa_enabled = 1, twofa_secret = ?, twofa_backup_codes = NULL, twofa_last_used = NULL WHERE id = ?',
        [$secret, $userId]);
    
    // Log security event
    log_security('2fa_enabled', [
        'user_id' => $userId,
        'method' => 'totp',
    ]);
    
    return ['ok' => true];
}

/**
 * Disable 2FA for a user
 */
function twofa_disable(int $userId): array
{
    q('UPDATE users SET twofa_enabled = 0, twofa_secret = NULL, twofa_backup_codes = NULL, twofa_last_used = NULL WHERE id = ?', [$userId]);
    q('DELETE FROM user_2fa_recovery WHERE user_id = ?', [$userId]);
    
    log_security('2fa_disabled', ['user_id' => $userId]);
    
    return ['ok' => true];
}

/**
 * Verify 2FA code (TOTP or backup)
 */
function twofa_verify(int $userId, string $code): array
{
    $user = fetch('SELECT twofa_enabled, twofa_secret FROM users WHERE id = ?', [(int) $userId]);
    if (!$user || !(int) $user['twofa_enabled']) {
        return ['ok' => false, 'error' => '2FA not enabled'];
    }
    
    // Try TOTP first
    if (!empty($user['twofa_secret']) && twofa_verify_totp($user['twofa_secret'], $code)) {
        q('UPDATE users SET twofa_last_used = NOW() WHERE id = ?', [(int) $userId]);
        log_security('2fa_verified', ['user_id' => $userId, 'method' => 'totp']);
        return ['ok' => true, 'method' => 'totp'];
    }
    
    // Try backup code
    if (twofa_verify_backup_code($userId, $code)) {
        q('UPDATE users SET twofa_last_used = NOW() WHERE id = ?', [(int) $userId]);
        log_security('2fa_verified', ['user_id' => $userId, 'method' => 'backup_code']);
        return ['ok' => true, 'method' => 'backup_code'];
    }
    
    // Log failed attempt
    log_security('2fa_failed', ['user_id' => $userId, 'ip' => get_client_ip()]);
    
    return ['ok' => false, 'error' => 'Invalid 2FA code'];
}

/**
 * Get 2FA status for user
 */
function twofa_get_status(int $userId): array
{
    $user = fetch('SELECT twofa_enabled, twofa_secret, twofa_last_used FROM users WHERE id = ?', [(int) $userId]);
    if (!$user) {
        return ['enabled' => false];
    }
    
    $recoveryCount = (int) fetch_one('SELECT COUNT(*) FROM user_2fa_recovery WHERE user_id = ? AND used = 0', [(int) $userId], 0);
    
    return [
        'enabled' => (bool) $user['twofa_enabled'],
        'secret' => $user['twofa_secret'] ?? null,
        'backup_codes_total' => $recoveryCount,
        'recovery_codes_remaining' => $recoveryCount,
        'last_used' => $user['twofa_last_used'] ?? null,
    ];
}

/**
 * Regenerate backup codes
 */
function twofa_regenerate_backup_codes(int $userId): array
{
    // Delete old unused codes
    q('DELETE FROM user_2fa_recovery WHERE user_id = ? AND used = 0', [(int) $userId]);
    
    $codes = twofa_generate_backup_codes(10);
    $hashedCodes = twofa_hash_backup_codes($codes);
    
    foreach ($hashedCodes as $hash) {
        insert('user_2fa_recovery', [
            'user_id' => (int) $userId,
            'code_hash' => $hash,
        ]);
    }
    
    q('UPDATE users SET twofa_backup_codes = NULL WHERE id = ?', [(int) $userId]);
    
    log_security('2fa_backup_codes_regenerated', ['user_id' => (int) $userId]);
    
    return ['ok' => true, 'codes' => $codes];
}

/**
 * Get QR code SVG for 2FA setup
 */
function twofa_get_qr_svg(string $qrUri, int $size = 200): string
{
    // Use Google Charts API for QR code generation
    $url = 'https://chart.googleapis.com/chart?chs=' . $size . 'x' . $size 
         . '&chl=' . urlencode($qrUri) 
         . '&cht=qr&chld=L|1';
    
    return '<img src="' . e($url) . '" alt="2FA QR Code" width="' . $size . '" height="' . $size . '">';
}

