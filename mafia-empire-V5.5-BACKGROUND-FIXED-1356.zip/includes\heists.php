<?php
/**
 * Eye Of The Mafia - Heist System (Crew Co-op Missions)
 * Multi-phase heists with shared rewards, crew coordination required.
 */

require_once __DIR__ . '/init.php';

/**
 * Get all active heists
 */
function heist_get_all(): array
{
    return fetch_all("
        SELECT * FROM heists 
        WHERE is_active = 1 
        ORDER BY sort_order, min_crew_level
    ");
}

/**
 * Get a single heist by ID
 */
function heist_get(int $heistId): ?array
{
    return fetch('SELECT * FROM heists WHERE id = ?', [$heistId]);
}

/**
 * Get heist by code
 */
function heist_get_by_code(string $code): ?array
{
    return fetch('SELECT * FROM heists WHERE code = ?', [$code]);
}

/**
 * Check if crew can start a heist
 */
function heist_can_start(int $crewId, int $heistId): array
{
    $heist = heist_get($heistId);
    if (!$heist) return ['ok' => false, 'error' => 'Heist not found'];
    if (!(int) $heist['is_active']) return ['ok' => false, 'error' => 'Heist not available'];

    $crew = fetch('SELECT * FROM crews WHERE id = ?', [$crewId]);
    if (!$crew) return ['ok' => false, 'error' => 'Crew not found'];

    // Check crew level
    if ((int) $crew['level'] < (int) $heist['min_crew_level']) {
        return ['ok' => false, 'error' => "Crew level {$heist['min_crew_level']} required"];
    }

    // Check member count
    $memberCount = (int) fetch_one('SELECT COUNT(*) FROM crew_members WHERE crew_id = ?', [$crewId], 0);
    if ($memberCount < (int) $heist['min_members']) {
        return ['ok' => false, 'error' => "Minimum {$heist['min_members']} crew members required"];
    }
    if ($memberCount > (int) $heist['max_members']) {
        return ['ok' => false, 'error' => "Maximum {$heist['max_members']} crew members allowed"];
    }

    // Check cooldown
    $lastInstance = fetch('
        SELECT * FROM heist_instances 
        WHERE crew_id = ? AND heist_id = ? 
        ORDER BY created_at DESC LIMIT 1
    ', [$crewId, $heistId]);
    if ($lastInstance) {
        $cooldownEnd = strtotime($lastInstance['created_at']) + (int) $heist['cooldown_hours'] * 3600;
        if (time() < $cooldownEnd) {
            $remaining = $cooldownEnd - time();
            $hours = floor($remaining / 3600);
            $mins = floor(($remaining % 3600) / 60);
            return ['ok' => false, 'error' => "Cooldown active: {$hours}h {$mins}m remaining"];
        }
    }

    // Check required items (crew vault)
    if (!empty($heist['required_items'])) {
        $required = json_decode($heist['required_items'], true);
        foreach ($required as $req) {
            $has = fetch_one('
                SELECT COALESCE(SUM(qty),0) FROM crew_armory 
                WHERE crew_id = ? AND item_id = ?
            ', [$crewId, (int) $req['item_id']], 0);
            if ($has < (int) $req['qty']) {
                $item = fetch('SELECT name FROM items WHERE id = ?', [(int) $req['item_id']]);
                return ['ok' => false, 'error' => "Need {$req['qty']}x {$item['name']} in crew armory"];
            }
        }
    }

    // Check required stats (crew averages)
    if (!empty($heist['required_stats'])) {
        $stats = json_decode($heist['required_stats'], true);
        $avg = fetch('
            SELECT AVG(u.strength) as str, AVG(u.speed) as spd, 
                   AVG(u.defense) as def, AVG(u.iq) as iq
            FROM crew_members cm
            JOIN users u ON u.id = cm.user_id
            WHERE cm.crew_id = ?
        ', [$crewId]);
        foreach ($stats as $stat => $min) {
            $statMap = ['strength' => 'str', 'speed' => 'spd', 'defense' => 'def', 'iq' => 'iq'];
            if (isset($statMap[$stat]) && (float) $avg[$statMap[$stat]] < (int) $min) {
                return ['ok' => false, 'error' => "Crew average {$stat} must be {$min}+ (currently " . round((float) $avg[$statMap[$stat]]) . ")"];
            }
        }
    }

    return ['ok' => true, 'heist' => $heist];
}

/**
 * Start a new heist instance
 */
function heist_start(int $crewId, int $heistId, int $leaderId): array
{
    $check = heist_can_start($crewId, $heistId);
    if (!$check['ok']) return $check;

    $heist = $check['heist'];
    $crew = fetch('SELECT * FROM crews WHERE id = ?', [$crewId]);

    // Verify leader is crew leader
    if ((int) $crew['leader_id'] !== $leaderId) {
        return ['ok' => false, 'error' => 'Only crew leader can start heist'];
    }

    // Get crew members
    $members = fetch_all('
        SELECT cm.user_id, cm.rank FROM crew_members cm WHERE cm.crew_id = ?
    ', [$crewId]);

    // Build participants JSON
    $participants = [];
    foreach ($members as $m) {
        $participants[] = [
            'user_id' => (int) $m['user_id'],
            'role' => ((int) $m['user_id'] === $leaderId) ? 'leader' : 'member',
            'joined_at' => date('Y-m-d H:i:s'),
            'ready' => false,
        ];
    }

    // Consume required items from armory
    if (!empty($heist['required_items'])) {
        $required = json_decode($heist['required_items'], true);
        foreach ($required as $req) {
            q('
                UPDATE crew_armory 
                SET qty = qty - ? 
                WHERE crew_id = ? AND item_id = ?
            ', [(int) $req['qty'], $crewId, (int) $req['item_id']]);
        }
    }

    // Create instance
    $instanceId = insert('heist_instances', [
        'heist_id'      => $heistId,
        'crew_id'       => $crewId,
        'leader_id'     => $leaderId,
        'status'        => 'planning',
        'current_phase' => 0,
        'participants'  => json_encode($participants),
        'phase_progress' => json_encode([]),
    ]);

    // Create participant rows
    foreach ($participants as $p) {
        insert('heist_participants', [
            'instance_id' => $instanceId,
            'user_id'     => (int) $p['user_id'],
            'role'        => $p['role'],
            'ready'       => 0,
        ]);
    }

    // Analytics
    analytics_track('heist_start', $leaderId, [
        'heist_id' => $heistId,
        'crew_id'  => $crewId,
        'members'  => count($participants),
    ]);

    return ['ok' => true, 'instance_id' => $instanceId];
}

/**
 * Get heist instance details
 */
function heist_get_instance(int $instanceId): ?array
{
    return fetch('SELECT * FROM heist_instances WHERE id = ?', [$instanceId]);
}

/**
 * Get instance with heist data
 */
function heist_get_instance_full(int $instanceId): ?array
{
    $inst = heist_get_instance($instanceId);
    if (!$inst) return null;
    $inst['heist'] = heist_get((int) $inst['heist_id']);
    $inst['participants_detail'] = fetch_all('
        SELECT hp.*, u.username, u.level, u.avatar
        FROM heist_participants hp
        JOIN users u ON u.id = hp.user_id
        WHERE hp.instance_id = ?
    ', [$instanceId]);
    return $inst;
}

/**
 * Get user's active heist instance
 */
function heist_get_user_active(int $userId): ?array
{
    $inst = fetch('
        SELECT hi.* FROM heist_instances hi
        JOIN heist_participants hp ON hp.instance_id = hi.id
        WHERE hp.user_id = ? AND hi.status IN (\'planning\',\'active\')
        ORDER BY hi.created_at DESC LIMIT 1
    ', [$userId]);
    if ($inst) {
        $inst['heist'] = heist_get((int) $inst['heist_id']);
    }
    return $inst;
}

/**
 * Ready up for heist (planning phase)
 */
function heist_ready(int $instanceId, int $userId): array
{
    $inst = heist_get_instance($instanceId);
    if (!$inst) return ['ok' => false, 'error' => 'Instance not found'];
    if ((int) $inst['status'] !== 0) return ['ok' => false, 'error' => 'Heist already started'];

    $part = fetch('SELECT * FROM heist_participants WHERE instance_id = ? AND user_id = ?', [$instanceId, $userId]);
    if (!$part) return ['ok' => false, 'error' => 'Not a participant'];

    q('UPDATE heist_participants SET ready = 1 WHERE instance_id = ? AND user_id = ?', [$instanceId, $userId]);

    // Check if all ready
    $unready = fetch_one('SELECT COUNT(*) FROM heist_participants WHERE instance_id = ? AND ready = 0', [$instanceId], 0);
    if ($unready === 0) {
        // All ready - start heist
        q('UPDATE heist_instances SET status = \'active\', current_phase = 1, phase_started_at = NOW() WHERE id = ?', [$instanceId]);
        
        // Notify all participants
        $participants = fetch_all('SELECT user_id FROM heist_participants WHERE instance_id = ?', [$instanceId]);
        foreach ($participants as $p) {
            notify((int) $p['user_id'], 'Heist started! Phase 1 begun.', 'heists.php');
        }
    }

    return ['ok' => true];
}

/**
 * Unready (cancel ready)
 */
function heist_unready(int $instanceId, int $userId): array
{
    q('UPDATE heist_participants SET ready = 0 WHERE instance_id = ? AND user_id = ?', [$instanceId, $userId]);
    return ['ok' => true];
}

/**
 * Abandon heist (leader only)
 */
function heist_abandon(int $instanceId, int $userId): array
{
    $inst = heist_get_instance($instanceId);
    if (!$inst) return ['ok' => false, 'error' => 'Instance not found'];
    if ((int) $inst['leader_id'] !== $userId) return ['ok' => false, 'error' => 'Only leader can abandon'];

    q('UPDATE heist_instances SET status = \'abandoned\' WHERE id = ?', [$instanceId]);
    return ['ok' => true];
}

/**
 * Complete a phase
 */
function heist_complete_phase(int $instanceId, int $userId, int $phaseIndex): array
{
    $inst = heist_get_instance($instanceId);
    if (!$inst) return ['ok' => false, 'error' => 'Instance not found'];
    if ($inst['status'] !== 'active') return ['ok' => false, 'error' => 'Heist not active'];
    if ((int) $inst['current_phase'] !== $phaseIndex + 1) return ['ok' => false, 'error' => 'Invalid phase'];

    $heist = heist_get((int) $inst['heist_id']);
    $phases = json_decode($heist['phases'], true);
    if (!isset($phases[$phaseIndex])) return ['ok' => false, 'error' => 'Phase not found'];

    // Check if user is participant
    $part = fetch('SELECT * FROM heist_participants WHERE instance_id = ? AND user_id = ?', [$instanceId, $userId]);
    if (!$part) return ['ok' => false, 'error' => 'Not a participant'];

    // Mark phase complete
    $progress = json_decode($inst['phase_progress'] ?? '{}', true);
    $progress[$phaseIndex] = [
        'completed' => true,
        'completed_by' => $userId,
        'completed_at' => date('Y-m-d H:i:s'),
    ];
    q('UPDATE heist_instances SET phase_progress = ? WHERE id = ?', [json_encode($progress), $instanceId]);

    // Award phase rewards
    $phase = $phases[$phaseIndex];
    $participants = fetch_all('SELECT user_id FROM heist_participants WHERE instance_id = ?', [$instanceId]);
    $count = count($participants);

    foreach ($participants as $p) {
        $shareMoney = $count > 0 ? floor((int) $phase['money'] / $count) : 0;
        $shareXp = $count > 0 ? floor((int) $phase['xp'] / $count) : 0;
        
        if ($shareMoney > 0) add_money((int) $p['user_id'], $shareMoney, 'Heist phase: ' . $heist['name']);
        if ($shareXp > 0) grant_xp((int) $p['user_id'], $shareXp);
        
        q('UPDATE heist_participants SET money_received = money_received + ?, xp_received = xp_received + ? WHERE instance_id = ? AND user_id = ?',
            [$shareMoney, $shareXp, $instanceId, (int) $p['user_id']]);
    }

    // Next phase or complete
    $nextPhase = $phaseIndex + 1;
    if ($nextPhase < count($phases)) {
        q('UPDATE heist_instances SET current_phase = ?, phase_started_at = NOW() WHERE id = ?', [$nextPhase + 1, $instanceId]);
        
        // Notify participants
        $participants = fetch_all('SELECT user_id FROM heist_participants WHERE instance_id = ?', [$instanceId]);
        foreach ($participants as $p) {
            notify((int) $p['user_id'], "Phase {$nextPhase} complete! Phase " . ($nextPhase + 1) . " started.", 'heists.php');
        }
    } else {
        // Heist complete!
        return heist_complete($instanceId, $heist);
    }

    return ['ok' => true, 'next_phase' => $nextPhase];
}

/**
 * Complete entire heist - distribute final rewards
 */
function heist_complete(int $instanceId, array $heist): array
{
    $inst = heist_get_instance($instanceId);
    $participants = fetch_all('SELECT user_id FROM heist_participants WHERE instance_id = ?', [$instanceId]);
    $count = count($participants);

    $totalMoney = (int) $heist['reward_money'];
    $totalXp = (int) $heist['reward_xp'];
    $totalPoints = (int) $heist['reward_points'];

    $shareMoney = $count > 0 ? floor($totalMoney / $count) : 0;
    $shareXp = $count > 0 ? floor($totalXp / $count) : 0;
    $sharePoints = $count > 0 ? floor($totalPoints / $count) : 0;

    $itemsAwarded = [];

    foreach ($participants as $p) {
        $uid = (int) $p['user_id'];
        
        if ($shareMoney > 0) add_money($uid, $shareMoney, 'Heist complete: ' . $heist['name']);
        if ($shareXp > 0) grant_xp($uid, $shareXp);
        if ($sharePoints > 0) add_points($uid, $sharePoints);

        // Feed the completion into any running heist tournament.
        if (function_exists('tournament_report_metric')) {
            tournament_report_metric('heist', $uid, 1);
        }

        // Random item rewards
        if (!empty($heist['reward_items'])) {
            $rewards = json_decode($heist['reward_items'], true);
            foreach ($rewards as $r) {
                if (mt_rand(1, 100) <= (int) ($r['chance'] * 100)) {
                    insert('user_items', [
                        'user_id' => $uid,
                        'item_id' => (int) $r['item_id'],
                        'qty' => (int) $r['qty'],
                        'equipped' => 0,
                    ]);
                    $itemsAwarded[] = ['user_id' => $uid, 'item_id' => (int) $r['item_id'], 'qty' => (int) $r['qty']];
                }
            }
        }

        q('UPDATE heist_participants SET 
            money_received = money_received + ?, 
            xp_received = xp_received + ?, 
            points_received = points_received + ?,
            items_received = ?
            WHERE instance_id = ? AND user_id = ?',
            [$shareMoney, $shareXp, $sharePoints, json_encode($itemsAwarded), $instanceId, $uid]);
    }

    q('UPDATE heist_instances SET 
        status = \'completed\', 
        completed_at = NOW(),
        total_money = ?, total_xp = ?, total_points = ?,
        items_awarded = ?
        WHERE id = ?',
        [$shareMoney * $count, $shareXp * $count, $sharePoints * $count, json_encode($itemsAwarded), $instanceId]);

    // Crew XP
    $crewXp = 100 + $shareXp / max(1, $count);
    q('UPDATE crews SET xp = xp + ? WHERE id = ?', [floor($crewXp), $inst['crew_id']]);

    // Analytics
    foreach ($participants as $p) {
        analytics_track('heist_complete', (int) $p['user_id'], [
            'heist_id' => $heist['id'],
            'instance_id' => $instanceId,
            'money' => $shareMoney,
            'xp' => $shareXp,
        ]);
    }

    // Notify
    foreach ($participants as $p) {
        notify((int) $p['user_id'], "Heist complete! Your share: " . money($shareMoney) . " + " . number_format($shareXp) . " XP", 'heists.php');
    }

    return ['ok' => true, 'share_money' => $shareMoney, 'share_xp' => $shareXp, 'share_points' => $sharePoints];
}

/**
 * Fail heist
 */
function heist_fail(int $instanceId, int $userId): array
{
    $inst = heist_get_instance($instanceId);
    if (!$inst) return ['ok' => false, 'error' => 'Instance not found'];
    if ((int) $inst['leader_id'] !== $userId) return ['ok' => false, 'error' => 'Only leader can fail'];

    q('UPDATE heist_instances SET status = \'failed\' WHERE id = ?', [$instanceId]);

    // Notify
    $participants = fetch_all('SELECT user_id FROM heist_participants WHERE instance_id = ?', [$instanceId]);
    foreach ($participants as $p) {
        notify((int) $p['user_id'], 'Heist failed. Better luck next time.', 'heists.php');
    }

    return ['ok' => true];
}

/**
 * Get heist history for crew
 */
function heist_get_crew_history(int $crewId, int $limit = 20): array
{
    return fetch_all('
        SELECT hi.*, h.name, h.code
        FROM heist_instances hi
        JOIN heists h ON h.id = hi.heist_id
        WHERE hi.crew_id = ?
        ORDER BY hi.created_at DESC
        LIMIT ?
    ', [$crewId, $limit]);
}

/**
 * Get user's heist history
 */
function heist_get_user_history(int $userId, int $limit = 20): array
{
    return fetch_all('
        SELECT hi.*, h.name, h.code, hp.money_received, hp.xp_received, hp.points_received
        FROM heist_instances hi
        JOIN heists h ON h.id = hi.heist_id
        JOIN heist_participants hp ON hp.instance_id = hi.id
        WHERE hp.user_id = ?
        ORDER BY hi.created_at DESC
        LIMIT ?
    ', [$userId, $limit]);
}

/**
 * Check if user has pending heist invite (for notifications)
 */
function heist_has_active(int $userId): bool
{
    return (bool) fetch_one('
        SELECT 1 FROM heist_instances hi
        JOIN heist_participants hp ON hp.instance_id = hi.id
        WHERE hp.user_id = ? AND hi.status IN (\'planning\',\'active\')
    ', [$userId], 0);
}

/**
 * Get heist phases for display
 */
function heist_get_phases(array $heist): array
{
    return json_decode($heist['phases'] ?? '[]', true);
}