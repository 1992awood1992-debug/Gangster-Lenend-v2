<?php
/**
 * Migration 27: Drop plaintext twofa_backup_codes column
 */
q("SET @s = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'twofa_backup_codes') > 0,
    'ALTER TABLE users DROP COLUMN twofa_backup_codes',
    'SELECT 1'
)); PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;");
