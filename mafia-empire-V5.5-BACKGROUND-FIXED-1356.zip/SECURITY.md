# Security Policy

## Implemented Security Measures

- **SQL Injection Protection**: All queries use PDO prepared statements
- **CSRF Protection**: CSRF tokens on all POST forms
- **Password Security**: `password_hash()` with PHP's default algorithm
- **Session Security**: `session_regenerate_id(true)` on login, secure cookie settings
- **Rate Limiting**: Auth endpoints rate-limited (5 attempts / 15 min per IP)
- **Input Validation**: Server-side validation on all user inputs
- **XSS Protection**: Output escaped with `htmlspecialchars()` via `e()` helper
- **Security Headers**: CSP, X-Content-Type-Options, X-Frame-Options, etc. in Apache/nginx
- **Rate Limits Table**: Tracks auth attempts with IP-based limiting
- **Enhanced Password Requirements**: 8+ chars with uppercase, lowercase, number, special char
- **Safe Redirects**: Prevents open redirect vulnerabilities
- **API Key Security**: Hashed API keys with per-key rate limits and scopes

## Security Best Practices

1. Never commit `.env` files
2. Use strong passwords in production
3. Keep PHP and dependencies updated
4. Enable HTTPS in production (secure cookies)
5. Regularly review logs for suspicious activity
6. Backup database regularly
7. Limit admin access
8. Monitor rate limit violations

## Reporting Vulnerabilities

If you discover a security vulnerability, please report it responsibly. Do not disclose it publicly until it's been addressed.

## Tools & Checks

Run tests to verify security basics. The codebase follows OWASP guidelines for web application security.
