<?php
/**
 * Mafia Empire - REST API bootstrap & helpers (v1).
 *
 * The API is stateless: callers authenticate with a key issued on the
 * "API Access" page (api_access.php). Keys look like `me_ab12cd34.<secret>`
 * and are stored only as a SHA-256 hash.
 *
 *   Authorization: Bearer <key>      or      X-API-Key: <key>
 *
 * This file is included by the front controller (api/index.php) and by tests.
 * It must never assume a browser session.
 */
define('API_MODE', true);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/webhooks.php';

/* ----------------------------- Output ----------------------------- */

/** Send a JSON response and stop. Records the status for the request log. */
function api_send(int $status, array $body, array $headers = []): void
{
    $GLOBALS['__api_status'] = $status;
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');
        foreach ($headers as $k => $v) {
            header($k . ': ' . $v);
        }
    }
    echo json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/** 2xx success envelope. */
function api_ok($data, array $meta = [], array $headers = []): void
{
    $body = ['ok' => true, 'data' => $data];
    if ($meta) {
        $body['meta'] = $meta;
    }
    api_send(200, $body, $headers);
}

function api_default_code(int $status): string
{
    return [
        400 => 'bad_request', 401 => 'unauthorized', 403 => 'forbidden',
        404 => 'not_found', 405 => 'method_not_allowed', 409 => 'conflict',
        419 => 'csrf', 429 => 'rate_limited', 500 => 'server_error',
        503 => 'unavailable',
    ][$status] ?? 'error';
}

/** Error envelope. */
function api_fail(int $status, string $message, string $code = '', array $extra = []): void
{
    $error = array_merge([
        'status'  => $status,
        'code'    => $code !== '' ? $code : api_default_code($status),
        'message' => $message,
    ], $extra);
    api_send($status, ['ok' => false, 'error' => $error]);
}

/** Permissive CORS: keys travel in headers, not cookies, so * is safe. */
function api_cors(): void
{
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-API-Key, Authorization');
    header('Access-Control-Max-Age: 600');
}

/** Register the shutdown logger that records api_requests. */
function api_register_logging(): void
{
    if (!API_REQUEST_LOG) {
        return;
    }
    register_shutdown_function(function () {
        $status = (int) ($GLOBALS['__api_status'] ?? 0);
        if ($status === 0) {
            return; // nothing handled this request
        }
        try {
            api_log_request($GLOBALS['__api_key'] ?? null, $_SERVER['REQUEST_METHOD'] ?? 'GET', $_SERVER['REQUEST_URI'] ?? '', $status);
        } catch (Throwable $e) {
            // logging must never break a response
        }
    });
}

function api_log_request(?array $key, string $method, string $path, int $status): void
{
    if (!API_REQUEST_LOG) {
        return;
    }
    insert('api_requests', [
        'key_id'     => $key ? (int) $key['id'] : null,
        'user_id'    => $key ? (int) $key['user_id'] : null,
        'method'     => substr($method, 0, 8),
        'path'       => substr($path, 0, 190),
        'status'     => $status,
        'ip'         => api_ip(),
        'created_at' => now(),
    ]);
}

function api_ip(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}

/** Parsed JSON body (or form body as a fallback). */
function api_input(): array
{
    static $in = null;
    if ($in !== null) {
        return $in;
    }
    $in = [];
    $ctype = (string) ($_SERVER['CONTENT_TYPE'] ?? '');
    if (stripos($ctype, 'application/json') !== false) {
        $decoded = json_decode((string) file_get_contents('php://input'), true);
        if (is_array($decoded)) {
            $in = $decoded;
        }
    } else {
        $in = $_POST;
    }
    return $in;
}

/* ----------------------------- Routing ----------------------------- */

/** Split the request into path segments, however the route was presented. */
function api_segments(): array
{
    $route = (string) ($_GET['route'] ?? '');
    if ($route === '') {
        $path = (string) ($_SERVER['PATH_INFO'] ?? '');
        if ($path === '') {
            $uri = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
            $pos = strpos($uri, '/api');
            if ($pos !== false) {
                $path = substr($uri, $pos + 4);
            }
        }
        $route = $path;
    }
    $route = trim($route, '/');
    $parts = $route === '' ? [] : explode('/', $route);
    if (($parts[0] ?? '') === 'index.php') {
        array_shift($parts);
    }
    return array_values(array_filter($parts, fn($p) => $p !== ''));
}

/* ----------------------------- API keys ----------------------------- */

/** Generate a fresh key: [plain, prefix, hash]. */
function api_generate_key(): array
{
    $prefix = API_KEY_PREFIX . bin2hex(random_bytes(4)); // e.g. me_1a2b3c4d
    $secret = bin2hex(random_bytes(24));                 // 48 hex chars
    $plain  = $prefix . '.' . $secret;
    return ['plain' => $plain, 'prefix' => $prefix, 'hash' => hash('sha256', $plain)];
}

/**
 * Create and store a key. Returns id + the plaintext (shown once).
 *
 * @param string[] $scopes
 */
function api_key_create(int $userId, string $name, array $scopes, int $rateLimit = API_DEFAULT_RATE_LIMIT): array
{
    $allowed = ['read', 'write', 'admin'];
    $scopes  = array_values(array_intersect($allowed, $scopes));
    if (!$scopes) {
        $scopes = ['read'];
    }
    $rateLimit = max(1, min(API_MAX_RATE_LIMIT, $rateLimit));

    $generated = api_generate_key();
    $id = insert('api_keys', [
        'user_id'    => $userId,
        'name'       => mb_substr(trim($name) !== '' ? trim($name) : 'API key', 0, 60),
        'prefix'     => $generated['prefix'],
        'key_hash'   => $generated['hash'],
        'scopes'     => implode(',', $scopes),
        'rate_limit' => $rateLimit,
        'created_at' => now(),
    ]);

    return ['id' => $id, 'plain' => $generated['plain'], 'prefix' => $generated['prefix'], 'scopes' => $scopes, 'rate_limit' => $rateLimit];
}

/** The key presented by the caller (header form), or ''. */
function api_presented_key(): string
{
    $key = (string) ($_SERVER['HTTP_X_API_KEY'] ?? '');
    if ($key === '') {
        $auth = (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? '');
        if (stripos($auth, 'Bearer ') === 0) {
            $key = substr($auth, 7);
        }
    }
    return trim($key);
}

/** Look up a presented key. Sends 401 and exits when invalid. */
function api_authenticate(): array
{
    $plain = api_presented_key();
    if ($plain === '') {
        api_fail(401, 'API key required. Send it as "X-API-Key: <key>".', 'missing_key');
    }
    $dot = strpos($plain, '.');
    if ($dot === false) {
        api_fail(401, 'Malformed API key.', 'bad_key');
    }
    $prefix = substr($plain, 0, $dot);
    $row = fetch('SELECT * FROM api_keys WHERE prefix = ?', [$prefix]);
    if (!$row || $row['revoked_at'] !== null) {
        api_fail(401, 'Invalid or revoked API key.', 'bad_key');
    }
    if (!hash_equals((string) $row['key_hash'], hash('sha256', $plain))) {
        api_fail(401, 'Invalid API key.', 'bad_key');
    }
    $GLOBALS['__api_key'] = $row;
    return $row;
}

/** The account behind a key. Sends 401/403 and exits when unusable. */
function api_key_user(array $key): array
{
    $u = fetch('SELECT * FROM users WHERE id = ?', [(int) $key['user_id']]);
    if (!$u) {
        api_fail(401, 'The account for this key no longer exists.', 'bad_key');
    }
    if ((int) $u['is_banned'] === 1) {
        api_fail(403, 'This account is banned.', 'banned');
    }
    return $u;
}

/** @return string[] */
function api_key_scopes(array $key): array
{
    if ((string) $key['scopes'] === '*') {
        return ['*'];
    }
    return array_values(array_filter(array_map('trim', explode(',', (string) $key['scopes']))));
}

/** Ensure the key carries a scope (write implies read). Exits with 403 otherwise. */
function api_require_scope(array $key, string $scope): void
{
    $have = api_key_scopes($key);
    if (in_array('*', $have, true) || in_array($scope, $have, true)) {
        return;
    }
    if ($scope === 'read' && in_array('write', $have, true)) {
        return;
    }
    api_fail(403, 'This API key lacks the "' . $scope . '" scope.', 'insufficient_scope');
}

/** Enforce the per-key, per-minute limit. Exits with 429 when exceeded. */
function api_rate_limit(array $key): void
{
    $limit  = max(1, (int) $key['rate_limit']);
    $window = (int) (floor(time() / 60) * 60);
    $row    = fetch('SELECT window_start, hits FROM api_rate WHERE key_id = ?', [(int) $key['id']]);

    if (!$row || (int) $row['window_start'] !== $window) {
        q('INSERT INTO api_rate (key_id, window_start, hits) VALUES (?, ?, 1)
           ON DUPLICATE KEY UPDATE window_start = VALUES(window_start), hits = 1',
            [(int) $key['id'], $window]);
        $hits = 1;
    } else {
        q('UPDATE api_rate SET hits = hits + 1 WHERE key_id = ?', [(int) $key['id']]);
        $hits = (int) $row['hits'] + 1;
    }

    $remaining = max(0, $limit - $hits);
    $reset     = $window + 60;
    if (!headers_sent()) {
        header('X-RateLimit-Limit: ' . $limit);
        header('X-RateLimit-Remaining: ' . $remaining);
        header('X-RateLimit-Reset: ' . $reset);
    }
    if ($hits > $limit) {
        if (!headers_sent()) {
            header('Retry-After: ' . max(1, $reset - time()));
        }
        api_fail(429, 'Rate limit exceeded (' . $limit . '/min). Try again in ' . max(1, $reset - time()) . ' seconds.', 'rate_limited');
    }
}

/** Record key usage. */
function api_touch_key(array $key): void
{
    q('UPDATE api_keys SET last_used_at = ?, request_count = request_count + 1 WHERE id = ?', [now(), (int) $key['id']]);
}

/* ----------------------------- Payloads ----------------------------- */

/** The caller's own profile (read scope). */
function api_player_payload(array $u): array
{
    return [
        'id'           => (int) $u['id'],
        'username'     => (string) $u['username'],
        'level'        => (int) $u['level'],
        'xp'           => (int) $u['xp'],
        'rank'         => rank_for_level((int) $u['level'])['name'] ?? null,
        'money'        => (int) $u['money'],
        'bank'         => (int) $u['bank'],
        'points'       => (int) $u['points'],
        'bullets'      => (int) $u['bullets'],
        'energy'       => (int) $u['energy'],
        'energy_max'   => (int) $u['energy_max'],
        'nerve'        => (int) $u['nerve'],
        'nerve_max'    => (int) $u['nerve_max'],
        'health'       => (int) $u['health'],
        'health_max'   => (int) $u['health_max'],
        'strength'     => (int) $u['strength'],
        'speed'        => (int) $u['speed'],
        'defense'      => (int) $u['defense'],
        'iq'           => (int) $u['iq'],
        'kills'        => (int) $u['kills'],
        'deaths'       => (int) $u['deaths'],
        'wins'         => (int) $u['wins'],
        'losses'       => (int) $u['losses'],
        'crew_id'      => $u['crew_id'] !== null ? (int) $u['crew_id'] : null,
        'hospitalized' => is_hospitalized($u),
        'created_at'   => $u['created_at'] ?? null,
    ];
}

/** A limited public profile. */
function api_public_player_payload(array $u): array
{
    return [
        'id'       => (int) $u['id'],
        'username' => (string) $u['username'],
        'level'    => (int) $u['level'],
        'kills'    => (int) $u['kills'],
        'deaths'   => (int) $u['deaths'],
        'crew_id'  => $u['crew_id'] !== null ? (int) $u['crew_id'] : null,
        'strength' => (int) $u['strength'],
        'speed'    => (int) $u['speed'],
        'defense'  => (int) $u['defense'],
        'iq'       => (int) $u['iq'],
    ];
}
