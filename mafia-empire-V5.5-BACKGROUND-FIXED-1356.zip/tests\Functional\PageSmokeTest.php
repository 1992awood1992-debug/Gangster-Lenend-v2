<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Functional;

use MafiaEmpire\Tests\Support\Http;
use MafiaEmpire\Tests\Support\TestCase;

/**
 * Page-load smoke test: every user-facing top-level page must render without a
 * PHP error and must run to completion.
 *
 * This is the regression net for the class of bug where a page references a
 * column/helper that does not exist and throws a PDOException at runtime (the
 * social pages used to do exactly this). Static linting cannot catch it — only
 * actually requesting the page can.
 *
 * Two independent signals are checked, so the test still works when
 * display_errors is off:
 *   1. the response body contains no PHP error markers, and
 *   2. every page that uses the shared footer closes its HTML document.
 *
 * Skipped unless APP_URL points at a running instance (see the functional
 * suite docs).
 */
final class PageSmokeTest extends TestCase
{
    /**
     * Non-page endpoints excluded from the sweep:
     *   config.php  - a config include, not a page
     *   logout.php  - ends the session we need for the rest of the sweep
     *   push.php    - JSON endpoint that answers 405 to a GET (tested elsewhere)
     *   admin.php   - admin-only; covered by testAdminTabsRenderWithoutErrors()
     */
    private const EXCLUDED = ['config.php', 'logout.php', 'push.php', 'admin.php'];

    /** PHP error/notice text that must never appear in a rendered page. */
    private const ERROR_MARKERS = '/Fatal error|Parse error|Uncaught|Warning:|Notice:|Deprecated:|SQLSTATE\[/';

    /** Reasonable player state so level/limit-gated pages render their full UI. */
    private const PLAYER_STATE = [
        'level'   => 10,
        'money'   => 50000,
        'bank'    => 10000,
        'bullets' => 500,
        'energy'  => 100,
        'nerve'   => 50,
        'points'  => 100,
    ];

    /** Admin tabs rendered by admin.php (keys of its $tabs array). */
    private const ADMIN_TABS = [
        'dashboard', 'users', 'settings', 'missions', 'items', 'bosses', 'jobs',
        'drugs', 'abilities', 'gyms', 'districts', 'points_store', 'achievements',
        'stickers', 'factories', 'lottery', 'economy', 'tickets', 'suggestions',
        'logs', 'analytics',
    ];

    private function requireServer(): void
    {
        if (!Http::configured()) {
            $this->markTestSkipped('Set APP_URL to a running instance to run the functional suite.');
        }
    }

    private function http(): Http
    {
        return new Http(Http::baseUrl());
    }

    /** @return list<string> top-level page filenames, minus the exclusions */
    private function pages(): array
    {
        $root = dirname(__DIR__, 2);
        $pages = [];
        foreach (glob($root . '/*.php') ?: [] as $file) {
            $name = basename($file);
            if (in_array($name, self::EXCLUDED, true)) {
                continue;
            }
            $pages[] = $name;
        }
        sort($pages);
        return $pages;
    }

    /** True when the page includes the shared footer (so it must close </html>). */
    private function usesFooter(string $page): bool
    {
        $source = @file_get_contents(dirname(__DIR__, 2) . '/' . $page);
        return $source !== false && str_contains($source, 'footer.php');
    }

    private function assertNoErrors(string $page, string $body): void
    {
        if (preg_match(self::ERROR_MARKERS, $body, $m) === 1) {
            $snippet = trim((string) preg_replace('/\s+/', ' ', substr($body, max(0, (int) strpos($body, $m[0]) - 40), 220)));
            $this->fail("PHP error on {$page}: {$snippet}");
        }
    }

    public function testEveryPageRendersWithoutErrors(): void
    {
        $this->requireServer();
        $user = $this->makeUser(self::PLAYER_STATE);
        $http = $this->http();
        $http->login($user['username'], 'testing123');

        foreach ($this->pages() as $page) {
            [$status, $body] = $http->get('/' . $page);

            $this->assertSame(200, $status, "{$page} should return HTTP 200");
            $this->assertNoErrors($page, $body);

            if ($this->usesFooter($page)) {
                $this->assertStringContainsString(
                    '</html>',
                    $body,
                    "{$page} did not render to completion (missing </html>)"
                );
            }
        }
    }

    public function testAdminTabsRenderWithoutErrors(): void
    {
        $this->requireServer();
        $admin = $this->makeUser(['is_admin' => 1]);
        $http = $this->http();
        $http->login($admin['username'], 'testing123');

        foreach (self::ADMIN_TABS as $tab) {
            [$status, $body] = $http->get('/admin.php?a=' . $tab);

            $this->assertSame(200, $status, "admin tab {$tab} should return HTTP 200");
            $this->assertStringContainsString('Admin Panel', $body, "admin tab {$tab} did not render the panel");
            $this->assertNoErrors("admin.php?a={$tab}", $body);
            $this->assertStringContainsString('</html>', $body, "admin tab {$tab} did not render to completion");
        }
    }

    public function testPublicPagesRenderWithoutErrors(): void
    {
        $this->requireServer();
        $http = $this->http();

        foreach (['index.php', 'login.php', 'register.php', 'help.php', 'install.php'] as $page) {
            [$status, $body] = $http->get('/' . $page);
            $this->assertSame(200, $status, "{$page} should be reachable while logged out");
            $this->assertNoErrors($page, $body);
        }

        [$status, $body] = $http->get('/health.php');
        $this->assertSame(200, $status);
        $this->assertIsArray(json_decode($body, true), 'health.php should return JSON');
    }
}
