<?php
ob_start();

require 'C:/Users/ash/Documents/Default Project/mafia-empire/config.php';
require 'C:/Users/ash/Documents/Default Project/mafia-empire/includes/db.php';

// Mimic exact init.php flow
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/game.php';
require_once __DIR__ . '/includes/migrate.php';
require_once __DIR__ . '/includes/webhooks.php';
require_once __DIR__ . '/includes/discord.php';
require_once __DIR__ . '/includes/push.php';
require_once __DIR__ . '/includes/cache.php';
require_once __DIR__ . '/includes/analytics.php';
require_once __DIR__ . '/includes/login_rewards.php';
require_once __DIR__ . '/includes/crafting.php';
require_once __DIR__ . '/includes/heists.php';
require_once __DIR__ . '/includes/tournaments.php';
require_once __DIR__ . '/includes/properties.php';
require_once __DIR__ . '/includes/racing.php';
require_once __DIR__ . '/includes/market.php';
require_once __DIR__ . '/includes/politics.php';
require_once __DIR__ . '/includes/social.php';
require_once __DIR__ . '/includes/graphql.php';
require_once __DIR__ . '/includes/logging.php';
require_once __DIR__ . '/includes/admin_tools.php';

echo "After all includes:\n";
echo "Output buffer length: " . ob_get_length() . "\n";
$output = ob_get_contents();
if ($output) {
    echo "OUTPUT DETECTED (" . strlen($output) . " bytes):\n";
    echo $output;
} else {
    echo "No output\n";
}
ob_end_clean();

echo "\nCalling init_secure_session()...\n";
require_once __DIR__ . '/includes/security.php';

echo "\nAfter init_secure_session:\n";
echo "Session status: " . session_status() . "\n";
echo "Session ID: " . session_id() . "\n";