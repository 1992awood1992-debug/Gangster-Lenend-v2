  </main>
</div>

<?php $__of = basename($_SERVER['SCRIPT_NAME'] ?? ''); ?>
<?php if (function_exists('is_logged_in') && is_logged_in()): ?>
<nav class="mobile-nav" aria-label="Quick navigation">
  <a href="<?= e(url('play.php')) ?>" class="<?= $__of === 'play.php' ? 'active' : '' ?>"><span class="mn-ico">&#9654;</span>Play</a>
  <a href="<?= e(url('missions.php')) ?>" class="<?= $__of === 'missions.php' ? 'active' : '' ?>"><span class="mn-ico">&#9670;</span>Missions</a>
  <a href="<?= e(url('kill.php')) ?>" class="<?= $__of === 'kill.php' ? 'active' : '' ?>"><span class="mn-ico">&#9876;</span>Kill</a>
  <a href="<?= e(url('casino.php')) ?>" class="<?= in_array($__of, ['casino.php', 'blackjack.php', 'baccarat.php', 'keno.php', 'crash.php', 'dice.php', 'slots.php'], true) ? 'active' : '' ?>"><span class="mn-ico">&#9824;</span>Casino</a>
  <a href="<?= e(url('money.php')) ?>" class="<?= $__of === 'money.php' ? 'active' : '' ?>"><span class="mn-ico">&#36;</span>Money</a>
</nav>
<?php endif; ?>

<footer class="footer">
  <div class="footer-cols">
    <div class="footer-col">
      <span class="footer-h">&#9647; <?= e(SITE_NAME) ?></span>
      <p class="muted small"><?= e(__('footer.tagline', [], 'en')) ?></p>
    </div>
    <div class="footer-col">
      <span class="footer-h"><?= e(__('footer.the_game', [], 'en')) ?></span>
      <nav>
        <a href="<?= e(url('play.php')) ?>"><?= e(__('nav.play', [], 'en')) ?></a>
        <a href="<?= e(url('missions.php')) ?>"><?= e(__('nav.missions', [], 'en')) ?></a>
        <a href="<?= e(url('empire.php')) ?>"><?= e(__('nav.empire', [], 'en')) ?></a>
        <a href="<?= e(url('casino.php')) ?>"><?= e(__('nav.casino', [], 'en')) ?></a>
        <a href="<?= e(url('daily_rewards.php')) ?>"><?= e(__('nav.daily_rewards', [], 'en')) ?></a>
        <a href="<?= e(url('crafting.php')) ?>"><?= e(__('nav.crafting', [], 'en')) ?></a>
        <a href="<?= e(url('heists.php')) ?>"><?= e(__('nav.heists', [], 'en')) ?></a>
        <a href="<?= e(url('tournaments.php')) ?>"><?= e(__('nav.tournaments', [], 'en')) ?></a>
        <a href="<?= e(url('properties.php')) ?>"><?= e(__('nav.properties', [], 'en')) ?></a>
        <a href="<?= e(url('racing.php')) ?>"><?= e(__('nav.racing', [], 'en')) ?></a>
        <a href="<?= e(url('market.php')) ?>"><?= e(__('nav.marketplace', [], 'en')) ?></a>
        <a href="<?= e(url('politics.php')) ?>"><?= e(__('nav.city_hall', [], 'en')) ?></a>
      </nav>
    </div>
    <div class="footer-col">
      <span class="footer-h"><?= e(__('footer.the_family', [], 'en')) ?></span>
      <nav>
        <a href="<?= e(url('crew.php')) ?>"><?= e(__('nav.crew', [], 'en')) ?></a>
        <a href="<?= e(url('people.php')) ?>"><?= e(__('nav.residents', [], 'en')) ?></a>
        <a href="<?= e(url('forum.php')) ?>"><?= e(__('nav.speakeasy', [], 'en')) ?></a>
        <a href="<?= e(url('leaderboards.php')) ?>"><?= e(__('nav.rankings', [], 'en')) ?></a>
      </nav>
    </div>
    <div class="footer-col">
      <span class="footer-h"><?= e(__('footer.support', [], 'en')) ?></span>
      <nav>
        <a href="<?= e(url('info.php')) ?>"><?= e(__('nav.info', [], 'en')) ?></a>
        <a href="<?= e(url('help.php')) ?>"><?= e(__('nav.help', [], 'en')) ?></a>
        <a href="<?= e(url('support.php')) ?>"><?= e(__('nav.support', [], 'en')) ?></a>
        <a href="<?= e(url('updates.php')) ?>"><?= e(__('nav.updates', [], 'en')) ?></a>
      </nav>
    </div>
  </div>
  <div class="footer-base">
    <span>&#9647; &copy; <?= date('Y') ?> <?= e(SITE_NAME) ?>. <?= e(__('footer.rights', [], 'en')) ?> &#9647;</span>
    <span class="muted small"><?= e(__('footer.bootleg', [], 'en')) ?></span>
    <form method="post" action="<?= e(url('set_language.php')) ?>" class="lang-switch">
      <?= csrf_field() ?>
      <label class="sr-only" for="langSelect"><?= e(__('footer.language', [], 'en')) ?></label>
      <select id="langSelect" name="locale" onchange="this.form.submit()">
        <?php foreach (i18n_get_languages() as $lc => $l): ?>
          <option value="<?= e($lc) ?>"<?= $lc === i18n_get_locale() ? ' selected' : '' ?>><?= e($l['flag']) ?> <?= e($l['native']) ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>
</footer>

<button class="to-top" id="toTop" type="button" aria-label="Back to top" title="Back to top">&#9650;</button>
<script src="<?= e(url('assets/app.js?v=' . @filemtime(__DIR__ . '/../assets/app.js'))) ?>"></script>
</body>
</html>
