# Testing

Mafia Empire ships with a [PHPUnit](https://phpunit.de/) suite covering the
game engine, economy, combat, crews/territory, and the public HTTP surface.

## Requirements

- PHP 8.1+ with `pdo_mysql` and `mbstring`
- A running MySQL/MariaDB server
- [Composer](https://getcomposer.org/) (for the test dependencies)

The suite **never touches your live database**: the bootstrap only runs against
a database whose name ends in `_test` and refuses to start otherwise.

## Setup

```bash
composer install
```

This installs PHPUnit into `vendor/`. (The project itself has no runtime
Composer dependencies — the game is plain PHP.)

## Running the suite

```bash
# Everything (unit + integration; functional tests are skipped)
composer test
# or
vendor/bin/phpunit

# A single suite
vendor/bin/phpunit --testsuite Unit
vendor/bin/phpunit --testsuite Integration
vendor/bin/phpunit --testsuite Functional

# With a coverage report (needs pcov or xdebug)
vendor/bin/phpunit --coverage-text
```

On Windows without Composer you can run the PHAR directly:

```powershell
php phpunit.phar --configuration phpunit.xml
```

### Database configuration

The bootstrap reads the usual `DB_*` environment variables and defaults to a
local root/no-password MySQL, using the database `mafia_empire_test`:

| Variable  | Default            |
|-----------|--------------------|
| `DB_HOST` | `127.0.0.1`        |
| `DB_PORT` | `3306`             |
| `DB_USER` | `root`             |
| `DB_PASS` | *(empty)*          |
| `DB_NAME` | `mafia_empire_test`|

At startup it drops and recreates that database, loads `sql/schema.sql`, seeds
the game content (`includes/seed.php`), and applies migrations — so every run is
deterministic. Each test then wipes the player-generated tables while keeping
the seeded content.

## Suites

| Suite         | What it covers                                                                 |
|---------------|--------------------------------------------------------------------------------|
| `Unit`        | Pure functions: XP/level maths, crew/territory maths, card parsing, formatting |
| `Integration` | Database-backed rules: economy, regeneration/cooldowns, combat, PK rewards, crew wars, clock alignment |
| `Functional`  | End-to-end HTTP flows (login, criminal job, mission, casino dice) + the `health.php` contract |

### Functional tests

The `Functional` suite drives a **running** instance over HTTP. It is skipped
unless `APP_URL` is set:

```bash
# Terminal 1 — serve the app against the test database
DB_NAME=mafia_empire_test php -S 127.0.0.1:8000

# Terminal 2
APP_URL=http://127.0.0.1:8000 vendor/bin/phpunit --testsuite Functional
```

On Windows:

```powershell
$env:DB_NAME='mafia_empire_test'
php -S 127.0.0.1:8000    # Terminal 1
$env:APP_URL='http://127.0.0.1:8000'
php phpunit.phar --testsuite Functional    # Terminal 2
```

> The server must use the **same** `mafia_empire_test` database as the test
> process, so the tests can verify the effects of the HTTP actions.

## Continuous integration

`.github/workflows/ci.yml` runs three jobs:

1. **lint** — `php -l` over every file.
2. **smoke** — loads the schema into a MariaDB service and hits `health.php`.
3. **tests** — installs Composer deps, starts the built-in server, and runs the
   full PHPUnit suite (functional tests included) against a MariaDB service,
   printing a coverage summary.

## Adding tests

- Put pure-function tests in `tests/Unit` (extend `PHPUnit\Framework\TestCase`).
- Put database-backed tests in `tests/Integration` (extend
  `MafiaEmpire\Tests\Support\TestCase`, which provides `makeUser()`,
  `makeCrew()`, `joinCrew()`, `freshUser()`, and per-test cleanup).
- Put HTTP-level flows in `tests/Functional` (use `MafiaEmpire\Tests\Support\Http`
  and skip when `APP_URL` is unset).

The fallback autoloader in `tests/bootstrap.php` maps the `MafiaEmpire\Tests\`
namespace to `tests/`, so the suite runs with or without Composer.
