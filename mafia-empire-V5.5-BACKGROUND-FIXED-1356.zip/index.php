<?php
require_once __DIR__ . '/includes/init.php';
$page_title = 'Home';
require __DIR__ . '/includes/header.php';

$latest = fetch_all('SELECT u.*, p.username FROM updates u JOIN users p ON p.id = u.user_id ORDER BY u.created_at DESC LIMIT 3');
$top = fetch_all('SELECT username, level, kills, money FROM users ORDER BY level DESC, xp DESC LIMIT 5');

if ($u):
  $rank = rank_for_level((int) $u['level']);
  $district = fetch('SELECT * FROM districts WHERE id = ?', [$u['district_id']]);
?>
<div class="card">
  <div class="panel-heading">Welcome back, <?= e($u['username']) ?></div>
  <div class="grid grid-3">
    <div>
      <div class="stat"><span>Rank</span><b><?= e($rank['name']) ?></b></div>
      <div class="stat"><span>Level</span><b><?= (int) $u['level'] ?></b></div>
      <div class="stat"><span>District</span><b><?= e($district['name'] ?? 'Downtown') ?></b></div>
    </div>
    <div>
      <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
      <div class="stat"><span>Bank</span><b><?= money($u['bank']) ?></b></div>
      <div class="stat"><span>Bullets</span><b><?= number_format((int) $u['bullets']) ?></b></div>
    </div>
    <div>
      <div class="stat"><span>Kills</span><b><?= (int) $u['kills'] ?></b></div>
      <div class="stat"><span>Missions</span><b><?= (int) $u['missions_done'] ?></b></div>
      <div class="stat"><span>Points</span><b><?= number_format((int) $u['points']) ?></b></div>
    </div>
  </div>
  <p style="margin-top:14px"><a class="btn btn-gold" href="<?= e(url('play.php')) ?>">Enter the City</a></p>
</div>
<?php else: ?>
<div class="card" style="text-align:center;padding:40px 20px;">
  <h1 style="font-size:2.4rem;color:var(--gold)">Rule the City. Build an Empire.</h1>
  <p class="muted" style="max-width:560px;margin:10px auto 22px;">
    Run missions, rob the bank, dominate the black market, gamble in the casino and climb from street associate to Syndicate Legend.
  </p>
  <p><a class="btn btn-gold" href="<?= e(url('register.php')) ?>">Create your character</a>
     <a class="btn btn-ghost" href="<?= e(url('login.php')) ?>">Log in</a></p>
</div>
<?php endif; ?>

<h2>Life in the City</h2>
<div class="grid grid-3">
  <?php
  $tiles = [
      ['Missions', 'Earn cash and XP', 'missions.php', '&#128373;'],
      ['Criminal Jobs', 'Spend nerve, take risk', 'criminal_jobs.php', '&#128274;'],
      ['The Gym', 'Train your stats', 'gym.php', '&#127947;'],
      ['Bosses', 'Fight the city elite', 'bosses.php', '&#128128;'],
      ['Casino', 'Test your luck', 'casino.php', '&#127920;'],
      ['Black Market', 'Buy and sell gear', 'black-market.php', '&#127982;'],
  ];
  foreach ($tiles as $t): ?>
    <a class="tile" href="<?= e(url($t[2])) ?>"><span class="ico"><?= $t[3] ?></span><b><?= e($t[0]) ?></b><small><?= e($t[1]) ?></small></a>
  <?php endforeach; ?>
</div>

<div class="grid grid-2" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Latest Updates</div>
    <?php if (!$latest): ?><p class="muted">No updates posted yet.</p><?php endif; ?>
    <?php foreach ($latest as $up): ?>
      <div style="margin-bottom:12px">
        <b><?= e($up['title']) ?></b>
        <div class="muted small">by <?= e($up['username']) ?> &middot; <?= date('M j, Y', strtotime($up['created_at'])) ?></div>
      </div>
    <?php endforeach; ?>
    <a href="<?= e(url('updates.php')) ?>">Read all updates &raquo;</a>
  </div>
  <div class="card">
    <div class="panel-heading">Most Feared</div>
    <div class="table-wrap"><table>
      <tr><th>#</th><th>Player</th><th>Level</th><th>Kills</th></tr>
      <?php foreach ($top as $i => $p): ?>
        <tr><td><?= $i + 1 ?></td><td><?= e($p['username']) ?></td><td><?= (int) $p['level'] ?></td><td><?= (int) $p['kills'] ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$top): ?><tr><td colspan="4" class="muted">No players yet.</td></tr><?php endif; ?>
    </table></div>
    <p style="margin-top:10px"><a href="<?= e(url('leaderboards.php')) ?>">Full leaderboards &raquo;</a></p>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
