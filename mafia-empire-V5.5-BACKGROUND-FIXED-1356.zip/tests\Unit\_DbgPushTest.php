<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

final class _DbgPushTest extends TestCase
{
    public function testDbg(): void
    {
        fwrite(STDERR, "\nPHP_BINARY=" . PHP_BINARY . "\n");
        fwrite(STDERR, 'extensions openssl=' . (extension_loaded('openssl') ? 'yes' : 'no') . "\n");
        fwrite(STDERR, 'candidates=' . json_encode(push_openssl_config_candidates()) . "\n");
        fwrite(STDERR, 'chosen=' . var_export(push_openssl_config(), true) . "\n");

        $k = push_ec_key_new();
        fwrite(STDERR, 'ec_key_new=' . ($k === false ? 'FALSE' : 'ok') . "\n");
        while (($e = openssl_error_string()) !== false) {
            fwrite(STDERR, 'err: ' . $e . "\n");
        }
        $this->assertTrue(true);
    }
}
