<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Crew XP, perks, zone caps and war resolution (Crew Wars & Territory).
 */
final class CrewWarfareTest extends TestCase
{
    public function testAddAndSpendCrewXp(): void
    {
        $leader = $this->makeUser();
        $crew   = $this->makeCrew(['leader_id' => $leader['id']]);

        add_crew_xp((int) $crew['id'], 4500);
        $fresh = $this->freshCrew((int) $crew['id']);
        $this->assertSame(4500, (int) $fresh['xp']);
        $this->assertSame(3, (int) $fresh['level']);

        $this->assertTrue(spend_crew_xp((int) $crew['id'], 500));
        $fresh = $this->freshCrew((int) $crew['id']);
        $this->assertSame(4000, (int) $fresh['xp']);
        $this->assertSame(500, (int) $fresh['xp_spent']);
        $this->assertSame(3, (int) $fresh['level']);

        $this->assertFalse(spend_crew_xp((int) $crew['id'], 999999));
    }

    public function testCrewPerkAndZoneCap(): void
    {
        $this->seedPerk('five_points', 'Five Points');
        $leader = $this->makeUser();
        $crew   = $this->makeCrew(['leader_id' => $leader['id']]);

        $this->assertFalse(crew_has_perk((int) $crew['id'], 'five_points'));
        insert('crew_unlocked_perks', ['crew_id' => $crew['id'], 'perk_code' => 'five_points']);

        $this->assertTrue(crew_has_perk((int) $crew['id'], 'five_points'));
        $this->assertFalse(crew_has_perk((int) $crew['id'], 'row_house'));
        // base 3 + floor(level/2)=2 + perk 1 = 6
        $this->assertSame(6, crew_zone_cap((int) $crew['id'], 4));
    }

    public function testMaxMembersUsesRecruiterPerk(): void
    {
        $this->seedPerk('recruiter', 'Recruiter');
        $leader = $this->makeUser();
        $crew   = $this->makeCrew(['leader_id' => $leader['id']]);

        $this->assertSame(15, crew_max_members((int) $crew['id']));
        insert('crew_unlocked_perks', ['crew_id' => $crew['id'], 'perk_code' => 'recruiter']);
        $this->assertSame(19, crew_max_members((int) $crew['id']));
    }

    public function testWarScoringAndFinishAwardsWinner(): void
    {
        $u1 = $this->makeUser();
        $u2 = $this->makeUser();
        $c1 = $this->makeCrew(['leader_id' => $u1['id']]);
        $c2 = $this->makeCrew(['leader_id' => $u2['id']]);
        $this->joinCrew((int) $u1['id'], (int) $c1['id']);
        $this->joinCrew((int) $u2['id'], (int) $c2['id']);

        q(
            "INSERT INTO crew_wars (attacker_id, defender_id, status, attacker_score, defender_score, ends_at)
             VALUES (?, ?, 'active', 0, 0, NOW() - INTERVAL 60 SECOND)",
            [$c1['id'], $c2['id']]
        );

        score_war_kill((int) $u1['id'], (int) $u2['id']);
        $war = fetch('SELECT * FROM crew_wars ORDER BY id DESC LIMIT 1');
        $this->assertSame(1, (int) $war['attacker_score']);
        $this->assertSame(50, (int) $this->freshCrew((int) $c1['id'])['xp']);

        $this->assertSame(1, finish_expired_wars());

        $war = fetch('SELECT * FROM crew_wars ORDER BY id DESC LIMIT 1');
        $this->assertSame('finished', $war['status']);
        $this->assertSame((int) $c1['id'], (int) $war['winner_id']);

        $this->assertSame(1, (int) $this->freshCrew((int) $c1['id'])['wars_won']);
        $this->assertSame(1, (int) $this->freshCrew((int) $c2['id'])['wars_lost']);
        $this->assertNotEmpty(fetch_all('SELECT * FROM notifications WHERE user_id = ?', [$u1['id']]));
    }

    public function testWarEndsInDrawWhenScoresEqual(): void
    {
        $u1 = $this->makeUser();
        $u2 = $this->makeUser();
        $c1 = $this->makeCrew(['leader_id' => $u1['id']]);
        $c2 = $this->makeCrew(['leader_id' => $u2['id']]);

        q(
            "INSERT INTO crew_wars (attacker_id, defender_id, status, attacker_score, defender_score, ends_at)
             VALUES (?, ?, 'active', 3, 3, NOW() - INTERVAL 60 SECOND)",
            [$c1['id'], $c2['id']]
        );

        $this->assertSame(1, finish_expired_wars());
        $war = fetch('SELECT * FROM crew_wars ORDER BY id DESC LIMIT 1');
        $this->assertSame('finished', $war['status']);
        $this->assertNull($war['winner_id']);
        $this->assertSame(0, (int) $this->freshCrew((int) $c1['id'])['wars_won']);
    }
}
