-- Properties 2.0: Upgradeable Safehouses & Crew Bases ---------------
-- Add new columns to property_types for defense, storage, crew base features

ALTER TABLE property_types
    ADD COLUMN IF NOT EXISTS is_crew_base TINYINT(1) NOT NULL DEFAULT 0 AFTER is_active,
    ADD COLUMN IF NOT EXISTS defense_bonus INT UNSIGNED NOT NULL DEFAULT 0 AFTER income_points_per_hour,
    ADD COLUMN IF NOT EXISTS storage_items INT UNSIGNED NOT NULL DEFAULT 0 AFTER defense_bonus,
    ADD COLUMN IF NOT EXISTS storage_drugs INT UNSIGNED NOT NULL DEFAULT 0 AFTER storage_items,
    ADD COLUMN IF NOT EXISTS storage_bullets INT UNSIGNED NOT NULL DEFAULT 0 AFTER storage_drugs,
    ADD COLUMN IF NOT EXISTS raid_protection INT UNSIGNED NOT NULL DEFAULT 0 AFTER storage_bullets,
    ADD COLUMN IF NOT EXISTS crew_xp_bonus INT UNSIGNED NOT NULL DEFAULT 0 AFTER raid_protection;

-- Add crew_id to user_properties for crew bases
ALTER TABLE user_properties
    ADD COLUMN IF NOT EXISTS crew_id INT UNSIGNED NULL AFTER user_id,
    ADD COLUMN IF NOT EXISTS upgraded_at DATETIME NULL AFTER last_collected_at,
    ADD COLUMN IF NOT EXISTS nickname VARCHAR(100) NULL AFTER upgraded_at;

-- Add indexes
ALTER TABLE user_properties
    ADD INDEX IF NOT EXISTS idx_crew (crew_id),
    ADD INDEX IF NOT EXISTS idx_upgraded (upgraded_at);

-- Add crew vault columns if not exist
ALTER TABLE crews
    ADD COLUMN IF NOT EXISTS vault_bullets BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER vault_money,
    ADD COLUMN IF NOT EXISTS vault_points INT UNSIGNED NOT NULL DEFAULT 0 AFTER vault_bullets,
    ADD COLUMN IF NOT EXISTS xp BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER vault_points;

-- Crew logs table for base activity
CREATE TABLE IF NOT EXISTS crew_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    crew_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    action VARCHAR(50) NOT NULL,
    details TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_crew (crew_id),
    KEY idx_user (user_id),
    KEY idx_action (action),
    KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed crew base property types
INSERT INTO property_types (code, name, description, base_price, max_level, income_money_per_hour, income_bullets_per_hour, income_points_per_hour, storage_items, storage_drugs, storage_bullets, defense_bonus, raid_protection, crew_xp_bonus, upgrade_money_base, upgrade_bullets_base, upgrade_points_base, is_crew_base, is_active) VALUES
('crew_safehouse', 'Crew Safehouse', 'Basic crew hideout. Shared income and storage.', 5000000, 10, 5000, 50, 5, 10, 5, 100, 5, 10, 10, 100000, 100, 10, 1, 1),
('crew_mansion', 'Crew Mansion', 'Luxury crew base. Better income, defense, and XP bonus.', 25000000, 15, 15000, 150, 15, 25, 15, 300, 15, 25, 25, 500000, 500, 50, 1, 1),
('crew_fortress', 'Crew Fortress', 'Impenetrable stronghold. Maximum defense and raid protection.', 100000000, 20, 50000, 500, 50, 50, 30, 500, 50, 50, 100, 2000000, 2000, 200, 1, 1)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Update existing property types with defense/storage defaults
UPDATE property_types SET 
    defense_bonus = CASE 
        WHEN code = 'apartment' THEN 1
        WHEN code = 'house' THEN 3
        WHEN code = 'mansion' THEN 10
        WHEN code = 'penthouse' THEN 20
        WHEN code = 'warehouse' THEN 15
        ELSE 5
    END,
    storage_items = CASE 
        WHEN code = 'apartment' THEN 5
        WHEN code = 'house' THEN 10
        WHEN code = 'mansion' THEN 25
        WHEN code = 'penthouse' THEN 50
        WHEN code = 'warehouse' THEN 100
        ELSE 10
    END,
    storage_drugs = CASE 
        WHEN code = 'apartment' THEN 2
        WHEN code = 'house' THEN 5
        WHEN code = 'mansion' THEN 15
        WHEN code = 'penthouse' THEN 25
        WHEN code = 'warehouse' THEN 50
        ELSE 5
    END,
    storage_bullets = CASE 
        WHEN code = 'apartment' THEN 50
        WHEN code = 'house' THEN 100
        WHEN code = 'mansion' THEN 500
        WHEN code = 'penthouse' THEN 200
        WHEN code = 'warehouse' THEN 1000
        ELSE 100
    END,
    raid_protection = CASE 
        WHEN code = 'apartment' THEN 5
        WHEN code = 'house' THEN 10
        WHEN code = 'mansion' THEN 25
        WHEN code = 'penthouse' THEN 40
        WHEN code = 'warehouse' THEN 30
        ELSE 15
    END
WHERE is_crew_base = 0 OR is_crew_base IS NULL;

-- Bump schema version
UPDATE settings SET v = '21' WHERE k = 'schema_version';