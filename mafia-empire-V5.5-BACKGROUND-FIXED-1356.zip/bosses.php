<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: start, strike
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'start') {
        $bossId = (int) ($_POST['boss_id'] ?? 0);
        $boss = fetch('SELECT * FROM bosses WHERE id = ?', [$bossId]);
        if (!$boss) {
            flash('Boss not found.', 'error');
        } elseif ((int) $u['level'] < (int) $boss['min_level']) {
            flash('Level ' . (int) $boss['min_level'] . ' required.', 'error');
        } elseif ((int) $u['energy'] < (int) $boss['energy_cost']) {
            flash('Not enough energy.', 'error');
        } elseif (is_hospitalized($u)) {
            flash('You are hospitalized.', 'error');
        } elseif (action_on_cooldown($u['id'], 'bosses')) {
            $cd = action_on_cooldown($u['id'], 'bosses');
            flash('Boss fight on cooldown. Try again in ' . $cd . '.', 'error');
        } else {
            // End any existing active fight
            q('UPDATE boss_fights SET active = 0 WHERE user_id = ? AND active = 1', [$u['id']]);
            q('UPDATE users SET energy = energy - ? WHERE id = ?', [(int) $boss['energy_cost'], $u['id']]);
            insert('boss_fights', ['user_id' => $u['id'], 'boss_id' => $bossId, 'boss_hp' => (int) $boss['hp'], 'turns' => 0, 'active' => 1]);
            flash('Fight started! Strike to attack.', 'success');
        }
    } elseif ($action === 'strike') {
        $fight = fetch('SELECT bf.*, b.name, b.attack, b.defense, b.reward_money, b.reward_xp, b.reward_points, b.reward_item_id
                        FROM boss_fights bf JOIN bosses b ON b.id = bf.boss_id
                        WHERE bf.user_id = ? AND bf.active = 1 ORDER BY bf.id DESC LIMIT 1', [$u['id']]);
        if (!$fight) {
            flash('No active fight.', 'error');
        } elseif (is_hospitalized($u)) {
            flash('You are hospitalized.', 'error');
        } else {
            // Player attacks boss
            $pAtk = $power = combat_power($u['id']);
            $pDmg = max(1, (int) round($pAtk['attack'] * (0.8 + mt_rand(0, 40) / 100) - (int) $fight['defense'] * 0.4));
            $newBossHp = max(0, (int) $fight['boss_hp'] - $pDmg);
            q('UPDATE boss_fights SET boss_hp = ?, turns = turns + 1 WHERE id = ?', [$newBossHp, $fight['id']]);
            // Boss attacks player
            $bDmg = max(1, (int) round((int) $fight['attack'] * (0.7 + mt_rand(0, 40) / 100) - $pAtk['defense'] * 0.4));
            $newHealth = max(0, (int) $u['health'] - $bDmg);
            q('UPDATE users SET health = ? WHERE id = ?', [$newHealth, $u['id']]);
            if ($newBossHp <= 0) {
                // Victory
                add_money($u['id'], (int) $fight['reward_money'], 'Boss: ' . $fight['name']);
                grant_xp($u['id'], (int) $fight['reward_xp']);
                add_points($u['id'], (int) $fight['reward_points']);
                q('UPDATE users SET boss_kills = boss_kills + 1 WHERE id = ?', [$u['id']]);
                event_track('boss_kills', 1, (int) $u['id']);
                q('UPDATE boss_fights SET active = 0 WHERE id = ?', [$fight['id']]);
                set_action_cooldown($u['id'], 'bosses');
                if ($fight['reward_item_id']) {
                    insert('user_items', ['user_id' => $u['id'], 'item_id' => $fight['reward_item_id'], 'qty' => 1, 'equipped' => 0]);
                    flash('Victory! You defeated ' . e($fight['name']) . ' and found a ' . fetch('SELECT name FROM items WHERE id = ?', [$fight['reward_item_id']])['name'] . '!', 'success');
                } else {
                    flash('Victory! You defeated ' . e($fight['name']) . '!', 'success');
                }
            } elseif ($newHealth <= 0) {
                // Defeat
                hospitalize($u['id'], 600, 'Defeated by ' . $fight['name']);
                q('UPDATE boss_fights SET active = 0 WHERE id = ?', [$fight['id']]);
                flash('You were defeated and hospitalized!', 'error');
            } else {
                flash('You hit for ' . $pDmg . '. Boss hit you for ' . $bDmg . '.', 'info');
            }
        }
    }
    redirect('bosses.php');
}

$page_title = 'Bosses';
require __DIR__ . '/includes/header.php';

$u = current_user();
$power = combat_power($u['id']);
$activeFight = fetch('SELECT bf.*, b.name, b.hp AS max_hp FROM boss_fights bf JOIN bosses b ON b.id = bf.boss_id WHERE bf.user_id = ? AND bf.active = 1 ORDER BY bf.id DESC LIMIT 1', [$u['id']]);
$bosses = fetch_all('SELECT b.*, d.name AS district_name FROM bosses b JOIN districts d ON d.id = b.district_id ORDER BY b.min_level');
?>
<div class="card">
  <div class="panel-heading">Bosses</div>
  <p class="muted small">Fight the city's elite. Spend energy to start, then strike until victory or defeat.</p>
</div>

<?php if ($activeFight): ?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading">Active Fight: <?= e($activeFight['name']) ?></div>
  <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:10px">
    <div style="flex:1;min-width:200px">
      <div class="muted small">Boss HP</div>
      <div class="progress" style="height:20px"><i style="width:<?= round($activeFight['boss_hp'] / max(1, $activeFight['max_hp']) * 100) ?>%"></i></div>
      <div class="small" style="margin-top:4px"><?= (int) $activeFight['boss_hp'] ?> / <?= (int) $activeFight['max_hp'] ?></div>
    </div>
    <div style="flex:1;min-width:200px">
      <div class="muted small">Your Health</div>
      <div class="progress bar-health" style="height:20px"><i style="width:<?= round((int) $u['health'] / max(1, (int) $u['health_max']) * 100) ?>%"></i></div>
      <div class="small" style="margin-top:4px"><?= (int) $u['health'] ?> / <?= (int) $u['health_max'] ?></div>
    </div>
  </div>
  <form method="post" style="display:inline">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="strike">
    <button class="btn btn-danger btn-lg" type="submit">Strike</button>
  </form>
</div>
<?php endif; ?>

<div class="grid grid-2">
  <?php foreach ($bosses as $b): $locked = (int) $u['level'] < (int) $b['min_level']; $isActive = $activeFight && $activeFight['boss_id'] == $b['id']; ?>
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <b><?= e($b['name']) ?></b>
        <span class="tag tag-<?= $locked ? 'common' : 'uncommon' ?>"><?= e($b['district_name']) ?></span>
      </div>
      <div class="stat"><span>HP</span><b><?= number_format((int) $b['hp']) ?></b></div>
      <div class="stat"><span>Attack / Defense</span><b><?= (int) $b['attack'] ?> / <?= (int) $b['defense'] ?></b></div>
      <div class="stat"><span>Energy Cost</span><b><?= (int) $b['energy_cost'] ?></b></div>
      <div class="stat"><span>Min Level</span><b><?= (int) $b['min_level'] ?></b></div>
      <div class="stat"><span>Rewards</span><b><?= money($b['reward_money']) ?> + <?= (int) $b['reward_xp'] ?> XP + <?= (int) $b['reward_points'] ?> pts</b></div>
      <?php if ($isActive): ?>
        <div style="margin-top:10px"><span class="tag tag-legendary">In Progress</span></div>
      <?php elseif ($locked): ?>
        <div style="margin-top:10px"><span class="tag tag-common">Locked</span></div>
      <?php else: ?>
        <form method="post" style="margin-top:10px">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="start">
          <input type="hidden" name="boss_id" value="<?= (int) $b['id'] ?>">
          <button class="btn btn-green btn-block" type="submit">Start Fight</button>
        </form>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>