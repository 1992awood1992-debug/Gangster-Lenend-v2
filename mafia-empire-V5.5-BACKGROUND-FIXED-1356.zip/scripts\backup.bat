@echo off
REM ---------------------------------------------------------------------------
REM Mafia Empire - database backup (Windows / XAMPP).
REM
REM Creates a .sql dump in .\backups and deletes backups older than 14 days.
REM Run from anywhere:  scripts\backup.bat
REM ---------------------------------------------------------------------------
setlocal enabledelayedexpansion

set "ROOT=%~dp0.."
set "MYSQLDUMP=C:\xampp\mysql\bin\mysqldump.exe"
set "DB_HOST=127.0.0.1"
set "DB_PORT=3306"
set "DB_NAME=mafia_empire"
set "DB_USER=root"
set "DB_PASS="
set "BACKUP_DIR=%ROOT%\backups"
set "RETENTION_DAYS=14"

if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%i"
set "OUT=%BACKUP_DIR%\%DB_NAME%_%STAMP%.sql"

echo Dumping %DB_NAME% to %OUT% ...
if "%DB_PASS%"=="" (
    "%MYSQLDUMP%" -h %DB_HOST% -P %DB_PORT% -u %DB_USER% --single-transaction --routines --triggers --default-character-set=utf8mb4 %DB_NAME% > "%OUT%"
) else (
    "%MYSQLDUMP%" -h %DB_HOST% -P %DB_PORT% -u %DB_USER% -p%DB_PASS% --single-transaction --routines --triggers --default-character-set=utf8mb4 %DB_NAME% > "%OUT%"
)
if errorlevel 1 (
    echo Backup FAILED.
    exit /b 1
)

echo Pruning backups older than %RETENTION_DAYS% days...
forfiles /p "%BACKUP_DIR%" /m "%DB_NAME%_*.sql" /d -%RETENTION_DAYS% /c "cmd /c del @path" 2>nul

echo Backup written: %OUT%
endlocal
