<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Support;

use PHPUnit\Framework\TestCase as BaseTestCase;

/**
 * Base class for database-backed tests.
 *
 * The bootstrap builds the schema once per run; each test starts from a clean
 * slate by wiping player-generated ("mutable") tables, while the seeded game
 * content (missions, items, ranks, ...) is preserved.
 */
abstract class TestCase extends BaseTestCase
{
    /** Player-generated tables wiped before every test. */
    protected const MUTABLE_TABLES = [
        'users', 'notifications', 'event_log', 'bank_transactions',
        'user_missions', 'boss_fights', 'user_job_cooldowns',
        'user_abilities', 'user_drugs', 'user_items',
        'market_listings', 'escrow', 'lottery_tickets',
        'casino_bets', 'casino_state',
        'crews', 'crew_members',
        'tournament_participants', 'tournament_matches', 'tournament_rewards_log', 'crew_invites',
        'zone_control', 'crew_wars', 'crew_armory',
        'crew_unlocked_perks', 'crew_diplomacy', 'zone_raids',
        'forum_threads', 'forum_posts',
        'user_achievements', 'user_stickers', 'scratch_cards', 'referral_rewards',
        'updates', 'update_votes', 'update_comments',
        'suggestions', 'suggestion_votes', 'suggestion_comments',
        'support_tickets', 'support_replies', 'kill_log',
        'api_keys', 'api_rate', 'api_requests', 'webhooks', 'webhook_deliveries',
        'push_subscriptions', 'push_outbox',
        'trades', 'hitlist', 'bounties', 'social_notifications',
        'crew_messages', 'crew_message_reads', 'analytics_events', 'rate_limits',
        'user_event_progress', 'event_rewards_log',
        'race_events', 'race_participants', 'race_bets',
        'mayor_elections', 'mayor_candidates', 'mayor_votes',
        'user_properties', 'property_income_log',
    ];

    protected function setUp(): void
    {
        parent::setUp();
        $this->resetMutableTables();
    }

    /** Delete all player-generated rows so each test is isolated. */
    protected function resetMutableTables(): void
    {
        $pdo = db();
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        foreach (self::MUTABLE_TABLES as $table) {
            $pdo->exec('DELETE FROM `' . $table . '`');
        }
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
    }

    /** Create a user with sensible defaults; returns the fresh row. */
    protected function makeUser(array $overrides = []): array
    {
        $suffix = bin2hex(random_bytes(4));
        $data = array_merge([
            'username'      => 'tester_' . $suffix,
            'email'         => 'tester_' . $suffix . '@example.test',
            'password_hash' => password_hash('testing123', PASSWORD_DEFAULT),
            'referral_code' => strtoupper($suffix),
        ], $overrides);

        $id = insert('users', $data);
        return fetch('SELECT * FROM users WHERE id = ?', [$id]);
    }

    /** Create a crew; returns the fresh row. */
    protected function makeCrew(array $overrides = []): array
    {
        $suffix = bin2hex(random_bytes(3));
        $data = array_merge([
            'name'      => 'Crew ' . $suffix,
            'tag'       => strtoupper(substr($suffix, 0, 4)),
            'leader_id' => 0,
            'level'     => 1,
            'xp'        => 0,
            'xp_spent'  => 0,
        ], $overrides);

        $id = insert('crews', $data);
        return fetch('SELECT * FROM crews WHERE id = ?', [$id]);
    }

    /** Put a user in a crew (mirrors crew.php's join flow). */
    protected function joinCrew(int $userId, int $crewId, string $rank = 'Recruit'): void
    {
        insert('crew_members', [
            'user_id' => $userId,
            'crew_id' => $crewId,
            'rank'    => $rank,
        ]);
        q('UPDATE users SET crew_id = ?, crew_rank = ? WHERE id = ?', [$crewId, $rank, $userId]);
    }

    /** Refetch a user row by id. */
    protected function freshUser(int $id): array
    {
        return fetch('SELECT * FROM users WHERE id = ?', [$id]);
    }

    /** Refetch a crew row by id. */
    protected function freshCrew(int $id): array
    {
        return fetch('SELECT * FROM crews WHERE id = ?', [$id]);
    }

    /** Ensure a crew perk fixture exists; returns the perk code. */
    protected function seedPerk(string $code, string $name = 'Test Perk'): string
    {
        if (!fetch_one('SELECT id FROM crew_perks WHERE code = ?', [$code])) {
            insert('crew_perks', ['code' => $code, 'name' => $name, 'cost_xp' => 100, 'description' => 'Test']);
        }
        return $code;
    }
}
