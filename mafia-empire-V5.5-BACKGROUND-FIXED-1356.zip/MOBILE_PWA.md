# Mobile & PWA Polish

## Current Status — IMPLEMENTED

- [x] PWA manifest (`manifest.webmanifest`) with `id`, `display_override`,
      maskable icon, categories, and **app shortcuts** (Play, Missions,
      Criminal Jobs, Casino)
- [x] Service worker (`sw.js`) — precache + runtime cache, update flow
- [x] Unified PWA status bar (offline / pending / update / install states)
- [x] Offline action queue for `form[data-offline-queue]`, auto-flush on reconnect
- [x] Push notifications (VAPID)
- [x] Touch-optimized UI: bottom nav, edge-swipe drawer, focus trap, swipe-to-dismiss toasts
- [x] Install prompt (`beforeinstallprompt`) + `appinstalled` handling
- [x] **iOS Safari install guidance** — detects iOS Safari (not Chrome/Firefox/Edge
      on iOS, which cannot install) and shows a persistent-dismissible
      "Add to Home Screen" hint
- [x] Mobile meta tags: `viewport-fit=cover`, `theme-color`, `apple-mobile-web-app-*`,
      `apple-touch-icon`, `mobile-web-app-capable`
- [x] Reduced-motion support (`prefers-reduced-motion`)

## Files

- `manifest.webmanifest` — PWA manifest (icons, shortcuts)
- `sw.js` — service worker
- `assets/app.js` — PWA client logic (SW registration, install/update/offline
  status bar, queue, drawer gestures, toasts)
- `includes/header.php` — PWA + mobile meta tags

## Testing

Test on mobile devices:
- Installation flow (Android Chrome + iOS Safari)
- Offline functionality (queue a move, reconnect, confirm flush)
- Push notifications
- Touch interactions: edge-swipe drawer, swipe-to-dismiss toasts
- Bottom navigation
- Service worker updates (deploy a change, confirm "Refresh" prompt)

## Still Optional

- Real device screenshots for the manifest `screenshots` array
  (existing `assets/img/*screenshot*.png` are not device-sized)
- Background Sync API for queue flush while the tab is closed
- Cohort/retention analytics surfaced on mobile (server-side already tracked)
