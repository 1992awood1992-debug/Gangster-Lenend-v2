<?php
/**
 * Eye Of The Mafia - Roulette (European + American)
 */

require_once __DIR__ . '/includes/init.php';
$u = require_login();

const ROULETTE_EU = [
    0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
];
const ROULETTE_US = [
    0, 28, 9, 26, 30, 11, 7, 20, 32, 17, 5, 22, 34, 15, 3, 24, 36, 13, 1, 00, 27, 10, 25, 29, 12, 8, 19, 31, 18, 6, 21, 33, 16, 4, 23, 35, 14, 2
];

$redNumbers = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
$blackNumbers = [2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35];

function roulette_get_color(int $num, bool $us = false): string
{
    if ($num === 0 || ($us && $num === 37)) return 'green';
    return in_array($num, [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]) ? 'red' : 'black';
}

function roulette_spin(bool $us = false): int
{
    $wheel = $us ? ROULETTE_US : ROULETTE_EU;
    return $wheel[array_rand($wheel)];
}

// Store bets in session state
$st = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'roulette']);
$st = $st ? json_decode($st['state'], true) : ['bets' => [], 'wheel' => 'eu', 'last_spin' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if (action_on_cooldown($u['id'], 'roulette')) {
        $cd = action_on_cooldown($u['id'], 'roulette');
        flash('Roulette on cooldown. Try again in ' . $cd . '.', 'error');
    } else {
    
    if ($action === 'place_bet') {
        $betType = $_POST['bet_type'] ?? '';
        $amount = max(1, (int) ($_POST['amount'] ?? 0));
        $value = $_POST['value'] ?? '';
        
        $totalBets = array_sum(array_column($st['bets'], 'amount'));
        if ($totalBets + $amount > $u['money']) {
            flash('Not enough cash for total bets.', 'error');
        } else {
            $st['bets'][] = ['type' => $betType, 'value' => $value, 'amount' => $amount];
            flash('Bet placed!', 'success');
        }
    } elseif ($action === 'clear_bets') {
        $st['bets'] = [];
        flash('Bets cleared.', 'success');
    } elseif ($action === 'spin') {
        if (empty($st['bets'])) {
            flash('Place at least one bet first.', 'error');
        } else {
            $totalBet = array_sum(array_column($st['bets'], 'amount'));
            if ($totalBet > $u['money']) {
                flash('Not enough cash.', 'error');
            } else {
                add_money($u['id'], -$totalBet, 'Roulette bets');
                
                $wheel = $st['wheel'] === 'us' ? 'us' : 'eu';
                $result = roulette_spin($wheel === 'us');
                $color = roulette_get_color($result, $wheel === 'us');
                
                $totalWin = 0;
                $details = [];
                
                foreach ($st['bets'] as $bet) {
                    $win = 0;
                    $betType = $bet['type'];
                    $betValue = $bet['value'];
                    $amount = $bet['amount'];
                    
                    switch ($betType) {
                        case 'straight': // Single number
                            if ((int) $betValue === $result || ($result === 37 && $betValue === '00')) $win = $amount * 35;
                            break;
                        case 'split': // Two adjacent numbers
                            $nums = explode(',', $betValue);
                            if (in_array($result, $nums)) $win = $amount * 17;
                            break;
                        case 'street': // Three numbers in a row
                            if ((int) $betValue <= 34 && $result >= (int) $betValue && $result <= (int) $betValue + 2) $win = $amount * 11;
                            break;
                        case 'corner': // Four numbers
                            // Simplified: check if result in corner
                            break;
                        case 'line': // Six numbers
                            break;
                        case 'dozen': // 1-12, 13-24, 25-36
                            $dozen = (int) $betValue;
                            if ($dozen === 1 && $result >= 1 && $result <= 12) $win = $amount * 2;
                            elseif ($dozen === 2 && $result >= 13 && $result <= 24) $win = $amount * 2;
                            elseif ($dozen === 3 && $result >= 25 && $result <= 36) $win = $amount * 2;
                            break;
                        case 'column': // Columns
                            break;
                        case 'red':
                            if ($color === 'red') $win = $amount * 2;
                            break;
                        case 'black':
                            if ($color === 'black') $win = $amount * 2;
                            break;
                        case 'even':
                            if ($result !== 0 && $result !== 37 && $result % 2 === 0) $win = $amount * 2;
                            break;
                        case 'odd':
                            if ($result !== 0 && $result !== 37 && $result % 2 === 1) $win = $amount * 2;
                            break;
                        case 'low': // 1-18
                            if ($result >= 1 && $result <= 18) $win = $amount * 2;
                            break;
                        case 'high': // 19-36
                            if ($result >= 19 && $result <= 36) $win = $amount * 2;
                            break;
                    }
                    
                    if ($win > 0) {
                        $totalWin += $win;
                        $details[] = $betType . ' won ' . money($win);
                    }
                }
                
                if ($totalWin > 0) {
                    add_money($u['id'], $totalWin, 'Roulette win');
                    event_track('casino_won', (int) $totalWin);
                    flash('You won ' . money($totalWin) . '!', 'success');
                } else {
                    flash('No wins this spin.', 'error');
                }
                
                insert('casino_bets', [
                    'user_id' => $u['id'], 
                    'game' => 'roulette', 
                    'stake' => $totalBet, 
                    'payout' => $totalWin, 
                    'detail' => 'Wheel: ' . ($wheel === 'us' ? 'American' : 'European') . ', Result: ' . ($result === 37 ? '00' : $result) . ' (' . $color . ')' . ($details ? ' | ' . implode(', ', $details) : '')
                ]);
                
                $st['last_spin'] = ['result' => $result, 'color' => $color, 'wheel' => $wheel, 'win' => $totalWin];
                $st['bets'] = []; // Clear bets after spin
            }
        }
    } elseif ($action === 'set_wheel') {
        $st['wheel'] = ($_POST['wheel'] ?? 'eu') === 'us' ? 'us' : 'eu';
        flash('Wheel set to ' . ($st['wheel'] === 'us' ? 'American (00)' : 'European (0)'), 'success');
    }
    
    q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'roulette', json_encode($st)]);
    redirect('roulette.php');
}

$page_title = 'Roulette';
require __DIR__ . '/includes/header.php';
$u = current_user();

$wheelNames = ['eu' => 'European (0)', 'us' => 'American (0, 00)'];
$lastSpin = $st['last_spin'] ?? null;
?>
<div class="card">
  <div class="panel-heading">Roulette</div>
  <p class="muted small">European (single 0, 2.7% house edge) or American (0 + 00, 5.26% house edge).</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
  <div class="stat"><span>Wheel</span><b><?= $wheelNames[$st['wheel']] ?></b></div>
  <form method="post" style="display:inline;margin-top:8px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="set_wheel">
    <select name="wheel" onchange="this.form.submit()" style="padding:6px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
      <option value="eu" <?= $st['wheel']==='eu'?'selected':'' ?>>European (0)</option>
      <option value="us" <?= $st['wheel']==='us'?'selected':'' ?>>American (0, 00)</option>
    </select>
  </form>
</div>

<?php if ($lastSpin): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Last Spin: <span style="color:<?= $lastSpin['color'] === 'red' ? '#c00' : ($lastSpin['color'] === 'black' ? '#fff' : '#d4a010') ?>;font-size:3rem;font-weight:bold"><?= $lastSpin['result'] === 37 ? '00' : $lastSpin['result'] ?></span> <span class="tag tag-<?= $lastSpin['color'] ?>"><?= ucfirst($lastSpin['color']) ?></span></div>
  <div class="stat"><span>Win</span><b><?= money($lastSpin['win']) ?></b></div>
</div>
<?php endif; ?>

<!-- Betting Layout -->
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Place Bets</div>
  
  <form method="post" style="margin-bottom:16px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="place_bet">
    <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:12px">
      <label>Bet Type
        <select name="bet_type" required style="padding:6px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
          <optgroup label="Inside Bets">
            <option value="straight">Straight Up (35:1) - Single number</option>
            <option value="split">Split (17:1) - Two numbers</option>
            <option value="street">Street (11:1) - Three numbers</option>
            <option value="corner">Corner (8:1) - Four numbers</option>
            <option value="line">Line (5:1) - Six numbers</option>
          </optgroup>
          <optgroup label="Outside Bets">
            <option value="dozen">Dozen (2:1) - 1-12, 13-24, 25-36</option>
            <option value="column">Column (2:1)</option>
            <option value="red">Red (1:1)</option>
            <option value="black">Black (1:1)</option>
            <option value="even">Even (1:1)</option>
            <option value="odd">Odd (1:1)</option>
            <option value="low">Low 1-18 (1:1)</option>
            <option value="high">High 19-36 (1:1)</option>
          </optgroup>
        </select>
      </label>
      <label>Amount <input type="number" name="amount" min="1" max="<?= (int) $u['money'] ?>" value="10" required style="width:100px;padding:6px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)"></label>
      <label>Value <input type="text" name="value" placeholder="e.g. 7, or 1-12, or red" style="width:140px;padding:6px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)"></label>
      <button class="btn btn-gold" type="submit">Place Bet</button>
      <button class="btn btn-sm" type="submit" name="action" value="clear_bets">Clear All</button>
    </div>
  </form>
  
  <?php if ($st['bets']): ?>
  <div class="card" style="margin-top:12px">
    <div class="panel-heading">Active Bets (Total: <?= money(array_sum(array_column($st['bets'], 'amount'))) ?>)</div>
    <div class="table-wrap"><table>
      <tr><th>Type</th><th>Value</th><th>Amount</th><th></th></tr>
      <?php foreach ($st['bets'] as $i => $bet): ?>
      <tr>
        <td><?= ucfirst($bet['type']) ?></td>
        <td><?= e($bet['value']) ?></td>
        <td><?= money($bet['amount']) ?></td>
        <td><form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="remove_bet"><input type="hidden" name="index" value="<?= $i ?>"><button class="btn btn-sm btn-danger" type="submit">Remove</button></form></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
  <?php endif; ?>
  
  <form method="post" style="margin-top:16px;display:flex;gap:12px;align-items:center;flex-wrap:wrap">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="spin">
    <button class="btn btn-gold btn-lg" type="submit" style="padding:16px 40px;font-size:1.2rem">🎯 SPIN</button>
    <?php if ($st['wheel'] === 'us'): ?>
      <span class="tag tag-error">American Wheel: House Edge 5.26%</span>
    <?php else: ?>
      <span class="tag tag-gold">European Wheel: House Edge 2.70%</span>
    <?php endif; ?>
  </form>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>