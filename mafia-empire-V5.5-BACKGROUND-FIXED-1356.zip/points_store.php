<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: buy
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (action_on_cooldown($u['id'], 'points_store')) {
        $cd = action_on_cooldown($u['id'], 'points_store');
        flash('Points Store on cooldown. Try again in ' . $cd . '.', 'error');
        redirect('points_store.php');
    }
    $itemId = (int) ($_POST['store_id'] ?? 0);
    $item = fetch('SELECT * FROM points_store WHERE id = ?', [$itemId]);
    if (!$item) {
        flash('Item not found.', 'error');
    } elseif ((int) $u['points'] < (int) $item['cost_points']) {
        flash('Not enough points.', 'error');
    } else {
        add_points($u['id'], -(int) $item['cost_points']);
        $kind = $item['kind'];
        $amt = (int) $item['amount'];
        if ($kind === 'money') {
            add_money($u['id'], $amt, 'Points Store: ' . $item['name']);
        } elseif ($kind === 'bullets') {
            add_bullets($u['id'], $amt);
        } elseif ($kind === 'energy') {
            $new = min((int) $u['energy_max'], (int) $u['energy'] + $amt);
            q('UPDATE users SET energy = ? WHERE id = ?', [$new, $u['id']]);
        } elseif ($kind === 'nerve') {
            $new = min((int) $u['nerve_max'], (int) $u['nerve'] + $amt);
            q('UPDATE users SET nerve = ? WHERE id = ?', [$new, $u['id']]);
        } elseif ($kind === 'heal') {
            q('UPDATE users SET health = health_max WHERE id = ?', [$u['id']]);
        } elseif ($kind === 'item' && $item['item_id']) {
            $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$u['id'], $item['item_id']]);
            if ($existing) {
                q('UPDATE user_items SET qty = qty + 1 WHERE id = ?', [(int) $existing['id']]);
            } else {
                insert('user_items', ['user_id' => $u['id'], 'item_id' => $item['item_id'], 'qty' => 1, 'equipped' => 0]);
            }
        } elseif ($kind === 'xp') {
            grant_xp($u['id'], $amt);
        }
        set_action_cooldown($u['id'], 'points_store');
        flash('Purchased ' . e($item['name']) . '.', 'success');
        if (function_exists('webhook_dispatch')) {
            webhook_dispatch((int) $u['id'], 'purchase', [
                'name'        => (string) $item['name'],
                'kind'        => (string) $item['kind'],
                'cost_points' => (int) $item['cost_points'],
            ]);
        }
    }
    redirect('points_store.php');
}

$page_title = 'Points Store';
require __DIR__ . '/includes/header.php';

$u = current_user();
$items = fetch_all('SELECT * FROM points_store ORDER BY cost_points');
?>
<div class="card">
  <div class="panel-heading">Points Store</div>
  <div class="stat"><span>Your Points</span><b><?= number_format((int) $u['points']) ?></b></div>
</div>

<div class="card">
  <div class="panel-heading">Catalog</div>
  <div class="grid grid-3">
    <?php foreach ($items as $it): ?>
      <div class="tile">
        <b><?= e($it['name']) ?></b>
        <small><?= e($it['description']) ?></small>
        <div style="margin-top:8px">
          <span class="tag tag-legendary"><?= number_format((int) $it['cost_points']) ?> pts</span>
        </div>
        <form method="post" style="margin-top:10px">
          <?= csrf_field() ?>
          <input type="hidden" name="store_id" value="<?= (int) $it['id'] ?>">
          <button class="btn btn-gold btn-block btn-sm" type="submit" <?= (int) $u['points'] < (int) $it['cost_points'] ? 'disabled' : '' ?>>Buy</button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>