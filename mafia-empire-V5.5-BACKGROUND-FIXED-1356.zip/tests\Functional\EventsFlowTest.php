<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Functional;

use MafiaEmpire\Tests\Support\Http;
use MafiaEmpire\Tests\Support\TestCase;

/**
 * Events dashboard claim flow over HTTP.
 *
 * Regression: events.php rendered a "Claim" form but had no POST handler, and
 * event_claim_reward() looked the progress row up by the wrong id, so rewards
 * could never be collected.
 *
 * Skipped unless APP_URL points at a running instance.
 */
final class EventsFlowTest extends TestCase
{
    private function requireServer(): void
    {
        if (!Http::configured()) {
            $this->markTestSkipped('Set APP_URL to a running instance to run the functional suite.');
        }
    }

    private function http(): Http
    {
        return new Http(Http::baseUrl());
    }

    public function testClaimFormCompletesTheReward(): void
    {
        $this->requireServer();
        $user = $this->makeUser(['money' => 1000]);
        $challenge = fetch("
            SELECT ec.* FROM event_challenges ec
            JOIN events e ON e.id = ec.event_id
            WHERE e.type = 'daily' AND ec.metric = 'missions_done'
            ORDER BY ec.sort_order LIMIT 1
        ");
        $this->assertNotNull($challenge);
        insert('user_event_progress', [
            'user_id'       => $user['id'],
            'event_id'      => (int) $challenge['event_id'],
            'challenge_id'  => (int) $challenge['id'],
            'current_value' => (int) $challenge['target_value'],
            'completed'     => 1,
            'claimed'       => 0,
        ]);

        $http = $this->http();
        $http->login($user['username'], 'testing123');
        [$status, $html] = $http->get('/events.php');
        $this->assertSame(200, $status);
        $this->assertStringContainsString('name="action" value="claim"', $html);
        $this->assertStringContainsString('name="challenge_id" value="' . (int) $challenge['id'] . '"', $html);

        $csrf = $http->csrfFrom('/events.php');
        $http->post('/events.php', [
            'csrf'         => $csrf,
            'action'       => 'claim',
            'challenge_id' => (int) $challenge['id'],
        ]);

        $row = fetch(
            'SELECT claimed FROM user_event_progress WHERE user_id = ? AND challenge_id = ?',
            [$user['id'], $challenge['id']]
        );
        $this->assertNotNull($row);
        $this->assertSame(1, (int) $row['claimed']);
        $this->assertGreaterThan(1000, (int) fetch('SELECT money FROM users WHERE id = ?', [$user['id']])['money']);
    }
}
