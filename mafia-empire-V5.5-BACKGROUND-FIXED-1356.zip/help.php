<?php
require_once __DIR__ . '/includes/init.php';
// Public page

$page_title = 'Help';
require __DIR__ . '/includes/header.php';

$faqs = fetch_all('SELECT * FROM faqs ORDER BY sort_order, id');
?>
<div class="card">
  <div class="panel-heading">Help & FAQ</div>
</div>

<?php if ($faqs): foreach ($faqs as $f): ?>
<div class="card" style="margin-top:10px">
  <details>
    <summary style="cursor:pointer;font-weight:600;color:var(--gold)"><?= e($f['question']) ?></summary>
    <div style="margin-top:8px;white-space:pre-wrap"><?= e($f['answer']) ?></div>
  </details>
</div>
<?php endforeach; else: ?>
<div class="card"><p class="muted">No FAQ entries yet.</p></div>
<?php endif; ?>

<div class="card" style="margin-top:18px">
  <div class="panel-heading">Game Rules</div>
  <ol style="padding-left:20px;line-height:1.8">
    <li>One account per person. Multi-accounting results in a ban.</li>
    <li>No botting, scripting, or automated play.</li>
    <li>Respect other players. Harassment is not tolerated.</li>
    <li>Exploiting bugs must be reported via Support. Abuse leads to bans.</li>
    <li>Account sharing is prohibited.</li>
    <li>Real-money trading is forbidden.</li>
  </ol>
</div>

<div class="grid grid-2" style="margin-top:18px">
  <a class="tile" href="<?= e(url('support.php')) ?>"><span class="ico">🎫</span><b>Contact Support</b></a>
  <a class="tile" href="<?= e(url('suggestions.php')) ?>"><span class="ico">💡</span><b>Suggest a Feature</b></a>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>