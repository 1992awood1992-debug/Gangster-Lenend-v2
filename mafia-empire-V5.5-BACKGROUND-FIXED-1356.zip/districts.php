<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: travel
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $districtId = (int) ($_POST['district_id'] ?? 0);
    $d = fetch('SELECT * FROM districts WHERE id = ?', [$districtId]);
    if (!$d) {
        flash('District not found.', 'error');
    } elseif ((int) $u['level'] < (int) $d['unlock_level']) {
        flash('Level ' . (int) $d['unlock_level'] . ' required to enter.', 'error');
    } elseif (action_on_cooldown($u['id'], 'districts')) {
        $cd = action_on_cooldown($u['id'], 'districts');
        flash('Travel on cooldown. Try again in ' . $cd . '.', 'error');
    } else {
        q('UPDATE users SET district_id = ? WHERE id = ?', [$districtId, $u['id']]);
        set_action_cooldown($u['id'], 'districts');
        flash('Traveled to ' . e($d['name']) . '.', 'success');
    }
    redirect('districts.php');
}

$page_title = 'Districts';
require __DIR__ . '/includes/header.php';

$districts = fetch_all('SELECT * FROM districts ORDER BY unlock_level');
$currentId = $u['district_id'];
?>
<div class="card">
  <div class="panel-heading">Districts</div>
  <p class="muted small">Each district has unique missions, bosses, and income bonuses. Travel to unlock new content.</p>
</div>

<div class="grid grid-2">
  <?php foreach ($districts as $d):
    $locked = (int) $u['level'] < (int) $d['unlock_level'];
    $isHere = $d['id'] === $currentId;
    $missionCount = (int) fetch_one('SELECT COUNT(*) FROM missions WHERE district_id = ?', [$d['id']], 0);
    $bossCount = (int) fetch_one('SELECT COUNT(*) FROM bosses WHERE district_id = ?', [$d['id']], 0);
    $playerCount = (int) fetch_one('SELECT COUNT(*) FROM users WHERE district_id = ?', [$d['id']], 0);
  ?>
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <b><?= e($d['name']) ?></b>
        <?php if ($isHere): ?><span class="tag tag-legendary">Current</span><?php elseif ($locked): ?><span class="tag tag-common">Locked</span><?php endif; ?>
      </div>
      <small class="muted"><?= e($d['description']) ?></small>
      <div class="pill-row" style="margin:8px 0">
        <span class="pill">Unlock: Lvl <?= (int) $d['unlock_level'] ?></span>
        <span class="pill">Income: +<?= (int) $d['income_bonus'] ?>%</span>
        <span class="pill">Missions: <?= $missionCount ?></span>
        <span class="pill">Bosses: <?= $bossCount ?></span>
        <span class="pill">Players: <?= $playerCount ?></span>
      </div>
      <?php if (!$locked && !$isHere): ?>
        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="district_id" value="<?= (int) $d['id'] ?>">
          <button class="btn btn-green btn-block btn-sm" type="submit">Travel Here</button>
        </form>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>