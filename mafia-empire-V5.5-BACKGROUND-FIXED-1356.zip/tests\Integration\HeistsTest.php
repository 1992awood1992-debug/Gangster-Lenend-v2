<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Integration tests for the Heists system.
 */
final class HeistsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        require_once dirname(__DIR__, 2) . '/includes/heists.php';
    }

    private function makeCrewWithMembers(int $leaderId, int $memberCount = 3, int $level = 10): array
    {
        $crew = $this->makeCrew([
            'leader_id' => $leaderId,
            'level' => $level,
            'xp' => 1000,
        ]);
        $this->joinCrew($leaderId, (int) $crew['id'], 'Leader');

        for ($i = 1; $i < $memberCount; $i++) {
            $member = $this->makeUser([
                'level' => $level,
                'strength' => 100,
                'speed' => 100,
                'defense' => 100,
                'iq' => 100,
            ]);
            $this->joinCrew((int) $member['id'], (int) $crew['id'], 'Member');
        }

        // Add required items to crew armory for bank_job
        insert('crew_armory', ['crew_id' => (int) $crew['id'], 'item_id' => 1, 'qty' => 5]); // Baseball Bat
        insert('crew_armory', ['crew_id' => (int) $crew['id'], 'item_id' => 2, 'qty' => 5]); // Switchblade
        insert('crew_armory', ['crew_id' => (int) $crew['id'], 'item_id' => 3, 'qty' => 5]); // 9mm Pistol
        insert('crew_armory', ['crew_id' => (int) $crew['id'], 'item_id' => 11, 'qty' => 1]); // Beaten-Up Sedan

        return $crew;
    }

    public function testHeistCanStartChecksCrewRequirements(): void
    {
        $leader = $this->makeUser(['level' => 10, 'strength' => 100, 'speed' => 100, 'defense' => 100, 'iq' => 100]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 10);

        // Should pass - crew meets all requirements for bank_job (min_crew_level 5, min_members 3)
        $check = heist_can_start((int) $crew['id'], 1); // bank_job is ID 1
        $this->assertTrue($check['ok'], $check['error'] ?? 'should pass');
        $this->assertSame('First National Bank Heist', $check['heist']['name']);
    }

    public function testHeistFailsIfCrewLevelTooLow(): void
    {
        $leader = $this->makeUser(['level' => 3, 'strength' => 100, 'speed' => 100, 'defense' => 100, 'iq' => 100]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 3);

        $check = heist_can_start((int) $crew['id'], 1); // bank_job needs level 5
        $this->assertFalse($check['ok']);
        $this->assertStringContainsString('level', strtolower($check['error'] ?? ''));
    }

    public function testHeistFailsIfNotEnoughMembers(): void
    {
        $leader = $this->makeUser(['level' => 10, 'strength' => 100, 'speed' => 100, 'defense' => 100, 'iq' => 100]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 2, 10); // Only 2 members, need 3

        $check = heist_can_start((int) $crew['id'], 1); // bank_job needs 3
        $this->assertFalse($check['ok']);
        $this->assertStringContainsString('member', strtolower($check['error'] ?? ''));
    }

    public function testHeistStartCreatesInstanceAndParticipants(): void
    {
        $leader = $this->makeUser(['level' => 10, 'money' => 100000, 'strength' => 100, 'speed' => 100, 'defense' => 100, 'iq' => 100]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 10);

        $result = heist_start((int) $crew['id'], 1, (int) $leader['id']);
        $this->assertTrue($result['ok'], $result['error'] ?? 'start failed');

        $instanceId = $result['instance_id'];
        $this->assertGreaterThan(0, $instanceId);

        $instance = heist_get_instance($instanceId);
        $this->assertNotNull($instance);
        $this->assertSame((int) $crew['id'], (int) $instance['crew_id']);
        $this->assertSame((int) $leader['id'], (int) $instance['leader_id']);
        $this->assertSame('planning', $instance['status']);

        $participants = fetch_all('SELECT * FROM heist_participants WHERE instance_id = ?', [$instanceId]);
        $this->assertCount(3, $participants);
    }

    public function testHeistReadyUpAndStart(): void
    {
        $leader = $this->makeUser(['level' => 10, 'money' => 100000, 'strength' => 100, 'speed' => 100, 'defense' => 100, 'iq' => 100]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 10);

        $result = heist_start((int) $crew['id'], 1, (int) $leader['id']);
        $this->assertTrue($result['ok']);
        $instanceId = $result['instance_id'];

        // Leader readies up
        $ready = heist_ready($instanceId, (int) $leader['id']);
        $this->assertTrue($ready['ok']);

        // Other members ready up
        $members = fetch_all('SELECT user_id FROM crew_members WHERE crew_id = ? AND user_id != ?', [(int) $crew['id'], (int) $leader['id']]);
        foreach ($members as $m) {
            $ready = heist_ready($instanceId, (int) $m['user_id']);
            $this->assertTrue($ready['ok'], "Member {$m['user_id']} ready failed");
        }

        // All ready - instance should now be active
        $instance = heist_get_instance($instanceId);
        $this->assertSame('active', $instance['status']);
        $this->assertSame(1, (int) $instance['current_phase']);
    }

    public function testPhaseCompletionAdvancesHeist(): void
    {
        $leader = $this->makeUser(['level' => 10, 'money' => 100000]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 10);

        $result = heist_start((int) $crew['id'], 1, (int) $leader['id']);
        $this->assertTrue($result['ok']);
        $instanceId = $result['instance_id'];

        // Ready all
        $members = fetch_all('SELECT user_id FROM crew_members WHERE crew_id = ?', [(int) $crew['id']]);
        foreach ($members as $m) {
            heist_ready($instanceId, (int) $m['user_id']);
        }

        // Complete phase 0 (first phase)
        $result = heist_complete_phase($instanceId, (int) $leader['id'], 0);
        $this->assertTrue($result['ok'], $result['error'] ?? 'phase complete failed');
        $this->assertArrayHasKey('next_phase', $result);
        $this->assertSame(1, $result['next_phase']); // next phase index

        // Instance should now be on phase 2
        $instance = heist_get_instance($instanceId);
        $this->assertSame(2, (int) $instance['current_phase']);
    }

    public function testHeistCompleteDistributesRewards(): void
    {
        $leader = $this->makeUser(['level' => 10, 'money' => 100000, 'xp' => 0]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 10);

        $result = heist_start((int) $crew['id'], 1, (int) $leader['id']);
        $this->assertTrue($result['ok']);
        $instanceId = $result['instance_id'];

        // Ready all and complete all phases
        $members = fetch_all('SELECT user_id FROM crew_members WHERE crew_id = ?', [(int) $crew['id']]);
        foreach ($members as $m) {
            heist_ready($instanceId, (int) $m['user_id']);
        }

        // Complete all 3 phases for bank_job
        for ($phase = 0; $phase < 3; $phase++) {
            $result = heist_complete_phase($instanceId, (int) $leader['id'], $phase);
            $this->assertTrue($result['ok'], "Phase $phase failed: " . ($result['error'] ?? ''));
        }

        // Heist should be completed
        $instance = heist_get_instance($instanceId);
        $this->assertSame('completed', $instance['status']);
        $this->assertGreaterThan(0, (int) $instance['total_money']);
        $this->assertGreaterThan(0, (int) $instance['total_xp']);

        // Check participant rewards
        $participants = fetch_all('SELECT * FROM heist_participants WHERE instance_id = ?', [$instanceId]);
        foreach ($participants as $p) {
            $this->assertGreaterThan(0, (int) $p['money_received']);
            $this->assertGreaterThan(0, (int) $p['xp_received']);
        }
    }

    public function testHeistCooldownPreventsImmediateRestart(): void
    {
        $leader = $this->makeUser(['level' => 10, 'money' => 100000, 'strength' => 100, 'speed' => 100, 'defense' => 100, 'iq' => 100]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 10);

        $result = heist_start((int) $crew['id'], 1, (int) $leader['id']);
        $this->assertTrue($result['ok']);

        // Try to start again immediately
        $result2 = heist_can_start((int) $crew['id'], 1);
        $this->assertFalse($result2['ok']);
        $this->assertStringContainsString('cooldown', strtolower($result2['error'] ?? ''));
    }

    public function testHeistHistoryTracking(): void
    {
        $leader = $this->makeUser(['level' => 10, 'strength' => 100, 'speed' => 100, 'defense' => 100, 'iq' => 100]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 10);

        heist_start((int) $crew['id'], 1, (int) $leader['id']);

        $history = heist_get_crew_history((int) $crew['id']);
        $this->assertGreaterThanOrEqual(1, count($history));
        $this->assertSame('bank_job', $history[0]['code']);
    }

    public function testHeistFailsIfNotLeader(): void
    {
        $leader = $this->makeUser(['level' => 10, 'money' => 100000, 'strength' => 100, 'speed' => 100, 'defense' => 100, 'iq' => 100]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 10);
        $member = $crew['id'] === $leader['id'] 
            ? fetch('SELECT user_id FROM crew_members WHERE crew_id = ? AND user_id != ?', [(int) $crew['id'], (int) $leader['id']])
            : null;

        if (!$member) {
            $this->markTestSkipped('No member to test with');
            return;
        }

        $result = heist_start((int) $crew['id'], 1, (int) $member['user_id']);
        $this->assertFalse($result['ok']);
        $this->assertStringContainsString('leader', strtolower($result['error'] ?? ''));
    }

    public function testHeistAbandonByLeader(): void
    {
        $leader = $this->makeUser(['level' => 10, 'money' => 100000, 'strength' => 100, 'speed' => 100, 'defense' => 100, 'iq' => 100]);
        $crew = $this->makeCrewWithMembers((int) $leader['id'], 3, 10);

        $result = heist_start((int) $crew['id'], 1, (int) $leader['id']);
        $this->assertTrue($result['ok']);
        $instanceId = $result['instance_id'];

        $result = heist_abandon($instanceId, (int) $leader['id']);
        $this->assertTrue($result['ok']);

        $instance = heist_get_instance($instanceId);
        $this->assertSame('abandoned', $instance['status']);
    }

    public function testHeistPhasesDataStructure(): void
    {
        $heists = heist_get_all();
        $this->assertGreaterThan(0, count($heists));

        foreach ($heists as $h) {
            $phases = heist_get_phases($h);
            $this->assertIsArray($phases);
            $this->assertGreaterThan(0, count($phases));

            foreach ($phases as $phase) {
                $this->assertArrayHasKey('name', $phase);
                $this->assertArrayHasKey('description', $phase);
                $this->assertArrayHasKey('requirements', $phase);
                $this->assertArrayHasKey('xp', $phase);
                $this->assertArrayHasKey('money', $phase);
            }
        }
    }
}