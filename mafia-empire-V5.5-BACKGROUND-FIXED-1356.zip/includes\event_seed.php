<?php
/**
 * Eye Of The Mafia - events schema + default seed data.
 *
 * Creates the events subsystem tables (idempotently) and seeds the built-in
 * daily, weekly and seasonal events plus their challenges.
 *
 * It owns its own DDL because the installer and test bootstrap run seed()
 * *before* automatic migrations, so sql/migrations/9.sql (which mirrors this
 * schema for upgrades of existing installations) may not have run yet.
 *
 * Safe to call repeatedly: tables use IF NOT EXISTS and events/challenges are
 * guarded on their unique codes.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

/**
 * DDL for the events subsystem. Mirrored by sql/migrations/9.sql.
 *
 * @return string[]
 */
function event_schema_statements(): array
{
    return [
        "CREATE TABLE IF NOT EXISTS events (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            code VARCHAR(50) NOT NULL UNIQUE,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            type ENUM('daily','weekly','seasonal','special') NOT NULL DEFAULT 'special',
            start_date DATETIME NULL,
            end_date DATETIME NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            config JSON,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_active_dates (is_active, start_date, end_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS event_challenges (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_id INT UNSIGNED NOT NULL,
            code VARCHAR(50) NOT NULL,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            target_value INT NOT NULL DEFAULT 1,
            metric VARCHAR(50) NOT NULL,
            reward_xp INT NOT NULL DEFAULT 0,
            reward_money INT NOT NULL DEFAULT 0,
            reward_points INT NOT NULL DEFAULT 0,
            reward_items JSON,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            sort_order INT NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_event (event_id),
            UNIQUE KEY uniq_event_code (event_id, code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS user_event_progress (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            event_id INT UNSIGNED NOT NULL,
            challenge_id INT UNSIGNED NOT NULL,
            current_value INT NOT NULL DEFAULT 0,
            completed TINYINT(1) NOT NULL DEFAULT 0,
            claimed TINYINT(1) NOT NULL DEFAULT 0,
            completed_at DATETIME NULL,
            claimed_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY idx_user_event (user_id, event_id),
            UNIQUE KEY uniq_user_challenge (user_id, challenge_id),
            KEY idx_completed (completed, claimed)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS event_rewards_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            event_id INT UNSIGNED NOT NULL,
            challenge_id INT UNSIGNED NULL,
            reward_type VARCHAR(20) NOT NULL,
            reward_value VARCHAR(255) NOT NULL,
            claimed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_user_event (user_id, event_id),
            KEY idx_claimed (claimed_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ];
}

/** Create any missing events tables. */
function event_ensure_tables(): void
{
    foreach (event_schema_statements() as $sql) {
        db()->exec($sql);
    }
}

/**
 * Map a challenge code (e.g. "missions_5", "boss", "gamble_50000") to the
 * metric it advances and the target value encoded in its suffix.
 *
 * @return array{0:string,1:int}
 */
function event_challenge_rule(string $code): array
{
    $target = (int) filter_var($code, FILTER_SANITIZE_NUMBER_INT) ?: 1;

    if (str_contains($code, 'mission')) {
        return ['missions_done', $target];
    }
    if (str_contains($code, 'job')) {
        return ['crimes_done', $target];
    }
    if (str_contains($code, 'win') || str_contains($code, 'kill')) {
        return ['kills', $target];
    }
    if (str_contains($code, 'boss')) {
        return ['boss_kills', $target];
    }
    if (str_contains($code, 'gamble')) {
        return ['casino_won', $target];
    }
    return ['missions_done', 1];
}

/**
 * Resolve the [start, end] window for an event config.
 *
 * @return array{0:?DateTime, 1:?DateTime}
 */
function event_config_dates(array $config, string $year): array
{
    $start = null;
    $end = null;

    if (isset($config['duration_hours'])) {
        $start = new DateTime('today');
        $end = (clone $start)->modify('+' . (int) $config['duration_hours'] . ' hours');
    } elseif (isset($config['start_date']) && $config['start_date'] !== 'dynamic') {
        $start = DateTime::createFromFormat('Y-m-d', $year . '-' . $config['start_date']);
        $end = DateTime::createFromFormat('Y-m-d', $year . '-' . $config['end_date']);
        if ($start && $end && $end <= $start) {
            // Window wraps the new year, e.g. Christmas Dec 20 - Jan 5.
            $end->modify('+1 year');
        }
    }

    return [$start, $end];
}

/** Built-in event definitions. */
function event_default_configs(): array
{
    return [
        'daily_challenge' => [
            'name' => 'Daily Challenge',
            'description' => 'Complete a daily task for bonus rewards.',
            'duration_hours' => 24,
            'frequency' => 'daily',
            'rewards' => ['xp' => 500, 'money' => 5000, 'points' => 10],
            'types' => [
                'mission' => 'Complete any mission',
                'job' => 'Complete a criminal job',
                'boss' => 'Defeat a boss',
                'kill' => 'Win a fight',
                'gamble' => 'Win at the casino',
            ],
        ],
        'weekly_challenge' => [
            'name' => 'Weekly Challenge',
            'description' => 'Complete a weekly goal for major rewards.',
            'duration_hours' => 168,
            'frequency' => 'weekly',
            'rewards' => ['xp' => 5000, 'money' => 50000, 'points' => 50],
            'types' => [
                'missions_5' => 'Complete 5 missions',
                'jobs_10' => 'Complete 10 criminal jobs',
                'wins_3' => 'Win 3 fights',
                'boss_2' => 'Defeat 2 bosses',
                'gamble_50000' => 'Win $50,000 at casino',
            ],
        ],
        'halloween' => [
            'name' => 'Halloween Haunt',
            'description' => 'Spooky season special event with unique rewards.',
            'start_date' => '10-25',
            'end_date' => '11-05',
            'recurring' => true,
            'rewards' => ['xp' => 10000, 'money' => 100000, 'points' => 100, 'items' => ['Halloween.ttf', 'Halloween Candy']],
            'special_missions' => true,
            'special_bosses' => true,
            'cosmetic_rewards' => ['Halloween.ttf', 'Pumpkin Lantern', 'Bat Wings'],
        ],
        'christmas' => [
            'name' => 'Christmas Caper',
            'description' => 'Holiday heist event with festive rewards.',
            'start_date' => '12-20',
            'end_date' => '01-05',
            'recurring' => true,
            'rewards' => ['xp' => 15000, 'money' => 200000, 'points' => 150],
            'special_missions' => true,
            'cosmetic_rewards' => ['Santa Hat', 'Candy Cane Bat', 'Snow Globe'],
        ],
        'new_year' => [
            'name' => "New Year's Raid",
            'description' => 'Ring in the new year with a bang.',
            'start_date' => '12-31',
            'end_date' => '01-07',
            'recurring' => true,
            'rewards' => ['xp' => 20000, 'money' => 500000, 'points' => 200],
            'special_bosses' => true,
            'cosmetic_rewards' => ['Party Hat', 'Confetti Cannon', 'Champagne Bottle'],
        ],
        'anniversary' => [
            'name' => 'Anniversary Gala',
            'description' => 'Celebrate another year of empire building.',
            'start_date' => '01-15',
            'end_date' => '01-22',
            'recurring' => true,
            'rewards' => ['xp' => 25000, 'money' => 1000000, 'points' => 500],
            'special_missions' => true,
            'special_bosses' => true,
            'cosmetic_rewards' => ['Anniversary Badge', 'Gold Watch', 'Crown'],
        ],
        'valentine' => [
            'name' => "Valentine's Vendetta",
            'description' => 'Love and war go hand in hand.',
            'start_date' => '02-10',
            'end_date' => '02-18',
            'recurring' => true,
            'rewards' => ['xp' => 8000, 'money' => 80000, 'points' => 80],
            'cosmetic_rewards' => ['Rose', 'Broken Heart', "Cupid's Bow"],
        ],
        'st_patrick' => [
            'name' => "St. Patrick's Heist",
            'description' => 'Steal the pot of gold.',
            'start_date' => '03-13',
            'end_date' => '03-20',
            'recurring' => true,
            'rewards' => ['xp' => 7000, 'money' => 70000, 'points' => 70],
            'cosmetic_rewards' => ['Four-Leaf Clover', 'Leprechaun Hat', 'Pot of Gold'],
        ],
        'easter' => [
            'name' => 'Easter Egg Hunt',
            'description' => 'Find the hidden eggs for rewards.',
            'start_date' => 'dynamic',
            'end_date' => 'dynamic',
            'recurring' => true,
            'rewards' => ['xp' => 5000, 'money' => 50000, 'points' => 50],
            'cosmetic_rewards' => ['Easter Egg', 'Bunny Ears', 'Carrot Dagger'],
        ],
        'independence_day' => [
            'name' => 'Independence Day Siege',
            'description' => 'Fireworks and firepower.',
            'start_date' => '07-01',
            'end_date' => '07-07',
            'recurring' => true,
            'rewards' => ['xp' => 12000, 'money' => 120000, 'points' => 120],
            'cosmetic_rewards' => ['Fireworks', 'Flag Cape', 'Eagle Pin'],
        ],
        'thanksgiving' => [
            'name' => 'Thanksgiving Takeover',
            'description' => 'Gobble up the competition.',
            'start_date' => '11-20',
            'end_date' => '11-30',
            'recurring' => true,
            'rewards' => ['xp' => 10000, 'money' => 100000, 'points' => 100],
            'cosmetic_rewards' => ['Turkey Leg', 'Pilgrim Hat', 'Cornucopia'],
        ],
    ];
}

/**
 * Create the events tables and seed the built-in events + challenges.
 * Idempotent: only missing rows are inserted.
 */
function event_seed_defaults(): void
{
    event_ensure_tables();
    $year = date('Y');

    foreach (event_default_configs() as $code => $config) {
        $eventId = (int) fetch_one('SELECT id FROM events WHERE code = ?', [$code], 0);
        if ($eventId === 0) {
            [$start, $end] = event_config_dates($config, $year);
            $eventId = insert('events', [
                'code'        => $code,
                'name'        => $config['name'],
                'description' => $config['description'] ?? '',
                // Seasonal configs have no frequency but belong in the seasonal section.
                'type'        => $config['frequency'] ?? 'seasonal',
                'start_date'  => $start ? $start->format('Y-m-d H:i:s') : null,
                'end_date'    => $end ? $end->format('Y-m-d H:i:s') : null,
                'is_active'   => 1,
                'config'      => json_encode($config),
            ]);
        }

        if (empty($config['types'])) {
            continue;
        }

        $rewardXp     = (int) ($config['rewards']['xp'] ?? 0);
        $rewardMoney  = (int) ($config['rewards']['money'] ?? 0);
        $rewardPoints = (int) ($config['rewards']['points'] ?? 0);
        $sort = 0;
        foreach ($config['types'] as $challengeCode => $desc) {
            $challengeCode = (string) $challengeCode;
            if (fetch_one('SELECT id FROM event_challenges WHERE event_id = ? AND code = ?', [$eventId, $challengeCode])) {
                $sort++;
                continue;
            }
            [$metric, $target] = event_challenge_rule($challengeCode);
            insert('event_challenges', [
                'event_id'      => $eventId,
                'code'          => $challengeCode,
                'name'          => $desc,
                'description'   => $desc,
                'target_value'  => $target,
                'metric'        => $metric,
                'reward_xp'     => $rewardXp,
                'reward_money'  => $rewardMoney,
                'reward_points' => $rewardPoints,
                'sort_order'    => $sort++,
            ]);
        }
    }
}
