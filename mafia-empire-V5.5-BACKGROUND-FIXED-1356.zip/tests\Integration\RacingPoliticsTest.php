<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

require_once __DIR__ . '/../../includes/racing.php';
require_once __DIR__ . '/../../includes/politics.php';

/**
 * Background-loop coverage for the street racing and mayor election systems,
 * which are driven by the cron tasks rather than by user requests.
 */
final class RacingPoliticsTest extends TestCase
{
    private function firstVehicleItemId(): int
    {
        return (int) fetch_one("SELECT id FROM items WHERE type = 'vehicle' ORDER BY id ASC LIMIT 1", [], 0);
    }

    private function firstTrackId(): int
    {
        return (int) fetch_one('SELECT id FROM race_tracks ORDER BY id ASC LIMIT 1', [], 0);
    }

    /** Create a user with one vehicle in their inventory. */
    private function makeRacer(int $vehicleItemId, array $overrides = []): array
    {
        $user = $this->makeUser($overrides);
        insert('user_items', [
            'user_id' => (int) $user['id'],
            'item_id' => $vehicleItemId,
            'qty' => 1,
            'equipped' => 0,
        ]);
        return $user;
    }

    private function vehicleRowId(int $userId): int
    {
        return (int) fetch_one('SELECT id FROM user_items WHERE user_id = ? ORDER BY id ASC LIMIT 1', [$userId], 0);
    }

    public function testRaceGetWithParticipantsKeepsEventId(): void
    {
        $trackId = $this->firstTrackId();
        if ($trackId <= 0) {
            $this->markTestSkipped('no race tracks seeded');
        }

        // Two races so the event id cannot coincidentally equal the track id.
        insert('race_events', ['track_id' => $trackId, 'status' => 'cancelled']);
        $raceId = insert('race_events', ['track_id' => $trackId, 'status' => 'waiting']);
        $this->assertNotSame($trackId, (int) $raceId);

        $race = race_get_with_participants((int) $raceId);
        $this->assertNotNull($race);
        $this->assertSame((int) $raceId, (int) $race['id'], 'the event id must not be overwritten by the track id');
        $this->assertSame($trackId, (int) $race['track_id']);
    }

    public function testRaceCronStartsAndSettles(): void
    {
        $itemId = $this->firstVehicleItemId();
        $trackId = $this->firstTrackId();
        if ($itemId <= 0 || $trackId <= 0) {
            $this->markTestSkipped('no vehicles or race tracks seeded');
        }

        $a = $this->makeRacer($itemId, ['money' => 10000]);
        $b = $this->makeRacer($itemId, ['money' => 10000]);

        $raceId = insert('race_events', [
            'track_id' => $trackId,
            'status' => 'waiting',
            'max_racers' => 8,
            'entry_fee_money' => 0,
            'entry_fee_bullets' => 0,
            'prize_pool_money' => 1000,
            'prize_pool_xp' => 100,
            'prize_pool_points' => 10,
        ]);
        insert('race_participants', ['race_id' => $raceId, 'user_id' => (int) $a['id'], 'vehicle_id' => $this->vehicleRowId((int) $a['id'])]);
        insert('race_participants', ['race_id' => $raceId, 'user_id' => (int) $b['id'], 'vehicle_id' => $this->vehicleRowId((int) $b['id'])]);
        q('UPDATE race_events SET created_at = ? WHERE id = ?', [date('Y-m-d H:i:s', time() - 300), $raceId]);

        $summary = race_cron();
        $this->assertGreaterThanOrEqual(1, $summary['races_started']);
        $this->assertSame('racing', fetch_one('SELECT status FROM race_events WHERE id = ?', [$raceId]));

        // Let it run past the settle window.
        q('UPDATE race_events SET started_at = ? WHERE id = ?', [date('Y-m-d H:i:s', time() - 300), $raceId]);
        $summary2 = race_cron();
        $this->assertGreaterThanOrEqual(1, $summary2['races_finished']);

        $row = fetch('SELECT status, finished_at FROM race_events WHERE id = ?', [$raceId]);
        $this->assertSame('finished', $row['status']);
        $this->assertNotNull($row['finished_at']);

        $positions = fetch_all('SELECT position FROM race_participants WHERE race_id = ?', [$raceId]);
        $this->assertCount(2, $positions);
        foreach ($positions as $p) {
            $this->assertNotNull($p['position'], 'every racer should be assigned a finishing position');
        }
    }

    public function testRaceCronCancelsStaleWaitingRaceAndRefunds(): void
    {
        $itemId = $this->firstVehicleItemId();
        $trackId = $this->firstTrackId();
        if ($itemId <= 0 || $trackId <= 0) {
            $this->markTestSkipped('no vehicle items or tracks seeded');
        }

        $user = $this->makeRacer($itemId, ['money' => 1000, 'bullets' => 10]);
        $raceId = insert('race_events', [
            'track_id' => $trackId,
            'status' => 'waiting',
            'max_racers' => 8,
            'entry_fee_money' => 250,
            'entry_fee_bullets' => 5,
            'prize_pool_money' => 0,
            'prize_pool_xp' => 0,
            'prize_pool_points' => 0,
        ]);
        insert('race_participants', [
            'race_id' => $raceId,
            'user_id' => (int) $user['id'],
            'vehicle_id' => $this->vehicleRowId((int) $user['id']),
        ]);
        q('UPDATE race_events SET created_at = ? WHERE id = ?', [date('Y-m-d H:i:s', time() - 7200), $raceId]);

        $summary = race_cron();
        $this->assertGreaterThanOrEqual(1, $summary['races_cancelled']);
        $this->assertSame('cancelled', fetch_one('SELECT status FROM race_events WHERE id = ?', [$raceId]));

        $after = $this->freshUser((int) $user['id']);
        $this->assertSame(1250, (int) $after['money'], 'entry fee should be refunded');
        $this->assertSame(15, (int) $after['bullets'], 'entry bullets should be refunded');
    }

    public function testPoliticsAdvancesElectionCycle(): void
    {
        $low = $this->makeUser();
        $high = $this->makeUser();
        $electionId = insert('mayor_elections', [
            'election_number' => 1,
            'status' => 'nominations',
            'term_start' => date('Y-m-d'),
            'term_end' => date('Y-m-d', strtotime('+7 days')),
        ]);
        insert('mayor_candidates', ['election_id' => $electionId, 'user_id' => (int) $low['id'], 'votes' => 1]);
        insert('mayor_candidates', ['election_id' => $electionId, 'user_id' => (int) $high['id'], 'votes' => 9]);
        q('UPDATE mayor_elections SET created_at = ? WHERE id = ?', [date('Y-m-d H:i:s', time() - 4 * 86400), $electionId]);

        // One overdue cycle catches up end-to-end: nominations -> voting -> finished.
        $result = politics_advance_elections();
        $this->assertGreaterThanOrEqual(1, $result['to_voting']);
        $this->assertGreaterThanOrEqual(1, $result['finished']);

        $row = fetch('SELECT status, mayor_id FROM mayor_elections WHERE id = ?', [$electionId]);
        $this->assertSame('finished', $row['status']);
        $this->assertSame((int) $high['id'], (int) $row['mayor_id'], 'the candidate with the most votes should win');

        // A fresh cycle is queued once nothing is pending.
        $this->assertSame(1, (int) fetch_one("SELECT COUNT(*) FROM mayor_elections WHERE status IN ('nominations','voting')", [], 0));
    }

    public function testPoliticsAbandonsElectionWithoutTwoCandidates(): void
    {
        $only = $this->makeUser();
        $electionId = insert('mayor_elections', [
            'election_number' => 1,
            'status' => 'nominations',
            'term_start' => date('Y-m-d'),
            'term_end' => date('Y-m-d', strtotime('+7 days')),
        ]);
        insert('mayor_candidates', ['election_id' => $electionId, 'user_id' => (int) $only['id'], 'votes' => 3]);
        q('UPDATE mayor_elections SET created_at = ? WHERE id = ?', [date('Y-m-d H:i:s', time() - 4 * 86400), $electionId]);

        politics_advance_elections();

        $row = fetch('SELECT status, mayor_id FROM mayor_elections WHERE id = ?', [$electionId]);
        $this->assertSame('finished', $row['status']);
        $this->assertNull($row['mayor_id'], 'no mayor should be installed with fewer than two candidates');
    }

    public function testRaceGetActiveIncludesParticipants(): void
    {
        $itemId = $this->firstVehicleItemId();
        $trackId = $this->firstTrackId();
        if ($itemId <= 0 || $trackId <= 0) {
            $this->markTestSkipped('no vehicles or race tracks seeded');
        }

        $a = $this->makeRacer($itemId);
        $raceId = insert('race_events', ['track_id' => $trackId, 'status' => 'waiting']);
        insert('race_participants', [
            'race_id' => $raceId,
            'user_id' => (int) $a['id'],
            'vehicle_id' => $this->vehicleRowId((int) $a['id']),
        ]);

        $races = race_get_active();
        $row = null;
        foreach ($races as $r) {
            if ((int) $r['id'] === (int) $raceId) { $row = $r; }
        }
        $this->assertNotNull($row);
        $this->assertIsArray($row['participants']);
        $this->assertCount(1, $row['participants']);
        $this->assertSame((int) $a['id'], (int) $row['participants'][0]['user_id']);
    }

    public function testRaceBetHistoryKeepsBetStatusNotEventStatus(): void
    {
        $trackId = $this->firstTrackId();
        if ($trackId <= 0) {
            $this->markTestSkipped('no race tracks seeded');
        }

        $bettor = $this->makeUser();
        $target = $this->makeUser();
        $raceId = insert('race_events', [
            'track_id' => $trackId,
            'status' => 'finished',
            'finished_at' => date('Y-m-d H:i:s'),
        ]);
        insert('race_bets', [
            'race_id' => $raceId,
            'bettor_id' => (int) $bettor['id'],
            'target_user_id' => (int) $target['id'],
            'amount_money' => 500,
            'payout' => 0,
            'status' => 'lost',
        ]);

        $history = race_get_bet_history((int) $bettor['id']);
        $this->assertCount(1, $history);
        $this->assertSame('lost', $history[0]['status'], 'bet status was clobbered by the event status');
        $this->assertSame((int) $target['id'], (int) $history[0]['target_user_id']);
        $this->assertSame(500, (int) $history[0]['amount_money']);
        $this->assertArrayHasKey('track_name', $history[0]);
        $this->assertArrayHasKey('target_name', $history[0]);
    }

    public function testCityPolicyMultipliersAffectEconomy(): void
    {
        try {
            q('UPDATE city_policies SET is_active = 0, enacted_by = NULL, expires_at = NULL');

            // Only an active policy with a matching effect type should apply.
            q("UPDATE city_policies SET is_active = 1 WHERE code = 'tax_cut'");
            $this->assertSame(1.0, politics_apply_policy_effect('market_fee_multiplier', 1.0));
            $this->assertEqualsWithDelta(1.10, politics_apply_policy_effect('money_multiplier', 1.0), 0.0001);

            // Public Healthcare (heal_rate 1.50) shortens hospital stays.
            q("UPDATE city_policies SET is_active = 1 WHERE code = 'healthcare'");
            $user = $this->makeUser();
            hospitalize((int) $user['id'], 150, 'policy test');
            $until = strtotime((string) fetch_one('SELECT hospital_until FROM users WHERE id = ?', [(int) $user['id']]));
            $remaining = $until - time();
            $this->assertGreaterThan(0, $remaining);
            $this->assertLessThan(150, $remaining, 'healthcare policy should reduce the hospital duration');
        } finally {
            q('UPDATE city_policies SET is_active = 0, enacted_by = NULL, expires_at = NULL');
        }
    }
}
