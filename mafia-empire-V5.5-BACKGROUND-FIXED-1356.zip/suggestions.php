<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$suggestionId = isset($_GET['id']) ? (int) $_GET['id'] : null;
$statusFilter = $_GET['status'] ?? 'all';
$sort = $_GET['sort'] ?? 'votes';

// POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $title = trim($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');
        if ($title && $body) {
            insert('suggestions', ['user_id' => $u['id'], 'title' => $title, 'body' => $body, 'status' => 'new']);
            flash('Suggestion submitted.', 'success');
        }
        redirect('suggestions.php');
    } elseif ($action === 'vote' && $suggestionId) {
        $value = (int) ($_POST['value'] ?? 0);
        if (!in_array($value, [1, -1])) { flash('Invalid vote.', 'error'); }
        else {
            $existing = fetch('SELECT value FROM suggestion_votes WHERE user_id = ? AND suggestion_id = ?', [$u['id'], $suggestionId]);
            if ($existing) {
                if ($existing['value'] == $value) { q('DELETE FROM suggestion_votes WHERE user_id = ? AND suggestion_id = ?', [$u['id'], $suggestionId]); flash('Vote removed.', 'success'); }
                else { q('UPDATE suggestion_votes SET value = ? WHERE user_id = ? AND suggestion_id = ?', [$value, $u['id'], $suggestionId]); flash('Vote changed.', 'success'); }
            } else {
                insert('suggestion_votes', ['user_id' => $u['id'], 'suggestion_id' => $suggestionId, 'value' => $value]);
                flash('Voted.', 'success');
            }
        }
    } elseif ($action === 'comment' && $suggestionId) {
        $body = trim($_POST['body'] ?? '');
        if ($body) {
            insert('suggestion_comments', ['suggestion_id' => $suggestionId, 'user_id' => $u['id'], 'body' => $body]);
            flash('Comment posted.', 'success');
        }
    } elseif ($action === 'set_status' && $suggestionId && (int) $u['is_admin'] === 1) {
        $status = $_POST['status'] ?? '';
        $allowed = ['new','open','locked','implemented','rejected'];
        if (in_array($status, $allowed)) {
            q('UPDATE suggestions SET status = ? WHERE id = ?', [$status, $suggestionId]);
            flash('Status updated.', 'success');
        }
    }
    redirect('suggestions.php' . ($suggestionId ? '?id=' . $suggestionId : ''));
}

$page_title = 'Suggestions';
require __DIR__ . '/includes/header.php';

if ($suggestionId) {
    // View single suggestion
    $s = fetch('SELECT s.*, u.username, u.avatar FROM suggestions s JOIN users u ON u.id = s.user_id WHERE s.id = ?', [$suggestionId]);
    if (!$s) { echo '<div class="card"><p class="muted">Suggestion not found.</p></div>'; require __DIR__ . '/includes/footer.php'; exit; }
    
    $upvotes = (int) fetch_one('SELECT COALESCE(SUM(value),0) FROM suggestion_votes WHERE suggestion_id = ? AND value = 1', [$suggestionId], 0);
    $downvotes = (int) fetch_one('SELECT COALESCE(SUM(value),0) FROM suggestion_votes WHERE suggestion_id = ? AND value = -1', [$suggestionId], 0);
    $myVote = fetch_one('SELECT value FROM suggestion_votes WHERE user_id = ? AND suggestion_id = ?', [$u['id'], $suggestionId], 0);
    $comments = fetch_all('SELECT sc.*, u.username, u.avatar FROM suggestion_comments sc JOIN users u ON u.id = sc.user_id WHERE sc.suggestion_id = ? ORDER BY sc.created_at', [$suggestionId]);
    
?>
<div class="card" style="margin-bottom:18px">
  <a class="btn btn-sm" href="<?= e(url('suggestions.php')) ?>">&larr; Back to all</a>
</div>

<div class="card">
  <div class="panel-heading"><?= e($s['title']) ?> <span class="tag tag-<?= match($s['status']) { 'implemented' => 'uncommon', 'rejected' => 'common', 'locked' => 'common', default => 'uncommon' } ?>"><?= ucfirst($s['status']) ?></span></div>
  <div class="small muted">by <a href="<?= e(url('profile.php?id=' . (int) $s['user_id'])) ?>"><?= e($s['username']) ?></a> · <?= date('M j, Y H:i', strtotime($s['created_at'])) ?></div>
  <div style="margin-top:10px;white-space:pre-wrap"><?= e($s['body']) ?></div>
  
  <div class="pill-row" style="margin-top:14px">
    <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="vote"><input type="hidden" name="suggestion_id" value="<?= (int) $s['id'] ?>"><input type="hidden" name="value" value="1"><button class="pill<?= $myVote == 1 ? ' on' : '' ?>" type="submit">▲ <?= $upvotes ?></button></form>
    <form method="post" style="display:inline;margin-left:8px"><?= csrf_field() ?><input type="hidden" name="action" value="vote"><input type="hidden" name="suggestion_id" value="<?= (int) $s['id'] ?>"><input type="hidden" name="value" value="-1"><button class="pill<?= $myVote == -1 ? ' on' : '' ?>" type="submit">▼ <?= abs($downvotes) ?></button></form>
  </div>
  
  <?php if ((int) $u['is_admin'] === 1): ?>
    <form method="post" style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="set_status">
      <input type="hidden" name="suggestion_id" value="<?= (int) $s['id'] ?>">
      <select name="status">
        <option value="new" <?= $s['status']==='new'?'selected':'' ?>>New</option>
        <option value="open" <?= $s['status']==='open'?'selected':'' ?>>Open</option>
        <option value="locked" <?= $s['status']==='locked'?'selected':'' ?>>Locked</option>
        <option value="implemented" <?= $s['status']==='implemented'?'selected':'' ?>>Implemented</option>
        <option value="rejected" <?= $s['status']==='rejected'?'selected':'' ?>>Rejected</option>
      </select>
      <button class="btn btn-gold btn-sm" type="submit">Update Status</button>
    </form>
  <?php endif; ?>
  
  <?php if ($comments): ?>
    <div style="margin-top:18px">
      <?php foreach ($comments as $c): ?>
        <div style="padding:10px;border-bottom:1px dashed var(--line)">
          <b><a href="<?= e(url('profile.php?id=' . (int) $c['user_id'])) ?>"><?= e($c['username']) ?></a></b>
          <span class="muted small"> · <?= date('M j, H:i', strtotime($c['created_at'])) ?></span>
          <div style="margin-top:6px;white-space:pre-wrap"><?= e($c['body']) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  
  <form method="post" style="margin-top:14px;display:grid;gap:8px;max-width:600px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="comment">
    <input type="hidden" name="suggestion_id" value="<?= (int) $s['id'] ?>">
    <label>Comment <textarea name="body" required placeholder="Add a comment..."></textarea></label>
    <button class="btn btn-gold" type="submit">Post Comment</button>
  </form>
</div>

<?php
} else {
    // List suggestions with filters
    $statuses = ['all' => 'All', 'new' => 'New', 'open' => 'Open', 'locked' => 'Locked', 'implemented' => 'Implemented', 'rejected' => 'Rejected'];
    $sorts = ['votes' => 'Most Voted', 'newest' => 'Newest', 'oldest' => 'Oldest'];
    
    $where = 'WHERE 1=1';
    if ($statusFilter !== 'all') { $where .= ' AND s.status = ?'; }
    
    $orderMap = ['votes' => 'net_votes DESC, s.created_at DESC', 'newest' => 's.created_at DESC', 'oldest' => 's.created_at ASC'];
    $order = $orderMap[$sort] ?? $orderMap['votes'];
    
    $params = $statusFilter !== 'all' ? [$statusFilter] : [];
    $suggestions = fetch_all("
        SELECT s.*, u.username,
            (SELECT COALESCE(SUM(value),0) FROM suggestion_votes sv WHERE sv.suggestion_id = s.id AND sv.value = 1) AS upvotes,
            (SELECT COALESCE(SUM(value),0) FROM suggestion_votes sv WHERE sv.suggestion_id = s.id AND sv.value = -1) AS downvotes,
            (SELECT COALESCE(SUM(value),0) FROM suggestion_votes sv WHERE sv.suggestion_id = s.id) AS net_votes,
            (SELECT COUNT(*) FROM suggestion_comments sc WHERE sc.suggestion_id = s.id) AS comment_count
        FROM suggestions s JOIN users u ON u.id = s.user_id
        $where
        ORDER BY $order
    ", $params);
?>
<div class="card">
  <div class="panel-heading">Suggestions</div>
  <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">
    <select name="status" onchange="this.form.submit()">
      <?php foreach ($statuses as $k => $v): ?><option value="<?= $k ?>" <?= $statusFilter === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach; ?>
    </select>
    <select name="sort" onchange="this.form.submit()">
      <?php foreach ($sorts as $k => $v): ?><option value="<?= $k ?>" <?= $sort === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach; ?>
    </select>
    <a class="btn btn-gold btn-sm" href="#newSuggestion" onclick="document.getElementById('newSuggestion').scrollIntoView()">New Suggestion</a>
  </form>
</div>

<div class="card" id="newSuggestion">
  <div class="panel-heading">Submit Suggestion</div>
  <form method="post" style="max-width:700px;display:grid;gap:10px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">
    <label>Title <input name="title" maxlength="190" required></label>
    <label>Description <textarea name="body" required></textarea></label>
    <button class="btn btn-gold" type="submit">Submit</button>
  </form>
</div>

<?php if (!$suggestions): ?>
  <div class="card" style="margin-top:18px"><p class="muted">No suggestions yet.</p></div>
<?php else: foreach ($suggestions as $s):
    $myVote = fetch_one('SELECT value FROM suggestion_votes WHERE user_id = ? AND suggestion_id = ?', [$u['id'], $s['id']], 0);
?>
<div class="card" style="margin-top:10px">
  <a href="<?= e(url('suggestions.php?id=' . (int) $s['id'])) ?>">
    <b><?= e($s['title']) ?></b>
    <div class="small muted">by <?= e($s['username']) ?> · <?= date('M j, Y', strtotime($s['created_at'])) ?> · <span class="tag tag-<?= match($s['status']) { 'implemented' => 'uncommon', 'rejected' => 'common', 'locked' => 'common', default => 'uncommon' } ?>"><?= ucfirst($s['status']) ?></span> · Votes: <b><?= (int) $s['net_votes'] ?></b> · Comments: <?= (int) $s['comment_count'] ?></div>
  </a>
</div>
<?php endforeach; endif; }
require __DIR__ . '/includes/footer.php'; ?>