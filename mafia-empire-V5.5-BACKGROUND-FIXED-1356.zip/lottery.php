<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// Auto-draw old open draws
$oldDraws = fetch_all('SELECT * FROM lottery_draws WHERE status = ? AND draw_date < CURDATE()', ['open']);
foreach ($oldDraws as $od) {
    $winning = mt_rand(0, 999);
    q('UPDATE lottery_draws SET winning_number = ?, status = ? WHERE id = ?', [$winning, 'drawn', $od['id']]);
    $winners = fetch_all('SELECT * FROM lottery_tickets WHERE draw_id = ? AND number = ?', [$od['id'], $winning]);
    if ($winners) {
        $split = (int) floor((int) $od['pot'] / count($winners));
        foreach ($winners as $w) {
            add_money($w['user_id'], $split, 'Lottery win');
            notify($w['user_id'], 'Your lottery ticket matched! You won ' . money($split) . '.', 'lottery.php');
        }
    }
}

// POST: buy ticket
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $number = (int) ($_POST['number'] ?? 0);
    $draw = fetch('SELECT * FROM lottery_draws WHERE status = ? ORDER BY draw_date DESC LIMIT 1', ['open']);
    if (!$draw) {
        flash('No active draw.', 'error');
    } elseif ($number < 0 || $number > 999) {
        flash('Number must be 0-999.', 'error');
    } elseif ((int) $u['money'] < 500) {
        flash('Ticket costs $500.', 'error');
    } else {
        add_money($u['id'], -500, 'Lottery ticket');
        q('UPDATE lottery_draws SET pot = pot + 500 WHERE id = ?', [$draw['id']]);
        insert('lottery_tickets', ['user_id' => $u['id'], 'draw_id' => $draw['id'], 'number' => $number]);
        flash('Ticket purchased for number ' . str_pad($number, 3, '0', STR_PAD_LEFT) . '.', 'success');
    }
    redirect('lottery.php');
}

$page_title = 'Lottery';
require __DIR__ . '/includes/header.php';

$u = current_user();
$draw = fetch('SELECT * FROM lottery_draws WHERE status = ? ORDER BY draw_date DESC LIMIT 1', ['open']);
$past = fetch_all('SELECT * FROM lottery_draws WHERE status = ? ORDER BY draw_date DESC LIMIT 10', ['drawn']);
$myTickets = $draw ? fetch_all('SELECT * FROM lottery_tickets WHERE user_id = ? AND draw_id = ?', [$u['id'], $draw['id']]) : [];
?>
<div class="card">
  <div class="panel-heading">Lottery</div>
  <p class="muted small">Tickets cost $500. Pick a number 000-999. Draw occurs daily. Exact match splits the pot.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<?php if ($draw): ?>
<div class="card">
  <div class="panel-heading">Today's Draw</div>
  <div class="stat"><span>Pot</span><b><?= money($draw['pot']) ?></b></div>
  <div class="stat"><span>Draw Date</span><b><?= date('M j, Y', strtotime($draw['draw_date'])) ?></b></div>
  <div class="stat"><span>Your Tickets</span><b><?= count($myTickets) ?></b></div>
  
  <form method="post" style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap">
    <?= csrf_field() ?>
    <input type="number" name="number" min="0" max="999" placeholder="Number (000-999)" required style="width:120px">
    <button class="btn btn-gold" type="submit">Buy Ticket ($500)</button>
  </form>
  
  <?php if ($myTickets): ?>
    <div style="margin-top:10px">
      <b>Your numbers:</b>
      <div class="pill-row" style="margin-top:6px">
        <?php foreach ($myTickets as $t): ?><span class="pill"><?= str_pad($t['number'], 3, '0', STR_PAD_LEFT) ?></span><?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php else: ?>
<div class="card"><p class="muted">No active draw at the moment.</p></div>
<?php endif; ?>

<div class="card" style="margin-top:18px">
  <div class="panel-heading">Past Draws</div>
  <?php if (!$past): ?>
    <p class="muted">No past draws.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Date</th><th>Winning #</th><th>Pot</th><th>Winners</th></tr>
      <?php foreach ($past as $p):
        $wc = (int) fetch_one('SELECT COUNT(*) FROM lottery_tickets WHERE draw_id = ? AND number = ?', [$p['id'], $p['winning_number']], 0);
      ?>
        <tr>
          <td><?= date('M j, Y', strtotime($p['draw_date'])) ?></td>
          <td><?= str_pad($p['winning_number'], 3, '0', STR_PAD_LEFT) ?></td>
          <td><?= money($p['pot']) ?></td>
          <td><?= $wc ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>