<?php
/**
 * Mafia Empire - Web Push (VAPID) support.
 *
 * Pure-PHP implementation of RFC 8291 (message encryption) and RFC 8292
 * (VAPID), with no external libraries. Everything degrades to a no-op when
 * no key pair is configured, so the game behaves identically without it.
 *
 * Generate a key pair with:  php cron/run.php vapid
 */

/** URL-safe base64 helpers. */
function push_b64url_encode(string $bin): string
{
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

function push_b64url_decode(string $s): string
{
    $s = strtr($s, '-_', '+/');
    $pad = strlen($s) % 4;
    if ($pad) {
        $s .= str_repeat('=', 4 - $pad);
    }
    return base64_decode($s) ?: '';
}

/** Ordered list of candidate openssl.cnf paths that exist on this host. */
function push_openssl_config_candidates(): array
{
    $dir = '';
    if (defined('PHP_BINARY') && PHP_BINARY) {
        $dir = dirname(PHP_BINARY);
    } elseif (defined('PHP_BINDIR')) {
        $dir = PHP_BINDIR;
    }
    $sep = DIRECTORY_SEPARATOR;
    $list = [];
    $env = getenv('OPENSSL_CONF');
    if ($env) {
        $list[] = $env;
    }
    foreach (['extras/openssl/openssl.cnf', 'extras/ssl/openssl.cnf', 'extras/openssl.cnf'] as $rel) {
        if ($dir !== '') {
            $list[] = $dir . $sep . str_replace('/', $sep, $rel);
        }
    }
    $list[] = 'C:/xampp/php/extras/openssl/openssl.cnf';
    $list[] = 'C:/xampp/php/extras/ssl/openssl.cnf';
    $list[] = 'C:/xampp/apache/conf/openssl.cnf';
    $list[] = '/etc/ssl/openssl.cnf';
    $list[] = '/usr/lib/ssl/openssl.cnf';
    $list[] = '/usr/local/ssl/openssl.cnf';

    $out = [];
    foreach ($list as $c) {
        if ($c !== '' && is_file($c) && !in_array($c, $out, true)) {
            $out[] = $c;
        }
    }
    return $out;
}

/**
 * Find an openssl.cnf that can both generate AND export an EC key. Some
 * shipped configs (e.g. Apache's on XAMPP) generate a key but cannot export it.
 */
function push_openssl_config(): ?string
{
    static $done = false;
    static $cfg = null;
    if ($done) {
        return $cfg;
    }
    $done = true;

    foreach (push_openssl_config_candidates() as $c) {
        $key = openssl_pkey_new(['config' => $c, 'curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
        $pem = '';
        $ok = false;
        if ($key) {
            $ok = @openssl_pkey_export($key, $pem, null, ['config' => $c]) && is_string($pem) && strpos($pem, 'BEGIN') !== false;
        }
        while (openssl_error_string() !== false) {
            // Drain the error queue between attempts.
        }
        if ($ok) {
            return $cfg = $c;
        }
    }
    // Try without config
    $key = @openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
    $pem = '';
    if ($key && @openssl_pkey_export($key, $pem)) {
        return $cfg = null;
    }
    return $cfg = null;
}

/** Create a fresh P-256 key pair, tolerating hosts without a default cnf. */
function push_ec_key_new()
{
    $args = ['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC];
    $cfg = push_openssl_config();
    if ($cfg !== null) {
        $args['config'] = $cfg;
        $key = @openssl_pkey_new($args);
        if ($key) return $key;
    }
    $key = @openssl_pkey_new($args);
    if ($key) return $key;
    // Fallback
    $args2 = ['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC, 'private_key_bits' => 256];
    return @openssl_pkey_new($args2);
}

/** X9.62 uncompressed point (0x04 || X || Y) from openssl EC details. */
function push_ec_point(array $ec): string
{
    $x = str_pad(substr($ec['x'] ?? '', -32), 32, "\x00", STR_PAD_LEFT);
    $y = str_pad(substr($ec['y'] ?? '', -32), 32, "\x00", STR_PAD_LEFT);
    return "\x04" . $x . $y;
}

/** Wrap a raw P-256 point in a SubjectPublicKeyInfo PEM (prime256v1). */
function push_point_to_pem(string $point): string
{
    $alg = "\x30\x13\x06\x07\x2a\x86\x48\xce\x3d\x02\x01\x06\x08\x2a\x86\x48\xce\x3d\x03\x01\x07";
    $der = "\x30\x59" . $alg . "\x03\x42\x00" . $point;
    return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
}

/** Convert an ECDSA DER signature to the raw 64-byte R||S used by JWS. */
function push_der_to_raw_sig(string $der): ?string
{
    $o = 0;
    if (($der[$o++] ?? '') !== "\x30") {
        return null;
    }
    $len = ord($der[$o++]);
    if ($len & 0x80) {
        $n = $len & 0x7f;
        $len = 0;
        for ($i = 0; $i < $n; $i++) {
            $len = ($len << 8) | ord($der[$o++]);
        }
    }
    $parts = [];
    for ($k = 0; $k < 2; $k++) {
        if (($der[$o++] ?? '') !== "\x02") {
            return null;
        }
        $l = ord($der[$o++]);
        if ($l & 0x80) {
            $n = $l & 0x7f;
            $l = 0;
            for ($i = 0; $i < $n; $i++) {
                $l = ($l << 8) | ord($der[$o++]);
            }
        }
        $v = ltrim(substr($der, $o, $l), "\x00");
        $o += $l;
        if (strlen($v) > 32) {
            return null;
        }
        $parts[] = str_pad($v, 32, "\x00", STR_PAD_LEFT);
    }
    return $parts[0] . $parts[1];
}

/** Resolve VAPID key material (config/vapid.php first, then env constants). */
function push_keys(): array
{
    // Test seam: integration tests can inject a throwaway key pair.
    if (!empty($GLOBALS['__push_keys_override'])) {
        $o = $GLOBALS['__push_keys_override'];
        return [
            'public'  => (string) ($o['public'] ?? ''),
            'private' => (string) ($o['private'] ?? ''),
            'subject' => (string) ($o['subject'] ?? 'mailto:tests@mafia-empire.test'),
        ];
    }
    static $keys = null;
    if ($keys !== null) {
        return $keys;
    }
    $subject = defined('VAPID_SUBJECT') ? VAPID_SUBJECT : 'mailto:admin@example.com';

    $file = __DIR__ . '/../config/vapid.php';
    if (is_file($file)) {
        $c = require $file;
        if (is_array($c) && !empty($c['public']) && !empty($c['private'])) {
            return $keys = ['public' => $c['public'], 'private' => $c['private'], 'subject' => $c['subject'] ?? $subject];
        }
    }

    $pub = defined('VAPID_PUBLIC_KEY') ? VAPID_PUBLIC_KEY : '';
    $priv = defined('VAPID_PRIVATE_KEY') ? VAPID_PRIVATE_KEY : '';
    if ($pub !== '' && $priv !== '') {
        if (is_file($priv)) {
            $priv = (string) file_get_contents($priv);
        } elseif (strpos($priv, 'BEGIN') === false) {
            $dec = base64_decode($priv, true);
            if ($dec && strpos($dec, 'BEGIN') !== false) {
                $priv = $dec;
            }
        }
        return $keys = ['public' => $pub, 'private' => $priv, 'subject' => $subject];
    }

    return $keys = ['public' => '', 'private' => '', 'subject' => $subject];
}

/** Is Web Push usable in this environment/configuration? */
function push_available(): bool
{
    $k = push_keys();
    return $k['public'] !== '' && $k['private'] !== ''
        && function_exists('openssl_pkey_derive') && function_exists('hash_hkdf');
}

/** The application server public key (base64url) for the browser. */
function vapid_public_key(): string
{
    return push_available() ? push_keys()['public'] : '';
}

/** Build the VAPID Authorization header for a push endpoint. */
function push_vapid_authorization(string $endpoint): ?string
{
    $k = push_keys();
    if ($k['public'] === '' || $k['private'] === '') {
        return null;
    }
    $priv = openssl_pkey_get_private($k['private']);
    if (!$priv) {
        return null;
    }
    $u = parse_url($endpoint);
    if (empty($u['scheme']) || empty($u['host'])) {
        return null;
    }
    $aud = $u['scheme'] . '://' . $u['host'] . (isset($u['port']) ? ':' . $u['port'] : '');
    $jwtHeader = push_b64url_encode(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
    $jwtBody = push_b64url_encode(json_encode(['aud' => $aud, 'exp' => time() + 43200, 'sub' => $k['subject']]));
    $input = $jwtHeader . '.' . $jwtBody;
    if (!openssl_sign($input, $der, $priv, OPENSSL_ALGO_SHA256)) {
        return null;
    }
    $raw = push_der_to_raw_sig($der);
    if ($raw === null) {
        return null;
    }
    return 'vapid t=' . $input . '.' . push_b64url_encode($raw) . ', k=' . $k['public'];
}

/** Encrypt a payload per RFC 8291 aes128gcm; returns the request body. */
function push_encrypt_payload(string $payload, string $uaPubB64, string $authB64): ?string
{
    $uaPoint = push_b64url_decode($uaPubB64);
    $authSecret = push_b64url_decode($authB64);
    if (strlen($uaPoint) !== 65 || strlen($authSecret) < 16) {
        return null;
    }
    $uaKey = openssl_pkey_get_public(push_point_to_pem($uaPoint));
    if (!$uaKey) {
        return null;
    }
    $eph = push_ec_key_new();
    if (!$eph) {
        return null;
    }
    $det = openssl_pkey_get_details($eph);
    if (empty($det['ec']['x'])) {
        return null;
    }
    $asPoint = push_ec_point($det['ec']);
    $ecdh = openssl_pkey_derive($uaKey, $eph, 32);
    if ($ecdh === false || strlen($ecdh) < 32) {
        return null;
    }

    $ikm = hash_hkdf('sha256', $ecdh, 32, "WebPush: info\x00" . $uaPoint . $asPoint, $authSecret);
    $salt = random_bytes(16);
    $cek = hash_hkdf('sha256', $ikm, 16, "Content-Encoding: aes128gcm\x00", $salt);
    $nonce = hash_hkdf('sha256', $ikm, 12, "Content-Encoding: nonce\x00", $salt);

    $header = $salt . pack('N', 4096) . chr(65) . $asPoint;
    $ct = openssl_encrypt($payload . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, $header, 16);
    if ($ct === false) {
        return null;
    }
    return $header . $ct . $tag;
}

/** Generate a fresh VAPID key pair: ['public' => b64url, 'private' => PEM]. */
function push_generate_keys(): array
{
    $res = push_ec_key_new();
    if (!$res) {
        return [];
    }
    $pem = '';
    $cfg = push_openssl_config();
    $ok = false;
    if ($cfg !== null) {
        $ok = @openssl_pkey_export($res, $pem, null, ['config' => $cfg]);
    } else {
        $ok = @openssl_pkey_export($res, $pem);
    }
    if (!$ok || $pem === '') {
        // try with config file passed differently
        $ok = @openssl_pkey_export($res, $pem, null, ['config' => 'C:/xampp/php/extras/ssl/openssl.cnf']);
    }
    if (!$ok) {
        return [];
    }
    $det = openssl_pkey_get_details($res);
    if (empty($det['ec']['x'])) {
        return [];
    }
    return ['public' => push_b64url_encode(push_ec_point($det['ec'])), 'private' => $pem];
}

/* --------------------------- Subscriptions --------------------------- */

function push_subscribe(int $uid, string $endpoint, string $p256dh, string $auth, string $ua = ''): bool
{
    if ($endpoint === '' || $p256dh === '' || $auth === '' || strlen($endpoint) > 1000) {
        return false;
    }
    q(
        'INSERT INTO push_subscriptions (user_id, endpoint_hash, endpoint, p256dh, auth, user_agent, created_at, last_seen)
         VALUES (?,?,?,?,?,?,?,?)
         ON DUPLICATE KEY UPDATE p256dh = VALUES(p256dh), auth = VALUES(auth),
           user_agent = VALUES(user_agent), user_id = VALUES(user_id),
           last_seen = VALUES(last_seen), fail_count = 0',
        [$uid, hash('sha256', $endpoint), $endpoint, $p256dh, $auth, substr($ua, 0, 255), now(), now()]
    );
    return true;
}

function push_unsubscribe(int $uid, string $endpoint): void
{
    q('DELETE FROM push_subscriptions WHERE user_id = ? AND endpoint_hash = ?', [$uid, hash('sha256', $endpoint)]);
}

function push_subscription_count(int $uid): int
{
    return (int) fetch_one('SELECT COUNT(*) FROM push_subscriptions WHERE user_id = ?', [$uid], 0);
}

/** Deliver one push message to every device a user has registered. */
function push_send_user(int $uid, string $title, string $body, string $url = ''): int
{
    if (!push_available()) {
        return 0;
    }
    $subs = fetch_all('SELECT * FROM push_subscriptions WHERE user_id = ?', [$uid]);
    if (!$subs) {
        return 0;
    }
    $payload = json_encode(['title' => $title, 'body' => $body, 'url' => $url, 'icon' => 'assets/img/icon-192.png']);
    $sent = 0;
    foreach ($subs as $s) {
        $r = push_send_endpoint($s['endpoint'], $s['p256dh'], $s['auth'], $payload);
        if ($r['ok']) {
            $sent++;
            q('UPDATE push_subscriptions SET last_seen = ?, fail_count = 0 WHERE id = ?', [now(), $s['id']]);
        } elseif ($r['gone']) {
            q('DELETE FROM push_subscriptions WHERE id = ?', [$s['id']]);
        } else {
            q('UPDATE push_subscriptions SET fail_count = fail_count + 1 WHERE id = ?', [$s['id']]);
        }
    }
    return $sent;
}

/** POST one encrypted payload to a push endpoint. */
function push_send_endpoint(string $endpoint, string $p256dh, string $auth, string $payloadJson): array
{
    $authorization = push_vapid_authorization($endpoint);
    if ($authorization === null) {
        return ['ok' => false, 'code' => 0, 'gone' => false, 'error' => 'vapid unavailable'];
    }
    $body = push_encrypt_payload($payloadJson, $p256dh, $auth);
    if ($body === null) {
        return ['ok' => false, 'code' => 0, 'gone' => false, 'error' => 'encryption failed'];
    }

    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => [
            'Authorization: ' . $authorization,
            'Content-Encoding: aes128gcm',
            'Content-Type: application/octet-stream',
            'TTL: 2419200',
            'Urgency: normal',
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => PUSH_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => PUSH_TIMEOUT,
    ]);
    curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    $ok = $code >= 200 && $code < 300;
    return ['ok' => $ok, 'code' => $code, 'gone' => in_array($code, [404, 410], true), 'error' => $ok ? '' : ($err ?: ('HTTP ' . $code))];
}

/** Queue a push when a player receives an in-app notification (never blocks). */
function push_notify(int $uid, string $text, string $link = ''): void
{
    if (!push_available()) {
        return;
    }
    try {
        if ((int) fetch_one('SELECT COUNT(*) FROM push_subscriptions WHERE user_id = ?', [$uid], 0) === 0) {
            return;
        }
        insert('push_outbox', [
            'user_id' => $uid,
            'title' => defined('SITE_NAME') ? SITE_NAME : 'Eye Of The Mafia',
            'body' => mb_substr($text, 0, 300),
            'url' => (string) $link,
            'created_at' => now(),
        ]);
    } catch (Throwable $e) {
        // A push failure must never break gameplay.
    }
}
