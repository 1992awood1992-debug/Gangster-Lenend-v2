<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * API key creation, hashing, scope handling and per-key rate limiting.
 */
final class ApiKeyTest extends TestCase
{
    protected function tearDown(): void
    {
        unset($_SERVER['HTTP_X_API_KEY'], $_SERVER['HTTP_AUTHORIZATION']);
        parent::tearDown();
    }

    public function testGenerateKeyFormat(): void
    {
        $g = api_generate_key();
        $this->assertStringStartsWith(API_KEY_PREFIX, $g['prefix']);
        $this->assertStringStartsWith($g['prefix'] . '.', $g['plain']);
        $this->assertSame(hash('sha256', $g['plain']), $g['hash']);
        $this->assertSame($g['prefix'], explode('.', $g['plain'], 2)[0]);
    }

    public function testCreateStoresHashAndScopes(): void
    {
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'Dashboard', ['read', 'write'], 120);

        $row = fetch('SELECT * FROM api_keys WHERE id = ?', [$created['id']]);
        $this->assertNotNull($row);
        $this->assertSame('Dashboard', $row['name']);
        $this->assertSame($created['plain'], $created['prefix'] . '.' . explode('.', $created['plain'], 2)[1]);
        $this->assertSame(hash('sha256', $created['plain']), $row['key_hash']);
        $this->assertStringNotContainsString($created['plain'], (string) $row['key_hash']);
        $this->assertSame('read,write', $row['scopes']);
        $this->assertSame(120, (int) $row['rate_limit']);
        $this->assertNull($row['revoked_at']);
    }

    public function testInvalidScopesFallBackToRead(): void
    {
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], '', ['nonsense'], 0);
        $this->assertSame(['read'], $created['scopes']);
        $this->assertGreaterThanOrEqual(1, $created['rate_limit']);
    }

    public function testRateLimitIsClamped(): void
    {
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'big', ['read'], 999999);
        $this->assertSame(API_MAX_RATE_LIMIT, $created['rate_limit']);
    }

    public function testKeyScopesHelper(): void
    {
        $this->assertSame(['read', 'write'], api_key_scopes(['scopes' => 'read,write']));
        $this->assertSame(['*'], api_key_scopes(['scopes' => '*']));
        $this->assertSame(['read'], api_key_scopes(['scopes' => 'read,']));
    }

    public function testRequireScopeAllowsGrantedAndImpliedScopes(): void
    {
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'writer', ['write'], 60);
        $key = fetch('SELECT * FROM api_keys WHERE id = ?', [$created['id']]);

        // Should not throw/exit for either of these.
        api_require_scope($key, 'write');
        api_require_scope($key, 'read'); // write implies read
        $this->assertTrue(true);
    }

    public function testAuthenticateWithHeaderKey(): void
    {
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'hdr', ['read'], 60);

        $_SERVER['HTTP_X_API_KEY'] = $created['plain'];
        $row = api_authenticate();
        $this->assertSame($created['id'], (int) $row['id']);
        $this->assertSame((int) $u['id'], (int) $row['user_id']);
    }

    public function testAuthenticateWithBearerToken(): void
    {
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'bearer', ['read'], 60);

        unset($_SERVER['HTTP_X_API_KEY']);
        $_SERVER['HTTP_AUTHORIZATION'] = 'Bearer ' . $created['plain'];
        $row = api_authenticate();
        $this->assertSame($created['id'], (int) $row['id']);
    }

    public function testRateLimitCounterIncrements(): void
    {
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'limited', ['read'], 5);
        $key = fetch('SELECT * FROM api_keys WHERE id = ?', [$created['id']]);

        for ($i = 0; $i < 5; $i++) {
            api_rate_limit($key);
        }
        $this->assertSame(5, (int) fetch_one('SELECT hits FROM api_rate WHERE key_id = ?', [$created['id']], 0));
    }

    public function testTouchKeyUpdatesUsage(): void
    {
        $u = $this->makeUser();
        $created = api_key_create((int) $u['id'], 'touch', ['read'], 60);
        $key = fetch('SELECT * FROM api_keys WHERE id = ?', [$created['id']]);

        api_touch_key($key);
        $row = fetch('SELECT request_count, last_used_at FROM api_keys WHERE id = ?', [$created['id']]);
        $this->assertSame(1, (int) $row['request_count']);
        $this->assertNotNull($row['last_used_at']);
    }

    public function testPlayerPayloadShape(): void
    {
        $u = $this->makeUser(['money' => 4321, 'bank' => 100]);
        $payload = api_player_payload($u);
        $this->assertSame((int) $u['id'], $payload['id']);
        $this->assertSame(4321, $payload['money']);
        $this->assertSame(100, $payload['bank']);
        $this->assertArrayHasKey('rank', $payload);
        $this->assertArrayHasKey('hospitalized', $payload);

        $pub = api_public_player_payload($u);
        $this->assertArrayNotHasKey('money', $pub);
        $this->assertArrayHasKey('kills', $pub);
    }
}
