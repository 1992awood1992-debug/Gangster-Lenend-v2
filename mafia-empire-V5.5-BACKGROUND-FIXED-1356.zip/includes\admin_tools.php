<?php
/**
 * Mafia Empire - Admin Tools
 * Advanced admin functionality: user management, economy tools, content management, reports
 */

declare(strict_types=1);

require_once __DIR__ . '/init.php';

/**
 * Get user with full details for admin panel
 */
function admin_get_user_detail(int $userId): ?array
{
    $user = fetch('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$user) return null;

    $user['items'] = fetch_all('SELECT ui.*, i.name, i.type, i.attack, i.defense FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.qty > 0', [$userId]);
    $user['drugs'] = fetch_all('SELECT ud.*, d.name, d.effect_stat, d.effect_amount FROM user_drugs ud JOIN drugs d ON d.id = ud.drug_id WHERE ud.user_id = ? AND ud.qty > 0', [$userId]);
    $user['abilities'] = fetch_all('SELECT ua.*, a.name, a.description, a.effect_type, a.effect_value FROM user_abilities ua JOIN abilities a ON a.id = ua.ability_id WHERE ua.user_id = ?', [$userId]);
    $user['missions'] = fetch_all('SELECT um.*, m.name, m.energy_cost, m.reward_money FROM user_missions um JOIN missions m ON m.id = um.mission_id WHERE um.user_id = ? ORDER BY um.created_at DESC LIMIT 20', [$userId]);
    $user['jobs'] = fetch_all('SELECT uj.*, cj.name, cj.nerve_cost, cj.payout_min, cj.payout_max FROM user_job_cooldowns uj JOIN criminal_jobs cj ON cj.id = uj.job_id WHERE uj.user_id = ? ORDER BY uj.ready_at DESC LIMIT 20', [$userId]);
    $user['kills'] = fetch_all('SELECT kl.*, u.username as victim_name FROM kill_log kl JOIN users u ON u.id = kl.victim_id WHERE kl.attacker_id = ? ORDER BY kl.created_at DESC LIMIT 20', [$userId]);
    $user['deaths'] = fetch_all('SELECT kl.*, u.username as attacker_name FROM kill_log kl JOIN users u ON u.id = kl.attacker_id WHERE kl.victim_id = ? ORDER BY kl.created_at DESC LIMIT 20', [$userId]);
    $user['transactions'] = fetch_all('SELECT * FROM bank_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', [$userId]);
    $user['properties'] = fetch_all('SELECT up.*, pt.name, pt.code FROM user_properties up JOIN property_types pt ON pt.id = up.property_type_id WHERE up.user_id = ? AND up.is_active = 1', [$userId]);
    $user['heists'] = fetch_all('SELECT hi.*, h.name FROM heist_instances hi JOIN heists h ON h.id = hi.heist_id WHERE hi.leader_id = ? ORDER BY hi.created_at DESC LIMIT 20', [$userId]);
    $user['races'] = fetch_all('SELECT rp.*, re.prize_pool_money, re.prize_pool_xp, re.prize_pool_points, re.finished_at, rt.name as track_name FROM race_participants rp JOIN race_events re ON re.id = rp.race_id JOIN race_tracks rt ON rt.id = re.track_id WHERE rp.user_id = ? AND re.status = \'finished\' ORDER BY re.finished_at DESC LIMIT 20', [$userId]);
    $user['market'] = fetch_all('SELECT ml.*, u.username as buyer_name FROM market_listings ml LEFT JOIN users u ON u.id = ml.buyer_id WHERE ml.seller_id = ? ORDER BY ml.created_at DESC LIMIT 20', [$userId]);
    $user['bids'] = fetch_all('SELECT mb.*, ml.item_type, ml.item_id FROM market_bids mb JOIN market_listings ml ON ml.id = mb.listing_id WHERE mb.bidder_id = ? ORDER BY mb.placed_at DESC LIMIT 20', [$userId]);
    $user['notifications'] = fetch_all('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', [$userId]);
    $user['crew'] = $user['crew_id'] ? fetch('SELECT c.*, cm.rank FROM crews c JOIN crew_members cm ON c.id = cm.crew_id WHERE cm.user_id = ?', [$userId]) : null;

    return $user;
}

/**
 * Search users with filters
 */
function admin_search_users(array $filters = [], int $page = 1, int $perPage = 50): array
{
    $where = ['1=1'];
    $params = [];

    if (!empty($filters['search'])) {
        $where[] = '(username LIKE ? OR email LIKE ?)';
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
    }
    if (!empty($filters['level_min'])) {
        $where[] = 'level >= ?';
        $params[] = (int) $filters['level_min'];
    }
    if (!empty($filters['level_max'])) {
        $where[] = 'level <= ?';
        $params[] = (int) $filters['level_max'];
    }
    if (!empty($filters['is_banned'])) {
        $where[] = 'is_banned = ?';
        $params[] = (int) $filters['is_banned'];
    }
    if (!empty($filters['is_admin'])) {
        $where[] = 'is_admin = ?';
        $params[] = (int) $filters['is_admin'];
    }
    if (!empty($filters['crew_id'])) {
        $where[] = 'crew_id = ?';
        $params[] = (int) $filters['crew_id'];
    }
    if (!empty($filters['district_id'])) {
        $where[] = 'district_id = ?';
        $params[] = (int) $filters['district_id'];
    }

    $whereSql = implode(' AND ', $where);
    $offset = ($page - 1) * $perPage;
    $params[] = $perPage;
    $params[] = $offset;

    $users = fetch_all("
        SELECT u.*, c.name as crew_name, c.tag as crew_tag
        FROM users u
        LEFT JOIN crews c ON c.id = u.crew_id
        WHERE $whereSql
        ORDER BY u.created_at DESC
        LIMIT ? OFFSET ?
    ", $params);

    $total = (int) fetch_one("SELECT COUNT(*) FROM users WHERE $whereSql", array_slice($params, 0, -2), 0);

    return [
        'users' => $users,
        'total' => $total,
        'page' => $page,
        'per_page' => $perPage,
        'total_pages' => (int) ceil($total / $perPage),
    ];
}

/**
 * Update user (admin)
 */
function admin_update_user(int $userId, array $data): array
{
    $allowed = ['username', 'email', 'level', 'xp', 'money', 'bank', 'points', 'bullets', 'energy', 'energy_max', 'nerve', 'nerve_max', 'health', 'health_max', 'strength', 'speed', 'defense', 'iq', 'kills', 'deaths', 'is_admin', 'is_banned', 'district_id', 'crew_id', 'crew_rank'];
    $update = [];
    $params = [];

    foreach ($data as $key => $value) {
        if (in_array($key, $allowed, true)) {
            $update[] = "`$key` = ?";
            $params[] = $value;
        }
    }

    if (empty($update)) {
        return ['ok' => false, 'error' => 'No valid fields to update'];
    }

    $params[] = $userId;
    q('UPDATE users SET ' . implode(', ', $update) . ' WHERE id = ?', $params);

    // Log admin action
    audit_log('user_update', $_SESSION['uid'] ?? 0, $userId, ['changes' => array_keys($data)]);

    return ['ok' => true];
}

/**
 * Ban user
 */
function admin_ban_user(int $targetId, int $adminId, string $reason, ?string $expiresAt = null, string $type = 'temporary'): array
{
    $target = fetch('SELECT * FROM users WHERE id = ?', [$targetId]);
    if (!$target) return ['ok' => false, 'error' => 'User not found'];
    if ((int) $target['is_admin'] === 1) return ['ok' => false, 'error' => 'Cannot ban admin'];

    if ($type === 'permanent') {
        q('UPDATE users SET is_banned = 1 WHERE id = ?', [$targetId]);
    } else {
        q('UPDATE users SET is_banned = 1, jail_until = ? WHERE id = ?', [$expiresAt ?: date('Y-m-d H:i:s', time() + 86400), $targetId]);
    }

    insert('admin_bans', [
        'user_id' => $targetId,
        'admin_id' => $adminId,
        'reason' => $reason,
        'type' => $type,
        'expires_at' => $type === 'temporary' ? ($expiresAt ?: date('Y-m-d H:i:s', time() + 86400)) : null,
    ]);

    notify($targetId, 'You have been banned: ' . $reason, 'profile.php');
    audit_log('user_ban', $adminId, $targetId, ['reason' => $reason, 'type' => $type, 'expires' => $expiresAt]);

    return ['ok' => true];
}

/**
 * Unban user
 */
function admin_unban_user(int $targetId, int $adminId): array
{
    q('UPDATE users SET is_banned = 0, jail_until = NULL WHERE id = ?', [$targetId]);
    q('UPDATE admin_bans SET lifted_at = NOW(), lifted_by = ? WHERE user_id = ? AND lifted_at IS NULL', [$adminId, $targetId]);
    audit_log('user_unban', $adminId, $targetId);
    return ['ok' => true];
}

/**
 * Give items/money to user (admin)
 */
function admin_give(int $targetId, int $adminId, string $type, int $amount, int $itemId = 0): array
{
    $target = fetch('SELECT * FROM users WHERE id = ?', [$targetId]);
    if (!$target) return ['ok' => false, 'error' => 'User not found'];

    switch ($type) {
        case 'money':
            add_money($targetId, $amount, 'Admin gift');
            break;
        case 'points':
            add_points($targetId, $amount);
            break;
        case 'bullets':
            q('UPDATE users SET bullets = bullets + ? WHERE id = ?', [$amount, $targetId]);
            break;
        case 'energy':
            q('UPDATE users SET energy = LEAST(energy + ?, energy_max) WHERE id = ?', [$amount, $targetId]);
            break;
        case 'nerve':
            q('UPDATE users SET nerve = LEAST(nerve + ?, nerve_max) WHERE id = ?', [$amount, $targetId]);
            break;
        case 'item':
            $item = fetch('SELECT * FROM items WHERE id = ?', [$itemId]);
            if (!$item) return ['ok' => false, 'error' => 'Item not found'];
            $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$targetId, $itemId]);
            if ($existing) {
                q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [$amount, (int) $existing['id']]);
            } else {
                insert('user_items', ['user_id' => $targetId, 'item_id' => $itemId, 'qty' => $amount, 'equipped' => 0]);
            }
            break;
        default:
            return ['ok' => false, 'error' => 'Invalid type'];
    }

    audit_log('admin_give', $adminId, $targetId, ['type' => $type, 'amount' => $amount, 'item_id' => $itemId]);
    notify($targetId, 'You received an admin gift!', 'profile.php');
    return ['ok' => true];
}

/**
 * Audit log for admin actions
 */
function audit_log(string $action, int $adminId, int $targetId = 0, array $details = []): void
{
    insert('admin_audit_log', [
        'admin_id' => $adminId,
        'action' => $action,
        'target_type' => $targetId ? 'user' : null,
        'target_id' => $targetId ?: null,
        'old_values' => null,
        'new_values' => json_encode($details),
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
    ]);
}

/**
 * Get audit log
 */
function admin_get_audit_log(array $filters = [], int $page = 1, int $perPage = 50): array
{
    $where = ['1=1'];
    $params = [];

    if (!empty($filters['admin_id'])) {
        $where[] = 'admin_id = ?';
        $params[] = (int) $filters['admin_id'];
    }
    if (!empty($filters['action'])) {
        $where[] = 'action = ?';
        $params[] = $filters['action'];
    }
    if (!empty($filters['target_id'])) {
        $where[] = 'target_id = ?';
        $params[] = (int) $filters['target_id'];
    }
    if (!empty($filters['date_from'])) {
        $where[] = 'created_at >= ?';
        $params[] = $filters['date_from'];
    }
    if (!empty($filters['date_to'])) {
        $where[] = 'created_at <= ?';
        $params[] = $filters['date_to'];
    }

    $whereSql = implode(' AND ', $where);
    $offset = ($page - 1) * $perPage;
    $params[] = $perPage;
    $params[] = $offset;

    $logs = fetch_all("
        SELECT al.*, u.username as admin_name, u2.username as target_name
        FROM admin_audit_log al
        LEFT JOIN users u ON u.id = al.admin_id
        LEFT JOIN users u2 ON u2.id = al.target_id
        WHERE $whereSql
        ORDER BY al.created_at DESC
        LIMIT ? OFFSET ?
    ", $params);

    $total = (int) fetch_one("SELECT COUNT(*) FROM admin_audit_log WHERE $whereSql", array_slice($params, 0, -2), 0);

    return [
        'logs' => $logs,
        'total' => $total,
        'page' => $page,
        'per_page' => $perPage,
        'total_pages' => (int) ceil($total / $perPage),
    ];
}

/**
 * Economy report
 */
function admin_economy_report(): array
{
    return [
        'total_money' => (int) fetch_one('SELECT COALESCE(SUM(money),0) FROM users', [], 0),
        'total_bank' => (int) fetch_one('SELECT COALESCE(SUM(bank),0) FROM users', [], 0),
        'total_points' => (int) fetch_one('SELECT COALESCE(SUM(points),0) FROM users', [], 0),
        'total_bullets' => (int) fetch_one('SELECT COALESCE(SUM(bullets),0) FROM users', [], 0),
        'avg_money' => (int) fetch_one('SELECT COALESCE(AVG(money),0) FROM users', [], 0),
        'richest' => fetch('SELECT username, money FROM users ORDER BY money DESC LIMIT 1'),
        'daily_income' => (int) fetch_one('SELECT COALESCE(SUM(amount),0) FROM bank_transactions WHERE amount > 0 AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [], 0),
        'daily_expenses' => (int) fetch_one('SELECT COALESCE(SUM(ABS(amount)),0) FROM bank_transactions WHERE amount < 0 AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [], 0),
        'market_volume' => (int) fetch_one('SELECT COALESCE(SUM(final_price),0) FROM market_listings WHERE status = \'sold\' AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [], 0),
        'heist_payouts' => (int) fetch_one('SELECT COALESCE(SUM(total_money),0) FROM heist_instances WHERE status = \'completed\' AND completed_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [], 0),
    ];
}

/**
 * Player retention report
 */
function admin_retention_report(): array
{
    return [
        'dau' => (int) fetch_one('SELECT COUNT(*) FROM users WHERE last_active > DATE_SUB(NOW(), INTERVAL 1 DAY)', [], 0),
        'wau' => (int) fetch_one('SELECT COUNT(*) FROM users WHERE last_active > DATE_SUB(NOW(), INTERVAL 7 DAY)', [], 0),
        'mau' => (int) fetch_one('SELECT COUNT(*) FROM users WHERE last_active > DATE_SUB(NOW(), INTERVAL 30 DAY)', [], 0),
        'new_today' => (int) fetch_one('SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()', [], 0),
        'new_week' => (int) fetch_one('SELECT COUNT(*) FROM users WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)', [], 0),
        'new_month' => (int) fetch_one('SELECT COUNT(*) FROM users WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)', [], 0),
        'retention_1d' => 0, // Calculate from cohort
        'retention_7d' => 0,
        'retention_30d' => 0,
    ];
}

/**
 * Content management helpers
 */
function admin_content_count(): array
{
    return [
        'missions' => (int) fetch_one('SELECT COUNT(*) FROM missions', [], 0),
        'bosses' => (int) fetch_one('SELECT COUNT(*) FROM bosses', [], 0),
        'items' => (int) fetch_one('SELECT COUNT(*) FROM items', [], 0),
        'drugs' => (int) fetch_one('SELECT COUNT(*) FROM drugs', [], 0),
        'abilities' => (int) fetch_one('SELECT COUNT(*) FROM abilities', [], 0),
        'achievements' => (int) fetch_one('SELECT COUNT(*) FROM achievements', [], 0),
        'stickers' => (int) fetch_one('SELECT COUNT(*) FROM stickers', [], 0),
        'districts' => (int) fetch_one('SELECT COUNT(*) FROM districts', [], 0),
        'jobs' => (int) fetch_one('SELECT COUNT(*) FROM criminal_jobs', [], 0),
        'abilities' => (int) fetch_one('SELECT COUNT(*) FROM abilities', [], 0),
        'heists' => (int) fetch_one('SELECT COUNT(*) FROM heists', [], 0),
        'tracks' => (int) fetch_one('SELECT COUNT(*) FROM race_tracks', [], 0),
        'properties' => (int) fetch_one('SELECT COUNT(*) FROM property_types', [], 0),
        'policies' => (int) fetch_one('SELECT COUNT(*) FROM city_policies', [], 0),
        'events' => (int) fetch_one('SELECT COUNT(*) FROM events', [], 0),
        'challenges' => (int) fetch_one('SELECT COUNT(*) FROM event_challenges', [], 0),
    ];
}