<?php
/**
 * Mafia Empire - outbound webhooks.
 *
 * Players may register one or more HTTPS endpoints. When a subscribed game
 * event happens (a kill, a level-up, an achievement, a store purchase) we
 * queue a signed POST for delivery by cron, so gameplay never blocks on a
 * slow third-party endpoint.
 *
 * Every delivery carries:
 *   X-Mafia-Event:     <event name>
 *   X-Mafia-Signature: sha256=<hex hmac of the raw body using the hook secret>
 */
require_once __DIR__ . '/db.php';

/** All events a player can subscribe to (plus the special test event). */
function webhook_events(): array
{
    return [
        'kill'        => 'You kill another player',
        'levelup'     => 'You gain a level',
        'achievement' => 'You unlock an achievement',
        'purchase'    => 'You buy something with points',
    ];
}

/** Normalise a stored events string ("kill,levelup" or "*") to a clean list. */
function webhook_valid_events(string $csv): array
{
    $out = [];
    foreach (array_map('trim', explode(',', $csv)) as $ev) {
        if ($ev === '*') {
            return ['*'];
        }
        if ($ev !== '' && array_key_exists($ev, webhook_events())) {
            $out[] = $ev;
        }
    }
    return array_values(array_unique($out));
}

/** HMAC-SHA256 signature for a webhook body. */
function webhook_sign(string $payload, string $secret): string
{
    return 'sha256=' . hash_hmac('sha256', $payload, $secret);
}

/** Build the exact JSON body we deliver, so signing and sending agree. */
function webhook_build_payload(string $event, int $userId, array $data): string
{
    return json_encode([
        'event'      => $event,
        'user_id'    => $userId,
        'created_at' => now(),
        'data'       => $data,
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

/**
 * Queue a signed delivery for every active hook the user owns that wants this
 * event. Returns the number of deliveries queued.
 */
function webhook_dispatch(int $userId, string $event, array $data): int
{
    $hooks = fetch_all('SELECT * FROM webhooks WHERE user_id = ? AND active = 1', [$userId]);
    if (!$hooks) {
        return 0;
    }
    $payload = webhook_build_payload($event, $userId, $data);
    $queued = 0;
    foreach ($hooks as $h) {
        $subscribed = webhook_valid_events((string) $h['events']);
        if ($subscribed !== ['*'] && !in_array($event, $subscribed, true)) {
            continue;
        }
        insert('webhook_deliveries', [
            'webhook_id'      => (int) $h['id'],
            'user_id'         => $userId,
            'event'           => $event,
            'payload'         => $payload,
            'status'          => 'pending',
            'next_attempt_at' => now(),
            'created_at'      => now(),
        ]);
        $queued++;
    }
    return $queued;
}

/**
 * POST a single payload to a URL.
 *
 * @return array{0:bool,1:int,2:string}  [ok, http_code, error]
 */
function webhook_post(string $url, string $event, string $payload, string $secret): array
{
    if (!function_exists('curl_init')) {
        return [false, 0, 'curl extension not available'];
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => WEBHOOK_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => WEBHOOK_TIMEOUT,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'User-Agent: MafiaEmpire-Webhooks/1.0',
            'X-Mafia-Event: ' . $event,
            'X-Mafia-Signature: ' . webhook_sign($payload, $secret),
        ],
    ]);
    curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = (string) curl_error($ch);
    curl_close($ch);

    $ok = $code >= 200 && $code < 300;
    return [$ok, $code, $ok ? '' : ($err !== '' ? $err : 'HTTP ' . $code)];
}

/** Send one test event synchronously (used by the UI + API test endpoint). */
function webhook_send_test(array $webhook): array
{
    $payload = webhook_build_payload('test', (int) $webhook['user_id'], [
        'message' => 'This is a test delivery from Eye Of The Mafia.',
    ]);
    return webhook_post((string) $webhook['url'], 'test', $payload, (string) $webhook['secret']);
}

/**
 * Deliver queued webhook payloads whose retry time has passed.
 * Failed attempts back off (1, 5, 25, 125 minutes) up to WEBHOOK_MAX_ATTEMPTS.
 *
 * @return array<string,int>
 */
function webhook_deliver_pending(int $limit = 25): array
{
    $limit = max(1, min(200, $limit));
    $rows = fetch_all(
        "SELECT d.*, w.url, w.secret
           FROM webhook_deliveries d
           JOIN webhooks w ON w.id = d.webhook_id
          WHERE d.status = 'pending'
            AND (d.next_attempt_at IS NULL OR d.next_attempt_at <= ?)
          ORDER BY d.id ASC
          LIMIT $limit",
        [now()]
    );

    $delivered = 0;
    $retried   = 0;
    $failed    = 0;

    foreach ($rows as $d) {
        [$ok, $code, $err] = webhook_post((string) $d['url'], (string) $d['event'], (string) $d['payload'], (string) $d['secret']);
        $attempts = (int) $d['attempts'] + 1;

        if ($ok) {
            update_row('webhook_deliveries', [
                'status'        => 'delivered',
                'attempts'      => $attempts,
                'response_code' => $code,
                'error'         => '',
                'delivered_at'  => now(),
            ], 'id = ?', [(int) $d['id']]);
            update_row('webhooks', [
                'last_status'    => $code,
                'last_called_at' => now(),
                'failures'       => 0,
            ], 'id = ?', [(int) $d['webhook_id']]);
            $delivered++;
            continue;
        }

        if ($attempts >= WEBHOOK_MAX_ATTEMPTS) {
            update_row('webhook_deliveries', [
                'status'          => 'failed',
                'attempts'        => $attempts,
                'response_code'   => $code,
                'error'           => substr($err, 0, 250),
                'next_attempt_at' => null,
            ], 'id = ?', [(int) $d['id']]);
            q('UPDATE webhooks SET failures = failures + 1, last_status = ?, last_called_at = ? WHERE id = ?',
                [$code, now(), (int) $d['webhook_id']]);
            $failed++;
        } else {
            $delay = 60 * (int) pow(5, $attempts - 1); // 1m, 5m, 25m, 125m
            update_row('webhook_deliveries', [
                'attempts'        => $attempts,
                'response_code'   => $code,
                'error'           => substr($err, 0, 250),
                'next_attempt_at' => date('Y-m-d H:i:s', time() + $delay),
            ], 'id = ?', [(int) $d['id']]);
            $retried++;
        }
    }

    return [
        'processed' => count($rows),
        'delivered' => $delivered,
        'retried'   => $retried,
        'failed'    => $failed,
    ];
}
