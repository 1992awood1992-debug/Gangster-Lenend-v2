<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'The Empire';
require __DIR__ . '/includes/header.php';

$u = current_user();
$rank = rank_for_level((int) $u['level']);
$xpNeed = xp_for_level((int) $u['level'] + 1);
$power = combat_power($u['id']);
$netWorth = (int) $u['money'] + (int) $u['bank'] + (int) $u['points'] * 100;

// Holdings
$factories = fetch_all('SELECT bf.*, d.name AS district_name FROM bullet_factories bf JOIN districts d ON d.id = bf.district_id WHERE bf.owner_id = ?', [$u['id']]);
$crew = $u['crew_id'] ? fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]) : null;
$equipped = fetch_all('SELECT ui.*, i.name, i.type, i.attack, i.defense, i.cost, i.rarity FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.equipped = 1', [$u['id']]);
$achCount = (int) fetch_one('SELECT COUNT(*) FROM user_achievements WHERE user_id = ?', [$u['id']], 0);
$totalAch = (int) fetch_one('SELECT COUNT(*) FROM achievements', [], 0);
$stickerCount = (int) fetch_one('SELECT SUM(qty) FROM user_stickers WHERE user_id = ?', [$u['id']], 0);
$totalStickers = (int) fetch_one('SELECT COUNT(*) FROM stickers', [], 0);
?>
<div class="card">
  <div class="panel-heading">The Empire — <?= e($u['username']) ?></div>
  <div class="grid grid-4">
    <div class="stat"><span>Rank</span><b><?= e($rank['name']) ?></b></div>
    <div class="stat"><span>Level</span><b><?= (int) $u['level'] ?> (<?= (int) $u['xp'] ?>/<?= $xpNeed ?> XP)</b></div>
    <div class="stat"><span>Net Worth</span><b><?= money($netWorth) ?></b></div>
    <div class="stat"><span>District</span><b><?= e(fetch('SELECT name FROM districts WHERE id = ?', [$u['district_id']])['name'] ?? '—') ?></b></div>
  </div>
  <div style="margin-top:10px">
    <div class="progress"><i style="width:<?= min(100, round((int) $u['xp'] / max(1, $xpNeed) * 100)) ?>%"></i></div>
  </div>
</div>

<div class="grid grid-3" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Combat</div>
    <div class="stat"><span>Attack</span><b><?= $power['attack'] ?></b></div>
    <div class="stat"><span>Defense</span><b><?= $power['defense'] ?></b></div>
    <div class="stat"><span>Health</span><b><?= (int) $u['health'] ?> / <?= (int) $u['health_max'] ?></b></div>
    <div class="stat"><span>Strength</span><b><?= (int) $u['strength'] ?></b></div>
    <div class="stat"><span>Speed</span><b><?= (int) $u['speed'] ?></b></div>
    <div class="stat"><span>Defense</span><b><?= (int) $u['defense'] ?></b></div>
    <div class="stat"><span>IQ</span><b><?= (int) $u['iq'] ?></b></div>
  </div>

  <div class="card">
    <div class="panel-heading">Equipped Gear</div>
    <?php if (!$equipped): ?>
      <p class="muted">Nothing equipped.</p>
    <?php else: ?>
      <?php foreach ($equipped as $eq): ?>
        <div class="stat"><span><?= e($eq['name']) ?></span><b>ATK +<?= (int) $eq['attack'] ?> DEF +<?= (int) $eq['defense'] ?></b></div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="panel-heading">Resources</div>
    <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
    <div class="stat"><span>Bank</span><b><?= money($u['bank']) ?></b></div>
    <div class="stat"><span>Bullets</span><b><?= number_format((int) $u['bullets']) ?></b></div>
    <div class="stat"><span>Points</span><b><?= number_format((int) $u['points']) ?></b></div>
    <div class="stat"><span>Energy</span><b><?= (int) $u['energy'] ?>/<?= (int) $u['energy_max'] ?></b></div>
    <div class="stat"><span>Nerve</span><b><?= (int) $u['nerve'] ?>/<?= (int) $u['nerve_max'] ?></b></div>
  </div>
</div>

<div class="grid grid-3" style="margin-top:18px">
  <div class="card">
    <div class="panel-heading">Bullet Factories (<?= count($factories) ?>)</div>
    <?php if (!$factories): ?>
      <p class="muted">No factories owned.</p>
    <?php else: ?>
      <?php foreach ($factories as $bf): ?>
        <div class="stat"><span><?= e($bf['district_name']) ?></span><b><?= number_format((int) $bf['production']) ?>/hr</b></div>
      <?php endforeach; ?>
      <p><a class="btn btn-sm" href="<?= e(url('bullet_factory.php')) ?>">Manage</a></p>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="panel-heading">Crew</div>
    <?php if ($crew): ?>
      <?php $turf = (int) fetch_one('SELECT COUNT(*) FROM zone_control WHERE crew_id = ?', [$crew['id']], 0); ?>
      <div class="stat"><span><?= e($crew['name']) ?> [<?= e($crew['tag']) ?>]</span><b><?= e($u['crew_rank']) ?></b></div>
      <div class="stat"><span>Crew Level</span><b><?= (int) $crew['level'] ?></b></div>
      <div class="stat"><span>Crew XP / Wars</span><b><?= number_format((int) $crew['xp']) ?> · <?= (int) $crew['wars_won'] ?>W/<?= (int) $crew['wars_lost'] ?>L</b></div>
      <div class="stat"><span>Crew Money / Turf</span><b><?= money($crew['money']) ?> · <?= $turf ?> zones</b></div>
      <p style="display:flex;gap:6px;flex-wrap:wrap">
        <a class="btn btn-sm" href="<?= e(url('crew.php')) ?>">View Crew</a>
        <a class="btn btn-sm" href="<?= e(url('territory.php')) ?>">Territory</a>
        <a class="btn btn-sm" href="<?= e(url('crew_wars.php')) ?>">Wars</a>
      </p>
    <?php else: ?>
      <p class="muted">Not in a crew.</p>
      <p><a class="btn btn-sm" href="<?= e(url('crew.php')) ?>">Create or Join</a></p>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="panel-heading">Progression</div>
    <div class="stat"><span>Missions Done</span><b><?= (int) $u['missions_done'] ?></b></div>
    <div class="stat"><span>Crimes Done</span><b><?= (int) $u['crimes_done'] ?></b></div>
    <div class="stat"><span>Boss Kills</span><b><?= (int) $u['boss_kills'] ?></b></div>
    <div class="stat"><span>Kills / Deaths</span><b><?= (int) $u['kills'] ?> / <?= (int) $u['deaths'] ?></b></div>
    <div class="stat"><span>Achievements</span><b><?= $achCount ?> / <?= $totalAch ?></b></div>
    <div class="stat"><span>Stickers</span><b><?= $stickerCount ?> / <?= $totalStickers ?></b></div>
  </div>
</div>

<div class="grid grid-4" style="margin-top:18px">
  <a class="tile" href="<?= e(url('missions.php')) ?>"><span class="ico">&#128373;</span><b>Missions</b></a>
  <a class="tile" href="<?= e(url('criminal_jobs.php')) ?>"><span class="ico">&#128274;</span><b>Criminal Jobs</b></a>
  <a class="tile" href="<?= e(url('gym.php')) ?>"><span class="ico">&#127947;</span><b>The Gym</b></a>
  <a class="tile" href="<?= e(url('bosses.php')) ?>"><span class="ico">&#128128;</span><b>Bosses</b></a>
  <a class="tile" href="<?= e(url('kill.php')) ?>"><span class="ico">&#128299;</span><b>Kill</b></a>
  <a class="tile" href="<?= e(url('drugs.php')) ?>"><span class="ico">&#128138;</span><b>Drugs</b></a>
  <a class="tile" href="<?= e(url('abilities.php')) ?>"><span class="ico">&#128161;</span><b>Abilities</b></a>
  <a class="tile" href="<?= e(url('districts.php')) ?>"><span class="ico">&#127961;</span><b>Districts</b></a>
  <a class="tile" href="<?= e(url('territory.php')) ?>"><span class="ico">&#128506;</span><b>Territory</b></a>
  <a class="tile" href="<?= e(url('crew_wars.php')) ?>"><span class="ico">&#9876;</span><b>Crew Wars</b></a>
  <a class="tile" href="<?= e(url('diplomacy.php')) ?>"><span class="ico">&#9996;</span><b>Diplomacy</b></a>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>