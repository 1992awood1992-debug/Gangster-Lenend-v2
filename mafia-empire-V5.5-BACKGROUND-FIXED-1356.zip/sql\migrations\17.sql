-- Migration 17: Tournament System
-- Idempotent: CREATE TABLE IF NOT EXISTS, safe to re-run.

-- ============================================================
-- TOURNAMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS tournaments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    type ENUM('elimination','round_robin','swiss','ladder') NOT NULL DEFAULT 'elimination',
    game_type ENUM('pvp','racing','heist','mission_speedrun','kill_race','casino') NOT NULL DEFAULT 'pvp',
    
    -- Scheduling
    registration_opens_at DATETIME NOT NULL,
    registration_closes_at DATETIME NOT NULL,
    starts_at DATETIME NOT NULL,
    estimated_end_at DATETIME NULL,
    
    -- Limits
    min_participants INT UNSIGNED NOT NULL DEFAULT 4,
    max_participants INT UNSIGNED NOT NULL DEFAULT 64,
    min_level INT UNSIGNED NOT NULL DEFAULT 1,
    max_level INT UNSIGNED NULL,
    crew_only TINYINT(1) NOT NULL DEFAULT 0,
    
    -- Entry
    entry_fee_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    entry_fee_points INT UNSIGNED NOT NULL DEFAULT 0,
    entry_fee_item_id INT UNSIGNED NULL,
    
    -- Prizes (split among top finishers)
    prize_pool_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    prize_pool_points INT UNSIGNED NOT NULL DEFAULT 0,
    prize_pool_xp BIGINT UNSIGNED NOT NULL DEFAULT 0,
    prize_items JSON NULL, -- [{"item_id":1,"qty":1,"place":1},...]
    
    -- Payout structure (JSON: [{"place":1,"pct":50},{"place":2,"pct":30},{"place":3,"pct":20}])
    payout_structure JSON NULL,
    
    -- Status
    status ENUM('draft','registration','in_progress','completed','cancelled') NOT NULL DEFAULT 'draft',
    max_rounds INT UNSIGNED NULL, -- for elimination
    
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    PRIMARY KEY (id),
    KEY idx_status (status),
    KEY idx_dates (starts_at, registration_closes_at),
    KEY idx_game_type (game_type),
    KEY idx_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TOURNAMENT PARTICIPANTS
-- ============================================================
CREATE TABLE IF NOT EXISTS tournament_participants (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    tournament_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NULL,
    crew_id INT UNSIGNED NULL, -- for crew tournaments
    team_name VARCHAR(100) NULL, -- for team tournaments
    
    -- Registration
    registered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status ENUM('registered','confirmed','checked_in','eliminated','withdrawn','disqualified') NOT NULL DEFAULT 'registered',
    
    -- Tournament progress
    seed INT UNSIGNED NULL, -- seeding position
    current_round INT UNSIGNED NOT NULL DEFAULT 0,
    wins INT UNSIGNED NOT NULL DEFAULT 0,
    losses INT UNSIGNED NOT NULL DEFAULT 0,
    draws INT UNSIGNED NOT NULL DEFAULT 0,
    points INT NOT NULL DEFAULT 0, -- for round-robin/swiss
    final_position INT UNSIGNED NULL,
    
    -- Rewards
    prize_money BIGINT UNSIGNED NOT NULL DEFAULT 0,
    prize_points INT UNSIGNED NOT NULL DEFAULT 0,
    prize_xp BIGINT UNSIGNED NOT NULL DEFAULT 0,
    prize_items JSON NULL,
    
    -- Stats
    total_score BIGINT NOT NULL DEFAULT 0, -- for speedrun/kill race
    best_time_ms INT UNSIGNED NULL, -- for speedrun
    kills INT UNSIGNED NOT NULL DEFAULT 0, -- for kill race
    
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    PRIMARY KEY (id),
    UNIQUE KEY uniq_tournament_user (tournament_id, user_id),
    UNIQUE KEY uniq_tournament_crew (tournament_id, crew_id),
    KEY idx_tournament_status (tournament_id, status),
    KEY idx_user (user_id),
    KEY idx_crew (crew_id),
    KEY idx_seed (tournament_id, seed),
    KEY idx_position (tournament_id, final_position)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TOURNAMENT MATCHES (for elimination/round-robin)
-- ============================================================
CREATE TABLE IF NOT EXISTS tournament_matches (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    tournament_id INT UNSIGNED NOT NULL,
    round_number INT UNSIGNED NOT NULL,
    match_number INT UNSIGNED NOT NULL, -- within round
    
    -- Participants
    participant1_id BIGINT UNSIGNED NULL, -- tournament_participants.id
    participant2_id BIGINT UNSIGNED NULL,
    
    -- Result
    winner_id BIGINT UNSIGNED NULL,
    loser_id BIGINT UNSIGNED NULL,
    is_draw TINYINT(1) NOT NULL DEFAULT 0,
    
    -- Scores
    score1 INT NOT NULL DEFAULT 0,
    score2 INT NOT NULL DEFAULT 0,
    
    -- Metadata
    scheduled_at DATETIME NULL,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    details JSON NULL, -- game-specific data (race times, kills, etc.)
    
    status ENUM('pending','in_progress','completed','cancelled','walkover') NOT NULL DEFAULT 'pending',
    
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    PRIMARY KEY (id),
    KEY idx_tournament_round (tournament_id, round_number),
    KEY idx_participant1 (participant1_id),
    KEY idx_participant2 (participant2_id),
    KEY idx_status (status),
    KEY idx_scheduled (scheduled_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TOURNAMENT REWARDS LOG
-- ============================================================
CREATE TABLE IF NOT EXISTS tournament_rewards_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    tournament_id INT UNSIGNED NOT NULL,
    participant_id BIGINT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    reward_type ENUM('money','points','xp','item') NOT NULL,
    amount BIGINT NOT NULL DEFAULT 0,
    item_id INT UNSIGNED NULL,
    item_qty INT UNSIGNED NULL,
    place INT UNSIGNED NULL,
    awarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_tournament (tournament_id),
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- DEFAULT TOURNAMENTS (recurring)
-- ============================================================
INSERT INTO tournaments (code, name, description, type, game_type, 
    registration_opens_at, registration_closes_at, starts_at,
    min_participants, max_participants, min_level, max_level,
    entry_fee_money, entry_fee_points,
    prize_pool_money, prize_pool_points, prize_pool_xp,
    payout_structure, status, max_rounds) VALUES

('daily_pvp', 'Daily PvP Arena', 'Daily elimination tournament for glory and gold.', 'elimination', 'pvp',
    DATE_SUB(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 23 HOUR), DATE_ADD(CURDATE(), INTERVAL 1 HOUR),
    4, 32, 5, NULL,
    10000, 0, 50000, 500, 5000,
    '[{"place":1,"pct":50},{"place":2,"pct":30},{"place":3,"pct":20}]',
    'registration', NULL),

('weekly_racing', 'Weekly Grand Prix', 'Weekly racing championship across all tracks.', 'elimination', 'racing',
    DATE_SUB(CURDATE(), INTERVAL 6 DAY), DATE_ADD(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 2 DAY),
    8, 64, 10, NULL,
    50000, 0, 250000, 2500, 25000,
    '[{"place":1,"pct":40},{"place":2,"pct":25},{"place":3,"pct":15},{"place":4,"pct":10},{"place":5,"pct":5},{"place":6,"pct":5}]',
    'registration', NULL),

('weekly_heist', 'Weekly Heist Championship', 'Crews compete for fastest heist completion.', 'elimination', 'heist',
    DATE_SUB(CURDATE(), INTERVAL 6 DAY), DATE_ADD(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 2 DAY),
    4, 16, 15, NULL,
    0, 1000, 0, 10000, 50000,
    '[{"place":1,"pct":50},{"place":2,"pct":30},{"place":3,"pct":20}]',
    'registration', NULL),

('monthly_kill_race', 'Monthly Assassin League', 'Most kills in 30 days wins the bounty.', 'ladder', 'kill_race',
    DATE_SUB(CURDATE(), INTERVAL 1 DAY), DATE_ADD(LAST_DAY(CURDATE()), INTERVAL 23 HOUR), DATE_ADD(CURDATE(), INTERVAL 1 HOUR),
    10, 500, 20, NULL,
    100000, 0, 1000000, 50000, 100000,
    '[{"place":1,"pct":30},{"place":2,"pct":20},{"place":3,"pct":15},{"place":4,"pct":10},{"place":5,"pct":10},{"place":6,"pct":5},{"place":7,"pct":5},{"place":8,"pct":5}]',
    'registration', NULL);

-- Migration 17 seed data for default tournaments
-- These will be inserted by the seeder when the migration runs