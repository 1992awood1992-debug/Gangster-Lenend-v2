<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Cash, bank, bullets and points accounting.
 */
final class EconomyTest extends TestCase
{
    public function testAddMoneyIncreasesCash(): void
    {
        $u = $this->makeUser(['money' => 1000]);
        add_money((int) $u['id'], 500);
        $this->assertSame(1500, (int) $this->freshUser((int) $u['id'])['money']);
    }

    public function testAddMoneyFloorsAtZero(): void
    {
        $u = $this->makeUser(['money' => 100]);
        add_money((int) $u['id'], -500);
        $this->assertSame(0, (int) $this->freshUser((int) $u['id'])['money']);
    }

    public function testBankColumnIsIndependentOfCash(): void
    {
        $u = $this->makeUser(['money' => 1000, 'bank' => 200]);
        add_money((int) $u['id'], 300, 'Deposit', true);
        $fresh = $this->freshUser((int) $u['id']);
        $this->assertSame(1000, (int) $fresh['money']);
        $this->assertSame(500, (int) $fresh['bank']);
    }

    public function testReasonLogsBankTransaction(): void
    {
        $u = $this->makeUser();
        add_money((int) $u['id'], 250, 'Mission payout');
        $rows = fetch_all('SELECT * FROM bank_transactions WHERE user_id = ?', [$u['id']]);
        $this->assertCount(1, $rows);
        $this->assertSame('Mission payout', $rows[0]['reason']);
        $this->assertSame(250, (int) $rows[0]['amount']);
    }

    public function testBlankReasonDoesNotLog(): void
    {
        $u = $this->makeUser();
        add_money((int) $u['id'], 250);
        $this->assertSame(0, (int) fetch_one('SELECT COUNT(*) FROM bank_transactions WHERE user_id = ?', [$u['id']], 0));
    }

    public function testBulletsAndPointsFloorAtZero(): void
    {
        $u = $this->makeUser(['bullets' => 5, 'points' => 3]);
        add_bullets((int) $u['id'], -50);
        add_points((int) $u['id'], -50);
        $fresh = $this->freshUser((int) $u['id']);
        $this->assertSame(0, (int) $fresh['bullets']);
        $this->assertSame(0, (int) $fresh['points']);
    }
}
