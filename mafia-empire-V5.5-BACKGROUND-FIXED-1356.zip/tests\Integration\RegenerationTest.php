<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Energy / nerve / health regeneration (the game's cooldown engine).
 */
final class RegenerationTest extends TestCase
{
    public function testEnergyRegeneratesPerTick(): void
    {
        $u = $this->makeUser([
            'energy'           => 10,
            'energy_max'       => 100,
            'last_energy_tick' => date('Y-m-d H:i:s', time() - 3 * ENERGY_TICK_SECONDS),
        ]);
        $row = $this->freshUser((int) $u['id']);
        tick_user($row);
        $this->assertSame(13, (int) $row['energy']);
    }

    public function testEnergyCapsAtMaximum(): void
    {
        $u = $this->makeUser([
            'energy'           => 99,
            'energy_max'       => 100,
            'last_energy_tick' => date('Y-m-d H:i:s', time() - 100 * ENERGY_TICK_SECONDS),
        ]);
        $row = $this->freshUser((int) $u['id']);
        tick_user($row);
        $this->assertSame(100, (int) $row['energy']);
    }

    public function testNoRegenBeforeFirstTickElapses(): void
    {
        $u = $this->makeUser([
            'energy'           => 10,
            'energy_max'       => 100,
            'last_energy_tick' => date('Y-m-d H:i:s', time() - 100),
        ]);
        $row = $this->freshUser((int) $u['id']);
        tick_user($row);
        $this->assertSame(10, (int) $row['energy']);
    }

    public function testNerveRegenerates(): void
    {
        $u = $this->makeUser([
            'nerve'           => 0,
            'nerve_max'       => 50,
            'last_nerve_tick' => date('Y-m-d H:i:s', time() - 2 * NERVE_TICK_SECONDS),
        ]);
        $row = $this->freshUser((int) $u['id']);
        tick_user($row);
        $this->assertSame(2, (int) $row['nerve']);
    }

    public function testHealthRegenerates(): void
    {
        $u = $this->makeUser([
            'health'           => 40,
            'health_max'       => 100,
            'last_health_tick' => date('Y-m-d H:i:s', time() - 5 * HEALTH_TICK_SECONDS),
        ]);
        $row = $this->freshUser((int) $u['id']);
        tick_user($row);
        $this->assertSame(45, (int) $row['health']);
    }

    public function testRegenerationPersistsToDatabase(): void
    {
        $u = $this->makeUser([
            'energy'           => 10,
            'energy_max'       => 100,
            'last_energy_tick' => date('Y-m-d H:i:s', time() - 2 * ENERGY_TICK_SECONDS),
        ]);
        $row = $this->freshUser((int) $u['id']);
        tick_user($row);
        $fresh = $this->freshUser((int) $u['id']);
        $this->assertSame(12, (int) $fresh['energy']);
        $this->assertGreaterThan(strtotime($u['last_energy_tick']), strtotime($fresh['last_energy_tick']));
    }
}
