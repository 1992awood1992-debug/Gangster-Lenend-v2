<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

require_once __DIR__ . '/../../includes/market.php';

/**
 * Marketplace helper coverage. Guards against column collisions between
 * `market_bids` and `market_listings`, which share `id`/`status`/`created_at`.
 */
final class MarketplaceTest extends TestCase
{
    private function firstItem(): array
    {
        $item = fetch('SELECT id, name FROM items ORDER BY id ASC LIMIT 1');
        $this->assertNotNull($item, 'Expected at least one seeded item');
        return $item;
    }

    public function testGetUserBidsKeepsBidStatusAndResolvesItemName(): void
    {
        $item = $this->firstItem();
        $seller = $this->makeUser();
        $bidder = $this->makeUser();

        $listingId = insert('market_listings', [
            'seller_id' => (int) $seller['id'],
            'item_type' => 'item',
            'item_id' => (int) $item['id'],
            'qty' => 1,
            'bid_price' => 150,
            'min_bid' => 100,
            'status' => 'active',
        ]);
        insert('market_bids', [
            'listing_id' => $listingId,
            'bidder_id' => (int) $bidder['id'],
            'amount' => 150,
            'status' => 'outbid',
        ]);

        $bids = market_get_user_bids((int) $bidder['id']);
        $this->assertCount(1, $bids);
        $this->assertSame('outbid', $bids[0]['status'], 'bid status was clobbered by the listing status');
        $this->assertSame((int) $listingId, (int) $bids[0]['listing_id']);
        $this->assertSame((int) $item['id'], (int) $bids[0]['item_id']);
        $this->assertSame($item['name'], $bids[0]['item_name']);
        $this->assertSame(150, (int) $bids[0]['amount']);
    }

    public function testGetUserBidsOnlyReturnsOwnBids(): void
    {
        $item = $this->firstItem();
        $seller = $this->makeUser();
        $mine = $this->makeUser();
        $other = $this->makeUser();

        $listingId = insert('market_listings', [
            'seller_id' => (int) $seller['id'],
            'item_type' => 'item',
            'item_id' => (int) $item['id'],
            'qty' => 1,
            'status' => 'active',
        ]);
        insert('market_bids', ['listing_id' => $listingId, 'bidder_id' => (int) $mine['id'], 'amount' => 10, 'status' => 'active']);
        insert('market_bids', ['listing_id' => $listingId, 'bidder_id' => (int) $other['id'], 'amount' => 20, 'status' => 'active']);

        $bids = market_get_user_bids((int) $mine['id']);
        $this->assertCount(1, $bids);
        $this->assertSame((int) $mine['id'], (int) $bids[0]['bidder_id']);
    }
}
