<?php
/**
 * Mafia Empire - Security Module
 * Comprehensive security: rate limiting, CSP, headers, input validation, rate limiting
 */

declare(strict_types=1);

if (!defined('SECURITY_LOADED')) {
    define('SECURITY_LOADED', true);
}

// Security configuration
const SECURITY_CONFIG = [
    'rate_limit' => [
        'enabled' => true,
        'requests_per_minute' => 60,
        'burst' => 10,
        'storage' => 'memory', // 'redis' or 'memory'
    ],
    'csp' => [
        'enabled' => true,
        'report_only' => false,
        'report_uri' => '/csp-report.php',
    ],
    '2fa' => [
        'enabled' => true,
        'issuer' => 'Eye Of The Mafia',
        'digits' => 6,
        'period' => 30,
        'tolerance' => 1,
    ],
    'audit_log' => [
        'enabled' => true,
        'retention_days' => 90,
    ],
    'headers' => [
        'strict_transport_security' => true,
        'hsts_max_age' => 31536000,
        'x_frame_options' => 'DENY',
        'x_content_type_options' => 'nosniff',
        'x_xss_protection' => '1; mode=block',
        'referrer_policy' => 'strict-origin-when-cross-origin',
        'permissions_policy' => 'camera=(), microphone=(), geolocation=()',
    ],
    'rate_limit_storage' => [],
];

/**
 * Apply all security headers
 */
function apply_security_headers(): void
{
    if (headers_sent()) {
        return;
    }

    $config = SECURITY_CONFIG;

    // Strict Transport Security (HSTS)
    if ($config['headers']['strict_transport_security']) {
        $maxAge = $config['headers']['hsts_max_age'];
        header("Strict-Transport-Security: max-age={$maxAge}; includeSubDomains; preload");
    }

    // X-Frame-Options
    header('X-Frame-Options: ' . $config['headers']['x_frame_options']);

    // X-Content-Type-Options
    header('X-Content-Type-Options: ' . $config['headers']['x_content_type_options']);

    // X-XSS-Protection
    header('X-XSS-Protection: ' . $config['headers']['x_xss_protection']);

    // Referrer Policy
    header('Referrer-Policy: ' . $config['headers']['referrer_policy']);

    // Permissions Policy
    header('Permissions-Policy: ' . $config['headers']['permissions_policy']);

    // Content Security Policy
    if ($config['csp']['enabled']) {
        $csp = build_csp_header();
        if ($config['csp']['report_only']) {
            header('Content-Security-Policy-Report-Only: ' . $csp);
        } else {
            header('Content-Security-Policy: ' . $csp);
        }
    }

    // Additional security headers
    header('X-Robots-Tag: noindex, nofollow');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
}

/**
 * Build Content Security Policy header
 */
function build_csp_header(): string
{
    $csp = [
        "default-src 'self'",
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net https://cdn.jsdelivr.net/npm/ https://cdn.jsdelivr.net/npm/graphql-playground-react@*/",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net",
        "font-src 'self' data: https://fonts.gstatic.com https://cdn.jsdelivr.net",
        "img-src 'self' data: https:",
        "connect-src 'self' https://fonts.gstatic.com https://fonts.googleapis.com",
        "frame-src 'self'",
        "object-src 'none'",
        "base-uri 'self'",
        "form-action 'self'",
        "frame-ancestors 'none'",
        "manifest-src 'self'",
    ];

    $cspString = implode('; ', $csp);

    $config = SECURITY_CONFIG;
    if ($config['csp']['report_uri']) {
        $cspString .= "; report-uri {$config['csp']['report_uri']}";
    }

    return $cspString;
}

/**
 * Initialize rate limiter
 */
function init_rate_limiter(): void
{
    if (!SECURITY_CONFIG['rate_limit']['enabled']) {
        return;
    }

    // Clean up old entries periodically
    if (mt_rand(1, 100) === 1) {
        cleanup_rate_limit_storage();
    }
}

/**
 * Check rate limit for current request
 * Returns array ['allowed' => bool, 'retry_after' => int|null, 'limit' => int, 'remaining' => int]
 */
function check_rate_limit(string $identifier = '', int $limit = 60, int $window = 60): array
{
    if (!SECURITY_CONFIG['rate_limit']['enabled']) {
        return ['allowed' => true, 'retry_after' => null, 'limit' => $limit, 'remaining' => $limit];
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $key = "ratelimit:{$identifier}:{$ip}";

    $now = time();
    $windowStart = $now - $window;

    // Use Redis if available, otherwise use in-memory storage
    if (function_exists('redis') && class_exists('Redis')) {
        return rate_limit_redis($key, $limit, $window, $windowStart);
    }

    return rate_limit_memory($key, $limit, $window, $windowStart);
}

/**
 * Rate limiting using in-memory storage
 */
function rate_limit_memory(string $key, int $limit, int $window, int $windowStart): array
{
    global $rate_limit_storage;

    if (!isset($rate_limit_storage[$key])) {
        $rate_limit_storage[$key] = [];
    }

    // Remove expired entries
    $rate_limit_storage[$key] = array_filter($rate_limit_storage[$key], function ($timestamp) use ($windowStart) {
        return $timestamp > $windowStart;
    });

    $count = count($rate_limit_storage[$key]);
    $remaining = max(0, $limit - $count);

    if ($count >= $limit) {
        // Find oldest entry to calculate retry-after
        $oldest = min($rate_limit_storage[$key]);
        $retryAfter = ($oldest + 60) - time();
        return [
            'allowed' => false,
            'retry_after' => max(1, $retryAfter),
            'limit' => $limit,
            'remaining' => 0,
        ];
    }

    // Add current request
    $rate_limit_storage[$key][] = time();

    return [
        'allowed' => true,
        'retry_after' => null,
        'limit' => $limit,
        'remaining' => $remaining,
    ];
}

/**
 * Rate limiting using Redis (if available)
 */
function rate_limit_redis(string $key, int $limit, int $window, int $windowStart): array
{
    try {
        $redis = new Redis();
        $redis->connect('127.0.0.1', 6379);

        $key = "ratelimit:{$key}";
        $now = time();

        // Remove expired entries
        $redis->zremrangebyscore($key, 0, $windowStart);

        $count = $redis->zcard($key);
        $remaining = max(0, $limit - $count);

        if ($count >= $limit) {
            $oldest = $redis->zrange($key, 0, 0, ['withscores' => true]);
            $retryAfter = $oldest ? max(1, ($oldest[1] + 60) - time()) : 60;
            return [
                'allowed' => false,
                'retry_after' => $retryAfter,
                'limit' => $limit,
                'remaining' => 0,
            ];
        }

        $redis->zadd($key, time(), uniqid());
        $redis->expire($key, 60);

        return [
            'allowed' => true,
            'retry_after' => null,
            'limit' => $limit,
            'remaining' => $remaining,
        ];
    } catch (Throwable $e) {
        // Fallback to memory storage
        return rate_limit_memory('fallback', 60, 60, time() - 60);
    }
}

/**
 * Clean up old rate limit entries
 */
function cleanup_rate_limit_storage(): void
{
    global $rate_limit_storage;
    if (!is_array($rate_limit_storage)) {
        return;
    }
    $now = time();
    $windowStart = $now - 300; // 5 minutes

    foreach ($rate_limit_storage as $key => &$timestamps) {
        $timestamps = array_filter($timestamps, fn($ts) => $ts > ($now - 300));
        if (empty($timestamps)) {
            unset($rate_limit_storage[$key]);
        }
    }
}

/**
 * Apply rate limiting to current request
 * Returns false if rate limited, true if allowed
 */
function apply_rate_limit(int $limit = 60, int $window = 60, string $action = 'default'): bool
{
    $identifier = $action . ':' . ($_SERVER['REQUEST_URI'] ?? '');
    $result = check_rate_limit($identifier, $limit, $window);

    // Add rate limit headers
    header('X-RateLimit-Limit: ' . $result['limit']);
    header('X-RateLimit-Remaining: ' . $result['remaining']);
    header('X-RateLimit-Reset: ' . (time() + $window));

    if (!$result['allowed']) {
        header('Retry-After: ' . $result['retry_after']);
        http_response_code(429);
        exit(json_encode([
            'error' => 'Rate limit exceeded',
            'retry_after' => $result['retry_after'],
            'limit' => $result['limit'],
        ]));
    }

    return true;
}

/**
 * Throttle a sensitive authentication action (login, register, ...).
 *
 * Prefers session-backed counting so it works without Redis; falls back to
 * the shared limiter when no session is active. Exits with HTTP 429 when the
 * caller has exceeded $limit attempts inside $window minutes.
 */
function auth_rate_limit(string $action, int $limit = 5, int $window = 15): void
{
    $windowSeconds = max(60, $window * 60);

    if (session_status() === PHP_SESSION_ACTIVE) {
        $bucket = $_SESSION['auth_rate_limit'][$action] ?? [];
        $bucket = array_values(array_filter($bucket, static fn($ts) => (int) $ts > time() - $windowSeconds));

        if (count($bucket) >= $limit) {
            $retry = max(1, ((int) $bucket[0] + $windowSeconds) - time());
            header('Retry-After: ' . $retry);
            http_response_code(429);
            exit('Too many attempts. Please try again in ' . max(1, (int) ceil($retry / 60)) . ' minute(s).');
        }

        $bucket[] = time();
        $_SESSION['auth_rate_limit'][$action] = $bucket;
        return;
    }

    if (function_exists('check_rate_limit')) {
        $result = check_rate_limit('auth:' . $action, $limit, $windowSeconds);
        if (empty($result['allowed'])) {
            $retry = (int) ($result['retry_after'] ?? $windowSeconds);
            header('Retry-After: ' . $retry);
            http_response_code(429);
            exit('Too many attempts. Please try again later.');
        }
    }
}

/** Clear the throttle counter for an action after a successful attempt. */
function auth_rate_limit_reset(string $action): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        unset($_SESSION['auth_rate_limit'][$action]);
    }
}

/**
 * Password strength check used by the registration flow.
 * Delegates to validate_password() and returns ['valid' => bool, 'errors' => string[]].
 */
function validate_password_strength(string $password): array
{
    return validate_password($password);
}

/**
 * Validate and sanitize input
 */
function sanitize_input(string $input, int $flags = ENT_QUOTES): string
{
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return $input;
}

/**
 * Validate email
 */
function validate_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate username (alphanumeric, underscore, 3-32 chars)
 */
function validate_username(string $username): bool
{
    return preg_match('/^[a-zA-Z0-9_]{3,32}$/', $username) === 1;
}

/**
 * Validate password strength
 */
function validate_password(string $password): array
{
    $errors = [];

    if (strlen($password) < 12) {
        $errors[] = 'Password must be at least 12 characters';
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Password must contain at least one uppercase letter';
    }
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = 'Password must contain at least one lowercase letter';
    }
    if (!preg_match('/\d/', $password)) {
        $errors[] = 'Password must contain at least one number';
    }
    if (!preg_match('/[^a-zA-Z0-9]/', $password)) {
        $errors[] = 'Password must contain at least one special character';
    }

    return [
        'valid' => empty($errors),
        'errors' => $errors,
    ];
}

/**
 * Generate secure random token
 */
function generate_secure_token(int $length = 32): string
{
    return bin2hex(random_bytes($length));
}

/**
 * Verify password with timing-safe comparison
 */
function verify_password_hash(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}

/**
 * Hash password using Argon2id (PHP 7.3+)
 */
function hash_password(string $password): string
{
    return password_hash($password, PASSWORD_ARGON2ID, ['memory_cost' => 65536, 'time_cost' => 4, 'threads' => 3]);
}

/**
 * Generate secure session ID
 */
function generate_session_id(): string
{
    return bin2hex(random_bytes(32));
}

/**
 * Regenerate session ID securely
 */
function regenerate_session_id(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }
}

/**
 * Set secure session cookie parameters
 */
function init_secure_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        $httponly = true;
        $samesite = 'Lax';
        $ttl = 1800; // 30 minutes

        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'domain' => '',
            'secure' => $secure,
            'httponly' => $httponly,
            'samesite' => $samesite,
        ]);

        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.cookie_secure', $secure ? '1' : '0');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', $samesite);
        ini_set('session.gc_maxlifetime', (string) $ttl);
        ini_set('session.gc_probability', '1');
        ini_set('session.gc_divisor', '100');

        // Initialize Redis session handler if available
        require_once __DIR__ . '/session_redis.php';
        init_redis_session($ttl);

        session_start();
    }
}

/**
 * Validate CSRF token with timing-safe comparison
 */
function verify_csrf_token(string $token): bool
{
    if (!isset($_SESSION['csrf'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf'], $token);
}

/**
 * Generate CSRF token
 */
function generate_csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

/**
 * Sanitize filename for uploads
 */
function sanitize_filename(string $filename): string
{
    $filename = basename($filename);
    $filename = preg_replace('/[^a-zA-Z0-9._-]/', '', $filename);
    $filename = substr($filename, 0, 255);
    return $filename;
}

/**
 * Validate file upload
 */
function validate_upload(array $file, array $allowedTypes = [], int $maxSize = 5242880): array
{
    $errors = [];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Upload error: ' . $file['error'];
        return ['valid' => false, 'errors' => $errors];
    }

    if ($file['size'] > $maxSize) {
        $errors[] = 'File too large (max ' . format_bytes($maxSize) . ')';
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!empty($allowedTypes) && !in_array($mime, $allowedTypes, true)) {
        $errors[] = 'File type not allowed';
    }

    return [
        'valid' => empty($errors),
        'errors' => $errors,
        'mime' => $mime,
    ];
}

/**
 * Format bytes to human readable
 */
function format_bytes(int $bytes, int $precision = 2): string
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    return round($bytes, $precision) . ' ' . $units[$pow];
}

/**
 * Generate CSP report endpoint
 */
function handle_csp_report(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit;
    }

    $input = file_get_contents('php://input');
    $report = json_decode($input, true);

    if ($report) {
        // Log CSP violation
        log_security('csp_violation', [
            'report' => $report,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
        ]);
    }

    http_response_code(204);
}

/**
 * Security headers middleware for API
 */
function apply_api_security_headers(): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
}

/**
 * Validate JSON request
 */
function validate_json_request(): array
{
    if ($_SERVER['CONTENT_TYPE'] !== 'application/json') {
        http_response_code(415);
        exit(json_encode(['error' => 'Content-Type must be application/json']));
    }

    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        exit(json_encode(['error' => 'Invalid JSON']));
    }

    return $data;
}

/**
 * Sanitize output for JSON
 */
function json_safe_encode(mixed $data): string
{
    return json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
}

/**
 * Generate secure random string
 */
function random_string(int $length = 32, string $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'): string
{
    $bytes = random_bytes($length);
    $result = '';
    for ($i = 0; $i < $length; $i++) {
        $result .= $chars[$bytes[$i] % strlen($chars)];
    }
    return $result;
}

/**
 * Secure compare strings (timing-safe)
 */
function secure_compare(string $a, string $b): bool
{
    if (strlen($a) !== strlen($b)) {
        return false;
    }
    return hash_equals($a, $b);
}

/**
 * Check if request is AJAX
 */
function is_ajax(): bool
{
    return (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
        || (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');
}

/**
 * Get client IP address
 */
function get_client_ip(): string
{
    $headers = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR',
    ];

    foreach ($headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ips = explode(',', $_SERVER[$header]);
            return trim($ips[0]);
        }
    }

    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

/**
 * Check if IP is banned
 */
function is_ip_banned(string $ip): bool
{
    return fetch_one('SELECT 1 FROM admin_ip_bans WHERE ip_address = ? AND (expires_at IS NULL OR expires_at > NOW())', [$ip], 0) > 0;
}

/**
 * Ban IP address
 */
function ban_ip(string $ip, int $adminId, string $reason, ?string $expiresAt = null): bool
{
    try {
        q('INSERT INTO admin_ip_bans (ip_address, admin_id, reason, expires_at) VALUES (?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE reason = VALUES(reason), expires_at = VALUES(expires_at)',
           [$ip, $adminId, $reason, $expiresAt]);
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * Unban IP address
 */
function unban_ip(string $ip): bool
{
    try {
        q('DELETE FROM admin_ip_bans WHERE ip_address = ?', [$ip]);
        return true;
    } catch (Throwable $e) {
        return false;
    }
}