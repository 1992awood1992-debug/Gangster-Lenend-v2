<?php
/**
 * Eye Of The Mafia - Vehicle Racing System
 * Race against other players, bet on outcomes.
 */

require_once __DIR__ . '/init.php';

/**
 * Get all active race tracks
 */
function race_get_tracks(): array
{
    return fetch_all("
        SELECT * FROM race_tracks 
        WHERE is_active = 1 
        ORDER BY min_vehicle_level
    ");
}

/**
 * Get a track by ID
 */
function race_get_track(int $trackId): ?array
{
    return fetch('SELECT * FROM race_tracks WHERE id = ?', [$trackId]);
}

/**
 * Get active/waiting races
 */
function race_get_active(): array
{
    $races = fetch_all("
        SELECT re.*, rt.name as track_name, rt.distance_km, rt.description
        FROM race_events re
        JOIN race_tracks rt ON rt.id = re.track_id
        WHERE re.status IN ('waiting','racing')
        ORDER BY re.created_at DESC
    ");
    // Attach the current entrants so the page can render the grid without
    // re-querying each race.
    foreach ($races as &$race) {
        $race['participants'] = fetch_all("
            SELECT rp.*, u.username, u.level, ui.item_id, i.name as vehicle_name,
                   i.attack as vehicle_speed, i.defense as vehicle_handling
            FROM race_participants rp
            JOIN users u ON u.id = rp.user_id
            LEFT JOIN user_items ui ON ui.id = rp.vehicle_id
            LEFT JOIN items i ON i.id = ui.item_id
            WHERE rp.race_id = ?
            ORDER BY rp.position ASC, rp.id ASC
        ", [(int) $race['id']]);
    }
    unset($race);
    return $races;
}

/**
 * Get race with participants
 */
function race_get_with_participants(int $raceId): ?array
{
    // Note: alias the track columns explicitly — a bare `rt.*` collides with
    // `re.id` / `re.entry_fee_*` and silently overwrites the event's own id.
    $race = fetch('SELECT re.*, rt.code AS track_code, rt.name, rt.description,
                          rt.min_vehicle_level, rt.distance_km, rt.base_reward_money,
                          rt.base_reward_xp, rt.base_reward_points, rt.is_active
                   FROM race_events re JOIN race_tracks rt ON rt.id = re.track_id
                   WHERE re.id = ?', [$raceId]);
    if (!$race) return null;
    
    $race['participants'] = fetch_all("
        SELECT rp.*, u.username, u.level, ui.item_id, i.name as vehicle_name, i.attack as vehicle_speed, i.defense as vehicle_handling
        FROM race_participants rp
        JOIN users u ON u.id = rp.user_id
        LEFT JOIN user_items ui ON ui.id = rp.vehicle_id
        LEFT JOIN items i ON i.id = ui.item_id
        WHERE rp.race_id = ?
    ", [$raceId]);
    
    $race['bets'] = fetch_all("
        SELECT rb.*, u.username as bettor_name, u2.username as target_name
        FROM race_bets rb
        JOIN users u ON u.id = rb.bettor_id
        JOIN users u2 ON u2.id = rb.target_user_id
        WHERE rb.race_id = ?
    ", [$raceId]);
    
    return $race;
}

/**
 * Get user's active race
 */
function race_get_user_active(int $userId): ?array
{
    return fetch("
        SELECT re.*, rt.name as track_name
        FROM race_events re
        JOIN race_tracks rt ON rt.id = re.track_id
        JOIN race_participants rp ON rp.race_id = re.id
        WHERE rp.user_id = ? AND re.status IN ('waiting','racing')
        ORDER BY re.created_at DESC LIMIT 1
    ", [$userId]);
}

/**
 * Get user's vehicles (items of type vehicle)
 */
function race_get_user_vehicles(int $userId): array
{
    return fetch_all("
        SELECT ui.*, i.name, i.attack, i.defense, i.type
        FROM user_items ui
        JOIN items i ON i.id = ui.item_id
        WHERE ui.user_id = ? AND ui.qty > 0 AND i.type = 'vehicle'
        ORDER BY i.attack DESC
    ", [$userId]);
}

/**
 * Check if user can join a race
 */
function race_can_join(int $userId, int $raceId): array
{
    $race = race_get_with_participants($raceId);
    if (!$race) return ['ok' => false, 'error' => 'Race not found'];
    if ($race['status'] !== 'waiting') return ['ok' => false, 'error' => 'Race not accepting entries'];

    $user = fetch('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$user) return ['ok' => false, 'error' => 'User not found'];

    // Check if already in race
    $existing = fetch_one('SELECT 1 FROM race_participants WHERE race_id = ? AND user_id = ?', [$raceId, $userId]);
    if ($existing) return ['ok' => false, 'error' => 'Already in this race'];

    // Check max racers
    $count = (int) fetch_one('SELECT COUNT(*) FROM race_participants WHERE race_id = ?', [$raceId], 0);
    if ($count >= (int) $race['max_racers']) return ['ok' => false, 'error' => 'Race is full'];

    // Check entry fee
    if ((int) $user['money'] < (int) $race['entry_fee_money']) return ['ok' => false, 'error' => 'Not enough cash for entry fee'];
    if ((int) $user['bullets'] < (int) $race['entry_fee_bullets']) return ['ok' => false, 'error' => 'Not enough bullets for entry fee'];

    // Check if user has a vehicle
    $vehicles = race_get_user_vehicles($userId);
    if (empty($vehicles)) return ['ok' => false, 'error' => 'No vehicle owned'];

    // Check vehicle level requirement
    // For simplicity, any vehicle works, but speed affects race outcome

    return ['ok' => true, 'race' => $race, 'vehicles' => $vehicles];
}

/**
 * Join a race
 */
function race_join(int $userId, int $raceId, int $vehicleId): array
{
    $check = race_can_join($userId, $raceId);
    if (!$check['ok']) return $check;

    $race = $check['race'];
    $vehicle = fetch('SELECT ui.*, i.name, i.attack, i.defense FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.id = ? AND ui.user_id = ?', [$vehicleId, $userId]);
    if (!$vehicle) return ['ok' => false, 'error' => 'Vehicle not found'];

    // Deduct entry fee
    add_money($userId, -(int) $race['entry_fee_money'], 'Race entry: ' . $race['name']);
    q('UPDATE users SET bullets = bullets - ? WHERE id = ?', [(int) $race['entry_fee_bullets'], $userId]);

    // Add to participants
    insert('race_participants', [
        'race_id' => $raceId,
        'user_id' => $userId,
        'vehicle_id' => $vehicleId,
    ]);

    // Update prize pool
    q('UPDATE race_events SET prize_pool_money = prize_pool_money + ?, prize_pool_xp = prize_pool_xp + ?, prize_pool_points = prize_pool_points + ? WHERE id = ?',
        [(int) $race['entry_fee_money'], (int) $race['base_reward_xp'], (int) $race['base_reward_points'], $race['id']]);

    analytics_track('race_join', $userId, [
        'race_id' => $raceId,
        'track_id' => (int) $race['track_id'],
        'vehicle_id' => $vehicleId,
    ]);

    return ['ok' => true];
}

/**
 * Place a bet on a racer
 */
function race_bet(int $bettorId, int $raceId, int $targetUserId, int $amountMoney, int $amountBullets = 0): array
{
    $race = race_get_with_participants($raceId);
    if (!$race) return ['ok' => false, 'error' => 'Race not found'];
    if ($race['status'] !== 'waiting' && $race['status'] !== 'racing') return ['ok' => false, 'error' => 'Betting closed'];

    $bettor = fetch('SELECT * FROM users WHERE id = ?', [$bettorId]);
    if (!$bettor) return ['ok' => false, 'error' => 'User not found'];

    // Can't bet on yourself
    if ($bettorId === $targetUserId) return ['ok' => false, 'error' => 'Cannot bet on yourself'];

    // Check target is in race
    $targetInRace = false;
    foreach ($race['participants'] as $p) {
        if ((int) $p['user_id'] === $targetUserId) { $targetInRace = true; break; }
    }
    if (!$targetInRace) return ['ok' => false, 'error' => 'Target not in this race'];

    // Check funds
    if ((int) $bettor['money'] < $amountMoney) return ['ok' => false, 'error' => 'Not enough cash'];
    if ((int) $bettor['bullets'] < $amountBullets) return ['ok' => false, 'error' => 'Not enough bullets'];

    // Deduct
    add_money($bettorId, -$amountMoney, 'Race bet on ' . $targetUserId);
    q('UPDATE users SET bullets = bullets - ? WHERE id = ?', [$amountBullets, $bettorId]);

    // Place bet
    insert('race_bets', [
        'race_id' => $raceId,
        'bettor_id' => $bettorId,
        'target_user_id' => $targetUserId,
        'amount_money' => $amountMoney,
        'amount_bullets' => $amountBullets,
    ]);

    analytics_track('race_bet', $bettorId, [
        'race_id' => $raceId,
        'target' => $targetUserId,
        'money' => $amountMoney,
    ]);

    return ['ok' => true];
}

/**
 * Start a race (cron or manual)
 */
function race_start(int $raceId): array
{
    $race = race_get_with_participants($raceId);
    if (!$race) return ['ok' => false, 'error' => 'Race not found'];
    if ($race['status'] !== 'waiting') return ['ok' => false, 'error' => 'Race not in waiting state'];

    $participants = $race['participants'];
    if (count($participants) < 2) return ['ok' => false, 'error' => 'Need at least 2 racers'];

    q('UPDATE race_events SET status = \'racing\', started_at = NOW() WHERE id = ?', [$raceId]);

    // Notify participants
    foreach ($race['participants'] as $p) {
        notify((int) $p['user_id'], 'Race started: ' . $race['name'], 'racing.php');
    }

    return ['ok' => true];
}

/**
 * Simulate race outcome (called by cron or when all finish)
 */
function race_finish(int $raceId): array
{
    $race = race_get_with_participants($raceId);
    if (!$race) return ['ok' => false, 'error' => 'Race not found'];
    if ($race['status'] !== 'racing') return ['ok' => false, 'error' => 'Race not active'];

    $participants = $race['participants'];
    
    // Calculate performance for each participant
    // Based on vehicle stats + random factor
    $results = [];
    foreach ($participants as $p) {
        $speed = (int) $p['vehicle_speed'];
        $handling = (int) $p['vehicle_handling'];
        $driverSkill = (int) $p['level'] * 2; // Level contributes
        
        // Base performance = speed * 0.6 + handling * 0.3 + driver * 0.1
        $basePerf = $speed * 0.6 + $handling * 0.3 + $driverSkill * 0.1;
        // Add randomness
        $randomFactor = mt_rand(80, 120) / 100;
        $finalTime = (int) (($race['distance_km'] * 1000) / ($basePerf * $randomFactor)); // ms
        
        $results[] = [
            'user_id' => (int) $p['user_id'],
            'time_ms' => $finalTime,
            'vehicle_name' => $p['vehicle_name'],
        ];
    }

    // Sort by time (lowest wins)
    usort($results, fn($a, $b) => $a['time_ms'] - $b['time_ms']);

    // Update participants with results
    $position = 1;
    $totalPrizeMoney = (int) $race['prize_pool_money'];
    $totalPrizeXp = (int) $race['prize_pool_xp'];
    $totalPrizePoints = (int) $race['prize_pool_points'];

    foreach ($results as $idx => $result) {
        $payoutMoney = 0;
        $payoutXp = 0;
        $payoutPoints = 0;
        
        if ($position === 1) {
            $payoutMoney = (int) floor($totalPrizeMoney * 0.5);
            $payoutXp = (int) floor((int) $race['base_reward_xp'] * 2);
            $payoutPoints = (int) floor((int) $race['base_reward_points'] * 2);
        } elseif ($position === 2) {
            $payoutMoney = (int) floor($totalPrizeMoney * 0.3);
            $payoutXp = (int) floor((int) $race['base_reward_xp'] * 1.5);
            $payoutPoints = (int) floor((int) $race['base_reward_points'] * 1.5);
        } elseif ($position === 3) {
            $payoutMoney = (int) floor($totalPrizeMoney * 0.2);
            $payoutXp = (int) $race['base_reward_xp'];
            $payoutPoints = (int) $race['base_reward_points'];
        } else {
            $payoutXp = (int) floor((int) $race['base_reward_xp'] * 0.5);
            $payoutPoints = (int) floor((int) $race['base_reward_points'] * 0.5);
        }

        // Update participant record
        q('UPDATE race_participants SET position = ?, finish_time_ms = ?, payout_money = ?, payout_xp = ?, payout_points = ? WHERE race_id = ? AND user_id = ?',
            [$position, $result['time_ms'], $payoutMoney, $payoutXp, $payoutPoints, $race['id'], $result['user_id']]);

        // Grant rewards
        if ($payoutMoney > 0) add_money($result['user_id'], $payoutMoney, 'Race winnings: ' . $race['name']);
        if ($payoutXp > 0) grant_xp($result['user_id'], $payoutXp);
        if ($payoutPoints > 0) add_points($result['user_id'], $payoutPoints);

        // Feed the result into any running racing tournament.
        if (function_exists('tournament_report_metric')) {
            $raceTournamentScore = [1 => 10, 2 => 6, 3 => 3][$position] ?? 1;
            tournament_report_metric('racing', (int) $result['user_id'], $raceTournamentScore, (int) $result['time_ms']);
        }

        // Resolve bets on this participant
        $betsOnWinner = fetch_all('SELECT * FROM race_bets WHERE race_id = ? AND target_user_id = ? AND status = \'pending\'', [$race['id'], $result['user_id']]);
        if ($betsOnWinner) {
            $racerName = 'the racer';
            foreach ($race['participants'] as $rp) {
                if ((int) $rp['user_id'] === $result['user_id']) { $racerName = (string) $rp['username']; break; }
            }
            foreach ($betsOnWinner as $bet) {
                $payout = $bet['amount_money'] * 2; // 2x payout for winner
                if ($payout > 0) add_money((int) $bet['bettor_id'], $payout, 'Race bet won: ' . $race['name']);
                q('UPDATE race_bets SET status = \'won\', payout = ?, resolved_at = NOW() WHERE id = ?', [$payout, (int) $bet['id']]);
                notify((int) $bet['bettor_id'], 'Your bet on ' . $racerName . ' won! Payout: ' . money($payout), 'racing.php');
            }
        }

        $position++;
    }

    // Mark losing bets
    q('UPDATE race_bets SET status = \'lost\', resolved_at = NOW() WHERE race_id = ? AND status = \'pending\'', [$race['id']]);

    // Update race status
    q('UPDATE race_events SET status = \'finished\', finished_at = NOW() WHERE id = ?', [$race['id']]);

    // Notify all
    $participants = fetch_all('SELECT user_id FROM race_participants WHERE race_id = ?', [$race['id']]);
    foreach ($participants as $p) {
        notify((int) $p['user_id'], 'Race finished: ' . $race['name'], 'racing.php');
    }

    return ['ok' => true, 'results' => $results];
}

/**
 * Auto-create new races for tracks that have none waiting (cron job).
 *
 * @return int number of races created
 */
function race_auto_create(): int
{
    $created = 0;
    $tracks = race_get_tracks();
    foreach ($tracks as $track) {
        // Check if there's already a waiting race for this track
        $existing = fetch_one('SELECT 1 FROM race_events WHERE track_id = ? AND status = \'waiting\'', [(int) $track['id']]);
        if ($existing) continue;

        // 30% chance to create a race
        if (mt_rand(1, 100) > 30) continue;

        $raceId = insert('race_events', [
            'track_id' => (int) $track['id'],
            'status' => 'waiting',
            'max_racers' => (int) $track['min_vehicle_level'] >= 5 ? 6 : 8,
            'entry_fee_money' => (int) $track['entry_fee_money'],
            'entry_fee_bullets' => (int) $track['entry_fee_bullets'],
            'prize_pool_money' => 0,
            'prize_pool_xp' => 0,
            'prize_pool_points' => 0,
        ]);
        if ($raceId) $created++;
    }
    return $created;
}

/**
 * Frequent cron: keep the racing circuit moving.
 *  - create new races on empty tracks
 *  - start waiting races once they have racers (and have waited a moment)
 *   - settle races in progress and pay out winners + bets
 *  - cancel races nobody joined in time, refunding entry fees
 *
 * @return array<string,int>
 */
function race_cron(): array
{
    $created = race_auto_create();

    $started = 0;
    $waiting = fetch_all("
        SELECT re.id, re.created_at, COUNT(rp.id) AS racers
        FROM race_events re
        LEFT JOIN race_participants rp ON rp.race_id = re.id
        WHERE re.status = 'waiting'
        GROUP BY re.id, re.created_at
    ");
    foreach ($waiting as $r) {
        $age = time() - strtotime((string) $r['created_at']);
        // Give players a couple of minutes to fill the grid before the flag drops.
        if ((int) $r['racers'] >= 2 && $age >= 120) {
            if (race_start((int) $r['id'])['ok']) $started++;
        }
    }

    $finished = 0;
    foreach (fetch_all("SELECT id FROM race_events WHERE status = 'racing' AND started_at IS NOT NULL AND started_at <= DATE_SUB(NOW(), INTERVAL 2 MINUTE)") as $r) {
        if (race_finish((int) $r['id'])['ok']) $finished++;
    }

    // Cancel races nobody joined in time and refund whoever did show up.
    $cancelled = 0;
    foreach (fetch_all("SELECT id, entry_fee_money, entry_fee_bullets FROM race_events WHERE status = 'waiting' AND created_at <= DATE_SUB(NOW(), INTERVAL 1 HOUR)") as $race) {
        foreach (fetch_all('SELECT user_id FROM race_participants WHERE race_id = ?', [(int) $race['id']]) as $p) {
            if ((int) $race['entry_fee_money'] > 0) add_money((int) $p['user_id'], (int) $race['entry_fee_money'], 'Race cancelled: refund');
            if ((int) $race['entry_fee_bullets'] > 0) q('UPDATE users SET bullets = bullets + ? WHERE id = ?', [(int) $race['entry_fee_bullets'], (int) $p['user_id']]);
            notify((int) $p['user_id'], 'A race you entered was cancelled. Your entry fee was refunded.', 'racing.php');
        }
        q("UPDATE race_events SET status = 'cancelled' WHERE id = ?", [(int) $race['id']]);
        $cancelled++;
    }

    return ['races_created' => $created, 'races_started' => $started, 'races_finished' => $finished, 'races_cancelled' => $cancelled];
}

/**
 * Get race history for user
 */
function race_get_user_history(int $userId, int $limit = 20): array
{
    // Select explicit event columns so the participant's own id/position win.
    return fetch_all("
        SELECT rp.*, re.track_id, re.prize_pool_money, re.prize_pool_xp, re.prize_pool_points,
               re.started_at, re.finished_at, rt.name as track_name
        FROM race_participants rp
        JOIN race_events re ON re.id = rp.race_id
        JOIN race_tracks rt ON rt.id = re.track_id
        WHERE rp.user_id = ? AND re.status = 'finished'
        ORDER BY re.finished_at DESC
        LIMIT ?
    ", [$userId, $limit]);
}

/**
 * Get betting history
 */
function race_get_bet_history(int $userId, int $limit = 20): array
{
    // `rb.*, re.*` would clobber the bet's status/payout with the event's.
    return fetch_all("
        SELECT rb.*, rt.name as track_name, u.username as target_name
        FROM race_bets rb
        JOIN race_events re ON re.id = rb.race_id
        JOIN race_tracks rt ON rt.id = re.track_id
        JOIN users u ON u.id = rb.target_user_id
        WHERE rb.bettor_id = ?
        ORDER BY rb.placed_at DESC
        LIMIT ?
    ", [$userId, $limit]);
}