# Mafia Empire - Full Expansion Roadmap

## Phase 1: Admin Panel (Week 1)
- [x] User management (search, edit, ban, delete, impersonate)
- [x] Game settings editor (rates, costs, cooldowns)
- [x] Economy tools (mass give/take, audit logs)
- [x] Content managers (missions, items, bosses, crimes, drugs, abilities)
- [x] Reports (daily stats, money flow, player retention)
- [x] Admin PIN gate + action logging

## Phase 2: Content Expansion (Week 1-2)
- [x] 50+ more missions across districts (50 added → 66 total)
- [x] 10+ new bosses with unique mechanics (10 added → 14 total)
- [x] 30+ new items (weapons, armor, vehicles, special) (33 added → 45 total)
- [x] 15+ new drugs with varied effects (15 added → 22 total)
- [x] 20+ new abilities (active + passive) (22 added → 30 total; new xp/money effects)
- [x] 50+ new achievements with chains (41 added → 51 total; 10 new metrics)
- [x] 20+ new stickers with sets/collections (20 added → 32 total, 4 themed sets)

## Phase 3: Crew Wars & Territory (Week 2)
- [x] Territory control map (districts split into zones) (12 zones, 4 districts)
- [x] Crew vs crew battles (scheduled wars, raids) (24h wars scored by kills; zone raids)
- [x] Turf income (hourly collection, upgradable)
- [x] Crew vault/armory (shared gear, bullets, drugs)
- [x] Crew perks tree (unlock with crew XP)
- [x] Diplomacy (alliances, NAPs, war declarations)

## Phase 4: More Casino Games (Week 2-3)
- [x] Blackjack (multi-hand, insurance, split, double)
- [x] Baccarat (player/banker/tie, commission)
- [x] Keno (pick 1-10, 20 balls drawn)
- [x] Crash (multiplier rises, cash out before crash)
- [x] Dice (roll under/over, multiple bets)
- [x] Slots (5-reel, paylines, wilds, scatters, bonus)

## Phase 5: Production Infrastructure (Week 3)
- [x] Dockerfile + docker-compose (nginx, php-fpm, mariadb, redis)
- [x] SSL/Let's Encrypt automation (certbot service + scripts/ssl-init.sh)
- [x] Cron jobs (tick/daily/weekly dispatcher in cron/run.php)
- [x] Backup/restore scripts (scripts/backup|restore.sh + .bat)
- [x] Health checks + monitoring (health.php JSON endpoint)
- [x] CI/CD pipeline (GitHub Actions: lint, boot smoke, tests)

## Phase 6: Automated Tests (Week 3) — DONE
- [x] PHPUnit setup (`composer.json`, `phpunit.xml`, `tests/bootstrap.php`)
- [x] Unit tests: combat, XP, economy, cooldowns
- [x] Integration tests: missions, jobs, casino, PvP
- [x] API contract tests (`health.php` contract + HTTP flow tests)
- [x] Coverage reporting wired up (pcov in CI; `includes/` target 80%+) — see `docs/TESTING.md`

## Phase 7: API & Extensions (Week 4) — DONE
- [x] REST API (auth, player data, leaderboards, market) — `api/index.php`, `includes/api.php`, `docs/API.md`
- [x] Webhooks (kill, levelup, achievement, purchase) — `includes/webhooks.php`, signed + retrying queue
- [x] Discord bot (stats, notifications, admin cmds) — `includes/discord.php`, `discord/interactions.php`, daily digest
- [x] Rate limiting, API keys, scopes — hashed keys, per-key per-minute limits, read/write/admin scopes

## Phase 8: Mobile & Polish (Week 4)
- [x] PWA manifest + service worker
- [x] Touch-optimized UI (bottom nav, swipe actions)
- [x] Offline queue for actions
- [x] Push notifications (VAPID)

## Phase 9: Social Features — DONE
- [x] Schema (migration 5.sql): trades, hitlist, bounties, crew_messages, crew_message_reads, social_notifications
- [x] Trade system (create/accept/decline, 24h expiry, notifications) — `includes/social.php`, `trades.php`
- [x] Crew chat with read tracking — `crew_chat.php`
- [x] Hitlist (place hits, bounties, claim) — `hitlist.php`
- [x] Bounty board (place/claim bounties) — `bounties.php`
- [x] Social notifications (unread counts, mark-read) + nav links
- [x] Tests: `SocialHelpersTest` (function presence)

## Phase 10: Theme & Events — DONE
- [x] Dark red mafia palette applied site-wide (pure white text)
- [x] Fonts: Cinzel + Merriweather (Google Fonts) with local fallbacks
- [x] Halloween boot screen (particles, bats, blood drips, shake, auto-hide, reduced motion)
- [x] Events system: daily/weekly/seasonal + challenge tracking
- [x] Events dashboard redesign (progress bars, rewards, claim flow, empty state)
- [x] Event metrics wired into missions + criminal jobs

## Phase 11: Security Hardening — DONE
- [x] Rate limiting on auth endpoints (login/register; 5 attempts / 15 min / IP)
- [x] `rate_limits` table (migration 6.sql, indexed)
- [x] Password strength validation (8+ chars, upper/lower/digit/special)
- [x] Security helpers: safe redirects, secure compare, token gen, session config — `includes/security.php`
- [x] Existing: CSRF tokens, prepared statements, security headers (CSP etc.)

## Phase 12: Deploy Prep & Docs — DONE
- [x] Production Docker stack reviewed (nginx/Apache configs, health checks, CI)
- [x] Compression + long-lived static asset caching (nginx + Apache)
- [x] `PUSH.md` (deployment checklist), refreshed `README.md`
- [x] Topic docs: SECURITY, PERFORMANCE, ANALYTICS, MOBILE_PWA, CONTENT_EXPANSION, SOCIAL_FEATURES

## Phase 13: Performance — DONE
- [x] Gzip + asset cache headers (docker/nginx/default.conf)
- [x] `asset()` cache-busting helper (filemtime) wired into header
- [x] Redis-backed cache helpers with per-request fallback — `includes/cache.php`
- [x] Cached: leaderboards, top crews, city ticker queries
- [x] Tests: `CacheAssetHelpersTest` (asset URL, get/set/del, remember)

## Phase 14: Analytics & Telemetry — DONE
- [x] `analytics_events` table (migration 7.sql, indexed)
- [x] Helpers: track / count / unique / daily / active-daily / prune — `includes/analytics.php`
- [x] Events wired: login, register, mission (win/fail), crime (win/fail), kill, lost fight
- [x] Admin → Analytics tab (24h KPIs, 14-day active-user chart, daily event matrix)
- [x] 30-day auto-prune via daily cron; `ANALYTICS.md` refreshed
- [x] Tests: `AnalyticsHelpersTest`

## Phase 14: Mobile / PWA Polish — DONE
- [x] Manifest: app shortcuts (Play, Missions, Criminal Jobs, Casino)
- [x] iOS Safari install guidance (no `beforeinstallprompt` on iOS)
- [x] Mobile meta tags verified (viewport-fit, theme-color, apple-*)
- [x] PWA docs refreshed (`MOBILE_PWA.md`)

## Phase 15: Content Expansion — DONE
- [x] Migration 8.sql: 2 districts (Chinatown, The Suburbs)
- [x] 8 new missions, 2 new bosses, 4 new criminal jobs, 4 legendary items
- [x] Idempotent inserts (`NOT EXISTS`) — safe on fresh + existing DBs
- [x] Live totals: 6 districts / 74 missions / 16 bosses / 24 jobs / 49 items

## Phase 16: Tournament System — DONE
- [x] Migration 17.sql: `tournaments`, `tournament_participants`, `tournament_matches`, `tournament_rewards_log` + 4 recurring seeds
- [x] Module `includes/tournaments.php`: registration + entry fees, four formats (elimination, round robin, swiss, ladder), six game types, match results, standings, prize distribution, scheduled sweep
- [x] Page `tournaments.php`: list + detail (bracket, standings, prize pool), register/withdraw
- [x] Wired into bootstrap, nav, footer and cron (auto-start / auto-complete)
- [x] Tests: `TournamentsTest` (18 tests)

## Phase 17: World Events & Community Systems — DONE
### Mini Events (random daily occurrences)
- [x] Migration: `mini_events` table (instance_code, type, name, rarity, weight, is_active, city_id, params JSON, started_at, ends_at)
- [x] Types: drug_surge, bullet_restock, safe_deposit, jackpot_boost (common/rare weights)
- [x] Cron tick task `task_mini_events()`: schedule next event 1-12h out, activate effects, post to city ticker + Discord
- [x] Effects: drug price multiplier, bullet factory production boost, safe crack pot boost, slots jackpot increment
- [x] Admin UI: list, manual trigger, force-end, config weights/intervals
- [x] "Online in last 10 min" notification via `notify()` loop + push bridge

### Weekend Events (scheduled per round week)
- [x] Migration: `weekend_events` table (event_type, week, start_at, end_at, status)
- [x] Types: double_xp, bullet_rush, looting_spree, motor_madness, crush_rush
- [x] Cron daily task: auto-activate/expire per schedule (Week 2 = Looting Spree, Week 3 = Double XP, etc.)
- [x] Gameplay hooks: XP multiplier, bullet drop rate, looting yield, vehicle theft chance, race payout boost
- [x] Admin UI: schedule editor, override dates, manual toggle

### Seasonal Events (calendar holidays)
- [x] Migration: `seasonal_events` table (holiday_code, year, start_at, end_at, config JSON)
- [x] Valentine's Day (Feb 14-15): Love Bug vehicle (100% theft), special mission, Cupid Coat respray
- [x] Easter (Good Friday–Easter Mon): Bunny Buggy (50% theft), Easter Eggs in looting, Bunny Drip respray
- [x] Independence Day (Jul 4 ±1): Mini Flags in looting, "Uncle Sam's Errand" mission, Liberty Gloss respray
- [x] Halloween (Oct 15-31): Candy from looting/heist/mission, Skeleton Key perk (30min 100% theft), Death Wagon, Blood Drip respray
- [x] Christmas (Dec 1-25): Daily Christmas Giveaway (same gift for all, uninsured), Santa's Sleigh 5000, Mistlechrome respray
- [x] Admin UI: per-year config, preview dates, toggle

### Respect System (community reputation)
- [x] Migration: `respect_log` table (from_user_id, to_user_id, amount, type=respect|disrespect, anonymous, message, created_at)
- [x] Daily send limit: 1-10 pts by main level (1-4:1, 5-9:2, … 45-50:10), +1 per 5 prestige levels
- [x] Profile shows net respect balance; send form on profile page
- [x] Recipient gets `notify()` alert with sender (unless anonymous), amount, message
- [x] Admin: leaderboards, manual adjust, audit

### Prestige System (unlimited post-50 progression)
- [x] Level cap raised to 50 "Original Gangster"; prestige starts at 101,000 XP
- [x] XP curve: Prestige N requires N×1,000 XP (P1=1k, P2=2k, … P100=100k)
- [x] Prestige levels treated as Level 50 for combat/shooting
- [x] 1 Prestige Coin per prestige level (spend in Black Market)
- [x] Migration: add `prestige_level` to users, `prestige_coins` balance
- [x] Admin: grant prestige, set level/coins, view distribution
- [x] Profile integration: prestige badge, progress bar, coins, effective level 50 for combat

### Deathmatch (final round week)
- [x] 7-day escalating finale: 2x→25x XP, rule changes, $5M/min free cash (max $250M)
- [x] Daily rule changes: bullet store ($50→$10, limit 500→2000/min), detectives (20min→2min intervals, 15→40 level range), airport wait (halved→1/3→10min), firearms/silencer 10% price, scratches 2x→4x, small crimes 100%, vehicle theft 90%, bribes $100, new player $250k, prison bribes, find gangsters shows city, butchie silence
- [x] Auto-announcements each day via ticker, Discord, notify()
- [x] Helper functions for all game systems to query current modifiers
- [x] Admin controls: set round end timestamp, manual trigger

## Phase 18: Major Systems Overhaul — DONE
### 1. Content Expansion v2 — DONE
- [x] Migration 20.sql: 50+ missions (132 total), 10+ bosses (32 total), 30+ items (73 total), 15+ drugs (49 total), 20+ abilities (70 total), 50+ achievements (79 total), 20+ stickers (80 total), 10 districts
### 2. Black Market / Prestige Coin Shop — DONE
- [x] prestige_shop.php with exclusive vehicles, weapons, perks, currency bundles, consumables
- [x] Nav integration, Prestige Coin spending, user_settings for perks
### 3. Properties 2.0: Upgradeable Safehouses & Crew Bases — DONE
- [x] Migration 21.sql: defense, storage, raid protection, crew bases, crew logs
- [x] property_get_crew_base(), property_crew_buy/upgrade/collect(), raid defense system
### 4. New Casino Games — DONE
- [x] Poker (Texas Hold'em vs AI)
- [x] Roulette (European/American, inside/outside bets)
- [x] Sports Betting (match outcomes, over/under, parlays)
### 5. API v2 — DONE
- [x] GraphQL endpoint (POST /api/v2/graphql)
- [x] SSE real-time stream (GET /api/v2/stream)
- [x] Webhook retry/status endpoints
- [x] sse_events table for real-time subscriptions
### 6. Discord Bot v2 — DONE
- [x] New slash commands: /profile, /event, /eventlist, /market, /crew, /minigame (coinflip, dice, highlow)
- [x] Rich embeds for player profiles, events, market listings, crew info
- [x] Mini-games: coinflip, dice, high/low playable in Discord
### 7. Mobile/PWA Polish — DONE
- [x] Background sync with IndexedDB offline queue
- [x] Service worker v2 with periodic sync, offline action queue
- [x] Native gestures: pull-to-refresh, swipe-back navigation, long-press context menus
- [x] Pull-to-refresh with visual indicator
- [x] Swipe-back navigation (edge swipe)
- [x] Long-press context menus
- [x] Toast swipe-to-dismiss
### 8. Advanced Economy & Marketplace — DONE
- [x] Stock Market: 10 companies, dividends, portfolio tracking, buy/sell/history
- [x] Pawn Shop: pawn items for instant cash, redeem with interest, buy forfeited items
- [x] Stock Market page with portfolio, history, dividends
- [x] Pawn Shop page with active pawns, forfeited items marketplace
- [x] Migration 23.sql: stocks, player_stocks, stock_history, stock_dividends, pawned_items, pawn_redeem_log
### 9. Performance & Scaling — DONE
- [x] Redis session store with file fallback — `includes/session_redis.php`
- [x] Query cache with tag-based invalidation — `cache_query()`, `cache_query_one()`
- [x] CDN asset preload headers — `asset_preload()`, `asset_cdn()`
- [x] CDN configuration — `CDN_BASE`, `CDN_PRELOAD_CRITICAL` in config.php
- [x] Redis session stats in admin analytics
### 10. Quality of Life — DONE
- [x] Keyboard shortcuts modal (press `?`) with G-key navigation (G+D=Dashboard, G+M=Missions, etc.)
- [x] Global G-key navigation: press G then letter to jump (D=Dashboard, M=Missions, K=Kill, C=Casino, B=Bank, P=Profile, etc.)
- [x] Bulk action forms helper (`qol_bulk_action_form()`)
- [x] Accessible input helper (`qol_accessible_input()`) with ARIA attributes
- [x] Skip link for main content
- [x] Live region announcements (`qol_announce()`)
- [x] Focus trap utility for modals/drawers
- [x] Sortable table headers helper (`qol_sortable_header()`)
- [x] Bulk action handler (`qol_handle_bulk_action()`)
- [x] Long-press context menus (touch)
- [x] Pull-to-refresh, swipe-back, swipe-to-dismiss toasts

### 11. Security Audit & 2FA — DONE
- [x] Redis session store with file fallback — `includes/session_redis.php`
- [x] Query cache with tag-based invalidation — `cache_query()`, `cache_query_one()`
- [x] CDN asset preload headers — `asset_preload()`, `asset_cdn()`
- [x] CDN configuration — `CDN_BASE`, `CDN_PRELOAD_CRITICAL` in config.php
- [x] Redis session stats in admin analytics
- [x] Database indexes for common query patterns (migration 25)
- [x] Persistent database connections
- [x] Security audit log — `security_audit_log` table
- [x] CSP violation reporting — `/csp_report.php` endpoint
- [x] Security events tracking — `security_events` table
- [x] Two-Factor Authentication (2FA) — TOTP with QR codes, backup codes
- [x] 2FA setup page — `twofa_setup.php`
- [x] 2FA login flow integration
- [x] Security admin dashboard — `admin.php?a=security`
- [x] IP ban management
- [x] CSP violation monitoring
- [x] Security event logging
- [x] Rate limit analytics

---

## Incident Recovery — style.css Reconstruction (20/10/2026)

- [x] `assets/style.css` was accidentally truncated (201 of 1343 lines) — fully reconstructed from scratch
- [x] 1200 lines / 544 rules covering: chrome (topbar, ticker, sidebar, footer), core components (cards, tables, forms, pills, tags, alerts, progress, section headers), casino (playing cards, keno, slots, crash, dice, turf map), events dashboard redesign, sticker book redesign (3D flip cards, progress ring, rarity tiers), PWA bar, pull-to-refresh, keyboard-shortcuts modal, auth pages, sepia ledger theme, responsive (1080/900/640/420px) + print styles
- [x] Verified: 89-page crawl clean (only expected `csp_report`/`push` 405s), 28 admin tabs clean, 216 tests / 933 assertions pass, browser DOM checks confirm all component styles apply
- [x] Leftover `debug_session*.php` / `debug_admin.php` files removed

### Known security finding (TODO)
- [ ] **2FA backup codes stored in plaintext** in `users.twofa_backup_codes` (JSON) in addition to hashed copies in `user_2fa_recovery` — count from hashed table and drop the plaintext column

---
**Current Status**: Core game (45 pages) ✓ | Theme ✓ | Admin panel ✓ | Content expansion ✓ | Crew wars & territory ✓ | Casino games ✓ | Production infra ✓ | Automated tests ✓ | API & extensions ✓ | Mobile & Polish ✓ | Social Features ✓ | Halloween theme + events ✓ | Security hardening ✓ | Deploy prep & docs ✓ | Performance ✓ | Analytics & telemetry ✓ | Mobile/PWA polish ✓ | Content expansion ✓ | Tournament system ✓ | Auth + marketplace fixes ✓ | Racing + politics + crew chat wiring ✓ | Tournament scheduling ✓ | Admin management + properties fix ✓ | Running locally ✓ | **World Events & Community Systems (Phase 18) ✓** | **Deathmatch ✓** | **Respect System ✓** | **Prestige System ✓** | **Seasonal Events ✓** | **Weekend Events ✓** | **Mini Events ✓** | **Admin UI for all new systems ✓** | **Content Expansion v2 ✓** | **Prestige Coin Shop ✓** | **Properties 2.0 ✓** | **New Casino Games ✓** | **API v2 ✓** | **Discord Bot v2 ✓** | **Mobile/PWA Polish ✓** | **Stock Market ✓** | **Pawn Shop ✓** | **Redis Sessions ✓** | **Query Cache ✓** | **CDN Preload ✓** | **Keyboard Shortcuts ✓** | **Bulk Actions ✓** | **Accessibility ✓** | **Security Audit ✓** | **Two-Factor Auth ✓** | **Security Dashboard ✓**