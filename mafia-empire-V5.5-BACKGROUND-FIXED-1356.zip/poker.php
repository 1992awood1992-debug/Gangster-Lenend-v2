<?php
/**
 * Eye Of The Mafia - Poker (Texas Hold'em vs AI)
 * Simplified Texas Hold'em against 1-5 AI opponents.
 */

require_once __DIR__ . '/includes/init.php';
$u = require_login();

const POKER_RANKS = [
    'HIGH_CARD' => 1, 'PAIR' => 2, 'TWO_PAIR' => 3, 'THREE_KIND' => 4,
    'STRAIGHT' => 5, 'FLUSH' => 6, 'FULL_HOUSE' => 7, 'FOUR_KIND' => 8,
    'STRAIGHT_FLUSH' => 9, 'ROYAL_FLUSH' => 10,
];

const SUITS = ['♠', '♥', '♦', '♣'];
const VALUES = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];

function poker_create_deck(): array
{
    $deck = [];
    foreach (SUITS as $suit) {
        foreach (VALUES as $i => $val) {
            $deck[] = ['suit' => $suit, 'value' => $val, 'rank' => $i];
        }
    }
    shuffle($deck);
    return $deck;
}

function poker_evaluate_hand(array $hole, array $community): array
{
    $all = array_merge($hole, $community); // 7 cards
    // Simplified: find best 5-card combination
    // For full implementation, use a proper hand evaluator
    // This is a simplified version for the game
    
    $values = array_count_values(array_column($all, 'rank'));
    $suits = array_count_values(array_column($all, 'suit'));
    
    // Check flush
    $flushSuit = null;
    foreach ($suits as $suit => $count) {
        if ($count >= 5) { $flushSuit = $suit; break; }
    }
    
    // Check straight
    $uniqueRanks = array_keys($values);
    sort($uniqueRanks);
    $straight = false;
    $straightHigh = 0;
    for ($i = 0; $i <= count($uniqueRanks) - 5; $i++) {
        $run = true;
        for ($j = 1; $j < 5; $j++) {
            if (!in_array($uniqueRanks[$i] + $j, $uniqueRanks)) { $run = false; break; }
        }
        if ($run) { $straight = true; $straightHigh = $uniqueRanks[$i + 4]; break; }
    }
    // Wheel straight (A-2-3-4-5)
    if (!$straight && in_array(12, $uniqueRanks) && in_array(0, $uniqueRanks) && in_array(1, $uniqueRanks) && in_array(2, $uniqueRanks) && in_array(3, $uniqueRanks)) {
        $straight = true; $straightHigh = 3;
    }
    
    // Count multiples
    arsort($values);
    $counts = array_values($values);
    $highCard = max(array_keys($values));
    
    if ($straight && $flushSuit) {
        if ($straightHigh === 12) return ['rank' => 'ROYAL_FLUSH', 'value' => POKER_RANKS['ROYAL_FLUSH'], 'high' => 12];
        return ['rank' => 'STRAIGHT_FLUSH', 'value' => POKER_RANKS['STRAIGHT_FLUSH'], 'high' => $straightHigh];
    }
    if ($counts[0] === 4) return ['rank' => 'FOUR_KIND', 'value' => POKER_RANKS['FOUR_KIND'], 'high' => array_search(4, $values)];
    if ($counts[0] === 3 && isset($counts[1]) && $counts[1] >= 2) return ['rank' => 'FULL_HOUSE', 'value' => POKER_RANKS['FULL_HOUSE'], 'high' => array_search(3, $values)];
    if ($flushSuit) return ['rank' => 'FLUSH', 'value' => POKER_RANKS['FLUSH'], 'high' => $highCard];
    if ($straight) return ['rank' => 'STRAIGHT', 'value' => POKER_RANKS['STRAIGHT'], 'high' => $straightHigh];
    if ($counts[0] === 3) return ['rank' => 'THREE_KIND', 'value' => POKER_RANKS['THREE_KIND'], 'high' => array_search(3, $values)];
    if ($counts[0] === 2 && isset($counts[1]) && $counts[1] === 2) return ['rank' => 'TWO_PAIR', 'value' => POKER_RANKS['TWO_PAIR'], 'high' => array_search(2, $values)];
    if ($counts[0] === 2) return ['rank' => 'PAIR', 'value' => POKER_RANKS['PAIR'], 'high' => array_search(2, $values)];
    return ['rank' => 'HIGH_CARD', 'value' => POKER_RANKS['HIGH_CARD'], 'high' => $highCard];
}

// Game state stored in casino_state
$st = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'poker']);
$st = $st ? json_decode($st['state'], true) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'new_game') {
        $stake = max(10, (int) ($_POST['stake'] ?? 0));
        $opponents = max(1, min(5, (int) ($_POST['opponents'] ?? 3)));
        if ($stake > $u['money']) { flash('Not enough cash.', 'error'); redirect('poker.php'); }
        
        add_money($u['id'], -$stake, 'Poker buy-in');
        
        $deck = poker_create_deck();
        $hole = [array_shift($deck), array_shift($deck)];
        $oppHoles = [];
        for ($i = 0; $i < $opponents; $i++) {
            $oppHoles[] = [array_shift($deck), array_shift($deck)];
        }
        $community = [array_shift($deck), array_shift($deck), array_shift($deck)]; // Flop
        $turn = array_shift($deck);
        $river = array_shift($deck);
        
        $st = [
            'stake' => $stake,
            'opponents' => $opponents,
            'deck' => $deck,
            'hole' => $hole,
            'opp_holes' => $oppHoles,
            'community' => $community,
            'turn' => $turn,
            'river' => $river,
            'stage' => 'flop', // preflop, flop, turn, river, showdown
            'pot' => $stake * ($opponents + 1),
            'current_bet' => 0,
            'player_bet' => 0,
            'opp_bets' => array_fill(0, $opponents, 0),
            'active_opponents' => array_fill(0, $opponents, true),
        ];
    } elseif ($action === 'fold' && $st && $st['stage'] !== 'showdown') {
        // Player folds - game ends, opponents win
        $st = null;
        flash('You folded.', 'error');
    } elseif (in_array($action, ['check','call','raise']) && $st && $st['stage'] !== 'showdown') {
        // Betting logic simplified
        if ($action === 'raise') {
            $raiseAmount = (int) ($_POST['amount'] ?? 0);
            if ($raiseAmount < $st['current_bet'] * 2 || $raiseAmount > $u['money'] + $st['player_bet']) {
                flash('Invalid raise amount.', 'error');
            } else {
                $st['player_bet'] = $raiseAmount;
                $st['current_bet'] = $raiseAmount;
                add_money($u['id'], -($raiseAmount - $st['player_bet']), 'Poker raise');
                $st['pot'] += $raiseAmount - $st['player_bet'];
            }
        } elseif ($action === 'call') {
            $callAmount = $st['current_bet'] - $st['player_bet'];
            if ($callAmount > $u['money']) { flash('Not enough cash.', 'error'); }
            else {
                add_money($u['id'], -$callAmount, 'Poker call');
                $st['player_bet'] = $st['current_bet'];
                $st['pot'] += $callAmount;
            }
        }
        // AI response simplified
        foreach ($st['opp_holes'] as $i => $opp) {
            if (!$st['active_opponents'][$i]) continue;
            // Simple AI: call/raise/fold based on hand strength
            $hand = poker_evaluate_hand($opp, $st['community']);
            if ($hand['value'] >= POKER_RANKS['PAIR']) {
                if ($st['current_bet'] > $st['opp_bets'][$i]) {
                    $st['opp_bets'][$i] = $st['current_bet'];
                    $st['pot'] += $st['current_bet'] - $st['opp_bets'][$i];
                }
            } elseif ($hand['value'] >= POKER_RANKS['HIGH_CARD'] && mt_rand(1,100) < 30) {
                // Bluff
                $raise = $st['current_bet'] * 2;
                $st['opp_bets'][$i] = $raise;
                $st['current_bet'] = $raise;
                $st['pot'] += $raise - $st['opp_bets'][$i];
            } else {
                $st['active_opponents'][$i] = false; // fold
            }
        }
        // Advance stage
        if ($st['stage'] === 'preflop') $st['stage'] = 'flop';
        elseif ($st['stage'] === 'flop') { $st['community'][] = $st['turn']; $st['stage'] = 'turn'; }
        elseif ($st['stage'] === 'turn') { $st['community'][] = $st['river']; $st['stage'] = 'river'; }
        elseif ($st['stage'] === 'river') { $st['stage'] = 'showdown'; }
    } elseif ($action === 'showdown' && $st && $st['stage'] === 'showdown') {
        // Evaluate all hands
        $playerHand = poker_evaluate_hand($st['hole'], $st['community']);
        $bestOppHand = ['value' => 0];
        $winners = 1; // player counts as 1
        
        foreach ($st['opp_holes'] as $i => $opp) {
            if (!$st['active_opponents'][$i]) continue;
            $oppHand = poker_evaluate_hand($opp, $st['community']);
            if ($oppHand['value'] > $bestOppHand['value'] || ($oppHand['value'] === $bestOppHand['value'] && $oppHand['high'] > $bestOppHand['high'])) {
                $bestOppHand = $oppHand;
            }
        }
        
        $playerWon = $playerHand['value'] > $bestOppHand['value'] || ($playerHand['value'] === $bestOppHand['value'] && $playerHand['high'] > $bestOppHand['high']);
        
        if ($playerWon) {
            $winnings = $st['pot'];
            add_money($u['id'], $winnings, 'Poker win');
            event_track('casino_won', (int) $winnings);
            flash('You won ' . money($winnings) . ' with ' . $playerHand['rank'] . '!', 'success');
        } else {
            flash('You lost with ' . $playerHand['rank'] . '. Best opponent had ' . $bestOppHand['rank'] . '.', 'error');
        }
        
        insert('casino_bets', ['user_id' => $u['id'], 'game' => 'poker', 'stake' => $st['stake'], 'payout' => $playerWon ? $st['pot'] : 0, 'detail' => $playerHand['rank'] . ' vs ' . $bestOppHand['rank']]);
        $st = null;
    }
    
    if ($st) {
        q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'poker', json_encode($st)]);
    } else {
        q('DELETE FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'poker']);
    }
    redirect('poker.php');
}

$page_title = 'Poker';
require __DIR__ . '/includes/header.php';
$u = current_user();

$activeOpponents = 0;
if ($st) {
    foreach ($st['active_opponents'] as $active) if ($active) $activeOpponents++;
}
?>
<div class="card">
  <div class="panel-heading">Poker — Texas Hold'em</div>
  <p class="muted small">Play against 1-5 AI opponents. Simplified betting: check, call, raise, or fold.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<?php if (!$st): ?>
<div class="card">
  <form method="post" style="max-width:400px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="new_game">
    <label>Buy-in (min $10) <input type="number" name="stake" min="10" max="<?= (int) $u['money'] ?>" value="100" required></label>
    <label>Opponents (1-5) <input type="number" name="opponents" min="1" max="5" value="3" required></label>
    <button class="btn btn-gold btn-block" type="submit">Start Game</button>
  </form>
</div>
<?php else: ?>
<!-- Poker Table -->
<div class="card">
  <div class="panel-heading">Table — Pot: <b><?= money($st['pot']) ?></b> | Stage: <b><?= ucfirst($st['stage']) ?></b> | To Call: <b><?= money(max(0, $st['current_bet'] - $st['player_bet'])) ?></b></div>
  
  <!-- Community Cards -->
  <div style="display:flex;gap:8px;justify-content:center;margin:16px 0;flex-wrap:wrap">
    <?php foreach ($st['community'] as $c): ?>
      <div class="slot-cell" style="width:60px;height:90px;font-size:1.5rem">
        <span style="color:<?= in_array($c['suit'],['♥','♦'])?'#c00':'#000' ?>"><?= $c['value'] . $c['suit'] ?></span>
      </div>
    <?php endforeach; ?>
    <?php if ($st['stage'] === 'turn' || $st['stage'] === 'river'): ?>
      <div class="slot-cell" style="width:60px;height:90px;background:#2a1d19;opacity:0.5">?</div>
    <?php endif; ?>
    <?php if ($st['stage'] === 'river'): ?>
      <div class="slot-cell" style="width:60px;height:90px;background:#2a1d19;opacity:0.5">?</div>
    <?php endif; ?>
  </div>
  
  <!-- Opponents -->
  <div style="display:flex;gap:16px;justify-content:center;margin:16px 0;flex-wrap:wrap">
    <?php foreach ($st['opp_holes'] as $i => $opp): 
      $active = $st['active_opponents'][$i];
      $bet = $st['opp_bets'][$i];
    ?>
    <div class="card" style="width:180px;opacity:<?= $active ? 1 : 0.4 ?>">
      <b>Opponent <?= $i+1 ?></b> <?= $active ? '' : '<span class="tag tag-common">FOLDED</span>' ?>
      <div class="muted small">Bet: <?= money($bet) ?></div>
      <div style="display:flex;gap:4px;justify-content:center">
        <div class="slot-cell" style="width:40px;height:60px;background:#2a1d19;opacity:0.5">?</div>
        <div class="slot-cell" style="width:40px;height:60px;background:#2a1d19;opacity:0.5">?</div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  
  <!-- Player Hand -->
  <div style="display:flex;gap:8px;justify-content:center;margin:16px 0">
    <?php foreach ($st['hole'] as $c): ?>
      <div class="slot-cell" style="width:70px;height:100px;font-size:2rem">
        <span style="color:<?= in_array($c['suit'],['♥','♦'])?'#c00':'#000' ?>"><?= $c['value'] . $c['suit'] ?></span>
      </div>
    <?php endforeach; ?>
  </div>
  
  <?php if ($st['stage'] !== 'showdown'): ?>
  <!-- Actions -->
  <div class="card" style="max-width:500px;margin:0 auto">
    <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="fold">
      <button class="btn btn-danger" type="submit">Fold</button>
      
      <?php if ($st['current_bet'] > $st['player_bet']): ?>
        <input type="hidden" name="action" value="call">
        <button class="btn btn-gold" type="submit">Call <?= money($st['current_bet'] - $st['player_bet']) ?></button>
        
        <input type="hidden" name="action" value="raise">
        <input type="number" name="amount" min="<?= $st['current_bet'] * 2 ?>" max="<?= (int) $u['money'] + $st['player_bet'] ?>" placeholder="Raise to" style="width:100px" required>
        <button class="btn btn-gold" type="submit">Raise</button>
      <?php else: ?>
        <input type="hidden" name="action" value="check">
        <button class="btn btn-gold" type="submit">Check</button>
        
        <input type="hidden" name="action" value="raise">
        <input type="number" name="amount" min="<?= max(10, $st['stake']) ?>" max="<?= (int) $u['money'] ?>" placeholder="Bet" style="width:100px" required>
        <button class="btn btn-gold" type="submit">Bet</button>
      <?php endif; ?>
    </form>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>