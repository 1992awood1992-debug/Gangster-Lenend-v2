<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    $uiId = (int)($_POST['user_item_id'] ?? 0);
    $ui = fetch('SELECT ui.*, i.name, i.type, i.attack, i.defense FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.id = ? AND ui.user_id = ?', [$uiId, $u['id']]);
    if (!$ui) { flash('Vehicle not found.', 'error'); redirect('garage.php'); }
    if ($action === 'equip') {
        if ((int)$u['level'] < (int)fetch_one('SELECT min_level FROM items WHERE id=?', [$ui['item_id']], 1)) { flash('Level too low.', 'error'); redirect('garage.php'); }
        q('UPDATE user_items SET equipped = 0 WHERE user_id = ? AND item_id IN (SELECT id FROM items WHERE type = ?)', [$u['id'], 'vehicle']);
        q('UPDATE user_items SET equipped = 1 WHERE id = ? AND user_id = ?', [$uiId, $u['id']]);
        flash('Equipped ' . e($ui['name']) . '.', 'success');
    } elseif ($action === 'unequip') {
        q('UPDATE user_items SET equipped = 0 WHERE id = ? AND user_id = ?', [$uiId, $u['id']]);
        flash('Unequipped ' . e($ui['name']) . '.', 'success');
    } elseif ($action === 'buy_vehicle') {
        $itemId = (int)($_POST['item_id'] ?? 0);
        $sv = fetch('SELECT * FROM items WHERE id = ? AND type = ?', [$itemId, 'vehicle']);
        if (!$sv) { flash('Vehicle not found.', 'error'); redirect('garage.php'); }
        if ((int)$u['level'] < (int)$sv['min_level']) { flash('Level too low.', 'error'); redirect('garage.php'); }
        if ((int)$u['money'] < (int)$sv['cost']) { flash('Not enough cash.', 'error'); redirect('garage.php'); }
        $owns = fetch('SELECT id FROM user_items WHERE user_id = ? AND item_id = ?', [$u['id'], $itemId]);
        if ($owns) { flash('Already owned.', 'error'); redirect('garage.php'); }
        add_money($u['id'], -(int)$sv['cost'], 'Bought vehicle: ' . $sv['name']);
        insert('user_items', ['user_id' => $u['id'], 'item_id' => $itemId, 'qty' => 1, 'equipped' => 0]);
        flash('Purchased ' . e($sv['name']) . '.', 'success');
    } elseif ($action === 'sell') {
        $refund = (int) floor((int)$ui['cost'] * 0.5);
        q('DELETE FROM user_items WHERE id = ? AND user_id = ?', [$uiId, $u['id']]);
        add_money($u['id'], $refund, 'Sold vehicle: ' . $ui['name']);
        flash('Sold ' . e($ui['name']) . ' for ' . money($refund) . '.', 'success');
    }
    redirect('garage.php');
}

$page_title = 'Garage';
require __DIR__ . '/includes/header.php';
$u = current_user();
$vehicles = fetch_all('SELECT ui.*, i.name, i.description, i.type, i.attack, i.defense, i.cost, i.min_level, i.rarity FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND i.type = ? ORDER BY ui.equipped DESC, ui.id DESC', [$u['id'], 'vehicle']);
$equipped = fetch('SELECT ui.*, i.name FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND i.type = ? AND ui.equipped = 1', [$u['id'], 'vehicle']);
$shopVehicles = fetch_all('SELECT * FROM items WHERE type = ? ORDER BY cost ASC', ['vehicle']);
?>
<div class="card"><div class="panel-heading">Garage</div><p class="muted small">Own, equip, and sell vehicles. Equipped vehicles boost combat power.</p></div>

<div class="card" style="margin-top:14px">
  <div class="panel-heading">Equipped Vehicle</div>
  <?php if (!$equipped): ?>
    <p class="muted">No vehicle equipped. Buy or equip one below.</p>
  <?php else: ?>
    <div class="stat"><span><?= e($equipped['name']) ?></span><b>ATK +<?= (int)$equipped['attack'] ?> DEF +<?= (int)$equipped['defense'] ?></b></div>
    <form method="post" style="margin-top:8px"><?= csrf_field() ?><input type="hidden" name="action" value="unequip"><input type="hidden" name="user_item_id" value="<?= (int)$equipped['id'] ?>"><button class="btn btn-sm" type="submit">Unequip</button></form>
  <?php endif; ?>
</div>

<?php if ($vehicles): ?>
<div class="card" style="margin-top:14px">
  <div class="panel-heading">Your Vehicles</div>
  <div class="table-wrap"><table>
    <tr><th>Vehicle</th><th>Stats</th><th>Rarity</th><th>Level</th><th>Status</th><th>Actions</th></tr>
    <?php foreach ($vehicles as $v): $isEquipped = (int)$v['equipped'] === 1; ?>
      <tr>
        <td><b><?= e($v['name']) ?></b><br><small class="muted"><?= e($v['description']) ?></small></td>
        <td>ATK +<?= (int)$v['attack'] ?><br>DEF +<?= (int)$v['defense'] ?></td>
        <td><span class="tag tag-<?= e($v['rarity']) ?>"><?= ucfirst(e($v['rarity'])) ?></span></td>
        <td><?= (int)$v['min_level'] ?></td>
        <td><?= $isEquipped ? '<span class="tag tag-gold">EQUIPPED</span>' : '<span class="muted">Stored</span>' ?></td>
        <td>
          <?php if (!$isEquipped): ?>
            <form method="post" style="display:inline-block;margin:2px 2px 0 0"><?= csrf_field() ?><input type="hidden" name="action" value="equip"><input type="hidden" name="user_item_id" value="<?= (int)$v['id'] ?>"><button class="btn btn-gold btn-sm" type="submit">Equip</button></form>
          <?php endif; ?>
          <form method="post" style="display:inline-block;margin:2px 0 0 0" onsubmit="return confirm('Sell this vehicle?')"><?= csrf_field() ?><input type="hidden" name="action" value="sell"><input type="hidden" name="user_item_id" value="<?= (int)$v['id'] ?>"><button class="btn btn-sm" type="submit">Sell (<?= money((int)floor((int)$v['cost'] * 0.5)) ?>)</button></form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
<?php else: ?>
<div class="card" style="margin-top:14px"><p class="muted">You own no vehicles. Buy one from the shop below.</p></div>
<?php endif; ?>

<?php if ($shopVehicles): ?>
<div class="card" style="margin-top:14px">
  <div class="panel-heading">Vehicle Shop</div>
  <div class="grid grid-3">
    <?php foreach ($shopVehicles as $sv): $canAfford = (int)$u['money'] >= (int)$sv['cost']; $levelOk = (int)$u['level'] >= (int)$sv['min_level']; ?>
      <div class="card" style="text-align:center;border-top:3px solid #c4a484">
        <div style="font-size:2rem;margin-bottom:6px">&#128663;</div>
        <div class="panel-heading" style="border:none;padding:0;margin-bottom:6px"><?= e($sv['name']) ?></div>
        <p class="muted small"><?= e($sv['description']) ?></p>
        <div class="stat"><span>ATK</span><b>+<?= (int)$sv['attack'] ?></b></div>
        <div class="stat"><span>DEF</span><b>+<?= (int)$sv['defense'] ?></b></div>
        <div class="stat"><span>Cost</span><b><?= money((int)$sv['cost']) ?></b></div>
        <div class="stat"><span>Level</span><b><?= (int)$sv['min_level'] ?></b></div>
        <?php if ($canAfford && $levelOk): ?>
          <form method="post" style="margin-top:8px"><?= csrf_field() ?><input type="hidden" name="action" value="buy_vehicle"><input type="hidden" name="item_id" value="<?= (int)$sv['id'] ?>"><button class="btn btn-gold btn-sm" type="submit">Buy</button></form>
        <?php elseif (!$canAfford): ?>
          <span class="tag tag-common" style="margin-top:8px;display:inline-block">Too expensive</span>
        <?php else: ?>
          <span class="tag tag-common" style="margin-top:8px;display:inline-block">Level <?= (int)$sv['min_level'] ?>+</span>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
