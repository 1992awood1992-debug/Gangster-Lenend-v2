#!/usr/bin/env bash
#
# Mafia Empire - obtain Let's Encrypt certificates for the Docker stack.
#
# Prerequisites: the "web" service is running and port 80 is reachable from
# the internet for DOMAIN. Then:
#
#   DOMAIN=game.example.com CERTBOT_EMAIL=admin@example.com ./scripts/ssl-init.sh
#
# After it succeeds, uncomment the HTTPS server block in
# docker/nginx/default.conf, mount docker/certbot/conf into the web service,
# and reload nginx:
#
#   docker compose exec web nginx -s reload
set -euo pipefail

DOMAIN="${DOMAIN:?Set DOMAIN (e.g. game.example.com)}"
CERTBOT_EMAIL="${CERTBOT_EMAIL:?Set CERTBOT_EMAIL}"
STAGING="${STAGING:-0}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONF_DIR="$ROOT_DIR/docker/certbot/conf"
WWW_DIR="$ROOT_DIR/docker/certbot/www"
mkdir -p "$CONF_DIR" "$WWW_DIR"

STAGING_ARG=""
if [[ "$STAGING" == "1" ]]; then
    STAGING_ARG="--staging"
fi

docker compose run --rm certbot certonly \
    --webroot -w /var/www/certbot \
    $STAGING_ARG \
    --email "$CERTBOT_EMAIL" \
    --agree-tos --no-eff-email \
    -d "$DOMAIN"

echo "Certificates stored under docker/certbot/conf/live/$DOMAIN"
