-- Migration 25: Performance Indexes
-- Add database indexes for common query patterns

-- Users table indexes
CREATE INDEX IF NOT EXISTS idx_users_last_active ON users(last_active);
CREATE INDEX IF NOT EXISTS idx_users_district ON users(district_id);
CREATE INDEX IF NOT EXISTS idx_users_crew ON users(crew_id);
CREATE INDEX IF NOT EXISTS idx_users_level ON users(level);
CREATE INDEX IF NOT EXISTS idx_users_last_login ON users(last_login_date);
CREATE INDEX IF NOT EXISTS idx_users_is_banned ON users(is_banned);
CREATE INDEX IF NOT EXISTS idx_users_is_admin ON users(is_admin);
CREATE INDEX IF NOT EXISTS idx_users_referred_by ON users(referred_by);

-- Market listings indexes
CREATE INDEX IF NOT EXISTS idx_market_status ON market_listings(status);
CREATE INDEX IF NOT EXISTS idx_market_seller ON market_listings(seller_id);
CREATE INDEX IF NOT EXISTS idx_market_type_item ON market_listings(item_type, item_id);
CREATE INDEX IF NOT EXISTS idx_market_created ON market_listings(created_at);
CREATE INDEX IF NOT EXISTS idx_market_buyer ON market_listings(buyer_id);

-- User items indexes
CREATE INDEX IF NOT EXISTS idx_user_items_user ON user_items(user_id);
CREATE INDEX IF NOT EXISTS idx_user_items_equipped ON user_items(user_id, equipped);
CREATE INDEX IF NOT EXISTS idx_user_items_item ON user_items(item_id);

-- Missions indexes
CREATE INDEX IF NOT EXISTS idx_missions_district ON missions(district_id);
CREATE INDEX IF NOT EXISTS idx_missions_level ON missions(min_level);

-- Criminal jobs indexes
CREATE INDEX IF NOT EXISTS idx_jobs_level ON criminal_jobs(min_level);

-- Race events indexes
CREATE INDEX IF NOT EXISTS idx_race_status ON race_events(status);
CREATE INDEX IF NOT EXISTS idx_race_track ON race_events(track_id);

-- Heist instances indexes
CREATE INDEX IF NOT EXISTS idx_heist_crew_status ON heist_instances(crew_id, status);
CREATE INDEX IF NOT EXISTS idx_heist_leader ON heist_instances(leader_id);
CREATE INDEX IF NOT EXISTS idx_heist_status ON heist_instances(status);

-- User properties indexes
CREATE INDEX IF NOT EXISTS idx_user_props_user ON user_properties(user_id);
CREATE INDEX IF NOT EXISTS idx_user_props_type ON user_properties(property_type_id);
CREATE INDEX IF NOT EXISTS idx_user_props_crew ON user_properties(crew_id);

-- Achievements
CREATE INDEX IF NOT EXISTS idx_achievements_metric ON achievements(metric);
CREATE INDEX IF NOT EXISTS idx_user_achievements_user ON user_achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_user_achievements_ach ON user_achievements(achievement_id);

-- Stickers
CREATE INDEX IF NOT EXISTS idx_stickers_rarity ON stickers(rarity);
CREATE INDEX IF NOT EXISTS idx_user_stickers_user ON user_stickers(user_id);
CREATE INDEX IF NOT EXISTS idx_user_stickers_sticker ON user_stickers(sticker_id);

-- Race events
CREATE INDEX IF NOT EXISTS idx_race_participants_race ON race_participants(race_id);
CREATE INDEX IF NOT EXISTS idx_race_participants_user ON race_participants(user_id);
CREATE INDEX IF NOT EXISTS idx_race_bets_race ON race_bets(race_id);
CREATE INDEX IF NOT EXISTS idx_race_bets_bettor ON race_bets(bettor_id);

-- Heist participants
CREATE INDEX IF NOT EXISTS idx_heist_participants_instance ON heist_participants(instance_id);
CREATE INDEX IF NOT EXISTS idx_heist_participants_user ON heist_participants(user_id);

-- Crew wars
CREATE INDEX IF NOT EXISTS idx_crew_wars_crew ON crew_wars(crew_id);
CREATE INDEX IF NOT EXISTS idx_crew_wars_status ON crew_wars(status);

-- Tournaments
CREATE INDEX IF NOT EXISTS idx_tournaments_status ON tournaments(status);
CREATE INDEX IF NOT EXISTS idx_tournament_participants_tournament ON tournament_participants(tournament_id);
CREATE INDEX IF NOT EXISTS idx_tournament_participants_user ON tournament_participants(user_id);

-- Bounties
CREATE INDEX IF NOT EXISTS idx_bounties_target ON bounties(target_id);
CREATE INDEX IF NOT EXISTS idx_bounties_status ON bounties(status);

-- Hitlist
CREATE INDEX IF NOT EXISTS idx_hitlist_target ON hitlist(target_id);
CREATE INDEX IF NOT EXISTS idx_hitlist_status ON hitlist(status);

-- Properties
CREATE INDEX IF NOT EXISTS idx_user_properties_user ON user_properties(user_id);
CREATE INDEX IF NOT EXISTS idx_user_properties_type ON user_properties(property_type_id);

-- Social notifications
CREATE INDEX IF NOT EXISTS idx_social_notif_user ON social_notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_social_notif_type ON social_notifications(type);
CREATE INDEX IF NOT EXISTS idx_social_notif_read ON social_notifications(is_read);

-- Crew messages
CREATE INDEX IF NOT EXISTS idx_crew_messages_crew ON crew_messages(crew_id);
CREATE INDEX IF NOT EXISTS idx_crew_messages_read ON crew_message_reads(message_id, user_id);

-- Kill log
CREATE INDEX IF NOT EXISTS idx_kill_log_attacker ON kill_log(attacker_id);
CREATE INDEX IF NOT EXISTS idx_kill_log_victim ON kill_log(victim_id);
CREATE INDEX IF NOT EXISTS idx_kill_log_created ON kill_log(created_at);

-- Event log
CREATE INDEX IF NOT EXISTS idx_event_log_user ON event_log(user_id);
CREATE INDEX IF NOT EXISTS idx_event_log_type ON event_log(type);
CREATE INDEX IF NOT EXISTS idx_event_log_created ON event_log(created_at);

-- Bank transactions
CREATE INDEX IF NOT EXISTS idx_bank_tx_user ON bank_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_bank_tx_created ON bank_transactions(created_at);

-- Casino bets
CREATE INDEX IF NOT EXISTS idx_casino_bets_user ON casino_bets(user_id);
CREATE INDEX IF NOT EXISTS idx_casino_bets_game ON casino_bets(game);
CREATE INDEX IF NOT EXISTS idx_casino_bets_created ON casino_bets(created_at);

-- User login streaks
CREATE INDEX IF NOT EXISTS idx_login_streaks_last_login ON user_login_streaks(last_login_date);

-- Analytics events
CREATE INDEX IF NOT EXISTS idx_analytics_user ON analytics_events(user_id);
CREATE INDEX IF NOT EXISTS idx_analytics_type ON analytics_events(event_type);
CREATE INDEX IF NOT EXISTS idx_analytics_created ON analytics_events(created_at);

-- API requests
CREATE INDEX IF NOT EXISTS idx_api_requests_key ON api_requests(api_key_id);
CREATE INDEX IF NOT EXISTS idx_api_requests_created ON api_requests(created_at);

-- Webhook deliveries
CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_webhook ON webhook_deliveries(webhook_id);
CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_status ON webhook_deliveries(status);

-- Bump schema version
UPDATE settings SET v = '25' WHERE k = 'schema_version';