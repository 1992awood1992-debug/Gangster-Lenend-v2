<?php
/**
 * Eye Of The Mafia - Marketplace / Auction House
 * Player-to-player trading with auctions and buyout.
 */

require_once __DIR__ . '/init.php';

/**
 * Create a new listing
 */
function market_create_listing(int $sellerId, string $itemType, int $itemId, int $qty, int $buyoutPrice = 0, int $bidPrice = 0, int $minBid = 0, int $durationHours = 24): array
{
    $user = fetch('SELECT * FROM users WHERE id = ?', [$sellerId]);
    if (!$user) return ['ok' => false, 'error' => 'User not found'];

    // Validate item ownership
    if ($itemType === 'item') {
        $item = fetch('SELECT * FROM user_items WHERE user_id = ? AND item_id = ? AND qty >= ?', [$sellerId, $itemId, $qty]);
        if (!$item) return ['ok' => false, 'error' => 'Item not in inventory'];
    } elseif ($itemType === 'drug') {
        $item = fetch('SELECT * FROM user_drugs WHERE user_id = ? AND drug_id = ? AND qty >= ?', [$sellerId, $itemId, $qty]);
        if (!$item) return ['ok' => false, 'error' => 'Drug not in inventory'];
    } elseif ($itemType === 'vehicle') {
        $item = fetch('SELECT * FROM user_items WHERE user_id = ? AND item_id = ? AND qty >= ?', [$sellerId, $itemId, $qty]);
        $itemInfo = fetch('SELECT type FROM items WHERE id = ?', [$itemId]);
        if (!$item || ($itemInfo && $itemInfo['type'] !== 'vehicle')) return ['ok' => false, 'error' => 'Vehicle not in inventory'];
    } elseif ($itemType === 'blueprint') {
        $item = fetch('SELECT * FROM user_items WHERE user_id = ? AND item_id = ? AND qty >= ?', [$sellerId, $itemId, $qty]);
        if (!$item) return ['ok' => false, 'error' => 'Blueprint not in inventory'];
    } else {
        return ['ok' => false, 'error' => 'Invalid item type'];
    }

    // Remove from inventory
    if ($itemType === 'item' || $itemType === 'vehicle' || $itemType === 'blueprint') {
        q('UPDATE user_items SET qty = qty - ? WHERE id = ?', [$qty, (int) $item['id']]);
        if ((int) $item['qty'] - $qty <= 0) {
            q('DELETE FROM user_items WHERE id = ?', [(int) $item['id']]);
        }
    } elseif ($itemType === 'drug') {
        q('UPDATE user_drugs SET qty = qty - ? WHERE id = ?', [$qty, (int) $item['id']]);
        if ((int) $item['qty'] - $qty <= 0) {
            q('DELETE FROM user_drugs WHERE id = ?', [(int) $item['id']]);
        }
    }

    $endTime = date('Y-m-d H:i:s', time() + (int) $durationHours * 3600);

    $listingId = insert('market_listings', [
        'seller_id' => $sellerId,
        'item_type' => $itemType,
        'item_id' => $itemId,
        'qty' => $qty,
        'buyout_price' => $buyoutPrice > 0 ? $buyoutPrice : null,
        'bid_price' => $bidPrice,
        'min_bid' => $minBid > 0 ? $minBid : $bidPrice,
        'auction_end' => $buyoutPrice > 0 && $bidPrice > 0 ? $endTime : null,
        'status' => 'active',
    ]);

    $data = ['listing_id' => $listingId, 'type' => $itemType, 'item_id' => $itemId, 'qty' => $qty];
    analytics_track('market_list', $sellerId, $data);

    return ['ok' => true, 'listing_id' => $listingId];
}

/**
 * Get active listings with filters
 */
function market_get_listings(array $filters = []): array
{
    $where = ['ml.status = \'active\''];
    $params = [];

    if (!empty($filters['type'])) {
        $where[] = 'ml.item_type = ?';
        $params[] = $filters['type'];
    }
    if (!empty($filters['item_id'])) {
        $where[] = 'ml.item_id = ?';
        $params[] = (int) $filters['item_id'];
    }
    if (!empty($filters['seller_id'])) {
        $where[] = 'ml.seller_id = ?';
        $params[] = (int) $filters['seller_id'];
    }
    if (!empty($filters['max_price'])) {
        $where[] = '(ml.buyout_price IS NULL OR ml.buyout_price <= ?) AND ml.bid_price <= ?';
        $params[] = (int) $filters['max_price'];
        $params[] = (int) $filters['max_price'];
    }
    if (!empty($filters['search'])) {
        $where[] = '(i.name LIKE ? OR d.name LIKE ?)';
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
    }

    $whereSql = implode(' AND ', $where);

    $sql = "
        SELECT ml.*, 
               CASE 
                 WHEN ml.item_type = 'item' THEN i.name
                 WHEN ml.item_type = 'drug' THEN d.name
                 WHEN ml.item_type = 'vehicle' THEN i.name
                 WHEN ml.item_type = 'blueprint' THEN i.name
               END as item_name,
               CASE 
                 WHEN ml.item_type = 'item' THEN i.type
                 WHEN ml.item_type = 'drug' THEN 'drug'
                 WHEN ml.item_type = 'vehicle' THEN 'vehicle'
                 WHEN ml.item_type = 'blueprint' THEN 'blueprint'
               END as item_type_name,
               CASE 
                 WHEN ml.item_type IN ('item','vehicle','blueprint') THEN i.attack
                 ELSE NULL
               END as attack,
               CASE 
                 WHEN ml.item_type IN ('item','vehicle','blueprint') THEN i.defense
                 ELSE NULL
               END as defense,
               CASE 
                 WHEN ml.item_type = 'drug' THEN d.buy_price
                 ELSE NULL
               END as drug_buy_price,
               u.username as seller_name
        FROM market_listings ml
        LEFT JOIN items i ON i.id = ml.item_id AND ml.item_type IN ('item','vehicle','blueprint')
        LEFT JOIN drugs d ON d.id = ml.item_id AND ml.item_type = 'drug'
        JOIN users u ON u.id = ml.seller_id
        WHERE $whereSql
        ORDER BY ml.created_at DESC
        LIMIT 100
    ";

    return fetch_all($sql, $params);
}

/**
 * Get user's listings
 */
function market_get_user_listings(int $userId, string $status = 'active'): array
{
    return fetch_all("
        SELECT ml.*, 
               CASE 
                 WHEN ml.item_type = 'item' THEN i.name
                 WHEN ml.item_type = 'drug' THEN d.name
                 WHEN ml.item_type = 'vehicle' THEN i.name
                 WHEN ml.item_type = 'blueprint' THEN i.name
               END as item_name,
               u.username as seller_name
        FROM market_listings ml
        LEFT JOIN items i ON i.id = ml.item_id AND ml.item_type IN ('item','vehicle','blueprint')
        LEFT JOIN drugs d ON d.id = ml.item_id AND ml.item_type = 'drug'
        JOIN users u ON u.id = ml.seller_id
        WHERE ml.seller_id = ? AND ml.status = ?
        ORDER BY ml.created_at DESC
    ", [$userId, $status]);
}

/**
 * Get user's bids
 */
function market_get_user_bids(int $userId): array
{
    // Select explicit listing columns: `mb.*, ml.*` would clobber the bid's own
    // `status`/`id` with the listing's, and the page needs the resolved item name.
    return fetch_all("
        SELECT mb.*,
               ml.status AS listing_status,
               ml.item_type,
               ml.item_id,
               ml.qty,
               ml.bid_price,
               ml.buyout_price,
               ml.auction_end,
               CASE
                 WHEN ml.item_type = 'drug' THEN d.name
                 ELSE i.name
               END AS item_name,
               u.username AS seller_name
        FROM market_bids mb
        JOIN market_listings ml ON ml.id = mb.listing_id
        LEFT JOIN items i ON i.id = ml.item_id AND ml.item_type IN ('item','vehicle','blueprint')
        LEFT JOIN drugs d ON d.id = ml.item_id AND ml.item_type = 'drug'
        JOIN users u ON u.id = ml.seller_id
        WHERE mb.bidder_id = ?
        ORDER BY mb.placed_at DESC
    ", [$userId]);
}

/**
 * Place a bid on a listing
 */
function market_bid(int $bidderId, int $listingId, int $amount): array
{
    $listing = fetch('SELECT * FROM market_listings WHERE id = ? AND status = \'active\'', [$listingId]);
    if (!$listing) return ['ok' => false, 'error' => 'Listing not found or not active'];

    if ((int) $listing['seller_id'] === $bidderId) return ['ok' => false, 'error' => 'Cannot bid on your own listing'];

    $currentBid = (int) $listing['bid_price'];
    $minBid = (int) $listing['min_bid'];
    $buyout = (int) $listing['buyout_price'];

    if ($amount <= $currentBid) return ['ok' => false, 'error' => 'Bid must exceed current bid'];
    if ($amount < $minBid) return ['ok' => false, 'error' => 'Bid below minimum'];

    if ($buyout > 0 && $amount >= $buyout) {
        return market_buyout($bidderId, (int) $listing['id'], $buyout);
    }

    $bidder = fetch('SELECT * FROM users WHERE id = ?', [$bidderId]);
    if (!$bidder) return ['ok' => false, 'error' => 'User not found'];
    if ((int) $bidder['money'] < $amount) return ['ok' => false, 'error' => 'Not enough cash'];

    $prevBid = fetch('SELECT * FROM market_bids WHERE listing_id = ? AND status = \'active\' ORDER BY amount DESC LIMIT 1', [$listingId]);
    if ($prevBid) {
        add_money((int) $prevBid['bidder_id'], (int) $prevBid['amount'], 'Outbid refund: listing #' . $listingId);
        q('UPDATE market_bids SET status = \'outbid\' WHERE id = ?', [(int) $prevBid['id']]);
    }

    add_money($bidderId, -$amount, 'Market bid: listing #' . $listingId);

    insert('market_bids', [
        'listing_id' => $listingId,
        'bidder_id' => $bidderId,
        'amount' => $amount,
    ]);

    q('UPDATE market_listings SET bid_price = ? WHERE id = ?', [$amount, $listingId]);

    $data = ['listing_id' => $listingId, 'amount' => $amount];
    analytics_track('market_bid', $bidderId, $data);

    notify((int) $listing['seller_id'], 'New bid on your listing: ' . money($amount), 'market.php');

    return ['ok' => true];
}

/**
 * Buyout a listing
 */
function market_buyout(int $buyerId, int $listingId, int $amount = 0): array
{
    $listing = fetch('SELECT * FROM market_listings WHERE id = ? AND status = \'active\'', [$listingId]);
    if (!$listing) return ['ok' => false, 'error' => 'Listing not found'];
    if ((int) $listing['seller_id'] === $buyerId) return ['ok' => false, 'error' => 'Cannot buy your own listing'];
    if (!(int) $listing['buyout_price']) return ['ok' => false, 'error' => 'No buyout price set'];

    $price = $amount > 0 ? $amount : (int) $listing['buyout_price'];
    $buyer = fetch('SELECT * FROM users WHERE id = ?', [$buyerId]);
    if (!$buyer) return ['ok' => false, 'error' => 'User not found'];
    if ((int) $buyer['money'] < $price) return ['ok' => false, 'error' => 'Not enough cash'];

    $bids = fetch_all('SELECT * FROM market_bids WHERE listing_id = ? AND status = \'active\'', [$listingId]);
    foreach ($bids as $bid) {
        add_money((int) $bid['bidder_id'], (int) $bid['amount'], 'Outbid refund (buyout): listing #' . $listingId);
        q('UPDATE market_bids SET status = \'outbid\' WHERE id = ?', [(int) $bid['id']]);
    }

    add_money($buyerId, -(int) $price, 'Market buyout: listing #' . $listingId);

    $itemType = $listing['item_type'];
    $itemId = (int) $listing['item_id'];
    $qty = (int) $listing['qty'];

    if ($itemType === 'item' || $itemType === 'vehicle' || $itemType === 'blueprint') {
        $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$buyerId, $itemId]);
        if ($existing) {
            q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [$qty, (int) $existing['id']]);
        } else {
            insert('user_items', ['user_id' => $buyerId, 'item_id' => $itemId, 'qty' => $qty, 'equipped' => 0]);
        }
    } elseif ($itemType === 'drug') {
        $existing = fetch('SELECT id, qty FROM user_drugs WHERE user_id = ? AND drug_id = ?', [$buyerId, $itemId]);
        if ($existing) {
            q('UPDATE user_drugs SET qty = qty + ? WHERE id = ?', [$qty, (int) $existing['id']]);
        } else {
            insert('user_drugs', ['user_id' => $buyerId, 'drug_id' => $itemId, 'qty' => $qty]);
        }
    }

    $feeRate = 0.05;
    if (function_exists('politics_apply_policy_effect')) {
        // A Black Market Permit reduces the auction-house commission.
        $feeRate *= politics_apply_policy_effect('market_fee_multiplier', 1.0);
    }
    $fee = (int) floor($listing['buyout_price'] * $feeRate);
    $sellerPayout = (int) $listing['buyout_price'] - $fee;
    add_money((int) $listing['seller_id'], $sellerPayout, 'Market sale: listing #' . $listingId);

    q('UPDATE market_listings SET status = \'sold\', sold_at = NOW(), buyer_id = ?, final_price = ? WHERE id = ?', [$buyerId, $price, $listingId]);

    q('UPDATE market_bids SET status = \'won\', resolved_at = NOW() WHERE listing_id = ? AND bidder_id = ?', [$listingId, $buyerId]);
    q('UPDATE market_bids SET status = \'lost\', resolved_at = NOW() WHERE listing_id = ? AND bidder_id != ?', [$listingId, $buyerId]);

    $data1 = ['listing_id' => (int) $listing['id'], 'buyer_id' => $buyerId, 'price' => $price];
    $data2 = ['listing_id' => (int) $listing['id'], 'seller_id' => (int) $listing['seller_id'], 'price' => $price];
    analytics_track('market_buyout', (int) $listing['seller_id'], $data1);
    analytics_track('market_buyout', $buyerId, $data2);

    notify((int) $listing['seller_id'], 'Your listing sold for ' . money($sellerPayout) . ' (fee: ' . money($fee) . ')', 'market.php');
    notify($buyerId, 'Purchase complete! Item delivered.', 'market.php');

    return ['ok' => true, 'price' => $price, 'fee' => $fee];
}

/**
 * Cancel a listing (seller only)
 */
function market_cancel(int $sellerId, int $listingId): array
{
    $listing = fetch('SELECT * FROM market_listings WHERE id = ? AND seller_id = ? AND status = \'active\'', [$listingId, $sellerId]);
    if (!$listing) return ['ok' => false, 'error' => 'Listing not found or cannot cancel'];

    $itemType = $listing['item_type'];
    $itemId = (int) $listing['item_id'];
    $qty = (int) $listing['qty'];

    if ($listing['item_type'] === 'item' || $listing['item_type'] === 'vehicle' || $listing['item_type'] === 'blueprint') {
        $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$sellerId, $itemId]);
        if ($existing) {
            q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [(int) $listing['qty'], (int) $existing['id']]);
        } else {
            insert('user_items', ['user_id' => $sellerId, 'item_id' => (int) $listing['item_id'], 'qty' => $qty, 'equipped' => 0]);
        }
    } elseif ($listing['item_type'] === 'drug') {
        $existing = fetch('SELECT id, qty FROM user_drugs WHERE user_id = ? AND drug_id = ?', [$sellerId, $itemId]);
        if ($existing) {
            q('UPDATE user_drugs SET qty = qty + ? WHERE id = ?', [(int) $listing['qty'], (int) $existing['id']]);
        } else {
            insert('user_drugs', ['user_id' => $sellerId, 'drug_id' => (int) $listing['item_id'], 'qty' => $qty]);
        }
    }

    $bids = fetch_all('SELECT * FROM market_bids WHERE listing_id = ? AND status = \'active\'', [$listingId]);
    foreach ($bids as $bid) {
        add_money((int) $bid['bidder_id'], (int) $bid['amount'], 'Listing cancelled refund: #' . $listingId);
        q('UPDATE market_bids SET status = \'cancelled\' WHERE id = ?', [(int) $bid['id']]);
    }

    q('UPDATE market_listings SET status = \'cancelled\' WHERE id = ?', [$listingId]);

    return ['ok' => true];
}

/**
 * Get marketplace stats
 */
function market_get_stats(): array
{
    $active = (int) fetch_one('SELECT COUNT(*) FROM market_listings WHERE status = \'active\'', [], 0);
    $total = (int) fetch_one('SELECT COUNT(*) FROM market_listings', [], 0);
    $volume = (int) fetch_one('SELECT COALESCE(SUM(final_price),0) FROM market_listings WHERE status = \'sold\'', [], 0);
    return ['active' => $active, 'total' => $total, 'volume' => $volume];
}

/**
 * Clean up expired listings (cron job). Returns the number of listings settled.
 */
function market_cleanup_expired(): int
{
    $expired = fetch_all("
        SELECT ml.*, mb.amount, mb.bidder_id
        FROM market_listings ml
        LEFT JOIN market_bids mb ON mb.listing_id = ml.id AND mb.status = 'active'
        WHERE ml.status = 'active' AND ml.auction_end IS NOT NULL AND ml.auction_end < NOW()
    ");

    foreach ($expired as $listing) {
        if (!empty($listing['bidder_id'])) {
            market_buyout((int) $listing['bidder_id'], (int) $listing['id'], (int) $listing['amount']);
        } else {
            market_cancel((int) $listing['seller_id'], (int) $listing['id']);
        }
    }

    return count($expired);
}

/**
 * Get marketplace categories
 */
function market_get_categories(): array
{
    return [
        'item' => '📦 Items',
        'vehicle' => '🚗 Vehicles',
        'drug' => '💊 Drugs',
        'blueprint' => '📜 Blueprints',
    ];
}