<?php
/**
 * Mafia Empire - Wanted/Heat System
 * Players gain heat from crimes/kills. High heat = police attention,
 * bounty hunters, and reduced earnings. Heat decays over time.
 */

/**
 * Get current heat level for a user (0-5, 5 = most wanted).
 */
function heat_get(int $uid): int
{
    $row = fetch("SELECT heat_level, last_decay FROM user_heat WHERE user_id = ?", [$uid]);
    if (!$row) {
        insert("user_heat", ["user_id" => $uid, "heat_level" => 0, "last_decay" => date("Y-m-d H:i:s")]);
        return 0;
    }
    // Decay heat over time (1 level per 30 minutes)
    $last = strtotime($row['last_decay']);
    $decay = floor((time() - $last) / 1800);
    if ($decay > 0) {
        $newLevel = max(0, (int)$row['heat_level'] - $decay);
        q("UPDATE user_heat SET heat_level = ?, last_decay = ? WHERE user_id = ?", [$newLevel, date("Y-m-d H:i:s"), $uid]);
        return $newLevel;
    }
    return (int)$row['heat_level'];
}

/**
 * Add heat to a user (from crimes, kills, etc.).
 */
function heat_add(int $uid, int $amount, string $source = ''): int
{
    $current = heat_get($uid);
    $newLevel = min(5, $current + $amount);
    q("UPDATE user_heat SET heat_level = ?, last_action = ?, " . ($source === 'kill' ? 'kills_at_heat = kills_at_heat + 1' : 'crimes_at_heat = crimes_at_heat + 1') . " WHERE user_id = ?", [$newLevel, date("Y-m-d H:i:s"), $uid]);
    if ($newLevel >= 4) {
        flash("WARNING: You are on the Most Wanted list! Police are searching.", 'error');
    }
    return $newLevel;
}

/**
 * Get heat multiplier for earnings (higher heat = lower earnings).
 */
function heat_earnings_multiplier(int $uid): float
{
    $level = heat_get($uid);
    $mults = [1.0, 0.95, 0.85, 0.70, 0.50, 0.30];
    return $mults[$level] ?? 1.0;
}

/**
 * Get heat display info.
 */
function heat_info(int $uid): array
{
    $level = heat_get($uid);
    $names = ['Cold', 'Suspicious', 'Hot', 'Dangerous', 'Most Wanted', 'Public Enemy'];
    $colors = ['#6b6b6b', '#a0a0a0', '#ffd700', '#ff8c00', '#ff3333', '#ff0000'];
    $icons = ['&#128759;', '&#128269;', '&#128293;', '&#9888;', '&#128681;', '&#128299;'];
    return [
        'level' => $level,
        'name' => $names[$level],
        'color' => $colors[$level],
        'icon' => $icons[$level],
        'multiplier' => heat_earnings_multiplier($uid),
    ];
}
