<?php
/**
 * Eye Of The Mafia - Sports Betting
 * Bet on match outcomes, over/under, parlays.
 */

require_once __DIR__ . '/includes/init.php';
$u = require_login();

// Mock sports events - in production these would come from an API
$events = [
    ['id' => 1, 'league' => 'NFL', 'match' => 'Chiefs @ Bills', 'time' => '+2h', 'odds' => ['home' => 1.85, 'away' => 2.05, 'draw' => 0], 'ou' => 47.5],
    ['id' => 2, 'league' => 'NBA', 'match' => 'Lakers vs Celtics', 'time' => '+4h', 'odds' => ['home' => 2.10, 'away' => 1.78, 'draw' => 0], 'ou' => 224.5],
    ['id' => 3, 'league' => 'MLB', 'match' => 'Yankees @ Red Sox', 'time' => '+6h', 'odds' => ['home' => 1.95, 'away' => 1.90, 'draw' => 0], 'ou' => 8.5],
    ['id' => 4, 'league' => 'NHL', 'match' => 'Rangers @ Bruins', 'time' => '+8h', 'odds' => ['home' => 2.25, 'away' => 1.65, 'draw' => 0], 'ou' => 5.5],
    ['id' => 5, 'league' => 'Soccer', 'match' => 'Manchester United vs Liverpool', 'time' => '+24h', 'odds' => ['home' => 2.50, 'away' => 2.75, 'draw' => 3.20], 'ou' => 2.5],
    ['id' => 6, 'league' => 'UFC', 'match' => 'Jones vs Miocic', 'time' => '+48h', 'odds' => ['home' => 1.40, 'away' => 2.90, 'draw' => 0], 'ou' => 2.5],
];

// Parlay bets stored in session
$st = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$u['id'], 'sports_betting']);
$st = $st ? json_decode($st['state'], true) : ['parlay' => [], 'single_bets' => []];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_single') {
        $eventId = (int) ($_POST['event_id'] ?? 0);
        $betType = $_POST['bet_type'] ?? '';
        $amount = max(1, (int) ($_POST['amount'] ?? 0));
        
        $event = $events[$eventId] ?? null;
        if (!$event) { flash('Invalid event.', 'error'); }
        elseif ($amount > $u['money']) { flash('Not enough cash.', 'error'); }
        else {
            add_money($u['id'], -$amount, 'Sports bet: ' . $event['match']);
            $st['single_bets'][] = [
                'event_id' => $eventId,
                'type' => $betType,
                'amount' => $amount,
                'odds' => $event['odds'][$betType] ?? 0,
                'potential' => round($amount * ($event['odds'][$betType] ?? 0), 2),
            ];
            flash('Bet placed!', 'success');
        }
    } elseif ($action === 'add_parlay') {
        $selections = $_POST['selections'] ?? [];
        $amount = max(1, (int) ($_POST['parlay_amount'] ?? 0));
        
        if (count($selections) < 2) {
            flash('Parlay requires at least 2 selections.', 'error');
        } elseif ($amount > $u['money']) {
            flash('Not enough cash.', 'error');
        } else {
            $totalOdds = 1;
            foreach ($selections as $sel) {
                $e = $events[$sel['event_id']] ?? null;
                if ($e) $totalOdds *= $e['odds'][$sel['type']] ?? 1;
            }
            
            add_money($u['id'], -$amount, 'Parlay bet');
            $st['parlay'][] = [
                'selections' => $selections,
                'amount' => $amount,
                'total_odds' => round($totalOdds, 2),
                'potential' => round($amount * $totalOdds, 2),
            ];
            flash('Parlay placed!', 'success');
        }
    } elseif ($action === 'clear_all') {
        $st['single_bets'] = [];
        $st['parlay'] = [];
        flash('All bets cleared.', 'success');
    } elseif ($action === 'settle') {
        // Simulate results (in production, this would use real results)
        $totalWin = 0;
        $results = [];
        
        foreach ($st['single_bets'] as $i => $bet) {
            $event = $events[$bet['event_id']] ?? null;
            if (!$event) continue;
            
            // Simulate: 50/50 chance (plus house edge)
            $won = mt_rand(1, 100) <= 48; // ~48% win rate for bettor
            if ($won) {
                $win = $bet['potential'];
                $totalWin += $win;
                $results[] = "Single: {$event['match']} - WON " . money($win);
            } else {
                $results[] = "Single: {$event['match']} - LOST";
            }
        }
        
        foreach ($st['parlay'] as $i => $parlay) {
            $allWon = true;
            foreach ($parlay['selections'] as $sel) {
                $event = $events[$sel['event_id']] ?? null;
                if (!$event || mt_rand(1, 100) > 48) { $allWon = false; break; }
            }
            if ($allWon) {
                $win = $parlay['potential'];
                $totalWin += $win;
                $results[] = "Parlay (" . count($parlay['selections']) . " legs) - WON " . money($win);
            } else {
                $results[] = "Parlay (" . count($parlay['selections']) . " legs) - LOST";
            }
        }
        
        if ($totalWin > 0) {
            add_money($u['id'], $totalWin, 'Sports betting wins');
            event_track('casino_won', (int) $totalWin);
            flash('Settled! Total winnings: ' . money($totalWin), 'success');
        } else {
            flash('All bets lost. Better luck next time!', 'error');
        }
        
        $st['single_bets'] = [];
        $st['parlay'] = [];
        
        insert('casino_bets', [
            'user_id' => $u['id'],
            'game' => 'sports_betting',
            'stake' => array_sum(array_column($st['single_bets'], 'amount')) + array_sum(array_column($st['parlay'], 'amount')),
            'payout' => $totalWin,
            'detail' => implode('; ', $results)
        ]);
    }
    
    q('INSERT INTO casino_state (user_id, game, state) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)', [$u['id'], 'sports_betting', json_encode($st)]);
    redirect('sports_betting.php');
}

$page_title = 'Sports Betting';
require __DIR__ . '/includes/header.php';
$u = current_user();
?>
<div class="card">
  <div class="panel-heading">Sports Betting</div>
  <p class="muted small">Bet on match winners, over/under, and build parlays. Results simulated with ~48% win rate.</p>
  <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
</div>

<!-- Events List -->
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Available Events</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px">
    <?php foreach ($events as $i => $e): ?>
    <div class="card">
      <b><?= e($e['league']) ?></b>: <?= e($e['match']) ?>
      <div class="muted small"><?= e($e['time']) ?></div>
      <div style="display:flex;gap:8px;justify-content:center;margin:8px 0;flex-wrap:wrap">
        <span class="stat" style="background:var(--bg-2);padding:4px 8px;border-radius:3px">
          Home: <b><?= $e['odds']['home'] ?>x</b>
        </span>
        <?php if ($e['odds']['draw'] > 0): ?>
        <span class="stat" style="background:var(--bg-2);padding:4px 8px;border-radius:3px">
          Draw: <b><?= $e['odds']['draw'] ?>x</b>
        </span>
        <?php endif; ?>
        <span class="stat" style="background:var(--bg-2);padding:4px 8px;border-radius:3px">
          Away: <b><?= $e['odds']['away'] ?>x</b>
        </span>
      </div>
      <div style="display:flex;gap:8px;justify-content:center;margin-bottom:8px">
        <span class="stat" style="background:var(--bg-2);padding:4px 8px;border-radius:3px">
          O/U: <b><?= $e['ou'] ?></b> @ 1.90
        </span>
      </div>
      <form method="post" style="display:flex;flex-direction:column;gap:6px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add_single">
        <input type="hidden" name="event_id" value="<?= $i ?>">
        <div style="display:flex;gap:6px">
          <select name="bet_type" style="flex:1;padding:6px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
            <option value="home">Home Win</option>
            <option value="away">Away Win</option>
            <?php if ($e['odds']['draw'] > 0): ?>
            <option value="draw">Draw</option>
            <?php endif; ?>
            <option value="over">Over <?= $e['ou'] ?></option>
            <option value="under">Under <?= $e['ou'] ?></option>
          </select>
          <input type="number" name="amount" min="1" max="<?= (int) $u['money'] ?>" value="10" required style="width:80px;padding:6px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)">
        </div>
        <button class="btn btn-gold btn-block" type="submit" name="action" value="add_single">Bet</button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Parlay Builder -->
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Parlay Builder (Min 2 legs)</div>
  <p class="muted small">Select 2+ bets. All must win for parlay to pay. Combined odds multiply.</p>
  
  <form method="post" style="display:flex;flex-direction:column;gap:12px;max-width:600px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="add_parlay">
    
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px">
      <?php foreach ($events as $i => $e): ?>
      <div class="card" style="padding:8px">
        <small class="muted"><?= e($e['league']) ?>: <?= e($e['match']) ?></small>
        <div style="display:flex;gap:4px;margin:4px 0;flex-wrap:wrap">
          <button type="button" class="parlay-select btn btn-sm" data-event="<?= $i ?>" data-type="home" data-odds="<?= $e['odds']['home'] ?>" style="flex:1;padding:4px;font-size:.75rem">Home: <?= $e['odds']['home'] ?>x</button>
          <button type="button" class="parlay-select btn btn-sm" data-event="<?= $i ?>" data-type="away" data-odds="<?= $e['odds']['away'] ?>" style="flex:1;padding:4px;font-size:.75rem">Away: <?= $e['odds']['away'] ?>x</button>
          <?php if ($e['odds']['draw'] > 0): ?>
          <button type="button" class="parlay-select btn btn-sm" data-event="<?= $i ?>" data-type="draw" data-odds="<?= $e['odds']['draw'] ?>" style="flex:1;padding:4px;font-size:.75rem">Draw: <?= $e['odds']['draw'] ?>x</button>
          <?php endif; ?>
          <button type="button" class="parlay-select btn btn-sm" data-event="<?= $i ?>" data-type="over" data-odds="1.90" style="flex:1;padding:4px;font-size:.75rem">Over <?= $e['ou'] ?>: 1.90x</button>
          <button type="button" class="parlay-select btn btn-sm" data-event="<?= $i ?>" data-type="under" data-odds="1.90" style="flex:1;padding:4px;font-size:.75rem">Under <?= $e['ou'] ?>: 1.90x</button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    
    <div id="parlay-slip" class="card" style="margin-top:12px;padding:12px;display:none">
      <b>Parlay Slip (<span id="parlay-count">0</span> legs)</b>
      <div id="parlay-legs" style="margin:8px 0;min-height:60px"></div>
      <div class="stat">Combined Odds: <b id="parlay-odds">1.00</b>x</div>
      <label>Stake <input type="number" name="parlay_amount" id="parlay-amount" min="1" max="<?= (int) $u['money'] ?>" value="10" required style="width:100px;padding:6px;border-radius:3px;border:1px solid var(--line);background:var(--bg);color:var(--fg)"></label>
      <div class="stat">Potential: <b id="parlay-potential">$0</b></div>
      <input type="hidden" name="selections" id="parlay-selections-input">
      <input type="hidden" name="parlay_amount" id="parlay-amount-input">
      <button class="btn btn-gold btn-block" type="submit" name="action" value="add_parlay" id="parlay-submit" disabled>Build Parlay First</button>
    </div>
  </form>
</div>

<!-- Active Bets -->
<?php if ($st['single_bets'] || $st['parlay']): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Active Bets</div>
  
  <?php if ($st['single_bets']): ?>
  <div class="card" style="margin-top:8px">
    <div class="panel-heading">Single Bets</div>
    <div class="table-wrap"><table>
      <tr><th>Event</th><th>Type</th><th>Odds</th><th>Stake</th><th>Potential</th></tr>
      <?php foreach ($st['single_bets'] as $i => $bet):
        $e = $events[$bet['event_id']] ?? null;
      ?>
      <tr>
        <td><?= $e ? e($e['match']) : 'Unknown' ?></td>
        <td><?= ucfirst($bet['type']) ?></td>
        <td><?= $bet['odds'] ?>x</td>
        <td><?= money($bet['amount']) ?></td>
        <td><?= money($bet['potential']) ?></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
  <?php endif; ?>
  
  <?php if ($st['parlay']): ?>
  <div class="card" style="margin-top:8px">
    <div class="panel-heading">Parlays</div>
    <?php foreach ($st['parlay'] as $i => $parlay): ?>
    <div class="card" style="margin:8px 0;padding:10px">
      <div><b>Parlay #<?= $i+1 ?></b> — <span class="tag tag-gold"><?= count($parlay['selections']) ?> legs @ <?= $parlay['total_odds'] ?>x</span></div>
      <div class="muted small" style="margin:4px 0">
        <?= implode(' | ', array_map(fn($s) => $events[$s['event_id']]['match'] . ' ' . ucfirst($s['type']) . ' @ ' . $events[$s['event_id']]['odds'][$s['type']] . 'x', $parlay['selections'])) ?>
      </div>
      <div class="stat">Stake: <b><?= money($parlay['amount']) ?></b> | Potential: <b><?= money($parlay['potential']) ?></b></div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  
  <form method="post" style="margin-top:12px;display:flex;gap:12px;align-items:center;flex-wrap:wrap">
    <?= csrf_field() ?>
    <button class="btn btn-gold" type="submit" name="action" value="settle">🎰 Settle All Bets (Simulate)</button>
    <button class="btn btn-sm btn-danger" type="submit" name="action" value="clear_all">Clear All</button>
  </form>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const slip = document.getElementById('parlay-slip');
  const countEl = document.getElementById('parlay-count');
  const legsEl = document.getElementById('parlay-legs');
  const oddsEl = document.getElementById('parlay-odds');
  const potentialEl = document.getElementById('parlay-potential');
  const amountEl = document.getElementById('parlay-amount');
  const selectionsInput = document.getElementById('parlay-selections-input');
  const amountInput = document.getElementById('parlay-amount-input');
  const submitBtn = document.getElementById('parlay-submit');
  
  let selections = [];
  
  document.querySelectorAll('.parlay-select').forEach(btn => {
    btn.addEventListener('click', () => {
      const event = btn.dataset.event;
      const type = btn.dataset.type;
      const odds = parseFloat(btn.dataset.odds);
      const idx = selections.findIndex(s => s.event_id == event && s.type === type);
      
      if (idx >= 0) {
        selections.splice(idx, 1);
        btn.classList.remove('btn-gold');
        btn.classList.add('btn');
      } else {
        selections.push({event_id: event, type: btn.dataset.type, odds});
        btn.classList.remove('btn');
        btn.classList.add('btn-gold');
      }
      
      updateSlip();
    });
    
    function updateSlip() {
      if (selections.length === 0) {
        slip.style.display = 'none';
        return;
      }
      slip.style.display = 'block';
      countEl.textContent = selections.length;
      
      let totalOdds = 1;
      legsEl.innerHTML = selections.map((s, i) => {
        const e = events[s.event_id];
        const legOdds = s.odds;
        totalOdds *= legOdds;
        return `<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--line)">
          <span>${e.match} — ${s.type} @ ${legOdds}x</span>
          <button type="button" onclick="removeLeg(${i})" class="btn btn-sm btn-danger" style="padding:2px 6px;font-size:.7rem">✕</button>
        </div>`;
      }).join('');
      
      oddsEl.textContent = totalOdds.toFixed(2);
      const stake = parseFloat(document.getElementById('parlay-amount').value) || 0;
      potentialEl.textContent = money(stake * totalOdds);
      
      selectionsInput.value = JSON.stringify(selections);
      amountInput.value = document.getElementById('parlay-amount').value;
      
      submitBtn.disabled = selections.length < 2;
      submitBtn.textContent = selections.length >= 2 ? 'Place Parlay' : 'Need 2+ selections';
    }
    
    window.removeLeg = (idx) => {
      selections.splice(idx, 1);
      updateSlip();
      // Update button states
      document.querySelectorAll('.parlay-select').forEach(btn => {
        const sel = selections.find(s => s.event_id == btn.dataset.event && s.type === btn.dataset.type);
        btn.classList.toggle('btn-gold', !!sel);
        btn.classList.toggle('btn', !sel);
      });
    };
    
    document.getElementById('parlay-amount').addEventListener('input', () => {
      const totalOdds = parseFloat(oddsEl.textContent) || 1;
      const stake = parseFloat(amountEl.value) || 0;
      potentialEl.textContent = money(stake * totalOdds);
      amountInput.value = amountEl.value;
    });
    
    // Make events available globally
    window.events = <?php echo json_encode($events); ?>;
  });
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>