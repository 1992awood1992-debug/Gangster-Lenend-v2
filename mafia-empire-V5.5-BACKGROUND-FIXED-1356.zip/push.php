<?php
/**
 * Mafia Empire - Web Push subscription endpoint (JSON).
 *
 * Actions (POST, CSRF-protected):
 *   vapid        -> returns the application server public key
 *   subscribe    -> stores a browser PushSubscription
 *   unsubscribe  -> removes a browser PushSubscription
 *   status       -> current enabled state + device count
 *
 * Fails closed: when no VAPID key pair is configured every action still
 * responds, but the browser side is told push is unavailable.
 */
require_once __DIR__ . '/includes/init.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function push_json(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if (!is_logged_in()) {
    push_json(['ok' => false, 'error' => 'login required'], 401);
}

$u = current_user();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    push_json(['ok' => false, 'error' => 'POST required'], 405);
}

$token = (string) ($_POST['csrf'] ?? '');
if ($token === '' || !hash_equals(csrf_token(), $token)) {
    push_json(['ok' => false, 'error' => 'bad csrf token'], 403);
}

$uid    = (int) $u['id'];
$action = (string) ($_POST['action'] ?? '');

switch ($action) {
    case 'vapid':
        push_json([
            'ok'        => true,
            'enabled'   => push_available(),
            'publicKey' => vapid_public_key(),
        ]);
        break;

    case 'subscribe':
        $sub = json_decode((string) ($_POST['subscription'] ?? ''), true);
        if (!is_array($sub) || empty($sub['endpoint'])) {
            push_json(['ok' => false, 'error' => 'malformed subscription'], 400);
        }
        $keys = is_array($sub['keys'] ?? null) ? $sub['keys'] : [];
        $ok = push_subscribe(
            $uid,
            (string) $sub['endpoint'],
            (string) ($keys['p256dh'] ?? ''),
            (string) ($keys['auth'] ?? ''),
            (string) ($_SERVER['HTTP_USER_AGENT'] ?? '')
        );
        push_json(['ok' => $ok, 'count' => push_subscription_count($uid)]);
        break;

    case 'unsubscribe':
        $sub = json_decode((string) ($_POST['subscription'] ?? ''), true);
        $endpoint = is_array($sub) ? (string) ($sub['endpoint'] ?? '') : (string) ($_POST['endpoint'] ?? '');
        if ($endpoint !== '') {
            push_unsubscribe($uid, $endpoint);
        }
        push_json(['ok' => true, 'count' => push_subscription_count($uid)]);
        break;

    case 'status':
        push_json([
            'ok'      => true,
            'enabled' => push_available(),
            'count'   => push_subscription_count($uid),
        ]);
        break;

    default:
        push_json(['ok' => false, 'error' => 'unknown action'], 400);
}
