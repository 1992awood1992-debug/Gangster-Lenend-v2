<?php
/**
 * Eye Of The Mafia - Seasonal Events System
 * Calendar holidays with unique vehicles, missions, currencies, perks, resprays.
 */

require_once __DIR__ . '/init.php';

/**
 * Seasonal Event Types and their configuration
 */
const SEASONAL_EVENT_TYPES = [
    'valentines' => [
        'name' => 'Valentine\'s Day',
        'default_start' => '02-14',
        'default_end' => '02-15',
        'config_keys' => ['vehicle', 'theft_chance', 'mission', 'respray'],
        'announce' => '💘 Valentine\'s Day Event! The Love Bug is available (100% theft chance). Special mission: Double Trouble. Cupid Coat respray unlocked!',
    ],
    'easter' => [
        'name' => 'Easter',
        'default_start' => '04-03', // Good Friday (varies, using 2026 date)
        'default_end' => '04-06',   // Easter Monday
        'config_keys' => ['vehicle', 'theft_chance', 'loot_item', 'respray'],
        'announce' => '🐰 Easter Event! The Bunny Buggy is available (50% theft chance). Find Easter Eggs in looting. Bunny Drip respray unlocked!',
    ],
    'independence' => [
        'name' => 'Independence Day',
        'default_start' => '07-03',
        'default_end' => '07-05',
        'config_keys' => ['loot_item', 'mission', 'respray'],
        'announce' => '🎆 Independence Day Event! Mini Flags in looting. Special mission: Uncle Sam\'s Errand. Liberty Gloss respray unlocked!',
    ],
    'halloween' => [
        'name' => 'Halloween',
        'default_start' => '10-15',
        'default_end' => '10-31',
        'config_keys' => ['currency', 'heist', 'perk', 'vehicle', 'respray'],
        'announce' => '🎃 Halloween Event! Earn Candy from looting, the Trick or Treat heist, and a special mission. Buy the Skeleton Key perk (30min 100% theft). Death Wagon available. Blood Drip respray unlocked!',
    ],
    'christmas' => [
        'name' => 'Christmas',
        'default_start' => '12-01',
        'default_end' => '12-25',
        'config_keys' => ['daily_giveaway', 'vehicle', 'respray'],
        'announce' => '🎄 Christmas Event! Daily Christmas Giveaway (Dec 1-25). Santa\'s Sleigh 5000 available. Mistlechrome respray unlocked!',
    ],
];

/**
 * Get active seasonal event (by current date)
 */
function seasonal_event_get_active(): ?array
{
    $now = date('Y-m-d H:i:s');
    $year = (int) date('Y');

    $ev = fetch("
        SELECT * FROM seasonal_events
        WHERE year = ? AND is_active = 1
        AND start_at <= ? AND end_at > ?
        ORDER BY start_at ASC
        LIMIT 1
    ", [$year, $now, $now]);

    if (!$ev) return null;

    $config = json_decode($ev['config'] ?? '{}', true);
    $typeConfig = SEASONAL_EVENT_TYPES[$ev['holiday_code']] ?? [];

    return [
        'id' => (int) $ev['id'],
        'holiday_code' => $ev['holiday_code'],
        'name' => $ev['holiday_code'] !== 'custom' ? ($typeConfig['name'] ?? $ev['holiday_code']) : ($config['name'] ?? 'Seasonal Event'),
        'year' => (int) $ev['year'],
        'start_at' => $ev['start_at'],
        'end_at' => $ev['end_at'],
        'config' => $config,
        'remaining_seconds' => max(0, (new DateTime($ev['end_at']))->getTimestamp() - time()),
    ];
}

/**
 * Get all seasonal events (for admin UI)
 */
function seasonal_event_get_all(): array
{
    return fetch_all("
        SELECT * FROM seasonal_events ORDER BY year DESC, start_at ASC
    ");
}

/**
 * Apply a seasonal event's effects
 */
function seasonal_event_apply_effect(array $event): void
{
    $code = $event['holiday_code'];
    $config = $event['config'] ?? [];

    // Store active event code for quick checks
    q("INSERT INTO settings (k, v) VALUES ('seasonal_event_active', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [$code]);

    // Store config keys as individual settings for easy access
    foreach ($config as $key => $value) {
        q("INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)",
            ["seasonal_event_{$key}", is_bool($value) ? ($value ? '1' : '0') : (is_array($value) ? json_encode($value) : (string) $value)]);
    }

    // Holiday-specific setup
    switch ($code) {
        case 'valentines':
            // Ensure Love Bug vehicle exists or create it
            seasonal_event_ensure_vehicle('Love Bug', 100, 'valentines');
            break;
        case 'easter':
            seasonal_event_ensure_vehicle('Bunny Buggy', 50, 'easter');
            break;
        case 'halloween':
            // Ensure Death Wagon exists
            seasonal_event_ensure_vehicle('Death Wagon', 0, 'halloween');
            // Ensure Skeleton Key perk exists in black market
            seasonal_event_ensure_skeleton_key();
            break;
        case 'christmas':
            seasonal_event_ensure_vehicle('Santa\'s Sleigh 5000', 0, 'christmas');
            break;
    }
}

/**
 * Remove a seasonal event's effects
 */
function seasonal_event_remove_effect(string $holidayCode): void
{
    $typeConfig = SEASONAL_EVENT_TYPES[$holidayCode] ?? [];
    $configKeys = $typeConfig['config_keys'] ?? [];

    foreach ($configKeys as $key) {
        q("DELETE FROM settings WHERE k = ?", ["seasonal_event_{$key}"]);
    }
    q("DELETE FROM settings WHERE k = 'seasonal_event_active'");
}

/**
 * Ensure a seasonal vehicle exists in items table
 */
function seasonal_event_ensure_vehicle(string $name, int $theftChance, string $eventCode): int
{
    $existing = fetch('SELECT id FROM items WHERE name = ? AND type = ?', [$name, 'vehicle']);
    if ($existing) return (int) $existing['id'];

    $id = insert('items', [
        'name' => $name,
        'type' => 'vehicle',
        'attack' => 0,
        'defense' => 0,
        'description' => "Seasonal vehicle from {$eventCode} event. Theft chance: {$theftChance}%",
        'min_level' => 1,
        'price' => $eventCode === 'christmas' ? 600000 : 100000,
    ]);

    return $id;
}

/**
 * Ensure Skeleton Key perk exists for Halloween
 */
function seasonal_event_ensure_skeleton_key(): void
{
    // This is handled via black market items - the perk is a purchasable item
    $existing = fetch('SELECT id FROM items WHERE name = ? AND type = ?', ['Skeleton Key', 'item']);
    if (!$existing) {
        insert('items', [
            'name' => 'Skeleton Key',
            'type' => 'item',
            'attack' => 0,
            'defense' => 0,
            'description' => 'Grants 30 minutes of 100% vehicle theft success. One-time use. Limited to one per event.',
            'min_level' => 1,
            'price' => 0, // Purchased with Candy currency
        ]);
    }
}

/**
 * Announce a seasonal event globally
 */
function seasonal_event_announce(string $message): void
{
    // 1. City ticker
    $tickerKey = 'ticker:seasonal_event';
    $existing = cache_get($tickerKey) ?? [];
    array_unshift($existing, $message);
    if (count($existing) > 3) $existing = array_slice($existing, 0, 3);
    cache_set($tickerKey, $existing, 86400); // 24 hour TTL

    // 2. Discord
    if (function_exists('discord_notify')) {
        try { discord_notify("🌐 **Seasonal Event**\n$message"); } catch (Throwable $e) {}
    }

    // 3. Notify all users
    $users = fetch_all('SELECT id FROM users WHERE is_banned = 0');
    foreach ($users as $u) {
        notify((int) $u['id'], $message, 'events.php');
    }
}

/**
 * Daily cron task: activate/expire seasonal events
 */
function seasonal_event_cron(): array
{
    $result = ['activated' => 0, 'expired' => 0];

    $now = date('Y-m-d H:i:s');
    $year = (int) date('Y');

    // Check for events starting today
    $starting = fetch_all("
        SELECT * FROM seasonal_events
        WHERE year = ? AND is_active = 1
        AND DATE(start_at) = CURDATE()
        AND start_at <= ?
    ", [$year, $now]);

    foreach ($starting as $ev) {
        seasonal_event_apply_effect($ev);
        $typeConfig = SEASONAL_EVENT_TYPES[$ev['holiday_code']] ?? ['announce' => 'Seasonal event started!'];
        seasonal_event_announce($typeConfig['announce']);
        $result['activated'] = 1;
        $result['event_type'] = $ev['holiday_code'];
    }

    // Check for events ending today
    $ending = fetch_all("
        SELECT * FROM seasonal_events
        WHERE year = ? AND is_active = 1
        AND DATE(end_at) = CURDATE()
        AND end_at <= ?
    ", [$year, $now]);

    foreach ($ending as $ev) {
        seasonal_event_remove_effect($ev['holiday_code']);
        $result['expired'] = 1;
        $result['event_type'] = $ev['holiday_code'];
    }

    return $result;
}

/**
 * Get active seasonal event for display
 */
function seasonal_event_get_active_for_display(): ?array
{
    return seasonal_event_get_active();
}

/**
 * Helper: Check if a seasonal event is currently active
 */
function seasonal_event_is_active(string $holidayCode = ''): bool
{
    $active = seasonal_event_get_active();
    if (!$active) return false;
    if ($holidayCode === '') return true;
    return $active['holiday_code'] === $holidayCode;
}

/**
 * Helper: Get seasonal event config value
 */
function seasonal_event_get_config(string $key, $default = null)
{
    $val = fetch_one("SELECT v FROM settings WHERE k = ?", ["seasonal_event_{$key}"], $default);
    if ($val === null) return $default;
    // Try to decode JSON
    $decoded = json_decode($val, true);
    return $decoded !== null ? $decoded : $val;
}

/**
 * Helper: Get current seasonal event's vehicle theft chance bonus
 */
function seasonal_event_get_vehicle_theft_bonus(): int
{
    if (!seasonal_event_is_active()) return 0;

    $code = fetch_one("SELECT v FROM settings WHERE k = 'seasonal_event_active'", [], '');
    $chance = (int) seasonal_event_get_config('theft_chance', 0);

    if (in_array($code, ['valentines', 'easter', 'halloween']) && $chance > 0) {
        return $chance;
    }
    return 0;
}

/**
 * Helper: Get seasonal loot item (e.g., Easter Eggs, Mini Flags, Candy)
 */
function seasonal_event_get_loot_item(): ?string
{
    if (!seasonal_event_is_active()) return null;
    return seasonal_event_get_config('loot_item', null);
}

/**
 * Helper: Check if seasonal daily giveaway is active (Christmas)
 */
function seasonal_event_is_daily_giveaway(): bool
{
    if (!seasonal_event_is_active('christmas')) return false;
    return (bool) seasonal_event_get_config('daily_giveaway', false);
}

/**
 * Helper: Get seasonal respray name
 */
function seasonal_event_get_respray(): ?string
{
    if (!seasonal_event_is_active()) return null;
    return seasonal_event_get_config('respray', null);
}

/**
 * Admin: toggle seasonal event
 */
function seasonal_event_toggle(int $eventId): array
{
    $ev = fetch('SELECT * FROM seasonal_events WHERE id = ?', [(int) $eventId]);
    if (!$ev) return ['ok' => false, 'error' => 'Event not found'];

    $newStatus = (int) $ev['is_active'] === 1 ? 0 : 1;
    q('UPDATE seasonal_events SET is_active = ? WHERE id = ?', [$newStatus, (int) $eventId]);

    if ($newStatus === 1) {
        seasonal_event_apply_effect($ev);
        $typeConfig = SEASONAL_EVENT_TYPES[$ev['holiday_code']] ?? ['announce' => 'Seasonal event started!'];
        seasonal_event_announce($typeConfig['announce']);
    } else {
        seasonal_event_remove_effect($ev['holiday_code']);
    }

    return ['ok' => true, 'is_active' => $newStatus];
}

/**
 * Admin: create/update seasonal event for a year
 */
function seasonal_event_upsert(string $holidayCode, int $year, string $startAt, string $endAt, array $config = []): array
{
    if (!isset(SEASONAL_EVENT_TYPES[$holidayCode]) && $holidayCode !== 'custom') {
        return ['ok' => false, 'error' => 'Unknown holiday code'];
    }

    $typeConfig = SEASONAL_EVENT_TYPES[$holidayCode] ?? ['name' => 'Custom Event', 'config_keys' => []];
    $mergedConfig = array_merge($typeConfig, $config);
    unset($mergedConfig['config_keys'], $mergedConfig['announce'], $mergedConfig['default_start'], $mergedConfig['default_end']);

    $existing = fetch('SELECT id FROM seasonal_events WHERE holiday_code = ? AND year = ?', [$holidayCode, $year]);

    if ($existing) {
        q('UPDATE seasonal_events SET start_at = ?, end_at = ?, config = ?, is_active = 1 WHERE id = ?',
            [$startAt, $endAt, json_encode($mergedConfig), (int) $existing['id']]);
        $id = (int) $existing['id'];
    } else {
        $id = insert('seasonal_events', [
            'holiday_code' => $holidayCode,
            'year' => $year,
            'start_at' => $startAt,
            'end_at' => $endAt,
            'config' => json_encode($mergedConfig),
            'is_active' => 1,
        ]);
    }

    return ['ok' => true, 'id' => $id];
}