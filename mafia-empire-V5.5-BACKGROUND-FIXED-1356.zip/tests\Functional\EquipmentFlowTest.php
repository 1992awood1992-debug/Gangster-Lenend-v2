<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Functional;

use MafiaEmpire\Tests\Support\Http;
use MafiaEmpire\Tests\Support\TestCase;

/**
 * Equipment equip/unequip over HTTP, driven against a running instance.
 *
 * Regression: equipment.php used to select `ui.*, i.*`, so the fetched `id`
 * (and therefore the hidden `ui_id` in every Equip/Unequip/Sell form) resolved
 * to the *item* id. The server then looked up a non-existent user_items row and
 * silently flashed "Item not found". These tests pin the form to the real
 * inventory row id and assert the persisted state.
 *
 * Skipped unless APP_URL points at a running instance.
 */
final class EquipmentFlowTest extends TestCase
{
    private function requireServer(): void
    {
        if (!Http::configured()) {
            $this->markTestSkipped('Set APP_URL to a running instance to run the functional suite.');
        }
    }

    private function http(): Http
    {
        return new Http(Http::baseUrl());
    }

    /** Gives the user one weapon and returns the user_items row id. */
    private function giveWeapon(array $user, int $offset = 0): int
    {
        $items = fetch_all('SELECT * FROM items WHERE type = ? ORDER BY id LIMIT ?', ['weapon', $offset + 1]);
        $item = $items[$offset];
        return insert('user_items', [
            'user_id'  => $user['id'],
            'item_id'  => $item['id'],
            'qty'      => 1,
            'equipped' => 0,
        ]);
    }

    public function testEquipFormPostsTheInventoryRowIdNotTheItemId(): void
    {
        $this->requireServer();
        $user = $this->makeUser(['money' => 50000, 'level' => 50]);
        $uiId = $this->giveWeapon($user);

        $http = $this->http();
        $http->login($user['username'], 'testing123');
        [$status, $html] = $http->get('/equipment.php');
        $this->assertSame(200, $status);

        $this->assertMatchesRegularExpression(
            '/name="action" value="equip">\s*<input type="hidden" name="ui_id" value="(\d+)"/',
            $html,
            'the Equip form should carry a ui_id input'
        );
        preg_match('/name="action" value="equip">\s*<input type="hidden" name="ui_id" value="(\d+)"/', $html, $m);
        $posted = (int) ($m[1] ?? 0);

        // Whatever id the form posts must resolve to this user's inventory row.
        $row = fetch('SELECT user_id FROM user_items WHERE id = ?', [$posted]);
        $this->assertNotNull($row, 'equip form must reference an existing user_items row');
        $this->assertSame((int) $user['id'], (int) $row['user_id']);
        $this->assertSame($uiId, $posted);
    }

    public function testEquipThenUnequipRoundTrips(): void
    {
        $this->requireServer();
        $user = $this->makeUser(['money' => 50000, 'level' => 50]);
        $uiId = $this->giveWeapon($user);

        $http = $this->http();
        $http->login($user['username'], 'testing123');
        $csrf = $http->csrfFrom('/equipment.php');

        $http->post('/equipment.php', ['csrf' => $csrf, 'action' => 'equip', 'ui_id' => $uiId]);
        $this->assertSame(1, (int) fetch('SELECT equipped FROM user_items WHERE id = ?', [$uiId])['equipped']);

        $http->post('/equipment.php', ['csrf' => $csrf, 'action' => 'unequip', 'ui_id' => $uiId]);
        $this->assertSame(0, (int) fetch('SELECT equipped FROM user_items WHERE id = ?', [$uiId])['equipped']);
    }

    public function testEquippingAnotherWeaponReplacesTheFirst(): void
    {
        $this->requireServer();
        $user = $this->makeUser(['money' => 50000, 'level' => 50]);
        $first = $this->giveWeapon($user, 0);
        $second = $this->giveWeapon($user, 1);

        $http = $this->http();
        $http->login($user['username'], 'testing123');
        $csrf = $http->csrfFrom('/equipment.php');

        $http->post('/equipment.php', ['csrf' => $csrf, 'action' => 'equip', 'ui_id' => $first]);
        $http->post('/equipment.php', ['csrf' => $csrf, 'action' => 'equip', 'ui_id' => $second]);

        $this->assertSame(0, (int) fetch('SELECT equipped FROM user_items WHERE id = ?', [$first])['equipped']);
        $this->assertSame(1, (int) fetch('SELECT equipped FROM user_items WHERE id = ?', [$second])['equipped']);
    }
}
