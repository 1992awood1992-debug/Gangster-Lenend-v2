<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Webhook queueing, event filtering, signing and the delivery/retry loop.
 *
 * Deliveries target an unbound local port so no external network is needed.
 */
final class WebhookQueueTest extends TestCase
{
    private const DEAD_URL = 'http://127.0.0.1:9/';

    /** Create a webhook row for a user and return it. */
    private function makeHook(int $userId, string $events, string $url = self::DEAD_URL, int $active = 1): array
    {
        $id = insert('webhooks', [
            'user_id'    => $userId,
            'url'        => $url,
            'secret'     => bin2hex(random_bytes(16)),
            'events'     => $events,
            'active'     => $active,
            'created_at' => now(),
        ]);
        return fetch('SELECT * FROM webhooks WHERE id = ?', [$id]);
    }

    public function testDispatchQueuesForSubscribedEvent(): void
    {
        $u = $this->makeUser();
        $this->makeHook((int) $u['id'], 'kill');

        $this->assertSame(1, webhook_dispatch((int) $u['id'], 'kill', ['victim' => 'Sal']));
        $queued = fetch('SELECT * FROM webhook_deliveries WHERE user_id = ?', [(int) $u['id']]);
        $this->assertNotNull($queued);
        $this->assertSame('pending', $queued['status']);
        $this->assertSame('kill', $queued['event']);
        $this->assertSame(0, (int) $queued['attempts']);
        $data = json_decode((string) $queued['payload'], true);
        $this->assertSame('Sal', $data['data']['victim']);
    }

    public function testDispatchSkipsUnsubscribedEvent(): void
    {
        $u = $this->makeUser();
        $this->makeHook((int) $u['id'], 'kill');
        $this->assertSame(0, webhook_dispatch((int) $u['id'], 'levelup', ['level' => 5]));
        $this->assertSame(0, (int) fetch_one('SELECT COUNT(*) FROM webhook_deliveries WHERE user_id = ?', [(int) $u['id']], 0));
    }

    public function testWildcardHookReceivesEverything(): void
    {
        $u = $this->makeUser();
        $this->makeHook((int) $u['id'], '*');
        $this->assertSame(1, webhook_dispatch((int) $u['id'], 'purchase', ['name' => 'Bullets']));
        $this->assertSame(1, webhook_dispatch((int) $u['id'], 'achievement', ['name' => 'Made Man']));
        $this->assertSame(2, (int) fetch_one('SELECT COUNT(*) FROM webhook_deliveries WHERE user_id = ?', [(int) $u['id']], 0));
    }

    public function testDisabledHookReceivesNothing(): void
    {
        $u = $this->makeUser();
        $this->makeHook((int) $u['id'], '*', self::DEAD_URL, 0);
        $this->assertSame(0, webhook_dispatch((int) $u['id'], 'kill', []));
    }

    public function testMultipleHooksEachGetCopy(): void
    {
        $u = $this->makeUser();
        $this->makeHook((int) $u['id'], 'kill');
        $this->makeHook((int) $u['id'], '*');
        $this->assertSame(2, webhook_dispatch((int) $u['id'], 'kill', []));
    }

    public function testSendTestToDeadUrlFailsGracefully(): void
    {
        $u = $this->makeUser();
        $hook = $this->makeHook((int) $u['id'], '*');
        [$ok, $code, $err] = webhook_send_test($hook);
        $this->assertFalse($ok);
        $this->assertIsString($err);
    }

    public function testDeliverPendingRetriesOnFailure(): void
    {
        $u = $this->makeUser();
        $this->makeHook((int) $u['id'], 'kill');
        webhook_dispatch((int) $u['id'], 'kill', []);

        $summary = webhook_deliver_pending();
        $this->assertSame(1, $summary['processed']);
        $this->assertSame(1, $summary['retried']);

        $d = fetch('SELECT * FROM webhook_deliveries WHERE user_id = ?', [(int) $u['id']]);
        $this->assertSame('pending', $d['status']);
        $this->assertSame(1, (int) $d['attempts']);
        $this->assertNotNull($d['next_attempt_at']);
    }

    public function testDeliverPendingGivesUpAfterMaxAttempts(): void
    {
        $u = $this->makeUser();
        $hook = $this->makeHook((int) $u['id'], 'kill');
        webhook_dispatch((int) $u['id'], 'kill', []);

        // Pretend we have retried to one short of the limit.
        update_row('webhook_deliveries', [
            'attempts'        => WEBHOOK_MAX_ATTEMPTS - 1,
            'next_attempt_at' => date('Y-m-d H:i:s', time() - 30),
        ], 'webhook_id = ?', [(int) $hook['id']]);

        $summary = webhook_deliver_pending();
        $this->assertSame(1, $summary['failed']);

        $d = fetch('SELECT * FROM webhook_deliveries WHERE user_id = ?', [(int) $u['id']]);
        $this->assertSame('failed', $d['status']);
        $this->assertSame(WEBHOOK_MAX_ATTEMPTS, (int) $d['attempts']);
        $this->assertNull($d['next_attempt_at']);

        $h = fetch('SELECT failures FROM webhooks WHERE id = ?', [(int) $hook['id']]);
        $this->assertSame(1, (int) $h['failures']);
    }

    public function testDeliverPendingRespectsBackoffWindow(): void
    {
        $u = $this->makeUser();
        $hook = $this->makeHook((int) $u['id'], 'kill');
        webhook_dispatch((int) $u['id'], 'kill', []);

        // A delivery already scheduled in the future must be left alone.
        update_row('webhook_deliveries', ['next_attempt_at' => date('Y-m-d H:i:s', time() + 300)], 'webhook_id = ?', [(int) $hook['id']]);
        $summary = webhook_deliver_pending();
        $this->assertSame(0, $summary['processed']);
    }

    public function testGrantXpDispatchesLevelup(): void
    {
        $u = $this->makeUser(['level' => 1, 'xp' => 0]);
        $this->makeHook((int) $u['id'], 'levelup');

        $levels = grant_xp((int) $u['id'], 1000);
        $this->assertGreaterThan(0, $levels);

        $d = fetch('SELECT * FROM webhook_deliveries WHERE user_id = ? AND event = ?', [(int) $u['id'], 'levelup']);
        $this->assertNotNull($d, 'a level-up must queue a webhook delivery');
        $data = json_decode((string) $d['payload'], true);
        $this->assertGreaterThan(1, $data['data']['level']);
    }

    public function testAwardKillDispatchesKill(): void
    {
        $attacker = $this->makeUser(['money' => 1000, 'level' => 1]);
        $victim   = $this->makeUser(['money' => 5000, 'level' => 1]);
        $this->makeHook((int) $attacker['id'], 'kill');

        award_kill($attacker, $victim);

        $d = fetch('SELECT * FROM webhook_deliveries WHERE user_id = ? AND event = ?', [(int) $attacker['id'], 'kill']);
        $this->assertNotNull($d, 'a kill must queue a webhook delivery');
        $data = json_decode((string) $d['payload'], true);
        $this->assertSame((int) $victim['id'], $data['data']['victim_id']);
    }
}
