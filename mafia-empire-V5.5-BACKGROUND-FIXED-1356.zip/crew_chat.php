<?php
/**
 * Eye Of The Mafia - Crew Chat
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/social.php';

$u = require_login();
$page_title = 'Crew Chat';

// Get user's crew
$crew = fetch('SELECT c.*, cm.rank AS role FROM crews c JOIN crew_members cm ON c.id = cm.crew_id WHERE cm.user_id = ?', [$u['id']]);

if (!$crew) {
    require __DIR__ . '/includes/header.php';
    echo '<div class="card"><div class="panel-heading">Crew Chat</div><p class="muted">You are not in a crew.</p></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$crewId = (int)$crew['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $msg = trim($_POST['message'] ?? '');
    if ($msg !== '') {
        $mid = crew_message_send($u['id'], $crewId, $msg);
        if ($mid) {
            $success = 'Message sent.';
        } else {
            $error = 'Failed to send message.';
        }
    } else {
        $error = 'Message cannot be empty.';
    }
}

$messages = crew_messages_get($crewId, 100);
$messageIds = array_map(fn($m) => (int)$m['id'], $messages);
crew_messages_mark_read($u['id'], $crewId, $messageIds);

require __DIR__ . '/includes/header.php';
?>
<div class="card animate-fade-in">
  <div class="panel-heading">
    <span class="n-ico">&#9993;</span><?= e($crew['name']) ?> - Crew Chat
    <span class="ws-status" id="wsStatus">
      <span class="ws-dot" id="wsDot"></span>
      <span id="wsText">Connecting...</span>
    </span>
  </div>
  <p class="muted small">Communicate with your crew members.</p>
</div>

<?php if ($error): ?><div class="alert alert-error" style="margin-top:12px"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success" style="margin-top:12px"><?= e($success) ?></div><?php endif; ?>

<div class="card chat-messages" id="chatMessages">
  <?php if (empty($messages)): ?>
    <div class="chat-empty">No messages yet. Be the first to say something.</div>
  <?php else: ?>
    <?php foreach ($messages as $m): ?>
      <div class="chat-message" id="msg-<?= (int) $m['id'] ?>">
        <div class="chat-message-meta">
          <span class="chat-message-author"><?= e($m['username']) ?></span>
          <span class="chat-message-time"><?= e($m['created_at']) ?></span>
        </div>
        <div class="chat-message-body"><?= nl2br(e($m['message'])) ?></div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<div class="card chat-form">
  <form method="post" action="crew_chat.php">
    <?= csrf_field() ?>
    <div class="form-row">
      <input type="text" name="message" class="form-input" placeholder="Type your message..." maxlength="500" required autocomplete="off">
    </div>
    <p class="chat-mention-tip">Tip: mention a crewmate with <b>@username</b> to send them a notification.</p>
    <div style="margin-top:8px">
      <button class="btn btn-gold" type="submit">Send</button>
    </div>
  </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const wsStatus = document.getElementById('wsStatus');
  const wsDot = document.getElementById('wsDot');
  const wsText = document.getElementById('wsText');
  const chatMessages = document.getElementById('chatMessages');

  function setWsStatus(connected, text) {
    if (!wsDot || !wsText) return;
    wsDot.className = 'ws-dot ' + (connected ? 'connected' : 'disconnected');
    wsText.textContent = text;
    if (!connected) wsDot.classList.add('disconnected');
  }

  // Auto-scroll to bottom
  function scrollToBottom() {
    if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;
  }
  scrollToBottom();

  // WebSocket integration for real-time crew chat
  if (typeof MafiaWebSocket !== 'undefined' && window.mafiaWS) {
    const ws = window.mafiaWS;
    const token = document.querySelector('meta[name="ws-token"]')?.content;

    if (token) {
      ws.auth(token);
      ws.subscribe('crew_' + <?= $crewId ?>);

      ws.on('connected', function() {
        setWsStatus(true, 'Live');
      });

      ws.on('disconnected', function() {
        setWsStatus(false, 'Reconnecting...');
      });

      ws.on('chat_message', function(data) {
        if (!data || data.channel !== 'crew_' + <?= $crewId ?>) return;
        const msg = data.message;
        if (!msg) return;

        const el = document.createElement('div');
        el.className = 'chat-message animate-fade-in-up';
        el.id = 'msg-' + msg.id;
        el.innerHTML =
          '<div class="chat-message-meta">' +
            '<span class="chat-message-author">' + (msg.username || 'Unknown') + '</span>' +
            '<span class="chat-message-time">' + msg.created_at + '</span>' +
          '</div>' +
          '<div class="chat-message-body">' + msg.message.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>') + '</div>';
        chatMessages.appendChild(el);
        scrollToBottom();

        // Highlight new message briefly
        el.style.background = 'rgba(212,160,16,.15)';
        setTimeout(() => { el.style.background = ''; }, 1500);
      });

      ws.on('message_sent', function(data) {
        // Message was echoed back from server - already handled by chat_message
      });

      ws.on('typing', function(data) {
        // Optional: show typing indicator
      });
    } else {
      setWsStatus(false, 'No token');
    }
  } else {
    setWsStatus(false, 'WebSocket unavailable');
  }
});
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>