<?php
/**
 * CSP Violation Report Endpoint
 */

require_once __DIR__ . '/includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$input = file_get_contents('php://input');
$report = json_decode($input, true);

if ($report) {
    // Log CSP violation
    $cspReport = $report['csp-report'] ?? $report;
    
    insert('csp_violations', [
        'document_uri' => $cspReport['document-uri'] ?? null,
        'referrer' => $cspReport['referrer'] ?? null,
        'blocked_uri' => $cspReport['blocked-uri'] ?? null,
        'violated_directive' => $cspReport['violated-directive'] ?? null,
        'original_policy' => $cspReport['original-policy'] ?? null,
        'source_file' => $cspReport['source-file'] ?? null,
        'line_number' => isset($cspReport['line-number']) ? (int) $cspReport['line-number'] : null,
        'column_number' => isset($cspReport['column-number']) ? (int) $cspReport['column-number'] : null,
        'script_sample' => $cspReport['script-sample'] ?? null,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
    ]);
    
    // Also log as security event
    log_security('csp_violation', [
        'directive' => $cspReport['violated-directive'] ?? null,
        'blocked_uri' => $cspReport['blocked-uri'] ?? null,
    ]);
}

http_response_code(204);