-- Migration 8: Content expansion (2 new districts + missions, bosses, jobs, legendary items)
-- Idempotent: every insert is guarded with NOT EXISTS so repeated runs are safe.

-- --- New districts ---------------------------------------------------------
INSERT INTO districts (name, description, unlock_level, income_bonus)
SELECT 'Chinatown', 'Jade, opium and silent knives behind paper screens.', 30, 50
WHERE NOT EXISTS (SELECT 1 FROM districts WHERE name = 'Chinatown');

INSERT INTO districts (name, description, unlock_level, income_bonus)
SELECT 'The Suburbs', 'White picket fences hide dirty money.', 45, 70
WHERE NOT EXISTS (SELECT 1 FROM districts WHERE name = 'The Suburbs');

-- --- Chinatown missions ----------------------------------------------------
INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story)
SELECT d.id, 'Extort the Tea House', 'A polite request with an unspoken threat.', 14, 30, 11000, 240, 4, 50, 'A polite request with an unspoken threat.'
FROM districts d WHERE d.name = 'Chinatown' AND NOT EXISTS (SELECT 1 FROM missions WHERE name = 'Extort the Tea House');

INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story)
SELECT d.id, 'Run Opium Through the Tunnels', 'Smuggle below the streets where nobody looks.', 18, 34, 18000, 360, 6, 55, 'Smuggle below the streets where nobody looks.'
FROM districts d WHERE d.name = 'Chinatown' AND NOT EXISTS (SELECT 1 FROM missions WHERE name = 'Run Opium Through the Tunnels');

INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story)
SELECT d.id, 'Fix a Mahjong Den', 'Stack the tiles and take the pot.', 12, 32, 13000, 280, 5, 48, 'Stack the tiles and take the pot.'
FROM districts d WHERE d.name = 'Chinatown' AND NOT EXISTS (SELECT 1 FROM missions WHERE name = 'Fix a Mahjong Den');

INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story)
SELECT d.id, 'Silence a Triad Informant', 'Loose lips sink empires.', 22, 40, 30000, 560, 9, 65, 'Loose lips sink empires.'
FROM districts d WHERE d.name = 'Chinatown' AND NOT EXISTS (SELECT 1 FROM missions WHERE name = 'Silence a Triad Informant');

-- --- The Suburbs missions --------------------------------------------------
INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story)
SELECT d.id, 'Rob a Country Club', 'Members only, especially the vault.', 16, 45, 26000, 480, 7, 55, 'Members only, especially the vault.'
FROM districts d WHERE d.name = 'The Suburbs' AND NOT EXISTS (SELECT 1 FROM missions WHERE name = 'Rob a Country Club');

INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story)
SELECT d.id, 'Fence Stolen Art', 'Move a masterpiece to a private buyer.', 20, 48, 42000, 720, 11, 60, 'Move a masterpiece to a private buyer.'
FROM districts d WHERE d.name = 'The Suburbs' AND NOT EXISTS (SELECT 1 FROM missions WHERE name = 'Fence Stolen Art');

INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story)
SELECT d.id, 'Blackmail the Mayor', 'A photograph is worth a fortune.', 24, 52, 60000, 950, 15, 68, 'A photograph is worth a fortune.'
FROM districts d WHERE d.name = 'The Suburbs' AND NOT EXISTS (SELECT 1 FROM missions WHERE name = 'Blackmail the Mayor');

INSERT INTO missions (district_id, name, description, energy_cost, min_level, reward_money, reward_xp, reward_points, risk, story)
SELECT d.id, 'Take the Suburban Racket', 'The quiet streets pay loud money.', 28, 55, 85000, 1300, 20, 72, 'The quiet streets pay loud money.'
FROM districts d WHERE d.name = 'The Suburbs' AND NOT EXISTS (SELECT 1 FROM missions WHERE name = 'Take the Suburban Racket');

-- --- New bosses ------------------------------------------------------------
INSERT INTO bosses (district_id, name, description, hp, attack, defense, min_level, energy_cost, reward_money, reward_xp, reward_points, reward_item_id)
SELECT d.id, 'Madame Lin Zhao', 'The porcelain boss of Chinatown.', 2400, 110, 55, 30, 28, 150000, 2600, 35, NULL
FROM districts d WHERE d.name = 'Chinatown' AND NOT EXISTS (SELECT 1 FROM bosses WHERE name = 'Madame Lin Zhao');

INSERT INTO bosses (district_id, name, description, hp, attack, defense, min_level, energy_cost, reward_money, reward_xp, reward_points, reward_item_id)
SELECT d.id, 'Senator Charles Vandermeer', 'Clean hands, dirty deals.', 4200, 165, 80, 48, 35, 400000, 5000, 60, NULL
FROM districts d WHERE d.name = 'The Suburbs' AND NOT EXISTS (SELECT 1 FROM bosses WHERE name = 'Senator Charles Vandermeer');

-- --- New criminal jobs -----------------------------------------------------
INSERT INTO criminal_jobs (name, description, nerve_cost, min_level, payout_min, payout_max, xp, fail_risk)
SELECT 'Smuggle Contraband', 'Move goods past the port authority.', 14, 28, 8000, 16000, 100, 42
WHERE NOT EXISTS (SELECT 1 FROM criminal_jobs WHERE name = 'Smuggle Contraband');

INSERT INTO criminal_jobs (name, description, nerve_cost, min_level, payout_min, payout_max, xp, fail_risk)
SELECT 'Fix a Boxing Match', 'A knockout nobody saw coming.', 18, 35, 18000, 34000, 160, 48
WHERE NOT EXISTS (SELECT 1 FROM criminal_jobs WHERE name = 'Fix a Boxing Match');

INSERT INTO criminal_jobs (name, description, nerve_cost, min_level, payout_min, payout_max, xp, fail_risk)
SELECT 'Counterfeit Bonds', 'Print your own fortune.', 22, 45, 40000, 75000, 240, 55
WHERE NOT EXISTS (SELECT 1 FROM criminal_jobs WHERE name = 'Counterfeit Bonds');

INSERT INTO criminal_jobs (name, description, nerve_cost, min_level, payout_min, payout_max, xp, fail_risk)
SELECT 'Broker a Hostile Takeover', 'Wall Street muscle for hire.', 26, 55, 80000, 150000, 360, 60
WHERE NOT EXISTS (SELECT 1 FROM criminal_jobs WHERE name = 'Broker a Hostile Takeover');

-- --- Legendary items -------------------------------------------------------
INSERT INTO items (name, description, type, attack, defense, cost, min_level, rarity)
SELECT 'Golden Tommy Gun', 'A showpiece that still shoots straight.', 'weapon', 60, 0, 500000, 40, 'legendary'
WHERE NOT EXISTS (SELECT 1 FROM items WHERE name = 'Golden Tommy Gun');

INSERT INTO items (name, description, type, attack, defense, cost, min_level, rarity)
SELECT 'Dragon Breath Shotgun', 'Short range, long memory.', 'weapon', 55, 2, 400000, 38, 'legendary'
WHERE NOT EXISTS (SELECT 1 FROM items WHERE name = 'Dragon Breath Shotgun');

INSERT INTO items (name, description, type, attack, defense, cost, min_level, rarity)
SELECT 'Dragon Scale Vest', 'Light as a whisper, hard as a wall.', 'armor', 0, 65, 450000, 42, 'legendary'
WHERE NOT EXISTS (SELECT 1 FROM items WHERE name = 'Dragon Scale Vest');

INSERT INTO items (name, description, type, attack, defense, cost, min_level, rarity)
SELECT 'Armored Limousine', 'Arrive in style, leave in one piece.', 'vehicle', 4, 30, 600000, 45, 'legendary'
WHERE NOT EXISTS (SELECT 1 FROM items WHERE name = 'Armored Limousine');
