﻿<?php
require_once __DIR__ . "/includes/init.php";
$u = require_login();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  csrf_verify();
  $db = fetch("SELECT * FROM daily_bonuses WHERE user_id=?", [$u["id"]]);
  $now = time();
  $streak = 1; $amount = 500; $xp = 50;
  if ($db) {
    $last = strtotime($db["last_claim"]);
    $diff = floor(($now - $last) / 86400);
    if ($diff < 1) { flash("Already claimed today.", "error"); redirect("daily.php"); }
    $streak = ($diff === 1) ? (int)$db["streak"] + 1 : 1;
    if ($streak > 7) $streak = 7;
  }
  $rewards = [1=>["money"=>500,"xp"=>50],2=>["money"=>1000,"xp"=>100],3=>["money"=>2000,"xp"=>200],4=>["money"=>4000,"xp"=>400],5=>["money"=>8000,"xp"=>800],6=>["money"=>15000,"xp"=>1500],7=>["money"=>30000,"xp"=>3000]];
  $r = $rewards[$streak];
  add_money($u["id"], (int)$r["money"], "Daily bonus streak day $streak");
  grant_xp($u["id"], (int)$r["xp"]);
  if (!$db) insert("daily_bonuses", ["user_id"=>$u["id"],"streak"=>$streak,"last_claim"=>date("Y-m-d H:i:s")]);
  else q("UPDATE daily_bonuses SET streak=?, last_claim=? WHERE user_id=?", [$streak, date("Y-m-d H:i:s"), $u["id"]]);
  $_SESSION["daily_result"] = ["streak"=>$streak,"money"=>$r["money"],"xp"=>$r["xp"]];
  redirect("daily.php");
}
$page_title = "Daily Bonus";
require __DIR__ . "/includes/header.php";
$u = current_user();
$db = fetch("SELECT * FROM daily_bonuses WHERE user_id=?", [$u["id"]]);
$canClaim = !$db || floor((time() - strtotime($db["last_claim"])) / 86400) >= 1;
$nextDay = $db ? ceil((strtotime($db["last_claim"]) + 86400 - time()) / 3600) : 0;
$result = $_SESSION["daily_result"] ?? null;
unset($_SESSION["daily_result"]);
$rewards = [1=>["money"=>500,"xp"=>50],2=>["money"=>1000,"xp"=>100],3=>["money"=>2000,"xp"=>200],4=>["money"=>4000,"xp"=>400],5=>["money"=>8000,"xp"=>800],6=>["money"=>15000,"xp"=>800],7=>["money"=>30000,"xp"=>3000]];
?>
<div class="card card-glass" style="text-align:center">
  <div class="panel-heading" style="justify-content:center">Daily Bonus</div>
  <p class="muted small" style="max-width:500px;margin:8px auto 0">Log in daily for cash and XP. Streak resets if you miss a day.</p>
</div>
<?php if ($result): ?>
<div class="card card-glass alert alert-success" style="margin-top:12px;text-align:center">
  <div style="font-size:2rem;margin-bottom:6px">&#128176;</div>
  <b style="font-size:1.4rem;color:var(--gold-bright)">Streak Day <?= (int)$result["streak"] ?>!</b><br>
  <span style="font-size:1.2rem">+<?= money((int)$result["money"]) ?> Cash &nbsp;|&nbsp; +<?= (int)$result["xp"] ?> XP</span>
</div>
<?php endif; ?>
<div class="card card-glass" style="margin-top:14px;padding-top:6px">
  <div class="panel-heading" style="border-bottom:none">7-Day Streak</div>
  <div class="grid grid-7" style="margin-top:12px">
<?php for ($d=1;$d<=7;$d++): $r = $rewards[$d]; $claimed = $db && (int)$db["streak"] >= $d; $active = $db && (int)$db["streak"] === ($d-1) && $canClaim && $d === (int)$db["streak"] + 1; ?>
    <div class="card" style="text-align:center;padding:10px 6px;border-top:3px solid <?= $claimed ? "#c4a484" : ($active ? "#ffd700" : "rgba(196,164,132,.15)") ?>;background:<?= $claimed ? "rgba(196,164,132,.1)" : ($active ? "rgba(255,215,0,.12)" : "rgba(24,24,24,.6)") ?>;border-radius:10px;position:relative;overflow:hidden">
      <?php if ($active && $canClaim): ?><div class="fw-combat-text" style="position:absolute;top:-6px;left:50%;transform:translateX(-50%);font-size:.8rem;color:#ffd700;text-shadow:0 0 10px #ffd700">&#9733;</div><?php endif; ?>
      <div style="font-size:1.7rem;margin-bottom:4px"><?= $claimed ? "&#10003;" : "&#9679;" ?></div>
      <div class="muted small" style="font-size:.72rem"><?= $claimed ? "Claimed" : "Day $d" ?></div>
      <div class="big" style="font-size:1.15rem"><?= $claimed ? "Done" : money((int)$r["money"]) ?></div>
      <div class="muted small">+<?= (int)$r["xp"] ?> XP</div>
      <?php if ($active && $canClaim): ?>
        <form method="post" style="margin-top:6px"><?= csrf_field() ?><button class="btn btn-gold btn-sm" type="submit">Claim</button></form>
      <?php elseif (!$canClaim && !$claimed && $d === (int)($db["streak"] ?? 0) + 1): ?>
        <span class="tag tag-common" style="margin-top:4px;display:inline-block">Wait <?= (int)$nextDay ?>h</span>
      <?php elseif (!$canClaim && !$claimed): ?>
        <span class="tag tag-common" style="margin-top:4px;display:inline-block">Locked</span>
      <?php endif; ?>
    </div>
<?php endfor; ?>
  </div>
</div>
<?php if ($db): ?>
<div class="card card-glass" style="margin-top:14px">
  <div class="stat"><span>Current Streak</span><b style="color:var(--gold-bright)"><?= (int)$db["streak"] ?> days</b></div>
  <div class="stat"><span>Last Claim</span><b><?= e(date("M j, g:i a", strtotime($db["last_claim"]))) ?></b></div>
  <div class="progress" style="max-width:300px;margin:8px auto 0"><i style="width:<?= min(100, (int)$db["streak"] * 100 / 7) ?>%"></i></div>
</div>
<?php else: ?>
<div class="card card-glass" style="margin-top:14px"><p class="muted">Never claimed. Start your streak today!</p></div>
<?php endif; ?>
<?php require __DIR__ . "/includes/footer.php"; ?>
