<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: buy, equip, unequip, sell
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if (action_on_cooldown($u['id'], 'equipment')) {
        $cd = action_on_cooldown($u['id'], 'equipment');
        flash('Equipment on cooldown. Try again in ' . $cd . '.', 'error');
        redirect('equipment.php');
    }
    if ($action === 'buy') {
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $item = fetch('SELECT * FROM items WHERE id = ?', [$itemId]);
        if (!$item) {
            flash('Item not found.', 'error');
        } elseif ((int) $u['level'] < (int) $item['min_level']) {
            flash('Level ' . (int) $item['min_level'] . ' required.', 'error');
        } elseif ((int) $u['money'] < (int) $item['cost']) {
            flash('Not enough cash.', 'error');
        } else {
            add_money($u['id'], -(int) $item['cost'], 'Bought ' . $item['name']);
            $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$u['id'], $itemId]);
            if ($existing) {
                q('UPDATE user_items SET qty = qty + 1 WHERE id = ?', [(int) $existing['id']]);
            } else {
                insert('user_items', ['user_id' => $u['id'], 'item_id' => $itemId, 'qty' => 1, 'equipped' => 0]);
            }
            set_action_cooldown($u['id'], 'equipment');
            flash('Purchased ' . e($item['name']) . '.', 'success');
        }
    } elseif ($action === 'equip') {
        $uiId = (int) ($_POST['ui_id'] ?? 0);
        $ui = fetch('SELECT ui.*, i.name, i.type FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.id = ? AND ui.user_id = ?', [$uiId, $u['id']]);
        if (!$ui) {
            flash('Item not found.', 'error');
        } else {
            // Unequip any other of same type
            q('UPDATE user_items SET equipped = 0 WHERE user_id = ? AND equipped = 1 AND item_id IN (SELECT id FROM items WHERE type = ?)', [$u['id'], $ui['type']]);
            q('UPDATE user_items SET equipped = 1 WHERE id = ?', [$uiId]);
            set_action_cooldown($u['id'], 'equipment');
            flash('Equipped ' . e($ui['name']) . '.', 'success');
        }
    } elseif ($action === 'unequip') {
        $uiId = (int) ($_POST['ui_id'] ?? 0);
        q('UPDATE user_items SET equipped = 0 WHERE id = ? AND user_id = ?', [$uiId, $u['id']]);
        flash('Unequipped.', 'success');
    } elseif ($action === 'sell') {
        $uiId = (int) ($_POST['ui_id'] ?? 0);
        $ui = fetch('SELECT ui.*, i.cost, i.name FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.id = ? AND ui.user_id = ?', [$uiId, $u['id']]);
        if (!$ui || (int) $ui['qty'] <= 0) {
            flash('Item not found.', 'error');
        } else {
            $sellPrice = (int) floor((int) $ui['cost'] * 0.5);
            add_money($u['id'], $sellPrice, 'Sold ' . $ui['name']);
            q('UPDATE user_items SET qty = qty - 1 WHERE id = ?', [$uiId]);
            q('DELETE FROM user_items WHERE id = ? AND qty <= 0', [$uiId]);
            set_action_cooldown($u['id'], 'equipment');
            flash('Sold ' . e($ui['name']) . ' for ' . money($sellPrice) . '.', 'success');
        }
    }
    redirect('equipment.php');
}

$page_title = 'Equipment';
require __DIR__ . '/includes/header.php';

// Shop items
$shopItems = fetch_all('SELECT * FROM items WHERE cost > 0 ORDER BY type, cost');
// Owned items
$myItems = fetch_all('SELECT ui.*, i.name, i.type, i.attack, i.defense, i.cost, i.min_level, i.rarity, i.description
                     FROM user_items ui JOIN items i ON i.id = ui.item_id
                     WHERE ui.user_id = ? AND ui.qty > 0 ORDER BY i.type, i.cost', [$u['id']]);
// Equipped
$equipped = fetch_all('SELECT ui.*, i.name, i.type, i.attack, i.defense, i.cost, i.min_level, i.rarity, i.description FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.equipped = 1', [$u['id']]);
$atkTotal = 0; $defTotal = 0;
foreach ($equipped as $eq) { $atkTotal += (int) $eq['attack']; $defTotal += (int) $eq['defense']; }
?>
<div class="card">
  <div class="panel-heading">Equipped Gear <span class="muted small">(ATK: +<?= $atkTotal ?> / DEF: +<?= $defTotal ?>)</span></div>
  <?php if (!$equipped): ?>
    <p class="muted">Nothing equipped.</p>
  <?php else: ?>
    <div class="table-wrap" style="overflow-x:auto"><table>
      <tr><th>Item</th><th>Type</th><th>ATK/DEF</th><th></th></tr>
      <?php foreach ($equipped as $eq): ?>
        <tr>
          <td><b><?= e($eq['name']) ?></b></td>
          <td><span class="tag"><?= e($eq['type']) ?></span></td>
          <td><?= (int) $eq['attack'] > 0 ? '+' . (int) $eq['attack'] : '' ?><?= (int) $eq['defense'] > 0 ? ' / +' . (int) $eq['defense'] : '' ?></td>
          <td>
            <form method="post" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="unequip">
              <input type="hidden" name="ui_id" value="<?= (int) $eq['id'] ?>">
              <button class="btn btn-sm" type="submit">Unequip</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="panel-heading">Shop</div>
  <div class="table-wrap" style="overflow-x:auto"><table>
    <tr><th>Item</th><th>Type</th><th>ATK</th><th>DEF</th><th>Cost</th><th>Min Lvl</th><th></th></tr>
    <?php foreach ($shopItems as $si): ?>
      <tr>
        <td><b><?= e($si['name']) ?></b><br><small class="muted"><?= e($si['description']) ?></small></td>
        <td><span class="tag"><?= e($si['type']) ?></span></td>
        <td><?= (int) $si['attack'] > 0 ? '+' . (int) $si['attack'] : '—' ?></td>
        <td><?= (int) $si['defense'] > 0 ? '+' . (int) $si['defense'] : '—' ?></td>
        <td><?= money($si['cost']) ?></td>
        <td><?= (int) $si['min_level'] ?></td>
        <td>
          <?php if ((int) $u['level'] >= (int) $si['min_level'] && (int) $u['money'] >= (int) $si['cost']): ?>
            <form method="post" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="buy">
              <input type="hidden" name="item_id" value="<?= (int) $si['id'] ?>">
              <button class="btn btn-green btn-sm" type="submit">Buy</button>
            </form>
          <?php else: ?>
            <span class="tag tag-common">Locked</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="card">
  <div class="panel-heading">Inventory</div>
  <?php if (!$myItems): ?>
    <p class="muted">Your inventory is empty.</p>
  <?php else: ?>
    <div class="table-wrap" style="overflow-x:auto"><table>
      <tr><th>Item</th><th>Type</th><th>Qty</th><th>ATK/DEF</th><th>Status</th><th></th></tr>
      <?php foreach ($myItems as $mi): ?>
        <tr>
          <td><b><?= e($mi['name']) ?></b></td>
          <td><span class="tag"><?= e($mi['type']) ?></span></td>
          <td><?= (int) $mi['qty'] ?></td>
          <td><?= (int) $mi['attack'] > 0 ? '+' . (int) $mi['attack'] : '' ?><?= (int) $mi['defense'] > 0 ? ' / +' . (int) $mi['defense'] : '' ?></td>
          <td><?= (int) $mi['equipped'] ? '<span class="tag tag-legendary">Equipped</span>' : '<span class="tag tag-common">Stored</span>' ?></td>
          <td>
            <?php if (!(int) $mi['equipped']): ?>
              <form method="post" style="display:inline-block">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="equip">
                <input type="hidden" name="ui_id" value="<?= (int) $mi['id'] ?>">
                <button class="btn btn-sm" type="submit">Equip</button>
              </form>
            <?php endif; ?>
            <form method="post" style="display:inline-block;margin-left:4px">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="sell">
              <input type="hidden" name="ui_id" value="<?= (int) $mi['id'] ?>">
              <button class="btn btn-sm" type="submit" data-confirm="Sell for <?= money((int) floor((int) $mi['cost'] * 0.5)) ?>?">Sell</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>