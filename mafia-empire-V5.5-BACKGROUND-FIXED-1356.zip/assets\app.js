// Halloween Boot Screen
(function () {
  var boot = document.getElementById('bootScreen');
  if (!boot) return;

  var inner = boot.querySelector('.boot-inner');
  var particlesContainer = boot.querySelector('.boot-particles');
  var batsContainer = boot.querySelector('.boot-bats');

  // Create floating particles
  function createParticles() {
    if (!particlesContainer) return;
    var particleCount = 25;
    for (var i = 0; i < particleCount; i++) {
      var particle = document.createElement('div');
      particle.className = 'boot-particle';
      var size = Math.random() * 6 + 2;
      particle.style.width = size + 'px';
      particle.style.height = size + 'px';
      particle.style.left = Math.random() * 100 + '%';
      particle.style.top = (100 + Math.random() * 20) + '%';
      particle.style.background = randomParticleColor();
      particle.style.setProperty('--drift', (Math.random() - 0.5) * 200 + 'px');
      particle.style.animationDelay = Math.random() * 8 + 's';
      particle.style.animationDuration = (8 + Math.random() * 4) + 's';
      particlesContainer.appendChild(particle);
    }
  }

  function randomParticleColor() {
    var colors = [
      'rgba(255,165,0,0.6)',   // orange
      'rgba(255,100,0,0.6)',   // pumpkin
      'rgba(255,255,255,0.4)', // white
      'rgba(255,165,0,0.5)',   // orange
      'rgba(128,0,128,0.4)',   // purple
      'rgba(255,100,0,0.5)',   // pumpkin
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  // Create bat silhouettes
  function createBats() {
    if (!batsContainer) return;
    var batCount = 8;
    for (var i = 0; i < batCount; i++) {
      var bat = document.createElement('div');
      bat.className = 'boot-bat';
      bat.style.left = Math.random() * 100 + '%';
      bat.style.top = (Math.random() * 60 + 10) + '%';
      bat.style.animationDelay = Math.random() * 15 + 's';
      bat.style.animationDuration = (15 + Math.random() * 10) + 's';
      bat.style.setProperty('--bat-drift', (Math.random() - 0.5) * 300 + 'px');
      bat.style.setProperty('--bat-rotate', (Math.random() * 30 - 15) + 'deg');
      batsContainer.appendChild(bat);
    }
  }

  var hideBoot = function () {
    if (boot.classList.contains('hidden')) return;
    boot.classList.add('hidden');
    boot.style.transition = 'opacity 1s cubic-bezier(0.4, 0, 0.2, 1), visibility 1s';
    boot.style.opacity = '0';
    boot.style.visibility = 'hidden';
    setTimeout(function () {
      boot.style.display = 'none';
      boot.removeAttribute('aria-hidden');
    }, 1000);
  };

  // Initialize particles and bats
  createParticles();
  createBats();

  // Screen shake on load
  var bootEl = document.getElementById('bootScreen');
  if (bootEl) {
    bootEl.classList.add('shake');
  }

  // Auto-hide after 3.5 seconds
  setTimeout(hideBoot, 3500);

  // Click/tap anywhere to dismiss early
  document.addEventListener('click', hideBoot, { once: true });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') {
      hideBoot();
    }
  }, { once: true });

  // Respect reduced motion
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) {
    hideBoot();
  }
})();

// Mafia Empire - UI enhancements (1914 Bootleg theme)
document.addEventListener('click', function (e) {
  var b = e.target.closest('[data-confirm]');
  if (b && !confirm(b.getAttribute('data-confirm'))) {
    e.preventDefault();
  }
});

// --- Collapsible sidebar groups (persisted) ---
document.querySelectorAll('[data-collapsible]').forEach(function (g) {
  var btn = g.querySelector('.nav-group-title');
  if (!btn) return;
  btn.addEventListener('click', function () {
    var collapsed = g.classList.toggle('collapsed');
    btn.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
    try { localStorage.setItem('nav-' + g.id, collapsed ? '1' : '0'); } catch (err) {}
  });
  try {
    if (localStorage.getItem('nav-' + g.id) === '1') {
      g.classList.add('collapsed');
      btn.setAttribute('aria-expanded', 'false');
    }
  } catch (err) {}
});

// --- Mobile sidebar toggle ---
var mt = document.getElementById('menuToggle');
var sidebar = document.getElementById('mainSidebar');
if (mt && sidebar) {
  mt.addEventListener('click', function () {
    var open = sidebar.classList.toggle('open');
    mt.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  sidebar.addEventListener('click', function (e) {
    if (e.target.closest('.nav-link')) {
      sidebar.classList.remove('open');
      mt.setAttribute('aria-expanded', 'false');
    }
  });
}

// Live countdown timers: <span data-until="2026-01-01 12:00:00"></span>
function tickTimers() {
  document.querySelectorAll('[data-until]').forEach(function (el) {
    var t = new Date(el.getAttribute('data-until').replace(' ', 'T')).getTime();
    var diff = Math.max(0, Math.floor((t - Date.now()) / 1000));
    var m = Math.floor(diff / 60), s = diff % 60;
    el.textContent = diff > 0 ? (m + 'm ' + String(s).padStart(2, '0') + 's') : 'Ready';
  });
}
setInterval(tickTimers, 1000);
tickTimers();

// ============================================================
// UI UPLIFT 2.0 — theme, toasts, progress, count-up, ripple
// ============================================================
(function () {
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // --- Ledger (sepia) theme toggle ---
  var root = document.documentElement;
  document.querySelectorAll('.theme-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var sepia = root.classList.toggle('theme-sepia');
      try { localStorage.setItem('me-theme', sepia ? 'sepia' : 'dark'); } catch (err) {}
      btn.textContent = sepia ? '\u263D' : '\u263C';
      var meta = document.querySelector('meta[name="theme-color"]');
      if (meta) meta.setAttribute('content', sepia ? '#e7dcc0' : '#140f0a');
    });
    if (root.classList.contains('theme-sepia')) btn.textContent = '\u263D';
  });

  // --- Toasts: dismiss + auto-hide (delegated to shared killToast) ---
  function killToast(t) {
    if (!t || t.classList.contains('out')) return;
    t.classList.add('out');
    setTimeout(function () { t.remove(); }, 250);
  }
  document.querySelectorAll('#toasts [data-toast]').forEach(function (t, i) {
    var close = t.querySelector('.toast-close');
    if (close) close.addEventListener('click', function () { killToast(t); });
    setTimeout(function () { killToast(t); }, 5200 + i * 400);
  });

  // --- Scroll progress bar ---
  var prog = document.getElementById('scrollProgress');
  function onScroll() {
    var top = window.scrollY || document.documentElement.scrollTop;
    var h = document.documentElement.scrollHeight - window.innerHeight;
    if (prog) prog.style.width = (h > 0 ? (top / h) * 100 : 0) + '%';
    var toTop = document.getElementById('toTop');
    if (toTop) toTop.classList.toggle('show', top > 420);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // --- Back to top ---
  var toTop = document.getElementById('toTop');
  if (toTop) toTop.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
  });

  // --- Count-up vitals ---
  if (!reduce) {
    document.querySelectorAll('[data-count]').forEach(function (el) {
      var target = parseInt(el.getAttribute('data-count'), 10) || 0;
      if (target <= 0) return;
      var start = null, dur = 700;
      function step(ts) {
        if (!start) start = ts;
        var p = Math.min(1, (ts - start) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(target * eased).toLocaleString();
        if (p < 1) requestAnimationFrame(step);
      }
      el.textContent = '0';
      requestAnimationFrame(step);
    });
  }

  // --- Button / tile ripple ---
  document.addEventListener('click', function (e) {
    var host = e.target.closest('.btn, .tile');
    if (!host || reduce) return;
    var rect = host.getBoundingClientRect();
    var d = Math.max(rect.width, rect.height);
    var span = document.createElement('span');
    span.className = 'ripple-el';
    span.style.width = span.style.height = d + 'px';
    span.style.left = (e.clientX - rect.left - d / 2) + 'px';
    span.style.top = (e.clientY - rect.top - d / 2) + 'px';
    host.appendChild(span);
    setTimeout(function () { span.remove(); }, 620);
  });

  // --- Form loading state (adds .loading class on submit) ---
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || !form.matches || form.hasAttribute('data-no-loading')) return;
    var btn = form.querySelector('button[type="submit"], input[type="submit"]');
    if (btn) {
      btn.classList.add('loading');
      // Safety: remove loading after 10s in case navigation fails
      setTimeout(function () { btn.classList.remove('loading'); }, 10000);
    }
  }, true);
  if (!reduce && 'IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    document.querySelectorAll('.card').forEach(function (c) {
      if (c.getBoundingClientRect().top > window.innerHeight * 0.82) {
        c.classList.add('reveal');
        io.observe(c);
      }
    });
  }

  // --- Constant-speed ticker regardless of headline length ---
  var track = document.querySelector('.ticker-items');
  if (track && !reduce) {
    var w = track.scrollWidth / 2;
    if (w > 0) track.style.animationDuration = Math.max(20, Math.round(w / 65)) + 's';
  }
})();

// ============================================================
// PHASE 8 - PWA: service worker, install prompt, offline queue,
// update notices, and touch gestures (drawer + toast swipe).
// All progressive: nothing here is required for the game to work.
// ============================================================
(function () {
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var body = document.body;

  /* ---------- Small toast helper ---------- */
  function flash(msg, type) {
    var host = document.getElementById('toasts');
    if (!host) {
      host = document.createElement('div');
      host.id = 'toasts';
      host.className = 'toasts';
      host.setAttribute('role', 'status');
      host.setAttribute('aria-live', 'polite');
      document.body.appendChild(host);
    }
    var t = document.createElement('div');
    t.className = 'toast toast-' + (type || 'info');
    t.setAttribute('data-toast', '');
    t.innerHTML = '<span class="toast-ico" aria-hidden="true">' +
      (type === 'success' ? '&#10003;' : type === 'error' ? '&#10007;' : type === 'warning' ? '&#9888;' : '&#8505;') +
      '</span><span class="toast-msg">' + msg + '</span>' +
      '<button class="toast-close" type="button" aria-label="Dismiss">&#10005;</button>';
    host.appendChild(t);

    // Limit to 5 visible toasts; remove oldest if exceeded
    var all = host.querySelectorAll('[data-toast]');
    if (all.length > 5) {
      for (var i = 0; i < all.length - 5; i++) { killToast(all[i]); }
    }

    var close = t.querySelector('.toast-close');
    if (close) close.addEventListener('click', function () { killToast(t); });
    setTimeout(function () { killToast(t); }, 5200 + all.length * 400);
  }

  function killToast(t) {
    if (!t || t.classList.contains('out')) return;
    t.classList.add('out');
    setTimeout(function () { t.remove(); }, 250);
  }

  /* ---------- Offline action queue ---------- */
  var QKEY = 'me-offline-queue';
  function getQueue() { try { return JSON.parse(localStorage.getItem(QKEY) || '[]'); } catch (e) { return []; } }
  function setQueue(q) { try { localStorage.setItem(QKEY, JSON.stringify(q)); } catch (e) {} }

  /* ---------- Unified PWA status bar ---------- */
  var pwa = { offline: !navigator.onLine, pending: getQueue().length, update: false, install: null, dismissed: false, reg: null, iosHint: false };
  var IOS_KEY = 'me-ios-install-dismissed';
  function pwaBar() {
    var el = document.getElementById('pwaBar');
    if (!el) {
      el = document.createElement('div');
      el.id = 'pwaBar';
      el.className = 'pwa-bar';
      el.hidden = true;
      el.innerHTML = '<span class="pb-ico" aria-hidden="true">&#9888;</span>'
        + '<span class="pb-msg" id="pwaMsg"></span>'
        + '<button class="pb-act" id="pwaAct" type="button" hidden></button>'
        + '<button class="pb-x" id="pwaX" type="button" aria-label="Dismiss">&#10005;</button>';
      document.body.appendChild(el);
      document.getElementById('pwaX').addEventListener('click', function () {
        pwa.dismissed = true;
        if (pwa.iosHint) { try { localStorage.setItem(IOS_KEY, '1'); } catch (e) {} }
        renderPwa();
      });
    }
    return el;
  }
  function renderPwa() {
    var el = pwaBar();
    var msg = document.getElementById('pwaMsg');
    var act = document.getElementById('pwaAct');
    el.classList.toggle('pwa-offline', pwa.offline);
    if (pwa.offline) {
      el.hidden = false;
      msg.textContent = pwa.pending
        ? 'Offline \u2014 ' + pwa.pending + ' move' + (pwa.pending === 1 ? '' : 's') + ' queued.'
        : 'Offline \u2014 your moves will be queued.';
      act.hidden = true;
      return;
    }
    if (pwa.pending) {
      el.hidden = false;
      msg.textContent = 'Sending ' + pwa.pending + ' queued move' + (pwa.pending === 1 ? '' : 's') + '\u2026';
      act.hidden = true;
      return;
    }
    if (pwa.update) {
      el.hidden = false;
      msg.textContent = 'A new version of the city is ready.';
      act.hidden = false;
      act.textContent = 'Refresh';
      act.onclick = function () {
        pwa.update = false;
        renderPwa();
        if (pwa.reg && pwa.reg.waiting) pwa.reg.waiting.postMessage('SKIP_WAITING');
      };
      return;
    }
    if (pwa.install && !pwa.dismissed) {
      el.hidden = false;
      msg.textContent = 'Install Mafia Empire on your device.';
      act.hidden = false;
      act.textContent = 'Install';
      act.onclick = function () { pwa.install.prompt(); };
      return;
    }
    // iOS Safari never fires beforeinstallprompt: guide the user manually.
    if (pwa.iosHint && !pwa.dismissed) {
      el.hidden = false;
      msg.textContent = 'Add to Home Screen: tap Share, then \u201cAdd to Home Screen\u201d.';
      act.hidden = true;
      return;
    }
    el.hidden = true;
  }

  function flushQueue() {
    var q = getQueue();
    if (!q.length) { pwa.pending = 0; renderPwa(); return; }
    var item = q.shift();
    setQueue(q);
    pwa.pending = q.length + 1;
    renderPwa();
    fetch(item.url, {
      method: item.method || 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: item.body,
      credentials: 'same-origin',
      redirect: 'manual'
    }).then(function () {
      if (getQueue().length) { setTimeout(flushQueue, 700); }
      else { pwa.pending = 0; flash('Queued moves sent.', 'success'); renderPwa(); location.reload(); }
    }).catch(function () {
      var rq = getQueue(); rq.unshift(item); setQueue(rq);
      pwa.pending = rq.length; renderPwa();
    });
  }

  // Capture-phase listener so we win the race with any page handlers.
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || !form.matches || !form.matches('form[data-offline-queue]')) return;
    if (navigator.onLine) return;
    if (form.querySelector('input[type="file"]')) return; // can't serialise files
    e.preventDefault();
    var q = getQueue();
    q.push({
      url: form.getAttribute('action') || location.href,
      method: (form.getAttribute('method') || 'POST').toUpperCase(),
      body: new URLSearchParams(new FormData(form)).toString(),
      ts: Date.now()
    });
    setQueue(q);
    pwa.pending = q.length;
    pwa.offline = !navigator.onLine;
    renderPwa();
    flash('Queued \u2014 it will send when you reconnect.', 'info');
  }, true);

  window.addEventListener('offline', function () { pwa.offline = true; renderPwa(); });
  window.addEventListener('online', function () { pwa.offline = false; pwa.dismissed = false; renderPwa(); flushQueue(); });

  /* ---------- Service worker: register + updates ---------- */
  var swUrl = body.getAttribute('data-sw');
  if (swUrl && 'serviceWorker' in navigator) {
    var reloading = false;
    var hadController = !!navigator.serviceWorker.controller; // false on the very first visit
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      // Ignore the initial claim; only reload when an *update* takes over.
      if (!hadController) { hadController = true; return; }
      if (reloading) return;
      reloading = true;
      location.reload();
    });
    window.addEventListener('load', function () {
      navigator.serviceWorker.register(swUrl).then(function (reg) {
        pwa.reg = reg;
        if (reg.waiting && navigator.serviceWorker.controller) { pwa.update = true; renderPwa(); }
        reg.addEventListener('updatefound', function () {
          var nw = reg.installing;
          if (!nw) return;
          nw.addEventListener('statechange', function () {
            if (nw.state === 'installed' && navigator.serviceWorker.controller) { pwa.update = true; renderPwa(); }
          });
        });
      }).catch(function () {});
    });
  }

  /* ---------- Install prompt ---------- */
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    pwa.install = e;
    pwa.dismissed = false;
    renderPwa();
  });
  window.addEventListener('appinstalled', function () { pwa.install = null; pwa.dismissed = true; renderPwa(); });

  /* ---------- iOS Safari: no beforeinstallprompt, so guide the user ---------- */
  (function () {
    var ua = navigator.userAgent || '';
    var isIos = /iphone|ipad|ipod/i.test(ua) && !window.MSStream;
    // Chrome/Firefox/Edge on iOS can't add to home screen either, so only Safari.
    var isOtherIosBrowser = /crios|fxios|edgios|opios/i.test(ua);
    var standalone = window.navigator.standalone === true ||
      (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches);
    var dismissed = false;
    try { dismissed = localStorage.getItem(IOS_KEY) === '1'; } catch (e) {}
    if (isIos && !standalone && !isOtherIosBrowser && !dismissed) {
      pwa.iosHint = true;
      renderPwa();
    }
  })();

  /* ---------- Touch: edge-swipe the drawer + focus trap + ESC/backdrop close ---------- */
  var sidebarEl = document.getElementById('mainSidebar');
  var menuBtn = document.getElementById('menuToggle');
  var backdrop = document.getElementById('sidebarBackdrop');
  var lastFocused = null;

  function setDrawer(open) {
    if (!sidebarEl || !menuBtn || !backdrop) return;
    var wasOpen = sidebarEl.classList.contains('open');
    sidebarEl.classList.toggle('open', open);
    backdrop.classList.toggle('visible', open);
    menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    backdrop.setAttribute('aria-hidden', open ? 'false' : 'true');

    if (open && !wasOpen) {
      lastFocused = document.activeElement;
      document.body.style.overflow = 'hidden';
      // Focus first focusable element in sidebar
      var firstFocusable = sidebarEl.querySelector('a, button, input, [tabindex]:not([tabindex="-1"])');
      if (firstFocusable) firstFocusable.focus();
      // Trap focus
      document.addEventListener('keydown', trapFocus);
      document.addEventListener('keydown', escClose);
    } else if (!open && wasOpen) {
      document.body.style.overflow = '';
      document.removeEventListener('keydown', trapFocus);
      document.removeEventListener('keydown', escClose);
      if (lastFocused && typeof lastFocused.focus === 'function') {
        try { lastFocused.focus(); } catch (e) {}
      }
    }
  }

  function trapFocus(e) {
    if (e.key !== 'Tab') return;
    var focusable = sidebarEl.querySelectorAll('a, button, input, [tabindex]:not([tabindex="-1"])');
    if (!focusable.length) return;
    var first = focusable[0];
    var last = focusable[focusable.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault(); last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault(); first.focus();
    }
  }

  function escClose(e) {
    if (e.key === 'Escape' && sidebarEl.classList.contains('open')) {
      setDrawer(false);
    }
  }

  if (sidebarEl && menuBtn && backdrop) {
    // Click backdrop to close
    backdrop.addEventListener('click', function () { setDrawer(false); });

    // Menu button click
    menuBtn.addEventListener('click', function () {
      setDrawer(!sidebarEl.classList.contains('open'));
    });

    // Edge swipe
    var st = { x: 0, y: 0, edge: false, open: false, active: false };
    document.addEventListener('touchstart', function (e) {
      if (e.touches.length !== 1) { st.active = false; return; }
      var t = e.touches[0];
      st.open = sidebarEl.classList.contains('open');
      st.edge = !st.open && t.clientX <= 26;
      st.x = t.clientX; st.y = t.clientY; st.active = st.edge || st.open;
    }, { passive: true });
    document.addEventListener('touchend', function (e) {
      if (!st.active) return;
      var t = e.changedTouches[0];
      var dx = t.clientX - st.x;
      var dy = Math.abs(t.clientY - st.y);
      st.active = false;
      if (dy > 55) return;
      if (st.edge && dx > 60) setDrawer(true);
      else if (st.open && dx < -60) setDrawer(false);
    }, { passive: true });
  }

  /* ---------- Touch: swipe toasts away ---------- */
  document.querySelectorAll('#toasts [data-toast]').forEach(function (t) {
    var sx = 0, dx = 0, down = false;
    t.addEventListener('touchstart', function (e) { down = true; sx = e.touches[0].clientX; dx = 0; t.classList.add('swiping'); }, { passive: true });
    t.addEventListener('touchmove', function (e) {
      if (!down) return;
      dx = e.touches[0].clientX - sx;
      if (!reduce) t.style.transform = 'translateX(' + dx + 'px)';
    }, { passive: true });
    t.addEventListener('touchend', function () {
      down = false;
      t.classList.remove('swiping');
      if (Math.abs(dx) > 70) {
        t.style.transform = '';
        t.classList.add('out');
        setTimeout(function () { t.remove(); }, 320);
      } else { t.style.transform = ''; }
    }, { passive: true });
  });

  /* ---------- Native gestures: pull-to-refresh, swipe-back, long-press ---------- */
  (function () {
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var isMobile = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
    if (!isMobile || reduce) return;

    // Pull-to-refresh
    var ptr = { startY: 0, currentY: 0, dragging: false, threshold: 80 };
    var ptrIndicator = document.createElement('div');
    ptrIndicator.className = 'ptr-indicator';
    ptrIndicator.innerHTML = '<span class="ptr-icon" aria-hidden="true">&#8595;</span><span class="ptr-text">Pull to refresh</span>';
    ptrIndicator.style.cssText = 'position:fixed;top:-60px;left:50%;transform:translateX(-50%);width:200px;height:60px;display:flex;align-items:center;justify-content:center;gap:8px;background:var(--panel);border:1px solid var(--line);border-radius:0 0 8px 8px;color:var(--text);font-size:0.8rem;z-index:1000;transition:top 0.2s;pointer-events:none';
    document.body.appendChild(ptrIndicator);

    document.addEventListener('touchstart', function (e) {
      if (window.scrollY === 0 && e.touches.length === 1) {
        ptr.startY = e.touches[0].clientY;
        ptr.dragging = true;
      }
    }, { passive: true });

    document.addEventListener('touchmove', function (e) {
      if (!ptr.dragging) return;
      ptr.currentY = e.touches[0].clientY;
      var dy = ptr.currentY - ptr.startY;
      if (dy > 0) {
        e.preventDefault();
        var progress = Math.min(1, dy / ptr.threshold);
        ptrIndicator.style.top = (dy * 0.5) + 'px';
        ptrIndicator.querySelector('.ptr-text').textContent = progress >= 1 ? 'Release to refresh' : 'Pull to refresh';
        ptrIndicator.querySelector('.ptr-icon').style.transform = 'rotate(' + (progress * 180) + 'deg)';
      } else {
        ptr.dragging = false;
      }
    }, { passive: false });

    document.addEventListener('touchend', function () {
      if (!ptr.dragging) return;
      var dy = ptr.currentY - ptr.startY;
      if (dy >= ptr.threshold) {
        ptrIndicator.querySelector('.ptr-text').textContent = 'Refreshing...';
        ptrIndicator.querySelector('.ptr-icon').style.transform = 'rotate(360deg)';
        ptrIndicator.style.top = '0';
        location.reload();
      } else {
        ptrIndicator.style.top = '-60px';
        ptr.dragging = false;
      }
    }, { passive: true });
  })();

  // Swipe-back navigation (left-to-right edge swipe)
  (function () {
    var sb = { startX: 0, dragging: false, threshold: 100 };
    document.addEventListener('touchstart', function (e) {
      if (e.touches.length === 1 && e.touches[0].clientX <= 24 && window.scrollY === 0) {
        sb.startX = e.touches[0].clientX;
        sb.dragging = true;
      }
    }, { passive: true });

    document.addEventListener('touchmove', function (e) {
      if (!sb.dragging) return;
      var dx = e.touches[0].clientX - sb.startX;
      if (dx > 0) {
        e.preventDefault();
        document.body.style.transform = 'translateX(' + Math.min(dx, 120) + 'px)';
        document.body.style.transition = 'none';
      } else {
        sb.dragging = false;
      }
    }, { passive: false });

    document.addEventListener('touchend', function () {
      if (!sb.dragging) return;
      var dx = (event.changedTouches ? event.changedTouches[0].clientX : sb.startX) - sb.startX;
      document.body.style.transition = 'transform 0.2s ease';
      if (dx >= sb.threshold && document.referrer) {
        history.back();
      } else {
        document.body.style.transform = '';
      }
      sb.dragging = false;
    }, { passive: true });
  })();

  // Long-press context menu (for desktop too via right-click)
  (function () {
    var lp = { timer: null, element: null };
    document.addEventListener('touchstart', function (e) {
      var target = e.target.closest('[data-longpress]');
      if (!target) return;
      lp.element = target;
      lp.timer = setTimeout(function () {
        var menu = document.createElement('div');
        menu.className = 'context-menu';
        menu.innerHTML = (target.dataset.longpressMenu || '').split('|').map(function (item) {
          var parts = item.split(':');
          return '<button type="button" data-action="' + parts[0] + '">' + parts[1] + '</button>';
        }).join('');
        menu.style.cssText = 'position:fixed;top:' + (event.touches[0].clientY) + 'px;left:' + (event.touches[0].clientX) + 'px;background:var(--panel);border:1px solid var(--line);border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.5);z-index:1001;min-width:160px';
        document.body.appendChild(menu);
        menu.querySelectorAll('button').forEach(function (btn) {
          btn.addEventListener('click', function () {
            var event = new CustomEvent('longpress-action', { detail: { action: btn.dataset.action, element: lp.element } });
            lp.element.dispatchEvent(event);
            menu.remove();
          });
        });
        document.addEventListener('click', function close() { menu.remove(); document.removeEventListener('click', close); }, { once: true });
      }, 600);
    }, { passive: true });

    document.addEventListener('touchend', function () { clearTimeout(lp.timer); });
    document.addEventListener('touchmove', function () { clearTimeout(lp.timer); });
  })();

  /* ---------- Keyboard Shortcuts Modal ---------- */
  (function () {
    var modal = document.createElement('div');
    modal.id = 'kb-shortcuts';
    modal.style.cssText = 'display:none;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:24px;max-width:500px;width:90%;z-index:1000;box-shadow:0 20px 60px rgba(0,0,0,.5)';
    modal.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px"><h3 style="margin:0">Keyboard Shortcuts</h3><button class="modal-close" style="background:none;border:none;color:var(--muted);font-size:1.5rem;cursor:pointer" aria-label="Close">&times;</button></div><div class="shortcuts-list" style="display:grid;grid-template-columns:auto auto 1fr;gap:8px 16px;font-size:.85rem"></div>';
    document.body.appendChild(modal);

    var shortcuts = [
      ['G', 'D', 'Go to Dashboard (index.php)'],
      ['G', 'M', 'Go to Missions (missions.php)'],
      ['G', 'K', 'Go to Kill (kill.php)'],
      ['G', 'C', 'Go to Casino (casino.php)'],
      ['G', 'B', 'Go to Bank (bank.php)'],
      ['G', 'P', 'Go to Profile (profile.php)'],
      ['G', 'S', 'Go to Settings'],
      ['/', '—', 'Focus Search'],
      ['?', '—', 'Show This Help'],
      ['Esc', '—', 'Close Modal / Close Drawer'],
      ['Alt', 'N', 'New Message (Crew Chat)'],
      ['Ctrl', 'Enter', 'Submit Form'],
    ];

    var list = modal.querySelector('.shortcuts-list');
    shortcuts.forEach(function (s) {
      var k1 = document.createElement('kbd');
      k1.textContent = s[0];
      k1.style.cssText = 'background:var(--bg);border:1px solid var(--line);border-radius:3px;padding:2px 6px;font-family:monospace;font-size:.75rem';
      var k2 = document.createElement('kbd');
      k2.textContent = s[1];
      k2.style.cssText = 'background:var(--bg);border:1px solid var(--line);border-radius:3px;padding:2px 6px;font-family:monospace;font-size:.75rem';
      var desc = document.createElement('span');
      desc.textContent = s[2];
      desc.style.cssText = 'color:var(--text)';
      var plus = document.createElement('span');
      plus.textContent = '+';
      plus.style.cssText = 'color:var(--muted)';
      if (s[1] === '—') { k2.style.display = 'none'; plus.style.display = 'none'; }
      list.appendChild(k1); list.appendChild(plus); list.appendChild(k2); list.appendChild(desc);
    });

    modal.querySelector('.modal-close').addEventListener('click', function () { modal.style.display = 'none'; });
    modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });

    // Show on ? key (not in input/textarea)
    document.addEventListener('keydown', function (e) {
      if (e.key === '?' && !['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)) {
        e.preventDefault();
        modal.style.display = 'block';
      }
      if (e.key === 'Escape') { modal.style.display = 'none'; }
    });

    // Global G-key navigation
    var gKeyTimer = null;
    document.addEventListener('keydown', function (e) {
      if (['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)) return;
      if (e.key.toLowerCase() === 'g') {
        if (!gKeyTimer) {
          gKeyTimer = setTimeout(function () { gKeyTimer = null; }, 1000);
        } else {
          clearTimeout(gKeyTimer);
          gKeyTimer = null;
          return;
        }
      }
      if (gKeyTimer && e.key.length === 1) {
        var dest = {
          'd': 'index.php', 'm': 'missions.php', 'k': 'kill.php',
          'c': 'casino.php', 'b': 'bank.php', 'p': 'profile.php',
          's': 'settings.php', 'e': 'events.php', 't': 'tournaments.php',
          'r': 'racing.php', 'h': 'heists.php', 'w': 'crew_wars.php',
          'o': 'properties.php', 'i': 'items.php', 'a': 'abilities.php',
          'g': 'gym.php', 'j': 'jobs.php', 'l': 'leaderboards.php'
        }[e.key.toLowerCase()];
        if (dest) { e.preventDefault(); location.href = dest; }
        clearTimeout(gKeyTimer);
        gKeyTimer = null;
      }
    });
  })();

  renderPwa();
})();

