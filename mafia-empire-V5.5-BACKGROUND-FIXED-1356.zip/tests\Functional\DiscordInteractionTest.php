<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Functional;

use MafiaEmpire\Tests\Support\Http;
use MafiaEmpire\Tests\Support\TestCase;

/**
 * The Discord interactions endpoint must fail closed: without a valid Ed25519
 * signature (and without the sodium extension) it never processes a command.
 */
final class DiscordInteractionTest extends TestCase
{
    private function http(): Http
    {
        if (!Http::configured()) {
            $this->markTestSkipped('Set APP_URL to a running instance to run the functional suite.');
        }
        return new Http(Http::baseUrl());
    }

    public function testUnsignedInteractionIsRejected(): void
    {
        $http = $this->http();
        [$status] = $http->post('discord/interactions.php', []);
        // 401 = signature rejected; 503 = sodium/config unavailable (fail closed).
        $this->assertContains($status, [401, 503], 'unsigned interactions must never be processed');
    }

    public function testNonPostIsMethodNotAllowed(): void
    {
        $http = $this->http();
        [$status] = $http->get('discord/interactions.php');
        $this->assertSame(405, $status);
    }
}
