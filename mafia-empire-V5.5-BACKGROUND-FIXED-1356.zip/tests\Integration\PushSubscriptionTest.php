<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * Web Push subscription storage, the notification bridge and the cron outbox
 * flush. Endpoints target an unbound local port so no external network runs.
 */
final class PushSubscriptionTest extends TestCase
{
    private const DEAD = 'http://127.0.0.1:9/push/dead';

    protected function tearDown(): void
    {
        unset($GLOBALS['__push_keys_override']);
        parent::tearDown();
    }

    /** Inject a throwaway VAPID key pair so push is "configured". */
    private function withKeys(): void
    {
        $GLOBALS['__push_keys_override'] = push_generate_keys() + ['subject' => 'mailto:tests@mafia-empire.test'];
    }

    /** Register a device with a genuine (encryptable) P-256 client key. */
    private function sub(int $uid, string $endpoint = self::DEAD): void
    {
        $ua = push_ec_key_new();
        $det = openssl_pkey_get_details($ua);
        push_subscribe(
            $uid,
            $endpoint,
            push_b64url_encode(push_ec_point($det['ec'])),
            push_b64url_encode(random_bytes(16)),
            'test-agent'
        );
    }

    public function testSubscribeRejectsEmptyFields(): void
    {
        $u = $this->makeUser();
        $this->assertFalse(push_subscribe((int) $u['id'], '', 'a', 'b'));
        $this->assertSame(0, push_subscription_count((int) $u['id']));
    }

    public function testSubscribeIsIdempotentPerEndpoint(): void
    {
        $u = $this->makeUser();
        $uid = (int) $u['id'];
        $p256 = push_b64url_encode(push_ec_point(openssl_pkey_get_details(push_ec_key_new())['ec']));
        $auth = push_b64url_encode(random_bytes(16));

        $this->assertTrue(push_subscribe($uid, self::DEAD, $p256, $auth, 'ua1'));
        $this->assertTrue(push_subscribe($uid, self::DEAD, $p256, $auth, 'ua2'));

        $this->assertSame(1, push_subscription_count($uid));
        $row = fetch('SELECT * FROM push_subscriptions WHERE user_id = ?', [$uid]);
        $this->assertSame('ua2', $row['user_agent']);
    }

    public function testUnsubscribeRemovesOnlyThatEndpoint(): void
    {
        $u = $this->makeUser();
        $uid = (int) $u['id'];
        $this->sub($uid, self::DEAD);
        $this->sub($uid, 'http://127.0.0.1:9/other');
        $this->assertSame(2, push_subscription_count($uid));

        push_unsubscribe($uid, self::DEAD);

        $this->assertSame(1, push_subscription_count($uid));
        $this->assertNull(fetch('SELECT * FROM push_subscriptions WHERE endpoint_hash = ?', [hash('sha256', self::DEAD)]));
    }

    public function testSendUserNeedsKeys(): void
    {
        $u = $this->makeUser();
        $this->sub((int) $u['id']);
        $this->assertSame(0, push_send_user((int) $u['id'], 'Title', 'Body'));
    }

    public function testPushNotifyQueuesOnlyForSubscribedUsers(): void
    {
        $this->withKeys();
        $subscribed = $this->makeUser();
        $plain = $this->makeUser();
        $this->sub((int) $subscribed['id']);

        push_notify((int) $subscribed['id'], 'You have been hospitalized', 'health.php');
        push_notify((int) $plain['id'], 'No devices here', 'health.php');

        $this->assertSame(1, (int) fetch_one('SELECT COUNT(*) FROM push_outbox', [], 0));
        $row = fetch('SELECT * FROM push_outbox');
        $this->assertSame((int) $subscribed['id'], (int) $row['user_id']);
        $this->assertStringContainsString('hospitalized', (string) $row['body']);
    }

    public function testTaskPushFlushesOutboxAndCountsFailures(): void
    {
        $this->withKeys();
        $u = $this->makeUser();
        $uid = (int) $u['id'];
        $this->sub($uid);
        insert('push_outbox', ['user_id' => $uid, 'title' => 'T', 'body' => 'B', 'url' => '', 'created_at' => now()]);

        $summary = task_push();
        $this->assertSame(1, $summary['queued']);
        $this->assertSame(0, $summary['sent']); // dead endpoint
        $this->assertSame(0, (int) fetch_one('SELECT COUNT(*) FROM push_outbox', [], 0));

        $row = fetch('SELECT * FROM push_subscriptions WHERE user_id = ?', [$uid]);
        $this->assertSame(1, (int) $row['fail_count']);
    }

    public function testTaskPushPrunesRepeatedlyFailingEndpoints(): void
    {
        $this->withKeys();
        $u = $this->makeUser();
        $uid = (int) $u['id'];
        $this->sub($uid);
        update_row('push_subscriptions', ['fail_count' => 10], 'user_id = ?', [$uid]);

        task_push();

        $this->assertSame(0, push_subscription_count($uid));
    }

    public function testTaskPushIsNoopWithoutKeys(): void
    {
        $u = $this->makeUser();
        $uid = (int) $u['id'];
        $this->sub($uid);
        insert('push_outbox', ['user_id' => $uid, 'title' => 'T', 'body' => 'B', 'url' => '', 'created_at' => now()]);

        $summary = task_push();
        $this->assertSame(0, $summary['sent']);
        $this->assertSame('push-not-configured', $summary['reason']);
        $this->assertSame(1, (int) fetch_one('SELECT COUNT(*) FROM push_outbox', [], 0));
    }
}
