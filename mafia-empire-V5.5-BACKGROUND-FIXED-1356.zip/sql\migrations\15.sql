-- Migration 15: Advanced Systems + More Content + Infrastructure
-- Idempotent: CREATE TABLE IF NOT EXISTS, safe to re-run.

-- ============================================================
-- NEW TABLES: Admin Tools & Moderation
-- ============================================================
CREATE TABLE IF NOT EXISTS admin_reports (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    reporter_id INT UNSIGNED NOT NULL,
    target_user_id INT UNSIGNED NOT NULL,
    reason VARCHAR(100) NOT NULL,
    details TEXT,
    status ENUM('pending','investigating','resolved','dismissed') NOT NULL DEFAULT 'pending',
    assigned_admin_id INT UNSIGNED NULL,
    resolved_by INT UNSIGNED NULL,
    resolved_at DATETIME NULL,
    resolution TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_reporter (reporter_id),
    KEY idx_target (target_user_id),
    KEY idx_status (status),
    KEY idx_assigned (assigned_admin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admin_bans (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    admin_id INT UNSIGNED NOT NULL,
    reason VARCHAR(255) NOT NULL,
    type ENUM('temporary','permanent','shadow') NOT NULL DEFAULT 'temporary',
    expires_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    lifted_at DATETIME NULL,
    lifted_by INT UNSIGNED NULL,
    PRIMARY KEY (id),
    KEY idx_user (user_id),
    KEY idx_admin (admin_id),
    KEY idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admin_ip_bans (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ip_address VARCHAR(45) NOT NULL,
    admin_id INT UNSIGNED NOT NULL,
    reason VARCHAR(255) NOT NULL,
    expires_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_ip (ip_address),
    KEY idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- NEW TABLES: Backup/Restore Tracking
-- ============================================================
CREATE TABLE IF NOT EXISTS backup_jobs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    type ENUM('full','incremental','schema_only') NOT NULL DEFAULT 'full',
    status ENUM('pending','running','completed','failed') NOT NULL DEFAULT 'pending',
    file_path VARCHAR(500) NULL,
    file_size BIGINT UNSIGNED NULL,
    tables_count INT UNSIGNED NULL,
    rows_count BIGINT UNSIGNED NULL,
    duration_ms INT UNSIGNED NULL,
    error_message TEXT NULL,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_status (status),
    KEY idx_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- NEW TABLES: Webhook Retry Queue (if not exists)
-- ============================================================
CREATE TABLE IF NOT EXISTS webhook_queue (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    webhook_id INT UNSIGNED NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    payload JSON NOT NULL,
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    max_attempts INT UNSIGNED NOT NULL DEFAULT 5,
    next_retry_at DATETIME NOT NULL,
    last_error TEXT NULL,
    status ENUM('pending','processing','completed','failed','dead') NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processed_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_status_next (status, next_retry_at),
    KEY idx_webhook (webhook_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- CONTENT EXPANSION: More Casino Games
-- ============================================================
INSERT INTO items (name, description, type, attack, defense, cost, min_level, rarity) VALUES
('Poker Chip Set', 'Professional clay composites.', 'misc', 0, 0, 5000, 10, 'uncommon'),
('Loaded Dice', 'Weighted for the house.', 'misc', 0, 0, 10000, 15, 'rare'),
('Card Shark Sunglasses', 'Hide your tells.', 'armor', 0, 3, 25000, 20, 'rare'),
('High Roller Cigar', 'Smoke in style.', 'consumable', 0, 0, 5000, 10, 'common'),
('VIP Casino Pass', 'Skip the line.', 'misc', 0, 0, 100000, 30, 'epic')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- CONTENT EXPANSION: More Achievements
-- ============================================================
INSERT INTO achievements (code, name, description, reward_points, target, metric) VALUES
('level_200', 'Double Centurion', 'Reach level 200.', 1000, 200, 'level'),
('level_500', 'Immortal', 'Reach level 500.', 5000, 500, 'level'),
('kills_10000', 'Genocide', 'Kill 10,000 players.', 5000, 10000, 'kills'),
('mission_10000', 'Mission Impossible', 'Complete 10,000 missions.', 10000, 10000, 'missions_done'),
('heist_5000', 'Heist God', 'Complete 5,000 heists.', 5000, 5000, 'heists_done'),
('race_1000', 'Speed Demon', 'Win 1,000 races.', 2000, 1000, 'race_wins'),
('market_10000', 'Market Emperor', 'Sell 10,000 items on market.', 5000, 10000, 'market_sales'),
('mayor_10', 'Career Politician', 'Win 10 mayoral elections.', 2000, 10, 'mayor_wins'),
('policy_100', 'Legislative Legend', 'Enact 100 city policies.', 5000, 100, 'policies_enacted'),
('property_20', 'Real Estate Tycoon', 'Own 20 properties.', 5000, 20, 'properties_owned'),
('crafting_1000', 'Master Artisan', 'Craft 1,000 items.', 2000, 1000, 'items_crafted'),
('drug_lord', 'Drug Lord', 'Sell 10,000 drugs.', 2000, 10000, 'drugs_sold'),
('armory_master', 'Armory Master', 'Own 50 different weapons.', 1000, 50, 'unique_weapons_owned'),
('collection_complete', 'Completionist', 'Unlock all achievements.', 10000, 1, 'all_achievements')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- CONTENT EXPANSION: More Stickers
-- ============================================================
INSERT INTO stickers (code, name, rarity) VALUES
('quantum_coin', 'Quantum Coin', 'legendary'),
('void_crystal', 'Void Crystal', 'legendary'),
('singularity_core', 'Singularity Core', 'legendary'),
('neutron_star', 'Neutron Star', 'epic'),
('black_hole', 'Black Hole', 'epic'),
('white_dwarf', 'White Dwarf', 'rare'),
('red_giant', 'Red Giant', 'rare'),
('pulsar', 'Pulsar', 'rare'),
('quasar', 'Quasar', 'epic'),
('dark_matter', 'Dark Matter', 'legendary'),
('antimatter', 'Antimatter', 'legendary'),
('cosmic_dust', 'Cosmic Dust', 'common'),
('stardust', 'Stardust', 'common'),
('nebula_gas', 'Nebula Gas', 'common'),
('solar_flare', 'Solar Flare', 'uncommon'),
('comet_tail', 'Comet Tail', 'uncommon')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- NEW TABLES: Referral Program Enhancements
-- ============================================================
CREATE TABLE IF NOT EXISTS referral_milestones (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    referrals_required INT UNSIGNED NOT NULL,
    reward_type ENUM('points','money','item','ability') NOT NULL,
    reward_value INT UNSIGNED NOT NULL,
    reward_item_id INT UNSIGNED NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_referrals (referrals_required)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO referral_milestones (referrals_required, reward_type, reward_value, name, description) VALUES
(1, 'points', 100, 'First Recruit', 'Refer your first friend.'),
(5, 'money', 50000, 'Recruiter', 'Refer 5 friends.'),
(10, 'points', 1000, 'Team Builder', 'Refer 10 friends.'),
(25, 'item', 0, 'Recruitment Officer', 'Refer 25 friends.', 6),
(50, 'money', 500000, 'Recruitment General', 'Refer 50 friends.'),
(100, 'ability', 0, 'Recruitment Warlord', 'Refer 100 friends.', 0, 19)
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ============================================================
-- CONTENT EXPANSION: Seasonal Events (Additional)
-- ============================================================
INSERT INTO event_challenges (event_id, code, name, description, target_value, metric, reward_xp, reward_money, reward_points, sort_order) 
SELECT e.id, 'kills_10', 'Kill 10 Players', 'Eliminate 10 rivals.', 10, 'kills', 5000, 50000, 50, 1
FROM events e WHERE e.code = 'halloween' AND NOT EXISTS (SELECT 1 FROM event_challenges WHERE event_id = e.id AND code = 'kills_10')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Additional seasonal challenge for Christmas
INSERT INTO event_challenges (event_id, code, name, description, target_value, metric, reward_xp, reward_money, reward_points, sort_order)
SELECT e.id, 'missions_20', 'Complete 20 Missions', 'Finish 20 missions during the event.', 20, 'missions_done', 15000, 200000, 150, 1
FROM events e WHERE e.code = 'christmas' AND NOT EXISTS (SELECT 1 FROM event_challenges WHERE event_id = e.id AND code = 'missions_20')
ON DUPLICATE KEY UPDATE name=VALUES(name);