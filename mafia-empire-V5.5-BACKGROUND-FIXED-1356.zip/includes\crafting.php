<?php
/**
 * Eye Of The Mafia - Crafting System
 * Combine items/drugs at the Workbench to create upgraded gear.
 */

require_once __DIR__ . '/init.php';

/**
 * Get all crafting recipes (optionally filtered by category).
 */
function crafting_get_recipes(?string $category = null, int $userId = 0): array
{
    $sql = "SELECT * FROM crafting_recipes WHERE 1=1";
    $params = [];
    if ($category) {
        $sql .= " AND category = ?";
        $params[] = $category;
    }
    $sql .= " ORDER BY category, min_level, name";
    return fetch_all($sql, $params);
}

/**
 * Get recipes the user has discovered (or all if discoverable).
 */
function crafting_get_available_recipes(int $userId, ?string $category = null): array
{
    $recipes = crafting_get_recipes($category, $userId);
    if (!$userId) return array_filter($recipes, fn($r) => $r['is_discoverable']);
    
    $known = fetch_all(
        "SELECT recipe_id FROM user_crafting_recipes WHERE user_id = ?",
        [$userId]
    );
    $knownIds = array_column($known, 'recipe_id');
    
    return array_filter($recipes, function ($r) use ($knownIds) {
        return (bool) $r['is_discoverable'] || in_array((int) $r['id'], $knownIds, true);
    });
}

/**
 * Check if user can craft a recipe (level, discovered, ingredients).
 */
function crafting_can_craft(int $userId, int $recipeId): array
{
    $recipe = fetch('SELECT * FROM crafting_recipes WHERE id = ?', [$recipeId]);
    if (!$recipe) return ['ok' => false, 'error' => 'Recipe not found'];
    
    $user = fetch('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$user) return ['ok' => false, 'error' => 'User not found'];
    
    // Level check
    if ((int) $user['level'] < (int) $recipe['min_level']) {
        return ['ok' => false, 'error' => "Level {$recipe['min_level']} required"];
    }
    
    // Discovery check
    if (!(bool) $recipe['is_discoverable']) {
        $known = fetch_one(
            'SELECT 1 FROM user_crafting_recipes WHERE user_id = ? AND recipe_id = ?',
            [$userId, $recipeId]
        );
        if (!$known) return ['ok' => false, 'error' => 'Recipe not discovered'];
    }
    
    // Energy check
    if ((int) $user['energy'] < (int) $recipe['energy_cost']) {
        return ['ok' => false, 'error' => 'Not enough energy'];
    }
    
    // Money check
    if ((int) $user['money'] < (int) $recipe['money_cost']) {
        return ['ok' => false, 'error' => 'Not enough cash'];
    }
    
    // Ingredients check
    $ingredients = json_decode($recipe['ingredients'], true);
    foreach ($ingredients as $ing) {
        if ($ing['type'] === 'item') {
            $have = fetch_one(
                'SELECT COALESCE(SUM(qty),0) FROM user_items WHERE user_id = ? AND item_id = ?',
                [$userId, (int) $ing['id']]
            );
            if ($have < (int) $ing['qty']) {
                $item = fetch('SELECT name FROM items WHERE id = ?', [(int) $ing['id']]);
                return ['ok' => false, 'error' => "Need {$ing['qty']}x {$item['name']} (have $have)"];
            }
        } elseif ($ing['type'] === 'drug') {
            $have = fetch_one(
                'SELECT COALESCE(SUM(qty),0) FROM user_drugs WHERE user_id = ? AND drug_id = ?',
                [$userId, (int) $ing['id']]
            );
            if ($have < (int) $ing['qty']) {
                $drug = fetch('SELECT name FROM drugs WHERE id = ?', [(int) $ing['id']]);
                return ['ok' => false, 'error' => "Need {$ing['qty']}x {$drug['name']} (have $have)"];
            }
        }
    }
    
    return ['ok' => true, 'recipe' => $recipe, 'ingredients' => $ingredients];
}

/**
 * Attempt to craft a recipe.
 * Returns ['ok' => true, 'output' => [...]] or ['ok' => false, 'error' => '...']
 */
function crafting_craft(int $userId, int $recipeId): array
{
    $check = crafting_can_craft($userId, $recipeId);
    if (!$check['ok']) return $check;
    
    $recipe = $check['recipe'];
    $ingredients = $check['ingredients'];
    $user = fetch('SELECT * FROM users WHERE id = ?', [$userId]);
    
    // Spend resources
    q('UPDATE users SET energy = energy - ?, money = money - ? WHERE id = ?',
        [(int) $recipe['energy_cost'], (int) $recipe['money_cost'], $userId]);
    
    // Consume ingredients
    foreach ($ingredients as $ing) {
        if ($ing['type'] === 'item') {
            $need = (int) $ing['qty'];
            $rows = fetch_all(
                'SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ? ORDER BY id',
                [$userId, (int) $ing['id']]
            );
            foreach ($rows as $row) {
                $take = min($need, (int) $row['qty']);
                q('UPDATE user_items SET qty = qty - ? WHERE id = ?', [$take, (int) $row['id']]);
                if (($row['qty'] - $take) <= 0) {
                    q('DELETE FROM user_items WHERE id = ?', [(int) $row['id']]);
                }
                $need -= $take;
                if ($need <= 0) break;
            }
        } elseif ($ing['type'] === 'drug') {
            $need = (int) $ing['qty'];
            $rows = fetch_all(
                'SELECT drug_id, qty FROM user_drugs WHERE user_id = ? AND drug_id = ?',
                [$userId, (int) $ing['id']]
            );
            foreach ($rows as $row) {
                $take = min($need, (int) $row['qty']);
                q('UPDATE user_drugs SET qty = qty - ? WHERE user_id = ? AND drug_id = ?', [$take, $userId, (int) $row['drug_id']]);
                if (($row['qty'] - $take) <= 0) {
                    q('DELETE FROM user_drugs WHERE user_id = ? AND drug_id = ?', [$userId, (int) $row['drug_id']]);
                }
                $need -= $take;
                if ($need <= 0) break;
            }
        }
    }
    
    // Determine success
    $chance = (int) $recipe['success_chance'];
    $success = mt_rand(1, 100) <= $chance;
    
    $output = [];
    $ingredientsLost = false;
    
    if ($success) {
        // Grant output
        if ($recipe['output_item_id']) {
            $existing = fetch(
                'SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?',
                [$userId, (int) $recipe['output_item_id']]
            );
            if ($existing) {
                q('UPDATE user_items SET qty = qty + ? WHERE id = ?',
                    [(int) $recipe['output_qty'], (int) $existing['id']]);
            } else {
                insert('user_items', [
                    'user_id' => $userId,
                    'item_id' => (int) $recipe['output_item_id'],
                    'qty' => (int) $recipe['output_qty'],
                    'equipped' => 0,
                ]);
            }
            $item = fetch('SELECT name FROM items WHERE id = ?', [(int) $recipe['output_item_id']]);
            $output[] = $recipe['output_qty'] . 'x ' . $item['name'];
            
            // Apply custom stats if provided
            if ($recipe['result_attack'] > 0 || $recipe['result_defense'] > 0) {
                // Note: These are base stats; the item's base stats still apply
            }
        }
        
        // Handle drug output (custom drugs not in DB yet)
        if ($recipe['output_drug_id']) {
            $existing = fetch(
                'SELECT drug_id, qty FROM user_drugs WHERE user_id = ? AND drug_id = ?',
                [$userId, (int) $recipe['output_drug_id']]
            );
            if ($existing) {
                q('UPDATE user_drugs SET qty = qty + ? WHERE user_id = ? AND drug_id = ?',
                    [(int) $recipe['output_qty'], $userId, (int) $existing['drug_id']]);
            } else {
                insert('user_drugs', [
                    'user_id' => $userId,
                    'drug_id' => (int) $recipe['output_drug_id'],
                    'qty' => (int) $recipe['output_qty'],
                ]);
            }
            $drug = fetch('SELECT name FROM drugs WHERE id = ?', [(int) $recipe['output_drug_id']]);
            $output[] = $recipe['output_qty'] . 'x ' . $drug['name'];
        }
        
        // Grant XP for successful craft
        $xpGain = 10 + (int) $recipe['min_level'] * 2;
        grant_xp($userId, $xpGain);
        $output[] = number_format($xpGain) . ' XP';
        
        analytics_track('craft_success', $userId, [
            'recipe_id' => $recipeId,
            'recipe_code' => $recipe['code'],
        ]);
    } else {
        // Failure
        if ((bool) $recipe['fail_lose_ingredients']) {
            $ingredientsLost = true;
        }
        analytics_track('craft_fail', $userId, [
            'recipe_id' => $recipeId,
            'recipe_code' => $recipe['code'],
        ]);
    }
    
    // Log the attempt
    insert('crafting_log', [
        'user_id' => $userId,
        'recipe_id' => $recipeId,
        'success' => $success ? 1 : 0,
        'ingredients_lost' => $ingredientsLost ? 1 : 0,
    ]);
    
    if ($success) {
        return [
            'ok' => true,
            'output' => $output,
            'message' => 'Crafting successful! Created: ' . implode(', ', $output),
        ];
    } else {
        $msg = 'Crafting failed.';
        if ($ingredientsLost) $msg .= ' Ingredients lost.';
        return ['ok' => false, 'error' => $msg, 'ingredients_lost' => $ingredientsLost];
    }
}

/**
 * Discover a recipe (from blueprint item or event).
 */
function crafting_discover(int $userId, int $recipeId): array
{
    $recipe = fetch('SELECT * FROM crafting_recipes WHERE id = ?', [$recipeId]);
    if (!$recipe) return ['ok' => false, 'error' => 'Recipe not found'];
    
    $exists = fetch_one(
        'SELECT 1 FROM user_crafting_recipes WHERE user_id = ? AND recipe_id = ?',
        [$userId, $recipeId]
    );
    if ($exists) return ['ok' => false, 'error' => 'Already known'];
    
    insert('user_crafting_recipes', ['user_id' => $userId, 'recipe_id' => $recipeId]);
    
    return ['ok' => true, 'recipe' => $recipe['name']];
}

/**
 * Use a blueprint item to learn a recipe.
 */
function crafting_use_blueprint(int $userId, int $blueprintItemId): array
{
    $recipe = fetch('SELECT * FROM crafting_recipes WHERE blueprint_item_id = ?', [$blueprintItemId]);
    if (!$recipe) return ['ok' => false, 'error' => 'No recipe for this blueprint'];
    
    return crafting_discover($userId, (int) $recipe['id']);
}

/**
 * Get user's known recipes.
 */
function crafting_get_known(int $userId): array
{
    return fetch_all("
        SELECT cr.* FROM crafting_recipes cr
        JOIN user_crafting_recipes ucr ON ucr.recipe_id = cr.id
        WHERE ucr.user_id = ?
        ORDER BY cr.category, cr.min_level, cr.name
    ", [$userId]);
}

/**
 * Get crafting history.
 */
function crafting_get_history(int $userId, int $limit = 50): array
{
    return fetch_all("
        SELECT cl.*, cr.name, cr.code
        FROM crafting_log cl
        JOIN crafting_recipes cr ON cr.id = cl.recipe_id
        WHERE cl.user_id = ?
        ORDER BY cl.created_at DESC
        LIMIT ?
    ", [$userId, $limit]);
}

/**
 * Get all recipes for a category (for UI grouping).
 */
function crafting_get_categories(): array
{
    return [
        'weapon' => '⚔️ Weapons',
        'armor' => '🛡️ Armor',
        'vehicle' => '🚗 Vehicles',
        'drug' => '💊 Drugs',
        'consumable' => '📦 Consumables',
        'special' => '✨ Special',
    ];
}