<?php

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/analytics.php';

class AnalyticsHelpersTest extends TestCase
{
    public function testHelpersExist(): void
    {
        $this->assertTrue(function_exists('analytics_track'));
        $this->assertTrue(function_exists('analytics_count_since'));
        $this->assertTrue(function_exists('analytics_unique_users_since'));
        $this->assertTrue(function_exists('analytics_daily'));
        $this->assertTrue(function_exists('analytics_active_users_daily'));
        $this->assertTrue(function_exists('analytics_prune'));
    }

    public function testTrackSwallowsErrors(): void
    {
        // Should not throw (writes to a real table only when DB present; here it
        // may hit a missing table, which analytics_track must tolerate).
        analytics_track('test_event', null, ['foo' => 'bar']);
        $this->assertTrue(true);
    }
}