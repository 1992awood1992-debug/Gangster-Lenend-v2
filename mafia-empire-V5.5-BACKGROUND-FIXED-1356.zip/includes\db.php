<?php
/**
 * Mafia Empire - database layer (PDO / MySQL)
 */
require_once __DIR__ . '/../config.php';

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_PERSISTENT => true,
            ]);
        } catch (PDOException $e) {
            // Database may not exist yet - create it.
            $root = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4', DB_USER, DB_PASS);
            $root->exec('CREATE DATABASE IF NOT EXISTS `' . str_replace('`', '', DB_NAME) . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci');
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_PERSISTENT => true,
            ]);
        }
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

        // Keep MySQL's clock in step with PHP's so SQL NOW() and the app's
        // now() helper never disagree (e.g. across timezone/dst boundaries).
        try {
            $pdo->exec("SET time_zone = '" . (new DateTime('now'))->format('P') . "'");
        } catch (Throwable $e) {
            // Non-fatal: the offset form is unsupported on a few MySQL builds.
        }
    }
    return $pdo;
}

/** Run a prepared query, return the statement. */
function q(string $sql, array $params = []): PDOStatement
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

/** Fetch a single row or null. */
function fetch(string $sql, array $params = []): ?array
{
    $row = q($sql, $params)->fetch();
    return $row === false ? null : $row;
}

/** Fetch all rows. */
function fetch_all(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}

/** Fetch a single column value. */
function fetch_one(string $sql, array $params = [], $default = null)
{
    $v = q($sql, $params)->fetchColumn();
    return $v === false ? $default : $v;
}

/** Insert an associative array, return last insert id. */
function insert(string $table, array $data): int
{
    $cols = implode(',', array_map(fn($c) => "`$c`", array_keys($data)));
    $ph   = implode(',', array_fill(0, count($data), '?'));
    q("INSERT INTO `$table` ($cols) VALUES ($ph)", array_values($data));
    return (int) db()->lastInsertId();
}

/** Update rows by a where clause. */
function update_row(string $table, array $data, string $where, array $params = []): void
{
    $set = implode(',', array_map(fn($c) => "`$c` = ?", array_keys($data)));
    q("UPDATE `$table` SET $set WHERE $where", array_merge(array_values($data), $params));
}

/** Current timestamp string for MySQL. */
function now(): string
{
    return date('Y-m-d H:i:s');
}

/** True if the core tables exist. */
function db_installed(): bool
{
    try {
        return (bool) fetch_one("SHOW TABLES LIKE 'users'");
    } catch (Throwable $e) {
        return false;
    }
}
