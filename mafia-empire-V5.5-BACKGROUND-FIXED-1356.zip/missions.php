<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: run mission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $missionId = (int) ($_POST['mission_id'] ?? 0);
    $m = fetch('SELECT * FROM missions WHERE id = ?', [$missionId]);
    if (!$m) {
        flash('Mission not found.', 'error');
    } elseif ((int) $u['level'] < (int) $m['min_level']) {
        flash('Level ' . (int) $m['min_level'] . ' required.', 'error');
    } elseif ((int) $u['energy'] < (int) $m['energy_cost']) {
        flash('Not enough energy.', 'error');
    } elseif (is_hospitalized($u)) {
        flash('You are hospitalized.', 'error');
    } elseif (action_on_cooldown($u['id'], 'missions')) {
        $cd = action_on_cooldown($u['id'], 'missions');
        flash('Mission on cooldown. Try again in ' . $cd . '.', 'error');
    } else {
        $cost = (int) $m['energy_cost'];
        q('UPDATE users SET energy = energy - ? WHERE id = ?', [$cost, $u['id']]);
        // Success chance: 100 - risk, slightly improved by level/iq
        $baseChance = 100 - (int) $m['risk'];
        $bonus = min(25, (int) floor((int) $u['level'] * 0.3 + (int) $u['iq'] * 0.5));
        $chance = min(95, max(10, $baseChance + $bonus));
        $success = mt_rand(1, 100) <= $chance;
        if ($success) {
            add_money($u['id'], (int) $m['reward_money'], 'Mission: ' . $m['name']);
            grant_xp($u['id'], (int) $m['reward_xp']);
            add_points($u['id'], (int) $m['reward_points']);
            q('UPDATE user_missions SET times_done = times_done + 1, completed = 1 WHERE user_id = ? AND mission_id = ?', [$u['id'], $missionId]);
            q('UPDATE users SET missions_done = missions_done + 1 WHERE id = ?', [$u['id']]);
            analytics_track('mission_complete', $u['id'], ['mission_id' => $missionId, 'reward_money' => (int) $m['reward_money']]);
            if (function_exists('tournament_report_metric')) {
                tournament_report_metric('mission_speedrun', (int) $u['id'], 1, mt_rand(20000, 90000) + $cost * 1000);
            }
            set_action_cooldown($u['id'], 'missions');
            flash('Mission success! Earned ' . money($m['reward_money']) . ', ' . (int) $m['reward_xp'] . ' XP, ' . (int) $m['reward_points'] . ' pts.', 'success');
        } else {
            $hpLoss = mt_rand(5, 15);
            $cashLoss = (int) floor((int) $u['money'] * 0.05);
            q('UPDATE users SET health = GREATEST(health - ?, 0), money = GREATEST(money - ?, 0) WHERE id = ?', [$hpLoss, $cashLoss, $u['id']]);
            analytics_track('mission_fail', $u['id'], ['mission_id' => $missionId]);
            flash('Mission failed. Lost ' . $hpLoss . ' health and ' . money($cashLoss) . '.', 'error');
        }
    }
    event_track('missions_done');
    redirect('missions.php');
}

$page_title = 'Missions';
require __DIR__ . '/includes/header.php';

$districts = fetch_all('SELECT * FROM districts ORDER BY unlock_level');
$allMissions = fetch_all('SELECT * FROM missions ORDER BY district_id, min_level');
$doneCounts = fetch_all('SELECT mission_id, times_done FROM user_missions WHERE user_id = ?', [$u['id']]);
$doneMap = [];
foreach ($doneCounts as $dc) { $doneMap[$dc['mission_id']] = (int) $dc['times_done']; }
?>
<div class="card">
  <div class="panel-heading">Missions</div>
  <p class="muted small">Complete missions to earn cash, XP, and points. Higher risk = higher reward.</p>
  <div class="grid grid-3" style="margin-bottom:14px">
    <div class="stat"><span>Energy</span><b><?= (int) $u['energy'] ?> / <?= (int) $u['energy_max'] ?></b></div>
    <div class="stat"><span>Health</span><b><?= (int) $u['health'] ?> / <?= (int) $u['health_max'] ?></b></div>
    <div class="stat"><span>Missions Done</span><b><?= (int) $u['missions_done'] ?></b></div>
  </div>
</div>

<?php
$byDistrict = [];
foreach ($allMissions as $m) { $byDistrict[$m['district_id']][] = $m; }
foreach ($districts as $d):
    $dMissions = $byDistrict[$d['id']] ?? [];
    if (!$dMissions) continue;
?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading"><?= e($d['name']) ?> <span class="tag tag-common">Lvl <?= (int) $d['unlock_level'] ?>+</span></div>
  <?php if ((int) $u['level'] < (int) $d['unlock_level']): ?>
    <p class="muted">Unlocks at level <?= (int) $d['unlock_level'] ?>.</p>
  <?php else: ?>
    <div class="table-wrap" style="overflow-x:auto"><table>
      <tr><th>Mission</th><th>Energy</th><th>Min Lvl</th><th>Rewards</th><th>Risk</th><th>Done</th><th>Cooldown</th><th></th></tr>
      <?php foreach ($dMissions as $m):
        $locked = (int) $u['level'] < (int) $m['min_level'];
        $done = $doneMap[$m['id']] ?? 0;
      ?>
        <tr <?= $locked ? 'style="opacity:.5"' : '' ?>>
          <td>
            <b><?= e($m['name']) ?></b><br>
            <small class="muted"><?= e($m['description']) ?></small>
          </td>
          <td><?= (int) $m['energy_cost'] ?></td>
          <td><?= (int) $m['min_level'] ?></td>
          <td>
            <?= (int) $m['reward_money'] ? money($m['reward_money']) : '' ?>
            <?= (int) $m['reward_xp'] ? ' + ' . (int) $m['reward_xp'] . ' XP' : '' ?>
            <?= (int) $m['reward_points'] ? ' + ' . (int) $m['reward_points'] . ' pts' : '' ?>
          </td>
          <td><?= (int) $m['risk'] ?>%</td>
          <td><?= $done ?></td>
          <td>
            <?php $cd = action_on_cooldown($u['id'], 'missions'); if ($cd): ?><span class="pill tag-red"><?= e($cd) ?></span><?php else: ?>-<?php endif; ?>
          </td>
          <td>
            <?php if (!$locked): ?>
              <form method="post" data-offline-queue data-offline-label="Mission" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="mission_id" value="<?= (int) $m['id'] ?>">
                <button class="btn btn-green btn-sm" type="submit">Run</button>
              </form>
            <?php else: ?>
              <span class="tag tag-common">Locked</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>
<?php endforeach; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>