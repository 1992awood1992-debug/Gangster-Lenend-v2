#!/usr/bin/env bash
#
# Mafia Empire - database restore.
#
# Restores a .sql or .sql.gz backup produced by scripts/backup.sh.
#
#   ./scripts/restore.sh backups/mafia_empire_20260101_030000.sql.gz
set -euo pipefail

if [[ $# -lt 1 ]]; then
    echo "Usage: $0 <backup.sql|backup.sql.gz>" >&2
    exit 1
fi

FILE="$1"
if [[ ! -f "$FILE" ]]; then
    echo "File not found: $FILE" >&2
    exit 1
fi

DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-3306}"
DB_NAME="${DB_NAME:-mafia_empire}"
DB_USER="${DB_USER:-root}"
DB_PASS="${DB_PASS:-}"
MYSQL="${MYSQL:-mysql}"

read -r -p "This will OVERWRITE database '$DB_NAME'. Type 'yes' to continue: " CONFIRM
if [[ "$CONFIRM" != "yes" ]]; then
    echo "Aborted."
    exit 1
fi

export MYSQL_PWD="$DB_PASS"

if [[ "$FILE" == *.gz ]]; then
    gunzip -c "$FILE" | "$MYSQL" --host="$DB_HOST" --port="$DB_PORT" --user="$DB_USER" "$DB_NAME"
else
    "$MYSQL" --host="$DB_HOST" --port="$DB_PORT" --user="$DB_USER" "$DB_NAME" < "$FILE"
fi

unset MYSQL_PWD
echo "Restore complete from: $FILE"
