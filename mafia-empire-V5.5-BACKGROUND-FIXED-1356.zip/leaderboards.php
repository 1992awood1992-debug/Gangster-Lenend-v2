<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$board = $_GET['board'] ?? 'level';
$allowed = ['level' => 'level DESC, xp DESC', 'kills' => 'kills DESC', 'cash' => '(money + bank) DESC', 'bullets' => 'bullets DESC'];
$order = $allowed[$board] ?? $allowed['level'];

$page_title = 'Leaderboards';
require __DIR__ . '/includes/header.php';

$list = cache_remember('leaderboard:' . $board, 60, function () use ($order) {
    return fetch_all("SELECT * FROM users WHERE is_banned = 0 ORDER BY $order LIMIT 50");
});
?>
<div class="card">
  <div class="panel-heading">Leaderboards</div>
  <div class="pill-row" style="margin-bottom:14px">
    <?php foreach ($allowed as $key => $label): $labelText = ucfirst($key); ?>
      <a class="pill<?= $key === $board ? ' on' : '' ?>" href="<?= e(url('leaderboards.php?board=' . $key)) ?>"><?= $labelText ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <?php if (!$list): ?>
    <p class="muted">No players.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>#</th><th>Player</th><th>Level</th><th>Kills</th><th>Cash</th><th>Bullets</th></tr>
      <?php foreach ($list as $i => $p):
        $isMe = $p['id'] == $u['id'];
        $rowStyle = $isMe ? 'style="background:rgba(230,182,76,.1)"' : '';
      ?>
        <tr <?= $rowStyle ?>>
          <td><?= $i + 1 ?></td>
          <td><a href="<?= e(url('profile.php?id=' . (int) $p['id'])) ?>"><b><?= e($p['username']) ?></b><?= $isMe ? ' <span class="tag tag-legendary">You</span>' : '' ?></a></td>
          <td><?= (int) $p['level'] ?></td>
          <td><?= (int) $p['kills'] ?></td>
          <td><?= money((int) $p['money'] + (int) $p['bank']) ?></td>
          <td><?= number_format((int) $p['bullets']) ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php if ($u['crew_id']): ?>
  <?php
  $crews = cache_remember('leaderboard:crews', 120, function () {
      return fetch_all('SELECT c.*, COUNT(cm.user_id) AS members FROM crews c LEFT JOIN crew_members cm ON cm.crew_id = c.id GROUP BY c.id ORDER BY c.level DESC, c.money DESC LIMIT 20');
  });
  if ($crews): ?>
    <div class="card" style="margin-top:18px">
      <div class="panel-heading">Top Crews</div>
      <div class="table-wrap"><table>
        <tr><th>#</th><th>Crew</th><th>Level</th><th>Members</th><th>Money</th><th>Bullets</th></tr>
        <?php foreach ($crews as $i => $c): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><b><?= e($c['name']) ?></b> [<?= e($c['tag']) ?>]</td>
            <td><?= (int) $c['level'] ?></td>
            <td><?= (int) $c['members'] ?></td>
            <td><?= money($c['money']) ?></td>
            <td><?= number_format((int) $c['bullets']) ?></td>
          </tr>
        <?php endforeach; ?>
      </table></div>
    </div>
  <?php endif; ?>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>