<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

finish_expired_wars();

$crew = $u['crew_id'] ? fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]) : null;
$isLeader = $crew && (int) $crew['leader_id'] === $u['id'];
$isBoss = $crew && in_array($u['crew_rank'], ['Leader', 'Underboss'], true);

// POST: claim / collect / upgrade / raid
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if (!$crew) {
        flash('Join a crew to control territory.', 'error');
        redirect('territory.php');
    }
    $zone = fetch('SELECT * FROM zones WHERE id = ?', [(int) ($_POST['zone_id'] ?? 0)]);
    if (!$zone) {
        flash('Zone not found.', 'error');
        redirect('territory.php');
    }
    $control = fetch('SELECT * FROM zone_control WHERE zone_id = ?', [$zone['id']]);
    $perks = array_column(fetch_all('SELECT perk_code FROM crew_unlocked_perks WHERE crew_id = ?', [$crew['id']]), 'perk_code');
    $myLevel = crew_level((int) $crew['xp'], (int) $crew['xp_spent']);

    if ($action === 'claim') {
        if (!$isBoss) {
            flash('Only a Leader or Underboss can claim turf.', 'error');
        } elseif ((int) $zone['min_crew_level'] > $myLevel) {
            flash('Your crew needs level ' . (int) $zone['min_crew_level'] . ' for this zone.', 'error');
        } elseif ($control) {
            flash('This zone is already claimed.', 'error');
        } else {
            $owned = (int) fetch_one('SELECT COUNT(*) FROM zone_control WHERE crew_id = ?', [$crew['id']], 0);
            if ($owned >= crew_zone_cap((int) $crew['id'], $myLevel)) {
                flash('Your crew controls the maximum number of zones.', 'error');
            } else {
                $cost = zone_claim_cost((int) $zone['base_income']);
                if ((int) $crew['money'] < $cost) {
                    flash('Your crew needs ' . money($cost) . ' to claim this zone.', 'error');
                } else {
                    q('UPDATE crews SET money = money - ? WHERE id = ?', [$cost, $crew['id']]);
                    insert('zone_control', ['zone_id' => $zone['id'], 'crew_id' => $crew['id'], 'level' => 1]);
                    add_crew_xp((int) $crew['id'], 100);
                    flash('Crew claimed ' . e($zone['name']) . '! (+100 crew XP)', 'success');
                }
            }
        }
    } elseif ($action === 'collect') {
        if (!$control || (int) $control['crew_id'] !== (int) $crew['id']) {
            flash('Your crew does not control this zone.', 'error');
        } elseif ($control['last_collect'] && strtotime($control['last_collect']) > time() - 3600) {
            $wait = 3600 - (time() - strtotime($control['last_collect']));
            flash('Turf income not ready. Come back in ' . ceil($wait / 60) . ' minutes.', 'error');
        } else {
            $income = zone_income((int) $zone['base_income'], (int) $control['level'], $perks);
            q('UPDATE crews SET money = money + ? WHERE id = ?', [$income, $crew['id']]);
            q('UPDATE zone_control SET last_collect = NOW() WHERE zone_id = ?', [$zone['id']]);
            flash('Collected ' . money($income) . ' from ' . e($zone['name']) . ' into the crew bank.', 'success');
        }
    } elseif ($action === 'upgrade') {
        if (!$isBoss) {
            flash('Only a Leader or Underboss can upgrade turf.', 'error');
        } elseif (!$control || (int) $control['crew_id'] !== (int) $crew['id']) {
            flash('Your crew does not control this zone.', 'error');
        } elseif ((int) $control['level'] >= 5) {
            flash('Zone is already max level.', 'error');
        } else {
            $cost = zone_upgrade_cost((int) $zone['base_income'], (int) $control['level']);
            if ((int) $crew['money'] < $cost) {
                flash('Your crew needs ' . money($cost) . ' to upgrade.', 'error');
            } else {
                q('UPDATE crews SET money = money - ? WHERE id = ?', [$cost, $crew['id']]);
                q('UPDATE zone_control SET level = level + 1 WHERE zone_id = ?', [$zone['id']]);
                flash(e($zone['name']) . ' upgraded to level ' . ((int) $control['level'] + 1) . '!', 'success');
            }
        }
    } elseif ($action === 'raid') {
        $target = $control;
        if (!$target || (int) $target['crew_id'] === (int) $crew['id']) {
            flash('That zone is not held by an enemy crew.', 'error');
        } else {
            $war = active_war_between((int) $crew['id'], (int) $target['crew_id']);
            if (!$war) {
                flash('You can only raid turf of a crew you are at war with.', 'error');
            } elseif ((int) $u['nerve'] < 25) {
                flash('Raid requires 25 nerve.', 'error');
            } else {
                $recent = fetch('SELECT id FROM zone_raids WHERE zone_id = ? AND crew_id = ? AND created_at > NOW() - INTERVAL 2 HOUR', [$zone['id'], $crew['id']]);
                if ($recent) {
                    flash('Your crew raided this zone recently. Wait 2 hours.', 'error');
                } else {
                    q('UPDATE users SET nerve = nerve - 25 WHERE id = ?', [$u['id']]);
                    insert('zone_raids', ['zone_id' => $zone['id'], 'crew_id' => $crew['id']]);
                    $chance = 50 + 5 * max(0, $myLevel - (int) $zone['min_crew_level']);
                    if (in_array('mole_network', $perks, true)) {
                        $chance += 15;
                    }
                    $chance = min(90, $chance);
                    $success = mt_rand(1, 100) <= $chance;
                    if ($success) {
                        q('UPDATE zone_control SET crew_id = ?, level = 1, captured_at = NOW(), last_collect = NULL WHERE zone_id = ?', [$crew['id'], $zone['id']]);
                        add_crew_xp((int) $crew['id'], 150);
                        notify_crew((int) $target['crew_id'], 'Your zone ' . e($zone['name']) . ' was raided and taken by ' . e($crew['name']) . '!', 'territory.php');
                        flash('Raid successful! ' . e($zone['name']) . ' now belongs to your crew! (+150 crew XP)', 'success');
                    } else {
                        $hpLoss = 10;
                        if (in_array('insurance', $perks, true)) {
                            $hpLoss = 5;
                        }
                        q('UPDATE users SET health = GREATEST(health - ?, 0) WHERE id = ?', [$hpLoss, $u['id']]);
                        flash('Raid failed. Your crew lost ' . $hpLoss . ' health.', 'error');
                    }
                }
            }
        }
    }
    redirect('territory.php');
}

$page_title = 'Territory';
require __DIR__ . '/includes/header.php';

// Data for rendering
$zones = fetch_all('SELECT * FROM zones ORDER BY district_id, min_crew_level');
$controls = fetch_all('SELECT zc.*, c.name AS crew_name, c.tag AS crew_tag FROM zone_control zc JOIN crews c ON c.id = zc.crew_id');
$controlMap = [];
foreach ($controls as $zc) {
    $controlMap[$zc['zone_id']] = $zc;
}
$districts = fetch_all('SELECT * FROM districts ORDER BY unlock_level');
$perks = $crew ? array_column(fetch_all('SELECT perk_code FROM crew_unlocked_perks WHERE crew_id = ?', [$crew['id']]), 'perk_code') : [];
$myLevel = $crew ? crew_level((int) $crew['xp'], (int) $crew['xp_spent']) : 0;
$ownedCount = $crew ? (int) fetch_one('SELECT COUNT(*) FROM zone_control WHERE crew_id = ?', [$crew['id']], 0) : 0;
$zoneCap = $crew ? crew_zone_cap((int) $crew['id'], $myLevel) : 0;
$warsWith = [];
if ($crew) {
    foreach (fetch_all("SELECT cw.*, cA.name AS aname, cA.tag AS atag, cD.name AS dname, cD.tag AS dtag FROM crew_wars cw JOIN crews cA ON cA.id = cw.attacker_id JOIN crews cD ON cD.id = cw.defender_id WHERE cw.status IN ('declared','active') AND (cw.attacker_id = ? OR cw.defender_id = ?)", [$crew['id'], $crew['id']]) as $w) {
        $warsWith[$w['attacker_id']] = $w;
        $warsWith[$w['defender_id']] = $w;
    }
}
?>
<div class="card">
  <div class="panel-heading">Territory of the City</div>
  <p class="muted small">Control turf for hourly income. Upgrade zones for bigger cuts. Raid enemy zones during a war to seize them.</p>
  <?php if (!$crew): ?>
    <p class="muted">Join or create a crew to control territory.</p>
  <?php else: ?>
    <div class="grid grid-4" style="margin-bottom:14px">
      <div class="stat"><span>Crew</span><b><?= e($crew['name']) ?></b></div>
      <div class="stat"><span>Level</span><b><?= $myLevel ?> (<?= (int) $crew['wars_won'] ?>W / <?= (int) $crew['wars_lost'] ?>L)</b></div>
      <div class="stat"><span>Turf Held</span><b><?= $ownedCount ?> / <?= $zoneCap ?></b></div>
      <div class="stat"><span>Crew Bank</span><b><?= money($crew['money']) ?></b></div>
    </div>
  <?php endif; ?>
</div>

<?php if ($crew): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">The Map</div>
  <div class="turf-map">
    <?php foreach ($zones as $z):
      $c = $controlMap[$z['id']] ?? null;
      $mine = $c && (int) $c['crew_id'] === (int) $crew['id'];
      $style = 'left:' . (int) $z['px'] . '%;top:' . (int) $z['py'] . '%;';
    ?>
      <div class="turf-marker <?= $mine ? 'mine' : ($c ? 'taken' : '') ?>" style="<?= $style ?>"
           title="<?= e($z['name']) ?> — <?= $c ? e($c['crew_name']) . ' (Lv' . (int) $c['level'] . ')' : 'Neutral' ?>"
           data-zone="<?= (int) $z['id'] ?>">
        <span class="tm-dot"></span>
        <span class="tm-label"><?= e($z['name']) ?></span>
      </div>
    <?php endforeach; ?>
    <div class="turf-legend">
      <span><i class="tm-dot mine"></i> Yours</span>
      <span><i class="tm-dot taken"></i> Enemy Turf</span>
      <span><i class="tm-dot"></i> Neutral</span>
    </div>
  </div>
</div>

<?php foreach ($districts as $d):
  $dz = array_values(array_filter($zones, fn($z) => (int) $z['district_id'] === (int) $d['id']));
  if (!$dz) continue;
?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading"><?= e($d['name']) ?> <span class="tag tag-common">Crew Lv <?= (int) $dz[0]['min_crew_level'] ?>+</span></div>
  <div class="table-wrap"><table>
    <tr><th>Zone</th><th>Controller</th><th>Level</th><th>Income / hr</th><th>Actions</th></tr>
    <?php foreach ($dz as $z):
      $c = $controlMap[$z['id']] ?? null;
      $mine = $c && (int) $c['crew_id'] === (int) $crew['id'];
      $enemyAtWar = $c && $c['crew_id'] !== $crew['id'] && isset($warsWith[$c['crew_id']]);
      $collectReady = $mine && (!$c['last_collect'] || strtotime($c['last_collect']) <= time() - 3600);
    ?>
      <tr>
        <td><b><?= e($z['name']) ?></b><br><small class="muted"><?= e($z['description']) ?></small></td>
        <td>
          <?php if (!$c): ?><span class="muted">Neutral</span>
          <?php else: ?><b><?= e($c['crew_name']) ?></b> <span class="tag tag-common">[<?= e($c['crew_tag']) ?>]</span><?php if ($mine): ?> <span class="tag tag-epic">Yours</span><?php endif; ?><?php endif; ?>
        </td>
        <td><?= $c ? (int) $c['level'] . ' / 5' : '—' ?></td>
        <td><?= $c ? money(zone_income((int) $z['base_income'], (int) $c['level'], $perks)) : (money(zone_income((int) $z['base_income'], 1, $perks))) ?></td>
        <td>
          <?php if (!$c && $isBoss): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="claim"><input type="hidden" name="zone_id" value="<?= (int) $z['id'] ?>"><button class="btn btn-green btn-sm" type="submit"<?= $myLevel < (int) $z['min_crew_level'] ? ' disabled' : '' ?>>Claim (<?= money(zone_claim_cost((int) $z['base_income'])) ?>)</button></form>
          <?php elseif ($mine && $collectReady): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="collect"><input type="hidden" name="zone_id" value="<?= (int) $z['id'] ?>"><button class="btn btn-gold btn-sm" type="submit">Collect (<?= money(zone_income((int) $z['base_income'], (int) $c['level'], $perks)) ?>)</button></form>
          <?php elseif ($mine && !$collectReady): ?>
            <span class="tag tag-common">Collect in ~<?= max(1, ceil((3600 - (time() - strtotime($c['last_collect']))) / 60)) ?> min</span>
          <?php endif; ?>
          <?php if ($mine && $isBoss && (int) $c['level'] < 5): ?>
            <form method="post" style="display:inline;margin-left:6px"><?= csrf_field() ?><input type="hidden" name="action" value="upgrade"><input type="hidden" name="zone_id" value="<?= (int) $z['id'] ?>"><button class="btn btn-sm" type="submit">Upgrade (<?= money(zone_upgrade_cost((int) $z['base_income'], (int) $c['level'])) ?>)</button></form>
          <?php endif; ?>
          <?php if ($enemyAtWar): ?>
            <form method="post" style="display:inline;margin-left:6px"><?= csrf_field() ?><input type="hidden" name="action" value="raid"><input type="hidden" name="zone_id" value="<?= (int) $z['id'] ?>"><button class="btn btn-danger btn-sm" type="submit">Raid (25 nerve)</button></form>
          <?php elseif ($c && !$mine): ?>
            <span class="muted small">Declare war to raid</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endforeach; ?>

<?php endif; ?>

<style>
.turf-map{position:relative;height:420px;background:radial-gradient(ellipse at 40% 30%, #2a2320 0%, #171310 70%);border:1px solid #5c4a2e;border-radius:6px;overflow:hidden}
.turf-marker{position:absolute;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;cursor:default;z-index:2}
.tm-dot{width:14px;height:14px;border-radius:50%;background:#7a8694;border:2px solid #171310;box-shadow:0 0 6px rgba(0,0,0,.6)}
.turf-marker.mine .tm-dot{background:#5fae5f;box-shadow:0 0 10px rgba(95,174,95,.8)}
.turf-marker.taken .tm-dot{background:#c0392b;box-shadow:0 0 10px rgba(192,57,43,.8)}
.tm-label{font-size:9px;color:#c9b27a;text-shadow:0 1px 2px #000;margin-top:2px;white-space:nowrap;background:rgba(0,0,0,.55);padding:1px 4px;border-radius:3px}
.turf-legend{position:absolute;bottom:8px;left:8px;right:8px;display:flex;gap:14px;font-size:11px;color:#c9b27a;background:rgba(0,0,0,.6);padding:6px 10px;border-radius:4px;z-index:3}
.turf-legend .tm-dot{width:10px;height:10px;display:inline-block;margin-right:4px;transform:none}
</style>

<?php require __DIR__ . '/includes/footer.php'; ?>