<?php
/**
 * Eye Of The Mafia - Prestige Coin Shop (Black Market)
 * Spend Prestige Coins on exclusive items, perks, and bonuses.
 */

require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/prestige.php';

$u = require_login();

$page_title = 'Prestige Coin Shop';
require __DIR__ . '/includes/header.php';

$coins = prestige_get_coins($u['id']);

// Handle purchase
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $itemCode = $_POST['item_code'] ?? '';
    $qty = max(1, (int) ($_POST['qty'] ?? 1));

    $shopItems = prestige_shop_get_items();
    $item = $shopItems[$itemCode] ?? null;

    if (!$item) {
        flash('Invalid item.', 'error');
    } elseif ($coins < $item['cost'] * $qty) {
        flash('Not enough Prestige Coins.', 'error');
    } else {
        $totalCost = $item['cost'] * $qty;
        $success = true;

        // Handle different item types
        switch ($item['type']) {
            case 'item':
                if ($item['item_id']) {
                    $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$u['id'], $item['item_id']]);
                    if ($existing) {
                        q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [$qty, $existing['id']]);
                    } else {
                        insert('user_items', ['user_id' => $u['id'], 'item_id' => $item['item_id'], 'qty' => $qty, 'equipped' => 0]);
                    }
                }
                break;
            case 'vehicle':
                if ($item['item_id']) {
                    $existing = fetch('SELECT id, qty FROM user_items WHERE user_id = ? AND item_id = ?', [$u['id'], $item['item_id']]);
                    if ($existing) {
                        q('UPDATE user_items SET qty = qty + ? WHERE id = ?', [$qty, $existing['id']]);
                    } else {
                        insert('user_items', ['user_id' => $u['id'], 'item_id' => $item['item_id'], 'qty' => $qty, 'equipped' => 0]);
                    }
                }
                break;
            case 'perk':
                // Permanent account perk
                if ($item['effect'] === 'extra_factory_slot') {
                    // Add to user settings
                    q("INSERT INTO user_settings (user_id, `key`, `value`) VALUES (?, 'extra_factory_slot', ?) ON DUPLICATE KEY UPDATE `value` = `value` + ?", [$u['id'], (string) $qty, (string) $qty]);
                } elseif ($item['effect'] === 'reduced_hospital') {
                    q("INSERT INTO user_settings (user_id, `key`, `value`) VALUES (?, 'reduced_hospital', ?) ON DUPLICATE KEY UPDATE `value` = `value` + ?", [$u['id'], (string) ($item['value'] * $qty), (string) ($item['value'] * $qty)]);
                } elseif ($item['effect'] === 'extra_crew_slot') {
                    q("INSERT INTO user_settings (user_id, `key`, `value`) VALUES (?, 'extra_crew_slot', ?) ON DUPLICATE KEY UPDATE `value` = `value` + ?", [$u['id'], (string) $qty, (string) $qty]);
                } elseif ($item['effect'] === 'prestige_xp_boost') {
                    q("INSERT INTO user_settings (user_id, `key`, `value`) VALUES (?, 'prestige_xp_boost', ?) ON DUPLICATE KEY UPDATE `value` = `value` + ?", [$u['id'], (string) ($item['value'] * $qty), (string) ($item['value'] * $qty)]);
                }
                break;
            case 'currency':
                if ($item['currency'] === 'money') {
                    add_money($u['id'], $item['value'] * $qty, 'Prestige Shop purchase');
                } elseif ($item['currency'] === 'bullets') {
                    add_bullets($u['id'], $item['value'] * $qty);
                } elseif ($item['currency'] === 'points') {
                    add_points($u['id'], $item['value'] * $qty);
                }
                break;
        }

        if ($success) {
            prestige_spend_coins($u['id'], $totalCost);
            flash('Purchased ' . $qty . 'x ' . e($item['name']) . ' for ' . ($totalCost) . ' Prestige Coins!', 'success');
        }
    }
    redirect('prestige_shop.php');
}

$shopItems = prestige_shop_get_items();

function prestige_shop_get_items(): array
{
    return [
        // Exclusive Vehicles
        'sleuth_mobile' => ['name' => 'Sleuth Mobile', 'type' => 'vehicle', 'item_id' => 0, 'cost' => 50, 'description' => 'Unmarked sedan. -50% detective range against you.', 'icon' => '🚗'],
        'ghost_car' => ['name' => 'Ghost Car', 'type' => 'vehicle', 'item_id' => 0, 'cost' => 200, 'description' => 'Invisible on Vehicle Theft lists. 100% theft immunity.', 'icon' => '👻'],
        'war_wagon' => ['name' => 'War Wagon', 'type' => 'vehicle', 'item_id' => 0, 'cost' => 100, 'description' => 'Armored beast. +50% vehicle HP, +25% crew raid damage.', 'icon' => '🛡️'],

        // Exclusive Weapons
        'golden_ak' => ['name' => 'Golden AK-47', 'type' => 'item', 'item_id' => 0, 'cost' => 75, 'description' => 'Attack +80. Flex on the poors.', 'icon' => '🔫'],
        'diamond_blade' => ['name' => 'Diamond Blade', 'type' => 'item', 'item_id' => 0, 'cost' => 100, 'description' => 'Attack +100, +10% crit. Cuts through anything.', 'icon' => '💎'],
        'nuke_launcher' => ['name' => 'Pocket Nuke', 'type' => 'item', 'item_id' => 0, 'cost' => 500, 'description' => 'Attack +500. One use. Destroys target AND their safe.', 'icon' => '☢️'],

        // Permanent Perks
        'extra_factory' => ['name' => 'Extra Factory Slot', 'type' => 'perk', 'cost' => 150, 'effect' => 'extra_factory_slot', 'value' => 1, 'description' => 'Own one additional bullet factory.', 'icon' => '🏭'],
        'crew_expansion' => ['name' => 'Crew Expansion', 'type' => 'perk', 'cost' => 100, 'effect' => 'extra_crew_slot', 'value' => 5, 'description' => '+5 max crew members (stackable).', 'icon' => '👥'],
        'hospital_vip' => ['name' => 'VIP Hospital Access', 'type' => 'perk', 'cost' => 80, 'effect' => 'reduced_hospital', 'value' => 25, 'description' => '-25% hospital time and cost permanently.', 'icon' => '🏥'],
        'prestige_mentor' => ['name' => 'Prestige Mentor', 'type' => 'perk', 'cost' => 200, 'effect' => 'prestige_xp_boost', 'value' => 50, 'description' => '+50% Prestige XP gain permanently.', 'icon' => '📈'],

        // Currency Bundles
        'cash_10m' => ['name' => '$10M Cash', 'type' => 'currency', 'cost' => 10, 'currency' => 'money', 'value' => 10000000, 'description' => 'Clean cash, no questions.', 'icon' => '💵'],
        'cash_100m' => ['name' => '$100M Cash', 'type' => 'currency', 'cost' => 80, 'currency' => 'money', 'value' => 100000000, 'description' => 'Serious capital injection.', 'icon' => '💰'],
        'bullets_10k' => ['name' => '10,000 Bullets', 'type' => 'currency', 'cost' => 5, 'currency' => 'bullets', 'value' => 10000, 'description' => 'Restock the armory.', 'icon' => '🔫'],
        'points_500' => ['name' => '500 Points', 'type' => 'currency', 'cost' => 20, 'currency' => 'points', 'value' => 500, 'description' => 'Points Store spending power.', 'icon' => '⭐'],

        // Consumables
        'immortality_serum' => ['name' => 'Immortality Serum', 'type' => 'item', 'item_id' => 0, 'cost' => 30, 'description' => 'Prevents next death. One use.', 'icon' => '💉'],
        'time_turner' => ['name' => 'Time Turner', 'type' => 'item', 'item_id' => 0, 'cost' => 40, 'description' => 'Reset all cooldowns instantly. One use.', 'icon' => '⏰'],
        'lucky_coin' => ['name' => 'Lucky Coin', 'type' => 'item', 'item_id' => 0, 'cost' => 15, 'description' => 'Next criminal job: 100% success, 2x payout. One use.', 'icon' => '🍀'],
    ];
}