/* ==========================================================================
   MAFIA EMPIRE V4.6 - FLASH EFFECTS (JavaScript)
   Confetti, screen shake, toasts, button flashes, page-wide flares
   ========================================================================== */
(function () {
  if (window.__mafiaFlashV2Loaded) return;
  window.__mafiaFlashV2Loaded = true;

  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---- Confetti explosion ---- */
  function confetti(count, color) {
    if (reduced || !document.body) return;
    count = count || 60;
    var container = document.createElement('div');
    container.className = 'fx-confetti';
    document.body.appendChild(container);
    var colors = color ? [color] : ['#c4a484','#ff3333','#888888','#ffd700','#e0e0e0','#a0a0a0'];
    for (var i = 0; i < count; i++) {
      var piece = document.createElement('div');
      piece.className = 'confetti-piece';
      piece.style.left = Math.random() * 100 + 'vw';
      piece.style.top = '-10vh';
      piece.style.background = colors[Math.floor(Math.random() * colors.length)];
      piece.style.animationDelay = (Math.random() * 0.4) + 's';
      piece.style.animationDuration = (1.2 + Math.random() * 1.2) + 's';
      container.appendChild(piece);
    }
    setTimeout(function () { container.remove(); }, 1800);
  }

  /* ---- Full screen flash overlay ---- */
  function flare(color, ms) {
    if (reduced) return;
    var el = document.createElement('div');
    el.className = 'fx-overlay';
    el.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:9999;opacity:.65;transition:opacity ' + (ms || 300) + 'ms ease-out;background:' + (color || 'radial-gradient(circle at 50% 40%, rgba(255,255,255,.7), rgba(196,164,132,.25) 45%, transparent 75%)');
    document.body.appendChild(el);
    requestAnimationFrame(function () { el.style.opacity = '0'; });
    setTimeout(function () { el.remove(); }, (ms || 300) + 100);
  }

  /* ---- Screen shake ---- */
  function shake(el, ms) {
    if (!el || reduced) return;
    el.classList.add('fx-shake');
    setTimeout(function () { el.classList.remove('fx-shake'); }, ms || 450);
  }

  /* ---- Flash an element (brightness pop) ---- */
  function pop(el, ms) {
    if (!el || reduced) return;
    el.classList.add('fx-flash');
    setTimeout(function () { el.classList.remove('fx-flash'); }, ms || 500);
  }

  /* ---- Expose to window ---- */
  window.mafiaFlash = {
    flare: flare,
    shake: shake,
    pop: pop,
    confetti: confetti
  };

  /* ---- CSS for JS effects (self contained) ---- */
  if (!document.getElementById('fx-js-style')) {
    var s = document.createElement('style');
    s.id = 'fx-js-style';
    s.textContent =
      '.fx-flash{animation:fw-js-flash .5s ease-out !important}' +
      '@keyframes fw-js-flash{0%{filter:brightness(2.2) saturate(1.4)}55%{filter:brightness(1.3)}100%{filter:brightness(1)}}' +
      '.fx-shake{animation:fw-js-shake .45s cubic-bezier(.36,.07,.19,.97) both}' +
      '@keyframes fw-js-shake{0%,100%{transform:translateX(0)}10%,30%,50%,70%,90%{transform:translateX(-7px)}20%,40%,60%,80%{transform:translateX(7px)}}' +
      '.confetti-piece{position:absolute;width:8px;height:8px;background:#c4a484;border-radius:2px;animation:fw-confetti 1.6s cubic-bezier(0,.9,.57,1) forwards}' +
      '.confetti-piece:nth-child(2n){background:#ff3333;width:6px;height:10px;border-radius:50%}' +
      '.confetti-piece:nth-child(3n){background:#888;width:10px;height:6px}' +
      '@keyframes fw-confetti{0%{transform:translateY(-10vh)rotate(0)scale(1);opacity:1}100%{transform:translateY(105vh)rotate(720deg)scale(0);opacity:0}}';
    document.head.appendChild(s);
  }

  /* ---- Auto wire interactions ---- */
  /* ---- Loading screen ---- */
  var loader = document.getElementById('fw-loading');
  if (loader) {
    loader.style.display = 'flex';
    setTimeout(function () {
      loader.style.opacity = '0';
      setTimeout(function () { loader.remove(); }, 600);
    }, 700);
  }

  document.addEventListener('DOMContentLoaded', function () {

    // Button / tile click flash
    document.addEventListener('click', function (ev) {
      var t = ev.target.closest('.btn, .tile, .nav-link, .mobile-nav a, button[type=submit]');
      if (t) {
        pop(t);
        if (window.mafiaSound) window.mafiaSound.play('click');
        if (t.classList.contains('btn-gold')) {
          if (window.mafiaSound) window.mafiaSound.play('gold');
          confetti(12);
        }
      }
    }, true);

    // Form submit -> subtle flare
    document.addEventListener('submit', function () {
      flare('radial-gradient(circle at 50% 45%, rgba(255,255,255,.55), transparent 70%)', 260);
      if (window.mafiaSound) window.mafiaSound.play('buy');
    }, true);

    // Toasts pop in + confetti on success/gold
    var toasts = document.getElementById('toasts');
    if (toasts && 'MutationObserver' in window) {
      new MutationObserver(function (muts) {
        muts.forEach(function (m) {
          Array.prototype.forEach.call(m.addedNodes, function (n) {
            if (n.nodeType !== 1) return;
            pop(n, 650);
            var cls = n.className || '';
            if (cls.indexOf('toast-success') >= 0 || cls.indexOf('toast-gold') >= 0 || n.textContent && /won|success|earned/i.test(n.textContent)) {
              confetti(40);
            }
            if (cls.indexOf('toast-error') >= 0) {
              shake(n, 400);
            }
          });
        });
      }).observe(toasts, { childList: true });
    }

    // Dismiss DB flash toasts via AJAX
    document.addEventListener('click', function (ev) {
      var btn = ev.target.closest('.toast-dismiss');
      if (!btn) return;
      var fid = btn.getAttribute('data-flash-id');
      if (!fid) return;
      ev.preventDefault();
      var toast = btn.closest('.toast');
      var csrf = document.querySelector('meta[name="csrf"]');
      var body = 'flash_id=' + encodeURIComponent(fid);
      if (csrf && csrf.content) body += '&csrf=' + encodeURIComponent(csrf.content);
      fetch('ajax/dismiss_flash.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: body
      }).then(function () {
        if (toast) {
          toast.style.opacity = '0';
          toast.style.transform = 'translateX(140px)';
          setTimeout(function () { toast.remove(); }, 240);
        }
      }).catch(function () {});
    }, true);

    // WS notification -> page flare + confetti
    if (window.mafiaWS && typeof window.mafiaWS.on === 'function') {
      try {
        window.mafiaWS.on('notification', function () {
          flare();
          confetti(25);
        });
      } catch (e) { /* ignore */ }
    }

    // Mobile nav / sidebar toggle
    var mt = document.getElementById('menuToggle');
    var sb = document.getElementById('mainSidebar');
    var bd = document.getElementById('sidebarBackdrop');
    if (mt && sb && bd) {
      mt.addEventListener('click', function () {
        var open = sb.classList.toggle('sidebar-open');
        bd.classList.toggle('visible', open);
        mt.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
      bd.addEventListener('click', function () {
        sb.classList.remove('sidebar-open');
        bd.classList.remove('visible');
        mt.setAttribute('aria-expanded', 'false');
      });
    }
  });
})();
