<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

$page_title = 'City Events';
require __DIR__ . '/includes/header.php';

$events = get_city_events();
$eventIcons = [
    'warning' => '&#9888;',
    'info' => '&#8505;',
    'success' => '&#10003;',
    'error' => '&#10007;',
];
?>
<div class="card card-glass">
  <div class="panel-heading">City Events</div>
  <p class="muted small">Latest happenings around The City.</p>
</div>
<div class="card card-glass" style="margin-top:14px">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Time</th><th>Event</th><th>Type</th></tr></thead>
      <tbody>
      <?php $hour = date('G'); foreach ($events as $i => $ev): $h = ($hour + $i * 3) % 24; $m = str_pad(($i * 17) % 60, 2, '0', STR_PAD_LEFT); $time = str_pad($h, 2, '0', STR_PAD_LEFT) . ':' . $m; ?>
        <tr>
          <td><?= $time ?></td>
          <td><?= e($ev[0]) ?></td>
          <td><span class="tag tag-<?= e($ev[1]) ?>"><?= ucfirst(e($ev[1])) ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
