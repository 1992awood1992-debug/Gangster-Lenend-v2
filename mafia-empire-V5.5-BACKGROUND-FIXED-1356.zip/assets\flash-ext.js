/* ==========================================================================
   MAFIA EMPIRE V4.6 - FLASH EFFECTS EXTENSIONS (JavaScript)
   Combat numbers, page transitions, notification flashes, modal pop, sound cues
   ========================================================================== */
(function () {
  if (window.__mafiaFlashExtLoaded) return;
  window.__mafiaFlashExtLoaded = true;

  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---- Floating combat / action numbers ---- */
  function floatNumber(x, y, text, color, el) {
    if (reduced || !document.body) return;
    var node = document.createElement('div');
    node.className = 'fw-float-num';
    node.textContent = text;
    node.style.cssText = 'position:fixed;left:' + x + 'px;top:' + y + 'px;color:' + (color || '#c4a484') +
      ';font-weight:800;font-size:1.3rem;text-shadow:0 0 10px rgba(0,0,0,.9),0 0 20px ' + (color || '#c4a484') +
      ';pointer-events:none;z-index:10000;transform-origin:center';
    document.body.appendChild(node);
    var start = Date.now(), dur = 900;
    function tick() {
      var t = Math.min(1, (Date.now() - start) / dur);
      node.style.transform = 'translateY(-' + (t * 140) + 'px) scale(' + (1 + t * .4) + ')';
      node.style.opacity = 1 - t;
      if (t < 1) requestAnimationFrame(tick); else node.remove();
    }
    requestAnimationFrame(tick);
  }

  window.mafiaFlash.floatNumber = floatNumber;

  /* ---- Combat hit flash on target element ---- */
  function hitFlash(targetEl, dmgText, isCrit) {
    if (!targetEl || reduced) return;
    var rect = targetEl.getBoundingClientRect();
    var cx = rect.left + rect.width / 2, cy = rect.top;
    pop(targetEl, 300);
    floatNumber(cx, cy, dmgText, isCrit ? '#ffd700' : '#ff3333', targetEl);
    shake(targetEl, 250);
    flare(isCrit ? 'radial-gradient(circle at 50% 40%, rgba(255,215,0,.6), transparent 60%)' : 'radial-gradient(circle at 50% 40%, rgba(255,51,51,.5), transparent 60%)', 200);
  }
  window.mafiaFlash.hitFlash = hitFlash;

  /* ---- Page transition flash (between page loads via JS if used) ---- */
  function pageFlash(color) {
    flare(color || 'linear-gradient(135deg, rgba(196,164,132,.35), rgba(196,164,132,.15))', 450);
  }
  window.mafiaFlash.pageFlash = pageFlash;

  /* ---- Modal dramatic entrance ---- */
  function modalOpen(modalEl) {
    if (!modalEl || reduced) return;
    modalEl.style.opacity = '0';
    modalEl.style.transform = 'scale(.85) translateY(30px)';
    modalEl.style.transition = 'all .35s cubic-bezier(.175,.885,.32,1.275)';
    requestAnimationFrame(function () {
      modalEl.style.opacity = '1';
      modalEl.style.transform = 'scale(1) translateY(0)';
    });
    confetti(30);
    flare('radial-gradient(circle at 50% 40%, rgba(255,255,255,.2), transparent 70%)', 300);
  }
  window.mafiaFlash.modalOpen = modalOpen;

  /* ---- Notification toast slam ---- */
  function toastSlam(toastEl, type) {
    if (!toastEl || reduced) return;
    pop(toastEl, 500);
    if (type === 'success' || type === 'gold') confetti(35);
    else if (type === 'error') shake(toastEl, 400);
    else flare('radial-gradient(circle at 50% 40%, rgba(196,164,132,.25), transparent 70%)', 240);
  }
  window.mafiaFlash.toastSlam = toastSlam;

  /* ---- Auto-wire existing toasts on load ---- */
  document.addEventListener('DOMContentLoaded', function () {
    var toasts = document.querySelectorAll('.toast');
    toasts.forEach(function (t) {
      var cls = t.className || '';
      var type = 'info';
      if (cls.indexOf('toast-success') >= 0) type = 'success';
      else if (cls.indexOf('toast-error') >= 0) type = 'error';
      else if (cls.indexOf('toast-warning') >= 0) type = 'warning';
      else if (cls.indexOf('toast-gold') >= 0) type = 'gold';
      toastSlam(t, type);
    });
  });
})();
