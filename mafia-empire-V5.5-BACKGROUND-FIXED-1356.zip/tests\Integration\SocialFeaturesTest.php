<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

require_once __DIR__ . '/../../includes/social.php';

/**
 * End-to-end coverage for the social feature helpers against the real schema:
 * trades, crew chat, hitlist and the bounty board.
 */
final class SocialFeaturesTest extends TestCase
{
    public function testBountyLifecycle(): void
    {
        $placer = $this->makeUser(['money' => 50000]);
        $target = $this->makeUser();
        $claimer = $this->makeUser();

        $id = bounty_create((int) $target['id'], 5000, (int) $placer['id'], 'test');
        $this->assertIsInt($id);
        $this->assertGreaterThan(0, $id);

        $active = bounties_get_active();
        $row = null;
        foreach ($active as $b) {
            if ((int) $b['id'] === $id) { $row = $b; }
        }
        $this->assertNotNull($row, 'bounty should be listed as active');
        $this->assertSame($target['username'], $row['target_name']);
        $this->assertSame($placer['username'], $row['creator_name']);
        $this->assertSame(5000, (int) $row['reward_money']);

        // The target may not claim their own bounty.
        $this->assertFalse(bounty_claim((int) $target['id'], (int) $id));

        $before = (int) $this->freshUser((int) $claimer['id'])['money'];
        $this->assertTrue(bounty_claim((int) $claimer['id'], (int) $id));
        $this->assertSame($before + 5000, (int) $this->freshUser((int) $claimer['id'])['money']);
        $this->assertSame('claimed', fetch('SELECT status FROM bounties WHERE id = ?', [$id])['status']);
    }

    public function testBountyEscrowsFunds(): void
    {
        $placer = $this->makeUser(['money' => 50000]);
        $target = $this->makeUser();

        $id = bounty_create((int) $target['id'], 5000, (int) $placer['id'], 'escrow test');
        $this->assertIsInt($id);
        $this->assertGreaterThan(0, $id);
        $this->assertSame(45000, (int) $this->freshUser((int) $placer['id'])['money'], 'reward is escrowed from the placer');
    }

    public function testBountyRejectsInsufficientFundsAndSelfTarget(): void
    {
        $poor = $this->makeUser(['money' => 100]);
        $target = $this->makeUser();

        $this->assertNull(bounty_create((int) $target['id'], 5000, (int) $poor['id']), 'cannot afford');
        $this->assertNull(bounty_create((int) $poor['id'], 50, (int) $poor['id']), 'cannot target self');
    }

    public function testHitlistLifecycle(): void
    {
        $placer = $this->makeUser(['money' => 50000]);
        $target = $this->makeUser();
        $claimer = $this->makeUser();

        $placerMoney = (int) $placer['money'];
        $id = hitlist_add((int) $placer['id'], (int) $target['id'], 3000);
        $this->assertIsInt($id);
        $this->assertSame($placerMoney - 3000, (int) $this->freshUser((int) $placer['id'])['money'], 'reward is escrowed');

        $hits = hitlist_get_active();
        $row = null;
        foreach ($hits as $h) {
            if ((int) $h['id'] === $id) { $row = $h; }
        }
        $this->assertNotNull($row);
        $this->assertSame($target['username'], $row['target_name']);
        $this->assertSame($placer['username'], $row['placer_name']);
        $this->assertSame(3000, (int) $row['reward_money']);

        $this->assertFalse(hitlist_claim((int) $target['id'], (int) $id));

        $before = (int) $this->freshUser((int) $claimer['id'])['money'];
        $this->assertTrue(hitlist_claim((int) $claimer['id'], (int) $id));
        $this->assertSame($before + 3000, (int) $this->freshUser((int) $claimer['id'])['money']);
    }

    public function testHitlistRejectsInsufficientFunds(): void
    {
        $placer = $this->makeUser(['money' => 100]);
        $target = $this->makeUser();

        $this->assertNull(hitlist_add((int) $placer['id'], (int) $target['id'], 5000));
    }

    public function testTradeLifecycle(): void
    {
        $sender = $this->makeUser(['money' => 1000, 'bullets' => 100]);
        $recipient = $this->makeUser(['money' => 500, 'bullets' => 50]);

        $id = trade_create((int) $sender['id'], (int) $recipient['id'], [], 1000, 100, [], 500, 50);
        $this->assertIsInt($id);
        $this->assertGreaterThan(0, $id);

        $pending = trades_get_pending((int) $recipient['id']);
        $this->assertNotEmpty($pending);
        $this->assertSame($id, (int) $pending[0]['id']);
        $this->assertSame($sender['username'], $pending[0]['sender_name']);

        $this->assertTrue(trade_accept((int) $id, (int) $recipient['id']));
        $this->assertSame('accepted', fetch('SELECT status FROM trades WHERE id = ?', [$id])['status']);

        // Cash and bullets actually change hands.
        $senderAfter = $this->freshUser((int) $sender['id']);
        $recipientAfter = $this->freshUser((int) $recipient['id']);
        $this->assertSame(500, (int) $senderAfter['money']);
        $this->assertSame(50, (int) $senderAfter['bullets']);
        $this->assertSame(1000, (int) $recipientAfter['money']);
        $this->assertSame(100, (int) $recipientAfter['bullets']);
    }

    public function testTradeAcceptRejectsInsufficientFunds(): void
    {
        $sender = $this->makeUser(['money' => 100]);
        $recipient = $this->makeUser(['money' => 5000]);
        $id = trade_create((int) $sender['id'], (int) $recipient['id'], [], 1000, 0, [], 0, 0);

        $this->assertFalse(trade_accept((int) $id, (int) $recipient['id']));
        $this->assertSame('pending', fetch('SELECT status FROM trades WHERE id = ?', [$id])['status']);
        $this->assertSame(100, (int) $this->freshUser((int) $sender['id'])['money']);
        $this->assertSame(5000, (int) $this->freshUser((int) $recipient['id'])['money']);
    }

    public function testTradeTransferMovesItems(): void
    {
        $sender = $this->makeUser();
        $recipient = $this->makeUser();
        $itemId = (int) fetch_one('SELECT id FROM items ORDER BY id ASC LIMIT 1', [], 0);
        if ($itemId <= 0) {
            $this->markTestSkipped('no items seeded');
        }
        insert('user_items', ['user_id' => $sender['id'], 'item_id' => $itemId, 'qty' => 3]);

        $id = trade_create((int) $sender['id'], (int) $recipient['id'], [['item_id' => $itemId, 'qty' => 2]], 0, 0, [], 0, 0);
        $this->assertTrue(trade_accept((int) $id, (int) $recipient['id']));
        $this->assertSame(1, (int) fetch_one('SELECT COALESCE(SUM(qty),0) FROM user_items WHERE user_id = ? AND item_id = ?', [(int) $sender['id'], $itemId], 0));
        $this->assertSame(2, (int) fetch_one('SELECT COALESCE(SUM(qty),0) FROM user_items WHERE user_id = ? AND item_id = ?', [(int) $recipient['id'], $itemId], 0));
    }

    public function testSocialCleanupRefundsExpiredContracts(): void
    {
        $placer = $this->makeUser(['money' => 10000]);
        $target = $this->makeUser();

        $hitId = hitlist_add((int) $placer['id'], (int) $target['id'], 2000);
        $bountyId = bounty_create((int) $target['id'], 1500, (int) $placer['id']);
        $this->assertSame(6500, (int) $this->freshUser((int) $placer['id'])['money'], 'escrow is held');

        $past = date('Y-m-d H:i:s', time() - 3600);
        q('UPDATE hitlist SET expires_at = ? WHERE id = ?', [$past, $hitId]);
        q('UPDATE bounties SET expires_at = ? WHERE id = ?', [$past, $bountyId]);

        $result = social_cleanup_expired();
        $this->assertSame(1, $result['hitlist_refunded']);
        $this->assertSame(1, $result['bounties_refunded']);
        $this->assertSame(10000, (int) $this->freshUser((int) $placer['id'])['money'], 'escrow returned');
        $this->assertSame('expired', fetch('SELECT status FROM hitlist WHERE id = ?', [$hitId])['status']);
        $this->assertSame('expired', fetch('SELECT status FROM bounties WHERE id = ?', [$bountyId])['status']);

        // Idempotent: a second sweep refunds nothing more.
        $again = social_cleanup_expired();
        $this->assertSame(0, $again['hitlist_refunded']);
        $this->assertSame(0, $again['bounties_refunded']);
        $this->assertSame(10000, (int) $this->freshUser((int) $placer['id'])['money']);
    }

    public function testSocialCleanupExpiresStaleTrades(): void
    {
        $sender = $this->makeUser();
        $recipient = $this->makeUser();
        $id = trade_create((int) $sender['id'], (int) $recipient['id'], [], 0, 0, [], 0, 0);
        q('UPDATE trades SET expires_at = ? WHERE id = ?', [date('Y-m-d H:i:s', time() - 3600), $id]);

        $result = social_cleanup_expired();
        $this->assertSame(1, $result['trades_expired']);
        $this->assertSame('expired', fetch('SELECT status FROM trades WHERE id = ?', [$id])['status']);
    }

    public function testTradeCannotBeAcceptedByNonRecipient(): void
    {
        $sender = $this->makeUser();
        $recipient = $this->makeUser();
        $id = trade_create((int) $sender['id'], (int) $recipient['id'], [], 0, 0, [], 0, 0);

        // The sender is not the recipient.
        $this->assertFalse(trade_accept((int) $id, (int) $sender['id']));
    }

    public function testCrewChatLifecycle(): void
    {
        $user = $this->makeUser();
        $crewId = insert('crews', ['name' => 'Chat Crew', 'tag' => 'CHT', 'leader_id' => $user['id']]);
        insert('crew_members', ['user_id' => $user['id'], 'crew_id' => $crewId, 'rank' => 'Leader']);

        $mid = crew_message_send((int) $user['id'], (int) $crewId, 'hello crew');
        $this->assertIsInt($mid);
        $this->assertGreaterThan(0, $mid);

        $messages = crew_messages_get((int) $crewId, 50, 0);
        $this->assertCount(1, $messages);
        $this->assertSame('hello crew', $messages[0]['message']);
        $this->assertSame($user['username'], $messages[0]['username']);
    }

    public function testCrewChatRejectsNonMember(): void
    {
        $user = $this->makeUser();
        $outsider = $this->makeUser();
        $crewId = insert('crews', ['name' => 'Private Crew', 'tag' => 'PRV', 'leader_id' => $user['id']]);
        insert('crew_members', ['user_id' => $user['id'], 'crew_id' => $crewId, 'rank' => 'Leader']);

        $this->assertNull(crew_message_send((int) $outsider['id'], (int) $crewId, 'sneaky'));
    }

    public function testSocialNotifications(): void
    {
        $user = $this->makeUser();
        $this->assertSame(0, social_notifications_unread_count((int) $user['id']));

        $id = social_notify((int) $user['id'], 'Test', 'hello', 'bounty_placed', null, 'bounty');
        $this->assertIsInt($id);
        $this->assertSame(1, social_notifications_unread_count((int) $user['id']));

        social_notification_mark_read((int) $id, (int) $user['id']);
        $this->assertSame(0, social_notifications_unread_count((int) $user['id']));
    }

    public function testSocialMarkAllRead(): void
    {
        $user = $this->makeUser();
        social_notify((int) $user['id'], 'Offer', 'msg', 'trade_request', null, 'trade');
        social_notify((int) $user['id'], 'Claimed', 'msg', 'bounty_claimed', null, 'bounty');
        $this->assertSame(2, social_notifications_unread_count((int) $user['id']));

        social_notifications_mark_all_read((int) $user['id']);
        $this->assertSame(0, social_notifications_unread_count((int) $user['id']));
    }

    public function testSocialNotificationLinkMapping(): void
    {
        $this->assertSame('trades.php', social_notification_link(['type' => 'trade_request']));
        $this->assertSame('trades.php', social_notification_link(['type' => 'trade_accepted']));
        $this->assertSame('bounties.php', social_notification_link(['type' => 'bounty_placed']));
        $this->assertSame('bounties.php', social_notification_link(['type' => 'bounty_claimed']));
        $this->assertSame('hitlist.php', social_notification_link(['type' => 'hitlist_placed']));
        $this->assertSame('hitlist.php', social_notification_link(['type' => 'hitlist_claimed']));
        $this->assertSame('crew_chat.php', social_notification_link(['type' => 'chat_mention']));
        $this->assertSame('notifications.php', social_notification_link(['type' => 'unknown']));
        $this->assertSame('notifications.php', social_notification_link([]));
    }

    public function testTradeRejectsUnownedItems(): void
    {
        $sender = $this->makeUser();
        $recipient = $this->makeUser();
        $itemId = (int) fetch_one('SELECT id FROM items ORDER BY id ASC LIMIT 1', [], 0);
        if ($itemId <= 0) {
            $this->markTestSkipped('no items seeded');
        }

        // The sender owns no such item yet, so the offer is refused.
        $this->assertNull(trade_create((int) $sender['id'], (int) $recipient['id'], [['item_id' => $itemId, 'qty' => 1]], 0, 0, [], 0, 0));
    }

    public function testTradeItemsSummary(): void
    {
        $item = fetch('SELECT id, name FROM items ORDER BY id ASC LIMIT 1');
        if (!$item) {
            $this->markTestSkipped('no items seeded');
        }
        $summary = trade_items_summary([['item_id' => (int) $item['id'], 'qty' => 2]]);
        $this->assertStringContainsString($item['name'], $summary);
        $this->assertStringContainsString('x2', $summary);
        $this->assertSame('', trade_items_summary([]));
    }

    public function testCrewMentionNotifiesMembers(): void
    {
        $sender = $this->makeUser();
        $mentioned = $this->makeUser();
        $bystander = $this->makeUser();
        $crewId = insert('crews', ['name' => 'Mention Crew', 'tag' => 'MNT', 'leader_id' => $sender['id']]);
        foreach ([$sender, $mentioned, $bystander] as $m) {
            insert('crew_members', ['user_id' => (int) $m['id'], 'crew_id' => $crewId, 'rank' => 'Member']);
        }

        $mid = crew_message_send((int) $sender['id'], (int) $crewId, 'watch my back @' . $mentioned['username'] . ' !');
        $this->assertIsInt($mid);

        $this->assertSame(1, social_notifications_unread_count((int) $mentioned['id']));
        $this->assertSame(0, social_notifications_unread_count((int) $bystander['id']));
        $this->assertSame(0, social_notifications_unread_count((int) $sender['id']));

        $notif = fetch('SELECT * FROM social_notifications WHERE user_id = ? ORDER BY id DESC LIMIT 1', [(int) $mentioned['id']]);
        $this->assertSame('chat_mention', $notif['type']);
        $this->assertSame('crew_chat.php', social_notification_link($notif));
    }

    public function testCrewUnreadCountTracksReadMarkers(): void
    {
        $user = $this->makeUser();
        $sender = $this->makeUser();
        $crew = $this->makeCrew();
        $this->joinCrew((int) $user['id'], (int) $crew['id']);
        $this->joinCrew((int) $sender['id'], (int) $crew['id']);

        $this->assertSame(0, crew_messages_unread_count((int) $user['id']));
        crew_message_send((int) $sender['id'], (int) $crew['id'], 'first');
        crew_message_send((int) $sender['id'], (int) $crew['id'], 'second');
        $this->assertSame(2, crew_messages_unread_count((int) $user['id']));

        $ids = array_map('intval', array_column(crew_messages_get((int) $crew['id']), 'id'));
        crew_messages_mark_read((int) $user['id'], (int) $crew['id'], $ids);
        $this->assertSame(0, crew_messages_unread_count((int) $user['id']));

        // Your own messages never count as unread.
        $this->assertSame(0, crew_messages_unread_count((int) $sender['id']));
    }
}
