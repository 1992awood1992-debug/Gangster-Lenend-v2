<?php
/**
 * Eye Of The Mafia - Respect System
 * Community reputation: send respect/disrespect daily, profile balance.
 */

require_once __DIR__ . '/init.php';

/**
 * Daily respect points by level (main levels 1-50, then prestige)
 * Levels 1-4: 1, 5-9: 2, 10-14: 3, 15-19: 4, 20-24: 5, 25-29: 6, 30-34: 7, 35-39: 8, 40-44: 9, 45-50: 10
 * Prestige +1 per 5 prestige levels
 */
function respect_get_daily_limit(int $userId): int
{
    $u = fetch('SELECT level, prestige_level FROM users WHERE id = ?', [(int) $userId]);
    if (!$u) return 1;

    $level = (int) $u['level'];
    $prestige = (int) $u['prestige_level'];

    // Main levels 1-50
    if ($level < 50) {
        $base = (int) ceil($level / 5);
        if ($base < 1) $base = 1;
        if ($base > 10) $base = 10;
        return $base;
    }

    // Level 50 = 10, then +1 per 5 prestige levels
    return 10 + (int) ceil($prestige / 5);
}

/**
 * Get total respect sent today by user
 */
function respect_get_sent_today(int $userId): int
{
    $today = date('Y-m-d');
    $count = fetch_one("
        SELECT COALESCE(SUM(ABS(amount)), 0) as total
        FROM respect_log
        WHERE from_user_id = ? AND DATE(created_at) = ?
    ", [(int) $userId, $today], 0);
    return (int) $count;
}

/**
 * Get user's net respect balance
 */
function respect_get_balance(int $userId): int
{
    return (int) fetch_one("
        SELECT COALESCE(SUM(amount), 0) as balance
        FROM respect_log
        WHERE to_user_id = ?
    ", [(int) $userId], 0);
}

/**
 * Send respect/disrespect to another user
 */
function respect_send(int $fromUserId, int $toUserId, int $amount, string $type, bool $anonymous = false, string $message = ''): array
{
    if ($fromUserId === $toUserId) {
        return ['ok' => false, 'error' => 'You cannot send respect to yourself.'];
    }

    $limit = respect_get_daily_limit($fromUserId);
    $sent = respect_get_sent_today($fromUserId);

    if ($sent + $amount > $limit) {
        return ['ok' => false, 'error' => "Daily limit reached. You can send {$limit} respect points per day."];
    }

    if ($amount < 1 || $amount > $limit) {
        return ['ok' => false, 'error' => "Invalid amount. Must be 1-{$limit}."];
    }

    if (!in_array($type, ['respect', 'disrespect'])) {
        return ['ok' => false, 'error' => 'Invalid type.'];
    }

    $toUser = fetch('SELECT id, username FROM users WHERE id = ?', [(int) $toUserId]);
    if (!$toUser) {
        return ['ok' => false, 'error' => 'Recipient not found.'];
    }

    // Apply sign: respect = positive, disrespect = negative
    $signedAmount = $type === 'respect' ? $amount : -$amount;

    insert('respect_log', [
        'from_user_id' => $fromUserId,
        'to_user_id' => $toUserId,
        'amount' => $signedAmount,
        'type' => $type,
        'anonymous' => $anonymous ? 1 : 0,
        'message' => substr($message, 0, 255),
        'created_at' => date('Y-m-d H:i:s'),
    ]);

    // Update recipient's cached net_respect
    $newBalance = respect_get_balance($toUserId);
    q('UPDATE users SET net_respect = ? WHERE id = ?', [$newBalance, $toUserId]);

    // Notify recipient
    $fromName = $anonymous ? 'Someone' : fetch_one('SELECT username FROM users WHERE id = ?', [$fromUserId], 'Someone');
    $typeLabel = $type === 'respect' ? 'Respect' : 'Disrespect';
    $notifyMsg = $anonymous
        ? "You received {$amount} {$typeLabel} from an anonymous sender."
        : "You received {$amount} {$typeLabel} from {$fromName}.";
    if ($message) {
        $notifyMsg .= " Message: \"{$message}\"";
    }
    notify($toUserId, $notifyMsg, 'profile.php?id=' . $toUserId);

    return ['ok' => true, 'remaining' => $limit - $sent - $amount];
}

/**
 * Get recent respect log for a user (received)
 */
function respect_get_received(int $userId, int $limit = 20): array
{
    return fetch_all("
        SELECT rl.*, u.username as from_name
        FROM respect_log rl
        LEFT JOIN users u ON u.id = rl.from_user_id
        WHERE rl.to_user_id = ?
        ORDER BY rl.created_at DESC
        LIMIT ?
    ", [(int) $userId, $limit]);
}

/**
 * Get recent respect log sent by user
 */
function respect_get_sent(int $userId, int $limit = 20): array
{
    return fetch_all("
        SELECT rl.*, u.username as to_name
        FROM respect_log rl
        LEFT JOIN users u ON u.id = rl.to_user_id
        WHERE rl.from_user_id = ?
        ORDER BY rl.created_at DESC
        LIMIT ?
    ", [(int) $userId, $limit]);
}

/**
 * Admin: adjust user's net respect
 */
function respect_admin_adjust(int $userId, int $adjustment, int $adminId): array
{
    $u = fetch('SELECT id, net_respect FROM users WHERE id = ?', [(int) $userId]);
    if (!$u) return ['ok' => false, 'error' => 'User not found'];

    $newBalance = (int) $u['net_respect'] + $adjustment;
    q('UPDATE users SET net_respect = ? WHERE id = ?', [$newBalance, $userId]);

    // Log as system action
    insert('respect_log', [
        'from_user_id' => $adminId,
        'to_user_id' => $userId,
        'amount' => $adjustment,
        'type' => $adjustment > 0 ? 'respect' : 'disrespect',
        'anonymous' => 0,
        'message' => 'Admin adjustment',
        'created_at' => date('Y-m-d H:i:s'),
    ]);

    return ['ok' => true, 'new_balance' => $newBalance];
}

/**
 * Get top respected users (leaderboard)
 */
function respect_get_leaderboard(int $limit = 20): array
{
    return fetch_all("
        SELECT u.id, u.username, u.level, u.net_respect
        FROM users u
        WHERE u.is_banned = 0
        ORDER BY u.net_respect DESC, u.level DESC
        LIMIT ?
    ", [$limit]);
}

/**
 * Get most disrespected users
 */
function respect_get_disrespected(int $limit = 20): array
{
    return fetch_all("
        SELECT u.id, u.username, u.level, u.net_respect
        FROM users u
        WHERE u.is_banned = 0
        ORDER BY u.net_respect ASC, u.level DESC
        LIMIT ?
    ", [$limit]);
}

/**
 * Daily cron: reset daily respect limits (no action needed, uses DATE(created_at))
 * But we can prune old logs if needed
 */
function respect_cron(): array
{
    // Optional: prune respect_log older than 2 years
    $pruned = q("DELETE FROM respect_log WHERE created_at < (NOW() - INTERVAL 2 YEAR)")->rowCount();
    return ['pruned' => $pruned];
}