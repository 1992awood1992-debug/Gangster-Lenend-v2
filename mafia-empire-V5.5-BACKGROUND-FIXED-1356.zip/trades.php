<?php
/**
 * Eye Of The Mafia - Player Trading
 */
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/social.php';

$u = require_login();
$page_title = 'Trades';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create') {
        $recipient = trim($_POST['recipient'] ?? '');
        $recipientUser = fetch('SELECT id FROM users WHERE username = ?', [$recipient]);

        // Collect any items the sender is offering (item_id => qty).
        $senderItems = [];
        foreach (($_POST['trade_item_qty'] ?? []) as $iid => $q) {
            $iid = (int) $iid;
            $q = (int) $q;
            if ($iid > 0 && $q > 0) {
                $senderItems[] = ['item_id' => $iid, 'qty' => $q];
            }
        }

        if (!$recipientUser) {
            $error = 'Player not found.';
        } else {
            $tradeId = trade_create(
                $u['id'],
                (int)$recipientUser['id'],
                $senderItems,
                (int)($_POST['sender_money'] ?? 0),
                (int)($_POST['sender_bullets'] ?? 0),
                [], // recipient items are chosen by the recipient when countering
                (int)($_POST['recipient_money'] ?? 0),
                (int)($_POST['recipient_bullets'] ?? 0)
            );
            if ($tradeId) {
                $success = 'Trade offer sent.';
            } else {
                $error = 'Failed to create trade — make sure you still hold the offered items, cash and bullets.';
            }
        }
    } elseif ($action === 'accept') {
        $tid = (int)($_POST['trade_id'] ?? 0);
        if (trade_accept($tid, $u['id'])) {
            $success = 'Trade accepted and settled.';
        } else {
            $error = 'That trade could not be completed — it may have expired, or one side no longer holds the offered cash, bullets or items.';
        }
    } elseif ($action === 'decline') {
        $tid = (int)($_POST['trade_id'] ?? 0);
        if (trade_decline($tid, $u['id'])) {
            $success = 'Trade declined.';
        } else {
            $error = 'Failed to decline trade.';
        }
    }
}

$pending = trades_get_pending($u['id']);
$inventory = fetch_all(
    'SELECT ui.item_id, SUM(ui.qty) AS qty, i.name
     FROM user_items ui JOIN items i ON i.id = ui.item_id
     WHERE ui.user_id = ? AND ui.equipped = 0
     GROUP BY ui.item_id, i.name
     HAVING SUM(ui.qty) > 0
     ORDER BY i.name ASC',
    [$u['id']]
);

require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <div class="panel-heading">Player Trading</div>
  <p class="muted small">Send and receive trade offers with other players.</p>
</div>

<?php if ($error): ?><div class="alert alert-error" style="margin-top:12px"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success" style="margin-top:12px"><?= e($success) ?></div><?php endif; ?>

<div class="card" style="margin-top:12px">
  <div class="panel-heading">New Trade Offer</div>
  <form method="post" action="trades.php">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">
    <div class="form-row">
      <label>Recipient Username</label>
      <input type="text" name="recipient" class="input" required>
    </div>
    <div class="grid" style="grid-template-columns:1fr 1fr; gap:12px; margin-top:10px">
      <div>
        <h4 style="margin:0 0 6px">You Offer</h4>
        <div class="form-row">
          <label>Money</label>
          <input type="number" name="sender_money" class="input" value="0" min="0">
        </div>
        <div class="form-row">
          <label>Bullets</label>
          <input type="number" name="sender_bullets" class="input" value="0" min="0">
        </div>
        <div class="form-row">
          <label>Items</label>
          <?php if ($inventory): ?>
            <?php foreach ($inventory as $inv): ?>
              <div style="display:flex;align-items:center;gap:8px;margin:4px 0">
                <input type="number" name="trade_item_qty[<?= (int) $inv['item_id'] ?>]" value="0" min="0" max="<?= (int) $inv['qty'] ?>" class="input" style="width:88px">
                <span class="muted small"><?= e($inv['name']) ?> (<?= (int) $inv['qty'] ?> available)</span>
              </div>
            <?php endforeach; ?>
            <p class="muted small" style="margin-top:4px">Only unequipped items can be traded.</p>
          <?php else: ?>
            <p class="muted small">No tradable items in your inventory.</p>
          <?php endif; ?>
        </div>
      </div>
      <div>
        <h4 style="margin:0 0 6px">You Receive</h4>
        <div class="form-row">
          <label>Money</label>
          <input type="number" name="recipient_money" class="input" value="0" min="0">
        </div>
        <div class="form-row">
          <label>Bullets</label>
          <input type="number" name="recipient_bullets" class="input" value="0" min="0">
        </div>
      </div>
    </div>
    <div style="margin-top:10px">
      <button class="btn btn-gold" type="submit">Send Trade Offer</button>
    </div>
  </form>
</div>

<div class="card" style="margin-top:12px">
  <div class="panel-heading">Pending Trade Offers</div>
  <?php if (empty($pending)): ?>
    <p class="muted small">No pending trade offers.</p>
  <?php else: ?>
    <?php foreach ($pending as $p): ?>
      <div class="trade-item" style="padding:10px 0; border-bottom:1px solid var(--line)">
        <div style="display:flex; justify-content:space-between; align-items:center">
          <div>
            <strong>From:</strong> <?= e($p['sender_name']) ?><br>
            <span class="muted small">
              You receive <?= money((int) $p['sender_money']) ?> &amp; <?= number_format((int) $p['sender_bullets']) ?> bullets
              &middot; You give <?= money((int) $p['recipient_money']) ?> &amp; <?= number_format((int) $p['recipient_bullets']) ?> bullets
            </span>
            <?php $pItems = trade_items_summary(is_array($p['sender_items'] ?? null) ? $p['sender_items'] : []); ?>
            <?php if ($pItems !== ''): ?><br><span class="muted small">Items you receive: <?= e($pItems) ?></span><?php endif; ?>
            <br>
            <span class="muted small">Created: <?= e($p['created_at']) ?> | Expires: <?= e($p['expires_at']) ?></span>
          </div>
          <div style="display:flex; gap:6px">
            <form method="post" action="trades.php" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="accept">
              <input type="hidden" name="trade_id" value="<?= (int)$p['id'] ?>">
              <button class="btn btn-sm" type="submit">Accept</button>
            </form>
            <form method="post" action="trades.php" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="decline">
              <input type="hidden" name="trade_id" value="<?= (int)$p['id'] ?>">
              <button class="btn btn-sm btn-ghost" type="submit">Decline</button>
            </form>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
