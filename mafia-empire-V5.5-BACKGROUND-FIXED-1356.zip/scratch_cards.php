<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: buy scratch card
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $cost = 1000;
    if ((int) $u['money'] < $cost) {
        flash('Need $1,000 to buy a scratch card.', 'error');
    } else {
        add_money($u['id'], -$cost, 'Scratch card');
        // Weighted prizes
        $prizes = [
            ['nothing', 0, 45],
            ['cash', 500, 20],
            ['cash', 2000, 15],
            ['bullets', 25, 10],
            ['points', 3, 5],
            ['cash', 10000, 3],
            ['points', 10, 2],
        ];
        $roll = mt_rand(1, 100);
        $cum = 0;
        $won = null;
        foreach ($prizes as $p) { $cum += $p[2]; if ($roll <= $cum) { $won = $p; break; } }
        
        $msg = 'Scratched: ';
        if ($won[0] === 'cash') {
            add_money($u['id'], $won[1], 'Scratch card win');
            $msg .= 'Won ' . money($won[1]) . '!';
        } elseif ($won[0] === 'bullets') {
            add_bullets($u['id'], $won[1]);
            $msg .= 'Won ' . $won[1] . ' bullets!';
        } elseif ($won[0] === 'points') {
            add_points($u['id'], $won[1]);
            $msg .= 'Won ' . $won[1] . ' points!';
        } else {
            $msg .= 'Nothing this time.';
        }
        insert('scratch_cards', ['user_id' => $u['id'], 'prize' => $won[0], 'amount' => $won[1]]);
        flash($msg, $won[0] === 'nothing' ? 'error' : 'success');
    }
    redirect('scratch_cards.php');
}

$page_title = 'Scratch Cards';
require __DIR__ . '/includes/header.php';

$u = current_user();
$history = fetch_all('SELECT * FROM scratch_cards WHERE user_id = ? ORDER BY created_at DESC LIMIT 20', [$u['id']]);
$totalSpent = (int) fetch_one('SELECT COALESCE(SUM(1000),0) FROM scratch_cards WHERE user_id = ?', [$u['id']], 0);
$totalWon = (int) fetch_one('SELECT COALESCE(SUM(amount),0) FROM scratch_cards WHERE user_id = ? AND prize IN (?,?)', [$u['id'], 'cash', 'bullets'], 0);
$totalPoints = (int) fetch_one('SELECT COALESCE(SUM(amount),0) FROM scratch_cards WHERE user_id = ? AND prize = ?', [$u['id'], 'points'], 0);
?>
<div class="card">
  <div class="panel-heading">Scratch Cards</div>
  <p class="muted small">Cost: $1,000 per card. Instant win or lose.</p>
  <div class="grid grid-4">
    <div class="stat"><span>Cash</span><b><?= money($u['money']) ?></b></div>
    <div class="stat"><span>Total Spent</span><b><?= money($totalSpent) ?></b></div>
    <div class="stat"><span>Cash Won</span><b><?= money($totalWon) ?></b></div>
    <div class="stat"><span>Points Won</span><b><?= $totalPoints ?></b></div>
  </div>
  
  <form method="post" style="margin-top:14px">
    <?= csrf_field() ?>
    <button class="btn btn-gold btn-block btn-lg" type="submit">Buy Scratch Card ($1,000)</button>
  </form>
</div>

<div class="card" style="margin-top:18px">
  <div class="panel-heading">Prize Odds</div>
  <div class="table-wrap"><table>
    <tr><th>Prize</th><th>Chance</th></tr>
    <tr><td>Nothing</td><td>45%</td></tr>
    <tr><td>$500</td><td>20%</td></tr>
    <tr><td>$2,000</td><td>15%</td></tr>
    <tr><td>25 Bullets</td><td>10%</td></tr>
    <tr><td>3 Points</td><td>5%</td></tr>
    <tr><td>$10,000</td><td>3%</td></tr>
    <tr><td>10 Points</td><td>2%</td></tr>
  </table></div>
</div>

<div class="card" style="margin-top:18px">
  <div class="panel-heading">Recent History</div>
  <?php if (!$history): ?>
    <p class="muted">No cards scratched yet.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Result</th><th>Amount</th><th>Date</th></tr>
      <?php foreach ($history as $h):
        $color = $h['prize'] === 'nothing' ? 'var(--red)' : 'var(--green)';
      ?>
        <tr>
          <td style="color:<?= $color ?>"><?= ucfirst($h['prize']) ?></td>
          <td><?= $h['prize'] === 'cash' ? money($h['amount']) : ($h['prize'] === 'bullets' ? $h['amount'] . ' bullets' : ($h['prize'] === 'points' ? $h['amount'] . ' pts' : '—')) ?></td>
          <td><?= date('M j, H:i', strtotime($h['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>