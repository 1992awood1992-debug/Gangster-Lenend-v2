<?php
/**
 * Eye Of The Mafia - Sticker Book
 * Modern redesign with album view, progress tracking, and animations
 */
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: buy pack
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $cost = 25;
    if ((int) $u['points'] < $cost) {
        flash('Need 25 points for a sticker pack.', 'error');
    } else {
        add_points($u['id'], -$cost);
        $allStickers = fetch_all('SELECT id, rarity FROM stickers');
        $rarityWeights = ['common' => 60, 'uncommon' => 25, 'rare' => 10, 'epic' => 4, 'legendary' => 1];
        $rand = mt_rand(1, 100);
        $cum = 0;
        $pickRarity = 'common';
        foreach ($rarityWeights as $r => $w) { $cum += $w; if ($rand <= $cum) { $pickRarity = $r; break; } }
        $pool = array_filter($allStickers, fn($s) => $s['rarity'] === $pickRarity);
        if (!$pool) { $pool = $allStickers; }
        $pick = $pool[array_rand($pool)];
        $existing = fetch('SELECT qty FROM user_stickers WHERE user_id = ? AND sticker_id = ?', [$u['id'], $pick['id']]);
        if ($existing) {
            q('UPDATE user_stickers SET qty = qty + 1 WHERE user_id = ? AND sticker_id = ?', [$u['id'], $pick['id']]);
        } else {
            insert('user_stickers', ['user_id' => $u['id'], 'sticker_id' => $pick['id'], 'qty' => 1]);
        }
        flash('Opened a pack! Got ' . e($pick['name']) . ' (' . $pick['rarity'] . ').', 'success');
    }
    redirect('sticker_book.php');
}

$page_title = 'Sticker Book';
require __DIR__ . '/includes/header.php';

$u = current_user();
$stickers = fetch_all('SELECT s.*, us.qty FROM stickers s LEFT JOIN user_stickers us ON us.sticker_id = s.id AND us.user_id = ? ORDER BY FIELD(s.rarity,\'common\',\'uncommon\',\'rare\',\'epic\',\'legendary\'), s.id', [$u['id']]);

$owned = 0;
$totalQty = 0;
$byRarity = ['common' => 0, 'uncommon' => 0, 'rare' => 0, 'epic' => 0, 'legendary' => 0];
$byRarityOwned = ['common' => 0, 'uncommon' => 0, 'rare' => 0, 'epic' => 0, 'legendary' => 0];

foreach ($stickers as $s) {
    $byRarity[$s['rarity']]++;
    if ($s['qty']) {
        $owned++;
        $totalQty += (int) $s['qty'];
        $byRarityOwned[$s['rarity']]++;
    }
}
$completion = count($stickers) > 0 ? round($owned / count($stickers) * 100) : 0;
?>
<div class="sticker-book">
  <header class="sticker-book-header">
    <div class="sticker-book-header-content">
      <div class="sticker-book-title-group">
        <h1 class="sticker-book-title">Sticker Book</h1>
        <p class="sticker-book-subtitle">Collect, trade, and complete your album</p>
      </div>
      <div class="sticker-book-stats">
        <div class="stat-pill">
          <span class="stat-value"><?= number_format((int) $u['points']) ?></span>
          <span class="stat-label">Points</span>
        </div>
        <div class="stat-pill">
          <span class="stat-value"><?= $completion ?>%</span>
          <span class="stat-label">Completion</span>
        </div>
        <div class="stat-pill">
          <span class="stat-value"><?= $owned ?> / <?= count($stickers) ?></span>
          <span class="stat-label">Unique</span>
        </div>
        <div class="stat-pill">
          <span class="stat-value"><?= $totalQty ?></span>
          <span class="stat-label">Total</span>
        </div>
      </div>
    </div>
    
    <div class="sticker-book-progress">
      <div class="progress-ring" style="--progress: <?= $completion ?>%">
        <svg viewBox="0 0 120 120" class="progress-ring-svg">
          <circle class="progress-ring-bg" cx="60" cy="60" r="54" stroke="var(--line)" stroke-width="8" fill="none"/>
          <circle class="progress-ring-fill" cx="60" cy="60" r="54" stroke="var(--gold)" stroke-width="8" fill="none" 
            stroke-dasharray="339.29" stroke-dashoffset="<?= 339.29 * (100 - $completion) / 100 ?>" 
            stroke-linecap="round" transform="rotate(-90 60 60)"/>
        </svg>
        <div class="progress-ring-text">
          <span class="progress-percent"><?= $completion ?>%</span>
          <span class="progress-label">Complete</span>
        </div>
      </div>
      <div class="completion-stats">
        <span class="completion-text"><?= $owned ?> / <?= count($stickers) ?> unique stickers</span>
        <span class="completion-text"><?= $totalQty ?> total stickers</span>
      </div>
    </div>
    
    <div class="sticker-book-actions">
      <form method="post" class="buy-pack-form">
        <?= csrf_field() ?>
        <button class="btn btn-gold btn-lg buy-pack-btn" type="submit" <?= (int)$u['points'] < 25 ? 'disabled' : '' ?>>
          <span class="btn-icon" aria-hidden="true">&#128187;</span>
          <span class="btn-text">Buy Sticker Pack</span>
          <span class="btn-cost"><span class="cost-icon" aria-hidden="true">&#9733;</span> 25 pts</span>
        </form>
        <div class="pack-preview" style="margin-top: 12px;">
          <span class="preview-label">Pack contains:</span>
          <span class="preview-rarity legendary">1 Legendary (1%)</span>
          <span class="preview-rarity epic">4 Epic (4%)</span>
          <span class="preview-rarity rare">10 Rare (10%)</span>
          <span class="preview-rarity uncommon">25 Uncommon (25%)</span>
          <span class="preview-rarity common">60 Common (60%)</span>
        </div>
      </form>
    </div>
  </header>

  <section class="sticker-progress-section">
    <header class="section-header">
      <div class="section-icon" aria-hidden="true">&#128197;</div>
      <div class="section-info">
        <h2 class="section-title">By Rarity</h2>
        <p class="section-desc">Track your collection progress by rarity tier</p>
      </div>
      <div class="completion-badge">
        <span class="completion-percent"><?= $completion ?>%</span>
        <span class="completion-label">Complete</span>
      </div>
    </header>
    <div class="rarity-progress-grid">
      <?php foreach (['common','uncommon','rare','epic','legendary'] as $r):
        $t = $byRarity[$r]; $o = $byRarityOwned[$r];
        $pct = $t > 0 ? round($o / $t * 100) : 0;
        $rarityColors = [
          'common' => ['bg' => 'rgba(160,160,160,0.1)', 'border' => '#a0a0a0', 'text' => '#c0c0c0'],
          'uncommon' => ['bg' => 'rgba(76,175,80,0.1)', 'border' => '#4caf50', 'text' => '#81c784'],
          'rare' => ['bg' => 'rgba(33,150,243,0.1)', 'border' => '#2196f3', 'text' => '#64b5f6'],
          'epic' => ['bg' => 'rgba(156,39,176,0.1)', 'border' => '#9c27b0', 'text' => '#ce93d8'],
          'legendary' => ['bg' => 'rgba(255,193,7,0.1)', 'border' => '#ffc107', 'text' => '#ffd54f'],
        ];
        $colors = $rarityColors[$r];
      ?>
      <div class="rarity-progress-card" style="--rarity-bg: <?= $colors['bg'] ?>; --rarity-border: <?= $colors['border'] ?>; --rarity-text: <?= $colors['text'] ?>">
        <div class="rarity-header">
          <span class="rarity-badge" style="background: var(--rarity-border); color: var(--rarity-text);">
            <?= ucfirst($r) ?>
          </span>
          <span class="rarity-count"><?= $o ?>/<?= $t ?></span>
        </div>
        <div class="rarity-progress-bar">
          <div class="progress-bar" role="progressbar" aria-valuenow="<?= $pct ?>" aria-valuemin="0" aria-valuemax="100">
            <div class="progress-fill" style="width: <?= $pct ?>%"></div>
          </div>
          <span class="progress-label"><?= $pct ?>% (<?= $o ?>/<?= $t ?>)</span>
        </div>
        <div class="rarity-milestone">
          <?php if ($o === $t && $t > 0): ?>
            <span class="milestone-badge complete">&#10003; Complete!</span>
          <?php elseif ($o > 0): ?>
            <span class="milestone-badge progress"><?= $t - $o ?> to go</span>
          <?php else: ?>
            <span class="milestone-badge empty">Not started</span>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="sticker-album-section">
    <header class="section-header">
      <div class="section-icon" aria-hidden="true">&#128197;</div>
      <div class="section-info">
        <h2 class="section-title">Album</h2>
        <p class="section-desc">Your complete sticker collection</p>
      </div>
      <div class="album-filters">
        <select id="rarity-filter" class="filter-select" aria-label="Filter by rarity">
          <option value="all">All Rarities</option>
          <option value="legendary">Legendary</option>
          <option value="epic">Epic</option>
          <option value="rare">Rare</option>
          <option value="uncommon">Uncommon</option>
          <option value="common">Common</option>
        </select>
        <select id="sort-filter" class="filter-select" aria-label="Sort by">
          <option value="rarity">Sort by Rarity</option>
          <option value="name">Sort by Name</option>
          <option value="owned">Owned First</option>
          <option value="quantity">Quantity</option>
        </select>
        <button id="toggle-view" class="icon-btn" aria-label="Toggle view mode" title="Toggle grid/list view">
          <span class="view-icon grid" aria-hidden="true">&#9673;</span>
          <span class="view-icon list" aria-hidden="true">&#9723;</span>
        </button>
      </div>
    </header>
    
    <div class="sticker-album" id="sticker-album">
      <?php foreach ($stickers as $s):
        $has = (int) $s['qty'] > 0;
        $emojiMap = ['tommy_gun'=>'&#128291;','fedora'=>'&#127909;','lucky_cat'=>'&#128049;','cigar'=>'&#128171;','diamond'=>'&#128140;','racehorse'=>'&#128046;','gold_bar'=>'&#128176;','vintage_car'=>'&#128691;','tommy_gun_gold'=>'&#10024;','crime_boss'=>'&#128117;','phoenix'=>'&#128293;','godfather'=>'&#128113;'];
        $emoji = $emojiMap[$s['code']] ?? '&#128204;';
        $rarityClass = 'rarity-' . $s['rarity'];
      ?>
      <article class="sticker-card <?= !$has ? 'locked' : '' ?> rarity-<?= $s['rarity'] ?>" data-rarity="<?= $s['rarity'] ?>" data-name="<?= e($s['name']) ?>" data-owned="<?= $has ? 'true' : 'false' ?>">
        <div class="sticker-inner">
          <div class="sticker-front">
            <div class="sticker-emoji" aria-hidden="true"><?= $emoji ?></div>
            <div class="sticker-name"><?= e($s['name']) ?></div>
            <div class="sticker-rarity rarity-<?= $s['rarity'] ?>"><?= ucfirst($s['rarity']) ?></div>
            <?php if ($has): ?>
              <div class="sticker-qty">x<?= (int) $s['qty'] ?></div>
            <?php endif; ?>
            <?php if (!$has): ?>
              <div class="locked-overlay">
                <span class="lock-icon" aria-hidden="true">&#128274;</span>
                <span class="locked-text">Locked</span>
              </div>
            <?php endif; ?>
          </div>
          <div class="sticker-back">
            <div class="sticker-details">
              <h4><?= e($s['name']) ?></h4>
              <p class="sticker-desc"><?= e($s['description'] ?? 'No description available.') ?></p>
              <div class="sticker-meta">
                <div class="meta-item">
                  <span class="meta-label">Rarity</span>
                  <span class="meta-value rarity-<?= $s['rarity'] ?>"><?= ucfirst($s['rarity']) ?></span>
                </div>
                <div class="meta-item">
                  <span class="meta-label">Code</span>
                  <span class="meta-value"><?= e($s['code']) ?></span>
                </div>
                <?php if ($has): ?>
                  <div class="meta-item">
                    <span class="meta-label">Quantity</span>
                    <span class="meta-value">x<?= (int) $s['qty'] ?></span>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </section>

  <script>
  document.addEventListener('DOMContentLoaded', function() {
    const album = document.getElementById('sticker-album');
    const filter = document.getElementById('rarity-filter');
    const sort = document.getElementById('sort-filter');
    const toggleView = document.getElementById('toggle-view');
    const cards = Array.from(document.querySelectorAll('.sticker-card'));
    
    let viewMode = 'grid';
    
    function filterAndSort() {
      const rarity = filter.value;
      const sortBy = sort.value;
      
      cards.forEach(card => {
        const matchesRarity = rarity === 'all' || card.dataset.rarity === rarity;
        card.style.display = matchesRarity ? '' : 'none';
      });
      
      const visible = cards.filter(c => c.style.display !== 'none');
      visible.sort((a, b) => {
        if (sortBy === 'rarity') {
          const order = {legendary: 5, epic: 4, rare: 3, uncommon: 2, common: 1};
          return order[b.dataset.rarity] - order[a.dataset.rarity];
        }
        if (sortBy === 'name') return a.dataset.name.localeCompare(b.dataset.name);
        if (sortBy === 'owned') return (b.dataset.owned === 'true' ? 1 : 0) - (a.dataset.owned === 'true' ? 1 : 0);
        if (sortBy === 'quantity') return parseInt(b.dataset.qty || 0) - parseInt(a.dataset.qty || 0);
        return 0;
      });
      
      visible.forEach((card, i) => card.style.order = i);
    }
    
    filter.addEventListener('change', filterAndSort);
    sort.addEventListener('change', filterAndSort);
    
    toggleView.addEventListener('click', () => {
      viewMode = viewMode === 'grid' ? 'list' : 'grid';
      album.classList.toggle('list-view', viewMode === 'list');
      toggleView.querySelector('.view-icon.grid').style.display = viewMode === 'grid' ? 'inline' : 'none';
      toggleView.querySelector('.view-icon.list').style.display = viewMode === 'list' ? 'inline' : 'none';
    });
    
    // 3D flip on click
    document.querySelectorAll('.sticker-card').forEach(card => {
      card.addEventListener('click', function(e) {
        if (!e.target.closest('form, button, a, select, button')) {
          this.classList.toggle('flipped');
        }
      });
      
      // Keyboard accessibility
      card.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          this.classList.toggle('flipped');
        }
      });
    });
    
    filterAndSort();
  });
  </script>

<?php require __DIR__ . '/includes/footer.php'; ?>