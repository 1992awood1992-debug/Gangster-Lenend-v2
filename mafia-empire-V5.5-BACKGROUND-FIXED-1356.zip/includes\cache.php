<?php
/**
 * Eye Of The Mafia - Cache helpers
 *
 * Layered cache: Redis when available, otherwise a per-request in-memory
 * array (no cross-request persistence). Safe to use everywhere without
 * extra runtime dependencies.
 * Supports tags for bulk invalidation, stats, and advanced operations.
 */

declare(strict_types=1);

/**
 * Get a shared Redis connection (lazy singleton), or null when unavailable.
 */
function cache_redis(): ?Redis
{
    static $redis = false;
    if ($redis !== false) {
        return $redis;
    }
    if (!extension_loaded('redis')) {
        return $redis = null;
    }
    try {
        $host = getenv('REDIS_HOST') ?: '127.0.0.1';
        $port = (int) (getenv('REDIS_PORT') ?: 6379);
        $password = getenv('REDIS_PASSWORD') ?: null;
        $db = (int) (getenv('REDIS_DB') ?: 0);
        $r = new Redis();
        $r->setOption(Redis::OPT_SERIALIZER, Redis::SERIALIZER_NONE);
        if (!$r->connect('127.0.0.1', 6379, 1)) {
            return $redis = null;
        }
        if ($password) {
            $r->auth($password);
        }
        if ($db) {
            $r->select($db);
        }
        return $redis = $r;
    } catch (Throwable $e) {
        return $redis = null;
    }
}

/**
 * Shared per-request in-memory store (fallback when Redis is unavailable).
 */
function &cache_local_store(): array
{
    static $store = [];
    return $store;
}

/**
 * Read a value from the cache.
 * @param int $ttl seconds
 * @return mixed cached value or null on miss
 */
function cache_get(string $key, int $ttl = 300)
{
    $redis = cache_redis();
    if ($redis) {
        $raw = $redis->get('mafia:' . $key);
        if ($raw === false || $raw === null) {
            return null;
        }
        $data = json_decode($raw, true);
        return is_array($data) && array_key_exists('v', $data) ? $data['v'] : null;
    }
    // Per-request fallback store (shared across get/set/del)
    $local =& cache_local_store();
    if (!isset($local[$key])) {
        return null;
    }
    [$stored, $expires] = $local[$key];
    return $expires >= time() ? $stored : null;
}

/**
 * Store a value with tags for bulk invalidation.
 * @param string[] $tags array of tags to associate with this key
 */
function cache_set_tagged(string $key, $value, int $ttl = 300, array $tags = []): void
{
    $redis = cache_redis();
    $data = json_encode(['v' => $value, 'tags' => $tags, 'ttl' => $ttl]);

    if (cache_redis()) {
        cache_redis()->setex('mafia:' . $key, max(1, $ttl), $data);
        foreach ($tags as $tag) {
            cache_redis()->sAdd('mafia:tag:' . $tag, $key);
        }
        return;
    }
    $local =& cache_local_store();
    $local[$key] = [$value, time() + max(1, $ttl), $tags];
}

/**
 * Invalidate all keys associated with a tag.
 */
function cache_invalidate_tag(string $tag): void
{
    $redis = cache_redis();
    if ($redis) {
        $keys = $redis->sMembers('mafia:tag:' . $tag);
        if ($keys) {
            $redis->del(array_map(fn($k) => 'mafia:' . $k, $keys));
        }
        $redis->del('mafia:tag:' . $tag);
        return;
    }
    // Per-request fallback - cannot efficiently tag without Redis
}

/**
 * Get cache statistics.
 */
function cache_stats(): array
{
    $redis = cache_redis();
    if (!$redis) {
        $local =& cache_local_store();
        return [
            'backend' => 'memory',
            'keys' => count($local),
            'memory_usage' => 'N/A',
            'hit_rate' => 'N/A',
        ];
    }
    $info = $redis->info('stats');
    $memory = $redis->info('memory');
    $keyspace = $redis->info('keyspace');
    $mafiaKeys = 0;
    if (isset($keyspace['db0']['keys'])) {
        $mafiaKeys = $keyspace['db0']['keys'];
    }
    return [
        'backend' => 'redis',
        'keys' => $mafiaKeys,
        'memory_usage' => $memory['used_memory_human'] ?? 'N/A',
        'hit_rate' => isset($info['keyspace_hits'], $info['keyspace_misses']) && ($info['keyspace_hits'] + $info['keyspace_misses'] > 0)
            ? round($info['keyspace_hits'] / ($info['keyspace_hits'] + $info['keyspace_misses']) * 100, 2) . '%'
            : 'N/A',
        'connected_clients' => $redis->info('clients')['connected_clients'] ?? 'N/A',
    ];
}

/**
 * Get all keys matching a pattern (for debugging).
 */
function cache_keys(string $pattern = '*'): array
{
    $redis = cache_redis();
    if (!$redis) {
        $local =& cache_local_store();
        $prefix = 'mafia:';
        $results = [];
        foreach ($local as $key => $value) {
            if (fnmatch('mafia:' . $pattern, $key)) {
                $results[] = substr($key, strlen('mafia:'));
            }
        }
        return $results;
    }
    return $redis->keys('mafia:' . $pattern);
}

/**
 * Check if a key exists.
 */
function cache_has(string $key): bool
{
    $redis = cache_redis();
    if ($redis) {
        return $redis->exists('mafia:' . $key);
    }
    $local =& cache_local_store();
    return isset($local[$key]);
}

/**
 * Get TTL for a key.
 */
function cache_ttl(string $key): int
{
    $redis = cache_redis();
    if ($redis) {
        return (int) $redis->ttl('mafia:' . $key);
    }
    $local =& cache_local_store();
    if (!isset($local[$key])) {
        return -2; // Not found
    }
    return $local[$key][1] - time();
}

/**
 * Increment a numeric value.
 */
function cache_increment(string $key, int $by = 1): int|false
{
    $redis = cache_redis();
    if ($redis) {
        return $redis->incrBy('mafia:' . $key, $by);
    }
    return false; // Not supported in memory store
}

/**
 * Set multiple keys at once.
 */
function cache_mset(array $pairs, int $ttl = 300): void
{
    $redis = cache_redis();
    if ($redis) {
        $pipeline = $redis->multi();
        foreach ($pairs as $key => $value) {
            $pipeline->setex('mafia:' . $key, max(1, $ttl), json_encode(['v' => $value]));
        }
        $pipeline->exec();
        return;
    }
    $local =& cache_local_store();
    foreach ($pairs as $key => $value) {
        $local[$key] = [$value, time() + max(1, $ttl)];
    }
}

/**
 * Get multiple keys at once.
 */
function cache_mget(array $keys): array
{
    $redis = cache_redis();
    if ($redis) {
        $keys = array_map(fn($k) => 'mafia:' . $k, $keys);
        $values = $redis->mGet($keys);
        $result = [];
        foreach ($values as $i => $raw) {
            $key = $keys[$i];
            if ($raw !== false && $raw !== null) {
                $data = json_decode($raw, true);
                $result[$key] = is_array($data) && array_key_exists('v', $data) ? $data['v'] : null;
            } else {
                $result[$key] = null;
            }
        }
        return $result;
    }
    $local =& cache_local_store();
    $result = [];
    foreach ($keys as $key) {
        if (isset($local[$key])) {
            [$stored, $expires] = $local[$key];
            $result[$key] = $expires >= time() ? $stored : null;
        } else {
            $result[$key] = null;
        }
    }
    return $result;
}

/**
 * Cache wrapper around a callable (only invoked on miss).
 */
function cache_remember(string $key, int $ttl, callable $loader)
{
    $hit = cache_get($key, 0); // Don't check TTL here, let the loader handle it
    if ($hit !== null) {
        return $hit;
    }
    $value = $loader();
    cache_set($key, $value, 300);
    return $value;
}

/**
 * Store a value in the cache.
 * @param mixed $value value to cache (must be JSON-safe)
 * @param int $ttl seconds
 */
function cache_set(string $key, $value, int $ttl = 300): void
{
    $redis = cache_redis();
    if ($redis) {
        $redis->setex('mafia:' . $key, max(1, $ttl), json_encode(['v' => $value]));
        return;
    }
    $local =& cache_local_store();
    $local[$key] = [$value, time() + max(1, $ttl)];
}

/**
 * Delete a cache key.
 */
function cache_del(string $key): void
{
    $redis = cache_redis();
    if ($redis) {
        $redis->del('mafia:' . $key);
        return;
    }
    $local =& cache_local_store();
    unset($local[$key]);
}

/**
 * Delete every key sharing a prefix (e.g. 'leaderboard:').
 */
function cache_flush_prefix(string $prefix): void
{
    $redis = cache_redis();
    if (!$redis) {
        return; // per-request cache has no cross-request lifetime to flush
    }
    $keys = $redis->keys('mafia:' . $prefix . '*');
    if ($keys) {
        $redis->del($keys);
    }
}

/**
 * Query cache wrapper for expensive SQL queries.
 * Caches query results with automatic invalidation support.
 */
function cache_query(string $sql, array $params = [], int $ttl = 300, array $tags = []): array
{
    // Create cache key from SQL + params
    $hash = hash('sha256', $sql . '|' . json_encode($params));
    $key = 'query:' . substr($hash, 0, 32);
    
    $cached = cache_get($key);
    if ($cached !== null) {
        return $cached;
    }
    
    $result = fetch_all($sql, $params);
    cache_set_tagged($key, $result, $ttl, $tags);
    return $result;
}

/**
 * Invalidate query cache by tag
 */
function cache_invalidate_query_tag(string $tag): void
{
    cache_invalidate_tag($tag);
}

/**
 * Cache a single row query result
 */
function cache_query_one(string $sql, array $params = [], int $ttl = 300, array $tags = []): mixed
{
    $hash = hash('sha256', $sql . '|' . json_encode($params));
    $key = 'query_one:' . substr($hash, 0, 32);
    
    $cached = cache_get($key);
    if ($cached !== null) {
        return $cached;
    }
    
    $result = fetch($sql, $params);
    cache_set_tagged($key, $result, $ttl, $tags);
    return $result;
}

/**
 * Asset cache busting with CDN support
 */
function asset_cdn(string $path, string $cdnBase = ''): string
{
    $base = $cdnBase ?: (defined('CDN_BASE') ? CDN_BASE : '');
    $url = $base . asset($path);
    return $url;
}

/**
 * Preload critical assets (for HTTP/2 push or preload headers)
 */
function asset_preload(array $paths, string $cdnBase = ''): string
{
    $links = [];
    foreach ($paths as $path) {
        $url = asset_cdn($path, $cdnBase);
        $as = 'style';
        if (str_ends_with($path, '.js')) $as = 'script';
        elseif (preg_match('/\.(woff2?|ttf|otf)$/i', $path)) $as = 'font';
        elseif (preg_match('/\.(png|jpg|jpeg|webp|svg)$/i', $path)) $as = 'image';
        $links[] = "<$url>; rel=preload; as=$as" . ($as === 'font' ? '; crossorigin' : '');
    }
    return implode(', ', $links);
}