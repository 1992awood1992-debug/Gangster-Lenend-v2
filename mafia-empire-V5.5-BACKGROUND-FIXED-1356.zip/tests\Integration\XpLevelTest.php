<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Integration;

use MafiaEmpire\Tests\Support\TestCase;

/**
 * XP granting and level-up side effects.
 */
final class XpLevelTest extends TestCase
{
    public function testXpIsAddedWithoutLevelUp(): void
    {
        $u = $this->makeUser(['xp' => 0, 'level' => 1]);
        $gained = grant_xp((int) $u['id'], 50);
        $this->assertSame(0, $gained);
        $fresh = $this->freshUser((int) $u['id']);
        $this->assertSame(50, (int) $fresh['xp']);
        $this->assertSame(1, (int) $fresh['level']);
    }

    public function testLevelUpRaisesAllCaps(): void
    {
        $u = $this->makeUser([
            'xp' => 0, 'level' => 1,
            'energy' => 50, 'energy_max' => 100,
            'nerve' => 10, 'nerve_max' => 50,
            'health' => 80, 'health_max' => 100,
        ]);

        $gained = grant_xp((int) $u['id'], xp_for_level(3)); // reaches level 3 (+2)

        $this->assertSame(2, $gained);
        $fresh = $this->freshUser((int) $u['id']);
        $this->assertSame(3, (int) $fresh['level']);
        $this->assertSame(110, (int) $fresh['energy_max']); // +5 per level
        $this->assertSame(54, (int) $fresh['nerve_max']);    // +2 per level
        $this->assertSame(120, (int) $fresh['health_max']);  // +10 per level
        $this->assertSame(100, (int) $fresh['health']);      // +10 per level
    }

    public function testLevelUpNotifiesPlayer(): void
    {
        $u = $this->makeUser(['xp' => 0, 'level' => 1]);
        grant_xp((int) $u['id'], xp_for_level(2));
        $notes = fetch_all('SELECT * FROM notifications WHERE user_id = ?', [$u['id']]);
        $this->assertNotEmpty($notes);
        $this->assertStringContainsStringIgnoringCase('level', $notes[0]['text']);
    }

    public function testZeroOrNegativeXpIsNoop(): void
    {
        $u = $this->makeUser(['xp' => 10]);
        $this->assertSame(0, grant_xp((int) $u['id'], 0));
        $this->assertSame(0, grant_xp((int) $u['id'], -5));
        $this->assertSame(10, (int) $this->freshUser((int) $u['id'])['xp']);
    }
}
