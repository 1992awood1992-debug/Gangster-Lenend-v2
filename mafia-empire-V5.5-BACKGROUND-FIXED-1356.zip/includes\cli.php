<?php
/**
 * Mafia Empire - CLI bootstrap for cron & maintenance scripts.
 *
 * Include at the top of any command-line script. It wires up the database
 * layer and shared helpers WITHOUT the web-only behaviour in init.php
 * (no redirect-to-installer, no ban check).
 *
 *   php cron/run.php tick
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("This script may only be run from the command line.\n");
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/game.php';
require_once __DIR__ . '/migrate.php';
require_once __DIR__ . '/webhooks.php';
require_once __DIR__ . '/discord.php';
require_once __DIR__ . '/push.php';
require_once __DIR__ . '/analytics.php';

if (!db_installed()) {
    fwrite(STDERR, "Database is not installed. Run install.php through the web UI first.\n");
    exit(1);
}

/** Write a timestamped line to STDOUT. */
function cli_log(string $msg): void
{
    fwrite(STDOUT, '[' . date('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL);
}

/** Write a timestamped line to STDERR. */
function cli_error(string $msg): void
{
    fwrite(STDERR, '[' . date('Y-m-d H:i:s') . '] ERROR: ' . $msg . PHP_EOL);
}
