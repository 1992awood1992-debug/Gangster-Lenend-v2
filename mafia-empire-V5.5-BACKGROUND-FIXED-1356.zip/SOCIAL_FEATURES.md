# Social Features Implementation

The social features schema (migration `5.sql`) has been created with tables for:
- `trades` - Player-to-player trading with items/money/bullets
- `hitlist` - Players can place hits on others with bounties
- `bounties` - Bounty tracking (separate from hitlist for flexibility)
- `crew_messages` - Crew chat with timestamps
- `crew_message_reads` - Read tracking for crew messages
- `social_notifications` - Social activity notifications

## Status

**Database schema**: Created in `sql/migrations/5.sql` (ready to apply)
**Implementation**: UI/pages and helpers need to be built

## Next Steps

1. Create `includes/social.php` helper functions
2. Create `trades.php` - Trade creation/listing/accept/decline
3. Create `crew_chat.php` - Crew chat interface with read tracking
4. Create `hitlist.php` - View/place hits, claim bounties
5. Create `bounties.php` - Bounty board
6. Wire event tracking for social actions
7. Add navigation links
8. Write PHPUnit tests for social features

See schema in `sql/migrations/5.sql` for full table structure.