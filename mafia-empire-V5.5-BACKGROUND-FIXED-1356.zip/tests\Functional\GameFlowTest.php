<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Functional;

use MafiaEmpire\Tests\Support\Http;
use MafiaEmpire\Tests\Support\TestCase;

/**
 * End-to-end flows driven over HTTP against a running instance:
 * login, criminal job, mission, and an instant casino game.
 *
 * These exercise the page-level controller code that the integration suite
 * cannot reach directly. Skipped unless APP_URL is configured.
 */
final class GameFlowTest extends TestCase
{
    private function requireServer(): void
    {
        if (!Http::configured()) {
            $this->markTestSkipped('Set APP_URL to a running instance to run the functional suite.');
        }
    }

    private function http(): Http
    {
        return new Http(Http::baseUrl());
    }

    public function testLoginReachesDashboard(): void
    {
        $this->requireServer();
        $user = $this->makeUser();

        [$status, $body] = $this->http()->login($user['username'], 'testing123');

        $this->assertSame(200, $status);
        $this->assertStringContainsString($user['username'], $body);
        $this->assertStringContainsString('Cash', $body);
    }

    public function testCriminalJobSpendsNerve(): void
    {
        $this->requireServer();
        $user = $this->makeUser(['nerve' => 50, 'level' => 1]);
        $http = $this->http();
        $http->login($user['username'], 'testing123');

        $job = fetch('SELECT * FROM criminal_jobs ORDER BY min_level ASC, id ASC LIMIT 1');
        $csrf = $http->csrfFrom('/criminal_jobs.php');
        $http->post('/criminal_jobs.php', ['csrf' => $csrf, 'job_id' => $job['id']]);

        $after = $this->freshUser((int) $user['id']);
        $this->assertSame(50 - (int) $job['nerve_cost'], (int) $after['nerve']);
    }

    public function testMissionSpendsEnergy(): void
    {
        $this->requireServer();
        $user = $this->makeUser(['energy' => 100, 'level' => 1]);
        $http = $this->http();
        $http->login($user['username'], 'testing123');

        $mission = fetch('SELECT * FROM missions ORDER BY min_level ASC, id ASC LIMIT 1');
        $csrf = $http->csrfFrom('/missions.php');
        $http->post('/missions.php', ['csrf' => $csrf, 'mission_id' => $mission['id']]);

        $after = $this->freshUser((int) $user['id']);
        $this->assertSame(100 - (int) $mission['energy_cost'], (int) $after['energy']);
    }

    public function testDiceRollPersistsBetAndState(): void
    {
        $this->requireServer();
        $user = $this->makeUser(['money' => 10000]);
        $http = $this->http();
        $http->login($user['username'], 'testing123');

        $csrf = $http->csrfFrom('/dice.php');
        $http->post('/dice.php', ['csrf' => $csrf, 'action' => 'roll', 'bet' => 'over7', 'stake' => 100]);

        $bets = fetch_all('SELECT * FROM casino_bets WHERE user_id = ?', [$user['id']]);
        $this->assertCount(1, $bets);
        $this->assertSame('dice', $bets[0]['game']);
        $this->assertSame(100, (int) $bets[0]['stake']);

        $state = fetch('SELECT state FROM casino_state WHERE user_id = ? AND game = ?', [$user['id'], 'dice']);
        $this->assertNotNull($state['state'] ?? null);
        $decoded = json_decode($state['state'], true);
        $this->assertArrayHasKey('last', $decoded);

        $payout = (int) $decoded['last']['payout'];
        $after = $this->freshUser((int) $user['id']);
        $this->assertSame(10000 - 100 + $payout, (int) $after['money']);
    }
}
