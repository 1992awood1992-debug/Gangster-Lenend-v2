-- 2FA Support (Migration 24)
-- Add two-factor authentication support

-- Add 2FA columns to users table
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS twofa_enabled TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS twofa_secret VARCHAR(32) NULL,
    ADD COLUMN IF NOT EXISTS twofa_backup_codes JSON NULL,
    ADD COLUMN IF NOT EXISTS twofa_last_used DATETIME NULL;

-- 2FA recovery codes table
CREATE TABLE IF NOT EXISTS user_2fa_recovery (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    code_hash VARCHAR(255) NOT NULL,
    used TINYINT(1) NOT NULL DEFAULT 0,
    used_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user (user_id),
    KEY idx_used (used)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Security audit log table
CREATE TABLE IF NOT EXISTS security_audit_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NULL,
    action VARCHAR(50) NOT NULL,
    details JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    success TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user (user_id),
    KEY idx_action (action),
    KEY idx_created (created_at),
    KEY idx_success (success)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- CSP violation log
CREATE TABLE IF NOT EXISTS csp_violations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    document_uri TEXT NULL,
    referrer TEXT NULL,
    blocked_uri TEXT NULL,
    violated_directive VARCHAR(255) NULL,
    original_policy TEXT NULL,
    source_file TEXT NULL,
    line_number INT NULL,
    column_number INT NULL,
    script_sample TEXT NULL,
    user_agent TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Security events table (rate limit violations, failed logins, etc.)
CREATE TABLE IF NOT EXISTS security_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NULL,
    event_type VARCHAR(50) NOT NULL,
    severity ENUM('low','medium','high','critical') NOT NULL DEFAULT 'low',
    details JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user (user_id),
    KEY idx_type (event_type),
    KEY idx_severity (severity),
    KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Update schema version
UPDATE settings SET v = '24' WHERE k = 'schema_version';