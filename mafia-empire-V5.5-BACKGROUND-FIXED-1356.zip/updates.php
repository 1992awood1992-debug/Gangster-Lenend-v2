<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

// POST: new update (admin), vote, comment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'post_update' && (int) $u['is_admin'] === 1) {
        $title = trim($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');
        if ($title && $body) {
            insert('updates', ['title' => $title, 'body' => $body, 'user_id' => $u['id']]);
            flash('Update posted.', 'success');
        }
    } elseif ($action === 'vote') {
        $updateId = (int) ($_POST['update_id'] ?? 0);
        $value = (int) ($_POST['value'] ?? 0);
        if (!in_array($value, [1, -1])) { flash('Invalid vote.', 'error'); }
        else {
            $existing = fetch('SELECT value FROM update_votes WHERE user_id = ? AND update_id = ?', [$u['id'], $updateId]);
            if ($existing) {
                if ($existing['value'] == $value) {
                    q('DELETE FROM update_votes WHERE user_id = ? AND update_id = ?', [$u['id'], $updateId]);
                    flash('Vote removed.', 'success');
                } else {
                    q('UPDATE update_votes SET value = ? WHERE user_id = ? AND update_id = ?', [$value, $u['id'], $updateId]);
                    flash('Vote changed.', 'success');
                }
            } else {
                insert('update_votes', ['user_id' => $u['id'], 'update_id' => $updateId, 'value' => $value]);
                flash('Voted.', 'success');
            }
        }
    } elseif ($action === 'comment') {
        $updateId = (int) ($_POST['update_id'] ?? 0);
        $body = trim($_POST['body'] ?? '');
        if ($body) {
            insert('update_comments', ['update_id' => $updateId, 'user_id' => $u['id'], 'body' => $body]);
            flash('Comment posted.', 'success');
        }
    }
    redirect('updates.php');
}

$page_title = 'Updates';
require __DIR__ . '/includes/header.php';

$updates = fetch_all('SELECT u.*, p.username, p.avatar FROM updates u JOIN users p ON p.id = u.user_id ORDER BY u.created_at DESC');
?>
<div class="card">
  <div class="panel-heading">Game Updates</div>
  <?php if ((int) $u['is_admin'] === 1): ?>
    <form method="post" style="margin-bottom:18px;display:grid;gap:10px;max-width:700px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="post_update">
      <label>Title <input name="title" maxlength="190" required></label>
      <label>Body <textarea name="body" required></textarea></label>
      <button class="btn btn-gold" type="submit">Post Update</button>
    </form>
  <?php endif; ?>
</div>

<?php foreach ($updates as $up):
    $upvotes = (int) fetch_one('SELECT COALESCE(SUM(value),0) FROM update_votes WHERE update_id = ? AND value = 1', [$up['id']], 0);
    $downvotes = (int) fetch_one('SELECT COALESCE(SUM(value),0) FROM update_votes WHERE update_id = ? AND value = -1', [$up['id']], 0);
    $myVote = fetch_one('SELECT value FROM update_votes WHERE user_id = ? AND update_id = ?', [$u['id'], $up['id']], 0);
    $comments = fetch_all('SELECT uc.*, u.username, u.avatar FROM update_comments uc JOIN users u ON u.id = uc.user_id WHERE uc.update_id = ? ORDER BY uc.created_at', [$up['id']]);
?>
<div class="card" style="margin-top:18px">
  <div class="panel-heading"><?= e($up['title']) ?></div>
  <div class="small muted">by <a href="<?= e(url('profile.php?id=' . (int) $up['user_id'])) ?>"><img src="<?= e($up['avatar']) ?>" class="avatar" style="width:20px;height:20px;margin-right:4px;vertical-align:middle" onerror="this.src='<?= e(url('assets/img/avatar-default.svg')) ?>'"><?= e($up['username']) ?></a> · <?= date('M j, Y H:i', strtotime($up['created_at'])) ?></div>
  <div style="margin-top:10px;white-space:pre-wrap"><?= e($up['body']) ?></div>
  
  <div class="pill-row" style="margin-top:14px">
    <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="vote"><input type="hidden" name="update_id" value="<?= (int) $up['id'] ?>"><input type="hidden" name="value" value="1"><button class="pill<?= $myVote == 1 ? ' on' : '' ?>" type="submit">▲ <?= $upvotes ?></button></form>
    <form method="post" style="display:inline;margin-left:8px"><?= csrf_field() ?><input type="hidden" name="action" value="vote"><input type="hidden" name="update_id" value="<?= (int) $up['id'] ?>"><input type="hidden" name="value" value="-1"><button class="pill<?= $myVote == -1 ? ' on' : '' ?>" type="submit">▼ <?= abs($downvotes) ?></button></form>
  </div>
  
  <?php if ($comments): ?>
    <div style="margin-top:18px">
      <?php foreach ($comments as $c): ?>
        <div style="padding:10px;border-bottom:1px dashed var(--line)">
          <b><a href="<?= e(url('profile.php?id=' . (int) $c['user_id'])) ?>"><?= e($c['username']) ?></a></b>
          <span class="muted small"> · <?= date('M j, H:i', strtotime($c['created_at'])) ?></span>
          <div style="margin-top:6px;white-space:pre-wrap"><?= e($c['body']) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  
  <form method="post" style="margin-top:14px;display:grid;gap:8px;max-width:600px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="comment">
    <input type="hidden" name="update_id" value="<?= (int) $up['id'] ?>">
    <label>Comment <textarea name="body" required placeholder="Add a comment..."></textarea></label>
    <button class="btn btn-gold" type="submit">Post Comment</button>
  </form>
</div>
<?php endforeach; ?>

<?php if (!$updates): ?>
<div class="card"><p class="muted">No updates yet.</p></div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>