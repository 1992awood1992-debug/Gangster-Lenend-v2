<?php

declare(strict_types=1);

namespace MafiaEmpire\Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * Crew / territory maths (pure functions — no database required).
 */
final class CrewMathTest extends TestCase
{
    public function testCrewLevelFromTotalXp(): void
    {
        $this->assertSame(1, crew_level(0, 0));
        $this->assertSame(1, crew_level(1999, 0));
        $this->assertSame(2, crew_level(2000, 0));
        $this->assertSame(1, crew_level(1000, 999));
        $this->assertSame(3, crew_level(1000, 3000));
    }

    public function testCrewXpToNext(): void
    {
        $this->assertSame(2000, crew_xp_to_next(0, 0));
        $this->assertSame(1500, crew_xp_to_next(500, 0));
        $this->assertSame(1000, crew_xp_to_next(1000, 0));
        $this->assertSame(2000, crew_xp_to_next(2000, 0));
    }

    public function testZoneIncomeScalesByLevel(): void
    {
        $this->assertSame(100, zone_income(100, 1));
        $this->assertSame(200, zone_income(100, 2));
        $this->assertSame(350, zone_income(100, 3));
        $this->assertSame(500, zone_income(100, 4));
        $this->assertSame(700, zone_income(100, 5));
    }

    public function testZoneIncomeClampsUnknownLevel(): void
    {
        $this->assertSame(100, zone_income(100, 0));
        $this->assertSame(100, zone_income(100, 99));
    }

    public function testZoneIncomeAppliesPerks(): void
    {
        $this->assertSame(875, zone_income(100, 5, ['turf_tycoon']));
        $this->assertSame(770, zone_income(100, 5, ['black_market']));
        $this->assertSame(962, zone_income(100, 5, ['turf_tycoon', 'black_market']));
    }

    public function testZoneCosts(): void
    {
        $this->assertSame(300, zone_claim_cost(100));
        $this->assertSame(400, zone_upgrade_cost(100, 1));
        $this->assertSame(1200, zone_upgrade_cost(100, 3));
    }
}
