<?php
/**
 * Eye Of The Mafia - Weekend Events System
 * Scheduled events per round week with global gameplay multipliers.
 */

require_once __DIR__ . '/init.php';

/**
 * Weekend Event Types and their configuration
 */
const WEEKEND_EVENT_TYPES = [
    'double_xp' => [
        'name' => 'Double XP Weekend',
        'duration_hours' => 48,
        'effect' => ['xp_multiplier' => 2.0],
        'announce' => '📈 Double XP Weekend! All XP gains doubled for 48 hours!',
    ],
    'bullet_rush' => [
        'name' => 'Bullet Rush',
        'duration_hours' => 48,
        'effect' => ['bullet_drop_multiplier' => 2.0, 'bullet_factory_multiplier' => 2.0],
        'announce' => '🔫 Bullet Rush! Bullet drops and factory output doubled for 48 hours!',
    ],
    'looting_spree' => [
        'name' => 'Looting Spree',
        'duration_hours' => 48,
        'effect' => ['looting_yield_multiplier' => 2.0, 'rare_find_chance_multiplier' => 1.5],
        'announce' => '💎 Looting Spree! Looting yields doubled and rare finds increased for 48 hours!',
    ],
    'motor_madness' => [
        'name' => 'Motor Madness',
        'duration_hours' => 48,
        'effect' => ['vehicle_theft_chance_bonus' => 0.25, 'race_payout_multiplier' => 1.5],
        'announce' => '🏎️ Motor Madness! Vehicle theft chance +25% and race payouts ×1.5 for 48 hours!',
    ],
    'crush_rush' => [
        'name' => 'Crush Rush',
        'duration_hours' => 48,
        'effect' => ['pvp_damage_multiplier' => 1.25, 'heal_cost_reduction' => 0.5],
        'announce' => '👊 Crush Rush! PvP damage ×1.25 and hospital costs halved for 48 hours!',
    ],
];

/**
 * Get the current round week (1-based, resets each round)
 * For now, use a simple week-of-year; admin can adjust via weekend_events table
 */
function weekend_event_get_current_week(): int
{
    $roundStart = (int) fetch_one("SELECT v FROM settings WHERE k = 'round_start_timestamp'", [], strtotime('2026-01-01'));
    $weeksSince = max(1, (int) floor((time() - $roundStart) / (7 * 86400)) + 1);
    return $weeksSince;
}

/**
 * Get active weekend event for current week
 */
function weekend_event_get_active(): ?array
{
    $week = weekend_event_get_current_week();
    $now = date('Y-m-d H:i:s');

    $ev = fetch("
        SELECT * FROM weekend_events
        WHERE week = ? AND is_active = 1
        AND start_at <= ? AND end_at > ?
        LIMIT 1
    ", [$week, $now, $now]);

    if (!$ev) return null;

    return [
        'id' => (int) $ev['id'],
        'event_type' => $ev['event_type'],
        'week' => (int) $ev['week'],
        'name' => WEEKEND_EVENT_TYPES[$ev['event_type']]['name'] ?? $ev['event_type'],
        'start_at' => $ev['start_at'],
        'end_at' => $ev['end_at'],
        'effect' => WEEKEND_EVENT_TYPES[$ev['event_type']]['effect'] ?? [],
        'remaining_seconds' => max(0, (new DateTime($ev['end_at']))->getTimestamp() - time()),
    ];
}

/**
 * Get all weekend events (for admin UI)
 */
function weekend_event_get_all(): array
{
    return fetch_all("
        SELECT * FROM weekend_events ORDER BY week
    ");
}

/**
 * Apply a weekend event's gameplay effect
 */
function weekend_event_apply_effect(string $eventType, array $effect): void
{
    foreach ($effect as $key => $value) {
        q("INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)",
            ["weekend_event_{$key}", (string) $value]);
    }
    // Mark event as active for quick checks
    q("INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)",
        ['weekend_event_active', $eventType]);
}

/**
 * Remove a weekend event's gameplay effect
 */
function weekend_event_remove_effect(string $eventType): void
{
    $effect = WEEKEND_EVENT_TYPES[$eventType]['effect'] ?? [];
    foreach ($effect as $key => $value) {
        q("DELETE FROM settings WHERE k = ?", ["weekend_event_{$key}"]);
    }
    q("DELETE FROM settings WHERE k = 'weekend_event_active'");
}

/**
 * Announce a weekend event globally
 */
function weekend_event_announce(string $message): void
{
    // 1. Add to city ticker
    $tickerKey = 'ticker:weekend_event';
    $existing = cache_get($tickerKey) ?? [];
    array_unshift($existing, $message);
    if (count($existing) > 3) $existing = array_slice($existing, 0, 3);
    cache_set($tickerKey, $existing, 3600); // 1 hour TTL

    // 2. Discord
    if (function_exists('discord_notify')) {
        try { discord_notify("🌐 **Weekend Event**\n$message"); } catch (Throwable $e) {}
    }

    // 3. Notify all users (these are major events - notify everyone)
    $users = fetch_all('SELECT id FROM users WHERE is_banned = 0');
    foreach ($users as $u) {
        notify((int) $u['id'], $message, 'events.php');
    }
}

/**
 * Daily cron task: activate/expire weekend events per schedule
 * Returns summary array for task_daily() logging
 */
function weekend_event_cron(): array
{
    $result = ['activated' => 0, 'expired' => 0, 'current_week' => weekend_event_get_current_week()];

    $week = weekend_event_get_current_week();
    $now = date('Y-m-d H:i:s');

    // Check if this week's event should be active
    $ev = fetch("
        SELECT * FROM weekend_events
        WHERE week = ? AND is_active = 1
        ORDER BY start_at ASC
        LIMIT 1
    ", [$week]);

    if ($ev) {
        $started = $ev['start_at'] <= $now;
        $ended = $ev['end_at'] <= $now;

        if ($started && !$ended) {
            // Event should be active - apply effects if not already
            $activeKey = fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '');
            if ($activeKey !== $ev['event_type']) {
                weekend_event_apply_effect($ev['event_type'], WEEKEND_EVENT_TYPES[$ev['event_type']]['effect'] ?? []);
                $cityName = fetch_one('SELECT name FROM districts WHERE id = (SELECT id FROM districts ORDER BY RAND() LIMIT 1)', [], 'the city');
                $msg = sprintf(WEEKEND_EVENT_TYPES[$ev['event_type']]['announce'] ?? 'Weekend event started!', $cityName);
                weekend_event_announce($msg);
                $result['activated'] = 1;
                $result['event_type'] = $ev['event_type'];
            }
        } elseif ($ended) {
            // Event expired - remove effects
            $activeKey = fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '');
            if ($activeKey === $ev['event_type']) {
                weekend_event_remove_effect($ev['event_type']);
                $result['expired'] = 1;
                $result['event_type'] = $ev['event_type'];
            }
        }
    }

    return $result;
}

/**
 * Get current active weekend event for display
 */
function weekend_event_get_active_for_display(): ?array
{
    return weekend_event_get_active();
}

/**
 * Helper: Get XP multiplier from weekend event (if active)
 */
function weekend_event_get_xp_multiplier(): float
{
    if (fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '') !== 'double_xp') {
        return 1.0;
    }
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_xp_multiplier'", [], 1.0);
}

/**
 * Helper: Get bullet drop multiplier from weekend event
 */
function weekend_event_get_bullet_drop_multiplier(): float
{
    if (fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '') !== 'bullet_rush') {
        return 1.0;
    }
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_bullet_drop_multiplier'", [], 1.0);
}

/**
 * Helper: Get bullet factory multiplier from weekend event
 */
function weekend_event_get_bullet_factory_multiplier(): float
{
    if (fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '') !== 'bullet_rush') {
        return 1.0;
    }
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_bullet_factory_multiplier'", [], 1.0);
}

/**
 * Helper: Get looting yield multiplier from weekend event
 */
function weekend_event_get_looting_multiplier(): float
{
    if (fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '') !== 'looting_spree') {
        return 1.0;
    }
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_looting_yield_multiplier'", [], 1.0);
}

/**
 * Helper: Get vehicle theft chance bonus from weekend event
 */
function weekend_event_get_vehicle_theft_bonus(): float
{
    if (fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '') !== 'motor_madness') {
        return 0.0;
    }
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_vehicle_theft_chance_bonus'", [], 0.0);
}

/**
 * Helper: Get race payout multiplier from weekend event
 */
function weekend_event_get_race_payout_multiplier(): float
{
    if (fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '') !== 'motor_madness') {
        return 1.0;
    }
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_race_payout_multiplier'", [], 1.0);
}

/**
 * Helper: Get PvP damage multiplier from weekend event
 */
function weekend_event_get_pvp_damage_multiplier(): float
{
    if (fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '') !== 'crush_rush') {
        return 1.0;
    }
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_pvp_damage_multiplier'", [], 1.0);
}

/**
 * Helper: Get heal cost reduction from weekend event
 */
function weekend_event_get_heal_cost_reduction(): float
{
    if (fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_active'", [], '') !== 'crush_rush') {
        return 0.0;
    }
    return (float) fetch_one("SELECT v FROM settings WHERE k = 'weekend_event_heal_cost_reduction'", [], 0.0);
}

/**
 * Admin: manually toggle a weekend event
 */
function weekend_event_toggle(int $eventId): array
{
    $ev = fetch('SELECT * FROM weekend_events WHERE id = ?', [(int) $eventId]);
    if (!$ev) return ['ok' => false, 'error' => 'Event not found'];

    $newStatus = (int) $ev['is_active'] === 1 ? 0 : 1;
    q('UPDATE weekend_events SET is_active = ? WHERE id = ?', [$newStatus, (int) $eventId]);

    if ($newStatus === 1) {
        weekend_event_apply_effect($ev['event_type'], WEEKEND_EVENT_TYPES[$ev['event_type']]['effect'] ?? []);
        $msg = sprintf(WEEKEND_EVENT_TYPES[$ev['event_type']]['announce'] ?? 'Weekend event started!', 'the city');
        weekend_event_announce($msg);
    } else {
        weekend_event_remove_effect($ev['event_type']);
    }

    return ['ok' => true, 'is_active' => $newStatus];
}