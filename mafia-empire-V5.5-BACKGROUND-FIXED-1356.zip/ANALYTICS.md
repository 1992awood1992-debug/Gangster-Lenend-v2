# Analytics & Telemetry

## Current Status — IMPLEMENTED

Lightweight, dependency-free event tracking is live:

- **Table**: `analytics_events` (migration `sql/migrations/7.sql`)
  `id, event_type, user_id, meta JSON, created_at` with indexes on
  `(event_type, created_at)` and `user_id`.
- **Helpers**: `includes/analytics.php`
  - `analytics_track($eventType, ?$userId, $meta)` — best-effort, never throws
  - `analytics_count_since($eventType, $hours = 24)`
  - `analytics_unique_users_since($eventType, $hours = 24)`
  - `analytics_daily($eventType, $days = 14)` — per-day counts (oldest first)
  - `analytics_active_users_daily($days = 14)` — distinct active users/day (DAU)
  - `analytics_prune($days = 30)` — retention window, called by the daily cron
- **Admin UI**: Admin Panel → **Analytics** tab
  - 24h KPIs (logins, registrations, missions, crimes, kills, fights lost)
  - 14-day active-user bar chart
  - 14-day daily-events matrix

## Tracked Events

| Event | Where | Meta |
|-------|-------|------|
| `login` | `login.php` | `via` |
| `register` | `register.php` | `referred` |
| `mission_complete` / `mission_fail` | `missions.php` | `mission_id`, `reward_money` |
| `crime_complete` / `crime_fail` | `criminal_jobs.php` | `job_id`, `payout` |
| `kill` / `lost_fight` | `kill.php` | `victim` / `vs`, `stolen` |

Adding more is one line: `analytics_track('event', $userId, ['k' => 'v'])`.

## Retention & Housekeeping

Raw rows are pruned after **30 days** by the `daily` cron task
(`task_daily()` → `analytics_prune(30)`). Raise/lower the window in
`includes/tasks.php`. For long-term trends, add a rollup table before
pruning (future work) or export to an external service.

## Privacy

- No PII beyond integer user IDs (no raw IPs, no emails).
- `meta` holds only gameplay identifiers (mission/job ids, amounts).
- GDPR/erasure: rows reference `user_id`; a user-deletion routine should
  `DELETE FROM analytics_events WHERE user_id = ?`.

## Next Steps (optional)

- Cohort/retention (1d/7d/30d) rollups
- Funnel: register → first mission → first kill
- Technical metrics (error rate, cron success) — pending dedicated storage
