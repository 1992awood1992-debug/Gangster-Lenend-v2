<?php
/**
 * Mafia Empire - City Events / News ticker data
 * Rotating city news shown in the topbar ticker and events page.
 */
$cityEvents = [
    ['The Mayor was found with a horse head in his bed.', 'warning'],
    ['New protection racket operations in Chinatown.', 'info'],
    ['Dock workers strike — cargo delayed.', 'warning'],
    ['Lucky sevens hit at The Velvet Room casino.', 'success'],
    ['Police raid on Speakeasy District 7.', 'error'],
    ['New Arms Dealer opened in The Suburbs.', 'info'],
    ['Triad war escalates — avoid Little Italy.', 'error'],
    ['High-roller baccarat table now open.', 'success'],
    ['City Council bribery scandal uncovered.', 'warning'],
    ['Black market rare vehicles arrived.', 'info'],
    ['Hitlist bounty doubled for top targets.', 'success'],
    ['Bullet Factory production increased 20%.', 'info'],
    ['Gym memberships half-price this weekend.', 'success'],
    ['Rival crew claims Downtown district.', 'error'],
    ['Underground fight club relocates.', 'info'],
];
function get_city_events() {
    global $cityEvents;
    return $cityEvents;
}
