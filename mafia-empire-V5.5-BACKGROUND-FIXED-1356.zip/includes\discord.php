<?php
/**
 * Mafia Empire - Discord integration.
 *
 * Two independent pieces:
 *   1. Outbound notifications: post rich messages to a configured channel
 *      webhook (DISCORD_WEBHOOK_URL). Used by the daily digest cron task.
 *   2. Inbound slash commands: discord/interactions.php verifies Discord's
 *      Ed25519 signature and answers /stats, /leaderboard and /serverstat.
 *
 * Signature verification needs the sodium extension. Without it the inbound
 * endpoint refuses requests rather than trusting an unverified payload.
 */
require_once __DIR__ . '/db.php';

function discord_webhook_url(): string
{
    return defined('DISCORD_WEBHOOK_URL') ? (string) DISCORD_WEBHOOK_URL : '';
}

function discord_enabled(): bool
{
    return discord_webhook_url() !== '';
}

function discord_admin_ids(): array
{
    $raw = defined('DISCORD_ADMIN_IDS') ? (string) DISCORD_ADMIN_IDS : '';
    return array_values(array_filter(array_map('trim', explode(',', $raw))));
}

/**
 * Verify Discord's Ed25519 request signature.
 * Returns false when sodium is unavailable (so callers must fail closed).
 */
function discord_verify_signature(string $timestamp, string $body, string $signature): bool
{
    if (!function_exists('sodium_crypto_sign_verify_detached')) {
        return false;
    }
    $publicKey = @hex2bin(defined('DISCORD_PUBLIC_KEY') ? (string) DISCORD_PUBLIC_KEY : '');
    $sig       = @hex2bin($signature);
    if ($publicKey === false || $sig === false) {
        return false;
    }
    if (strlen($publicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) {
        return false;
    }
    return sodium_crypto_sign_verify_detached($sig, $timestamp . $body, $publicKey);
}

/** A PONG reply to Discord's PING (type 1). */
function discord_ping_response(): array
{
    return ['type' => 1];
}

/** An immediate channel message reply (type 4). */
function discord_message_response(string $content, bool $ephemeral = false): array
{
    $data = ['content' => $content];
    if ($ephemeral) {
        $data['flags'] = 64; // EPHEMERAL
    }
    return ['type' => 4, 'data' => $data];
}

/** A rich embed response. */
function discord_embed_response(string $title, array $fields, string $description = ''): array
{
    return ['type' => 4, 'data' => ['embeds' => [[
        'title'       => $title,
        'description' => $description,
        'color'       => 0xD9A441,
        'fields'      => $fields,
    ]]]];
}

/** POST a message (and optional embeds) to the configured channel webhook. */
function discord_notify(string $content, array $embeds = []): array
{
    $url = discord_webhook_url();
    if ($url === '') {
        return [false, 0, 'Discord webhook not configured'];
    }
    if (!function_exists('curl_init')) {
        return [false, 0, 'curl extension not available'];
    }
    $body = json_encode(array_filter([
        'content' => $content,
        'embeds'  => $embeds ?: null,
    ]), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => WEBHOOK_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => WEBHOOK_TIMEOUT,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    ]);
    curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = (string) curl_error($ch);
    curl_close($ch);
    $ok = $code >= 200 && $code < 300;
    return [$ok, $code, $ok ? '' : ($err !== '' ? $err : 'HTTP ' . $code)];
}

/** Build a leaderboard embed for a given board. */
function discord_leaderboard_embed(string $board, int $limit = 10): array
{
    $order = [
        'level' => 'level DESC, xp DESC',
        'kills' => 'kills DESC',
        'cash'  => '(money + bank) DESC',
    ][$board] ?? null;
    if ($order === null) {
        $board = 'level';
        $order = 'level DESC, xp DESC';
    }
    $limit = max(1, min(25, $limit));
    $rows  = fetch_all("SELECT username, level, kills, (money + bank) AS cash FROM users WHERE is_banned = 0 ORDER BY $order LIMIT $limit");

    $lines = [];
    $i = 1;
    foreach ($rows as $r) {
        $lines[] = sprintf('%d. **%s** — Lv %d · %d kills · %s', $i++, $r['username'], (int) $r['level'], (int) $r['kills'], money((int) $r['cash']));
    }
    return discord_embed_response(
        ucfirst($board) . ' leaderboard',
        [['name' => 'Top ' . count($rows), 'value' => $lines ? implode("\n", $lines) : 'No players yet.', 'inline' => false]]
    );
}

/**
 * Resolve an incoming interaction payload into a response payload.
 * Pure-ish: only reads the database for command data.
 */
function discord_handle_interaction(array $interaction): array
{
    $type = (int) ($interaction['type'] ?? 0);
    if ($type === 1) {
        return discord_ping_response(); // PING handshake
    }
    if ($type !== 2) {
        return discord_message_response('Unsupported interaction.', true);
    }

    $name = (string) ($interaction['data']['name'] ?? '');
    $opts = [];
    foreach (($interaction['data']['options'] ?? []) as $opt) {
        if (isset($opt['name'])) {
            $opts[(string) $opt['name']] = $opt['value'] ?? null;
        }
    }

    switch ($name) {
        case 'stats':
            return discord_command_stats((string) ($opts['username'] ?? ''));

        case 'profile':
            return discord_command_profile($opts);

        case 'leaderboard':
            $board = (string) ($opts['board'] ?? 'level');
            $limit = (int) ($opts['limit'] ?? 10);
            return discord_leaderboard_embed($board, $limit);

        case 'serverstat':
            if (!discord_is_admin($interaction)) {
                return discord_message_response('You do not have permission to run this command.', true);
            }
            return discord_command_serverstat();

        case 'event':
            return discord_command_event();

        case 'eventlist':
            return discord_command_eventlist();

        case 'market':
            return discord_command_market($opts);

        case 'crew':
            return discord_command_crew($opts);

        case 'minigame':
            return discord_command_minigame($opts);

        default:
            return discord_message_response('Unknown command.', true);
    }
}

/** Is the invoking Discord member in the admin allow-list? */
function discord_is_admin(array $interaction): bool
{
    $ids = discord_admin_ids();
    if (!$ids) {
        return false;
    }
    $invoker = (string) ($interaction['member']['user']['id'] ?? $interaction['user']['id'] ?? '');
    return $invoker !== '' && in_array($invoker, $ids, true);
}

function discord_command_stats(string $username): array
{
    $username = trim($username);
    if ($username === '') {
        return discord_message_response('Usage: /stats username:<player>', true);
    }
    $u = fetch('SELECT * FROM users WHERE username = ?', [$username]);
    if (!$u) {
        return discord_message_response('No player named "' . $username . '".', true);
    }
    return discord_embed_response('📊 ' . $u['username'], [
        ['name' => 'Level',  'value' => (string) (int) $u['level'],                       'inline' => true],
        ['name' => 'Cash',   'value' => money((int) $u['money'] + (int) $u['bank']),      'inline' => true],
        ['name' => 'Points', 'value' => number_format((int) $u['points']),                'inline' => true],
        ['name' => 'Kills',  'value' => (string) (int) $u['kills'],                       'inline' => true],
        ['name' => 'Deaths', 'value' => (string) (int) $u['deaths'],                      'inline' => true],
        ['name' => 'Bullets','value' => number_format((int) $u['bullets']),               'inline' => true],
    ], 'A snapshot of ' . $u['username'] . "'s empire.");
}

function discord_command_serverstat(): array
{
    $players = (int) fetch_one('SELECT COUNT(*) FROM users', [], 0);
    $crews   = (int) fetch_one('SELECT COUNT(*) FROM crews', [], 0);
    $kills   = (int) fetch_one('SELECT COUNT(*) FROM kill_log', [], 0);
    $cash    = (int) fetch_one('SELECT COALESCE(SUM(money + bank), 0) FROM users', [], 0);
    return discord_embed_response('🏙️ ' . SITE_NAME . ' — server stats', [
        ['name' => 'Players', 'value' => number_format($players), 'inline' => true],
        ['name' => 'Crews',   'value' => number_format($crews),   'inline' => true],
        ['name' => 'Kills',   'value' => number_format($kills),   'inline' => true],
        ['name' => 'Cash in play', 'value' => money($cash),       'inline' => true],
    ]);
}

/**
 * /profile - show player profile with prestige, respect, stats
 */
function discord_command_profile(array $opts): array
{
    $username = trim((string) ($opts['username'] ?? ''));
    if ($username === '') {
        return discord_message_response('Usage: /profile username:<player>', true);
    }
    $u = fetch('SELECT * FROM users WHERE username = ?', [$username]);
    if (!$u) {
        return discord_message_response('No player named "' . $username . '".', true);
    }
    $prestige = (int) $u['prestige_level'];
    $respect = (int) $u['net_respect'];
    $display = $prestige > 0 ? 'P' . $prestige : 'L' . (int) $u['level'];
    return discord_embed_response('📋 ' . $u['username'] . ' — ' . $display, [
        ['name' => 'Level',          'value' => $display,                                              'inline' => true],
        ['name' => 'Prestige Coins', 'value' => number_format((int) $u['prestige_coins']),             'inline' => true],
        ['name' => 'Net Respect',    'value' => number_format((int) $u['net_respect']),                'inline' => true],
        ['name' => 'Cash',           'value' => money((int) $u['money'] + (int) $u['bank']),           'inline' => true],
        ['name' => 'Points',         'value' => number_format((int) $u['points']),                     'inline' => true],
        ['name' => 'Bullets',        'value' => number_format((int) $u['bullets']),                    'inline' => true],
        ['name' => 'Kills / Deaths', 'value' => (int) $u['kills'] . ' / ' . (int) $u['deaths'],       'inline' => true],
        ['name' => 'Wins / Losses',  'value' => (int) $u['wins'] . ' / ' . (int) $u['losses'],        'inline' => true],
        ['name' => 'District',       'value' => fetch_one('SELECT name FROM districts WHERE id = ?', [(int) $u['district_id']], '—'), 'inline' => true],
        ['name' => 'Crew',           'value' => $u['crew_id'] ? (fetch('SELECT name FROM crews WHERE id = ?', [(int) $u['crew_id']])['name'] ?? '—') : 'None', 'inline' => true],
    ], 'Joined ' . date('M j, Y', strtotime($u['created_at'])) . ' | Last active ' . date('M j, Y H:i', strtotime($u['last_active'])));
}

/**
 * /event - show current active mini/weekend/seasonal event
 */
function discord_command_event(): array
{
    require_once __DIR__ . '/mini_events.php';
    require_once __DIR__ . '/weekend_events.php';
    require_once __DIR__ . '/seasonal_events.php';
    require_once __DIR__ . '/deathmatch.php';

    $fields = [];
    $mini = mini_event_get_active_for_display();
    if ($mini) {
        $fields[] = [
            'name' => '🎲 Mini Event: ' . $mini['name'],
            'value' => $mini['city'] . ' — ends in ' . gmdate('H:i:s', $mini['remaining_seconds']),
            'inline' => false,
        ];
    }
    $weekend = weekend_event_get_active_for_display();
    if ($weekend) {
        $fields[] = [
            'name' => '📅 Weekend Event: ' . $weekend['name'],
            'value' => 'Week ' . $weekend['week'] . ' — ends in ' . gmdate('H:i:s', $weekend['remaining_seconds']),
            'inline' => false,
        ];
    }
    $seasonal = seasonal_event_get_active_for_display();
    if ($seasonal) {
        $fields[] = [
            'name' => '🎄 Seasonal: ' . $seasonal['name'],
            'value' => 'Ends ' . date('M j', strtotime($seasonal['end_at'])),
            'inline' => false,
        ];
    }
    $dm = deathmatch_get_status();
    if ($dm['active']) {
        $fields[] = [
            'name' => '💀 Deathmatch: Day ' . $dm['day'] . ($dm['finale'] ? ' FINALE' : ''),
            'value' => 'XP: ' . $dm['config']['xp_multiplier'] . 'x | Ends ' . date('M j H:i', strtotime($dm['round_ends_at'])),
            'inline' => false,
        ];
    }
    if (empty($fields)) {
        $fields[] = ['name' => 'No active events', 'value' => 'Check back later!', 'inline' => false];
    }
    return discord_embed_response('🎯 Current Events', $fields);
}

/**
 * /market - show top marketplace listings
 */
function discord_command_market(array $opts): array
{
    $type = strtolower((string) ($opts['type'] ?? 'all'));
    $limit = min(10, max(1, (int) ($opts['limit'] ?? 5)));
    
    $sql = "
        SELECT l.id, l.item_type, l.item_id, l.qty, l.bid_price, l.buyout_price, l.seller_id,
               u.username as seller_name, i.name as item_name
        FROM market_listings l
        JOIN users u ON u.id = l.seller_id
        JOIN items i ON i.id = l.item_id
        WHERE l.status = 'open'
    ";
    if ($type !== 'all') {
        $sql .= " AND l.item_type = ?";
        $rows = fetch_all($sql . " ORDER BY l.created_at DESC LIMIT ?", [$type, $limit]);
    } else {
        $rows = fetch_all($sql . " ORDER BY l.created_at DESC LIMIT ?", [$limit]);
    }

    if (!$rows) {
        return discord_message_response('No active listings.', true);
    }

    $lines = [];
    foreach ($rows as $r) {
        $price = (int) $r['buyout_price'] > 0 ? money((int) $r['buyout_price']) : 'Bid: ' . money((int) $r['bid_price']);
        $lines[] = sprintf('**%s** x%d — %s (Seller: %s)', $r['item_name'], (int) $r['qty'], $price, $r['seller_name']);
    }

    return discord_embed_response('🛒 Marketplace — Top Listings', [
        ['name' => 'Active Listings', 'value' => implode("\n", $lines), 'inline' => false],
    ]);
}

/**
 * /crew - show crew info
 */
function discord_command_crew(array $opts): array
{
    $name = trim((string) ($opts['name'] ?? ''));
    if ($name === '') {
        return discord_message_response('Usage: /crew name:<crew_name>', true);
    }
    $crew = fetch('SELECT * FROM crews WHERE name LIKE ?', ['%' . $name . '%']);
    if (!$crew) {
        return discord_message_response('No crew found matching "' . $name . '".', true);
    }
    $members = fetch_all('SELECT u.username, u.level, cm.rank FROM crew_members cm JOIN users u ON u.id = cm.user_id WHERE cm.crew_id = ?', [(int) $crew['id']]);
    $memberLines = [];
    foreach ($members as $m) {
        $memberLines[] = sprintf('%s **%s** (Lv %d)', $m['rank'], $m['username'], (int) $m['level']);
    }
    return discord_embed_response('👥 ' . $crew['name'] . ' [' . $crew['tag'] . ']', [
        ['name' => 'Leader', 'value' => (fetch('SELECT username FROM users WHERE id = ?', [(int) $crew['leader_id']])['username'] ?? '—'), 'inline' => true],
        ['name' => 'Members', 'value' => (int) $crew['member_count'] . ' / ' . (int) $crew['max_members'], 'inline' => true],
        ['name' => 'Crew XP', 'value' => number_format((int) $crew['xp']), 'inline' => true],
        ['name' => 'Vault', 'value' => money((int) $crew['vault_money']) . ' | ' . number_format((int) $crew['vault_bullets']) . ' bullets | ' . number_format((int) $crew['vault_points']) . ' pts', 'inline' => false],
        ['name' => 'Members', 'value' => $memberLines ? implode("\n", $memberLines) : 'None', 'inline' => false],
    ]);
}

/**
 * /eventlist - list all event types
 */
function discord_command_eventlist(): array
{
    require_once __DIR__ . '/mini_events.php';
    require_once __DIR__ . '/weekend_events.php';
    require_once __DIR__ . '/seasonal_events.php';

    $fields = [
        ['name' => '🎲 Mini Events (Random 1-12h)', 'value' => 'Drug Surge, Bullet Restock, Safe Deposit, Jackpot Boost', 'inline' => false],
        ['name' => '📅 Weekend Events (Weekly Rotation)', 'value' => 'Double XP, Bullet Rush, Looting Spree, Motor Madness, Crush Rush', 'inline' => false],
        ['name' => '🎄 Seasonal Events (Calendar)', 'value' => "Valentine's, Easter, Independence, Halloween, Christmas", 'inline' => false],
        ['name' => '💀 Deathmatch (Final Round Week)', 'value' => '7-day escalation: 2x→25x XP, $5M/min cash finale', 'inline' => false],
    ];
    return discord_embed_response('📅 Event Schedule', $fields);
}

/**
 * /minigame - play a quick mini-game (blackjack, dice, coinflip)
 */
function discord_command_minigame(array $opts): array
{
    $game = strtolower((string) ($opts['game'] ?? ''));
    $bet = max(1, (int) ($opts['bet'] ?? 0));
    
    if ($game === '') {
        return discord_message_response('Usage: /minigame game:<coinflip|dice|highlow> bet:<amount>', true);
    }
    
    // Note: This is a Discord-only simulation, doesn't affect actual game account
    switch ($game) {
        case 'coinflip':
            $result = mt_rand(0, 1) ? 'Heads' : 'Tails';
            $userChoice = strtolower((string) ($opts['choice'] ?? ''));
            $won = $userChoice && ($userChoice === 'heads' || $userChoice === 'h') && $result === 'Heads'
                || ($userChoice === 'tails' || $userChoice === 't') && $result === 'Tails';
            $emoji = $result === 'Heads' ? '🦅' : '🦋';
            return discord_embed_response($emoji . ' Coin Flip: ' . $result, [
                ['name' => 'Your Call', 'value' => $userChoice ? ucfirst($userChoice) : 'None', 'inline' => true],
                ['name' => 'Result', 'value' => $won ? '🎉 YOU WIN!' : '💀 You lose', 'inline' => true],
            ]);
        case 'dice':
            $d1 = mt_rand(1, 6);
            $d2 = mt_rand(1, 6);
            $total = $d1 + $d2;
            return discord_embed_response('🎲 Dice Roll', [
                ['name' => 'Die 1', 'value' => (string) $d1, 'inline' => true],
                ['name' => 'Die 2', 'value' => (string) $d2, 'inline' => true],
                ['name' => 'Total', 'value' => (string) $total, 'inline' => true],
                ['name' => 'Result', 'value' => $total >= 7 ? '🎉 HIGH' : ($total <= 7 ? '🎯 LOW' : '🎲 SEVEN'), 'inline' => false],
            ]);
        case 'highlow':
            $card = mt_rand(1, 13);
            $guess = strtolower((string) ($opts['choice'] ?? ''));
            $nextCard = mt_rand(1, 13);
            $won = ($guess === 'high' || $guess === 'h') && $nextCard > $card
                || ($guess === 'low' || $guess === 'l') && $nextCard < $card;
            return discord_embed_response('🃏 High/Low', [
                ['name' => 'First Card', 'value' => card_name($card), 'inline' => true],
                ['name' => 'Your Guess', 'value' => ucfirst($guess), 'inline' => true],
                ['name' => 'Next Card', 'value' => card_name($nextCard), 'inline' => true],
                ['name' => 'Result', 'value' => $won ? '🎉 CORRECT!' : '💀 WRONG', 'inline' => false],
            ]);
        default:
            return discord_message_response('Games: coinflip (choice: heads/tails), dice, highlow (choice: high/low)', true);
    }
}

function card_name(int $val): string
{
    if ($val === 1) return 'Ace';
    if ($val === 11) return 'Jack';
    if ($val === 12) return 'Queen';
    if ($val === 13) return 'King';
    return (string) $val;
}
