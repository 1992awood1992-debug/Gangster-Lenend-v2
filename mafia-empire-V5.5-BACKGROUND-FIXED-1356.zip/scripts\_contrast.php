<?php
function lum($hex) {
    $hex = ltrim($hex, '#');
    $r = hexdec(substr($hex,0,2))/255;
    $g = hexdec(substr($hex,2,2))/255;
    $b = hexdec(substr($hex,4,2))/255;
    foreach ([$r,$g,$b] as $i => $c) {
        $c = $c <= 0.03928 ? $c/12.92 : pow(($c+0.055)/1.055, 2.4);
        if($i===0) $r=$c; elseif($i===1) $g=$c; else $b=$c;
    }
    return 0.2126*$r + 0.7152*$g + 0.0722*$b;
}
function contrast($fg, $bg) {
    $lf = lum($fg); $lb = lum($bg);
    return round((max($lf,$lb)+0.05)/(min($lf,$lb)+0.05), 2);
}
$bg = '140f0a';
$pairs = [
    'gold #eec362' => 'eec362',
    'accent #d9a441' => 'd9a441',
    'text #ecd9b5' => 'ecd9b5',
    'muted #a18d6c' => 'a18d6c',
    'accent-2 #b8872e' => 'b8872e',
    'green #7a9a54' => '7a9a54',
    'blue #6d97a5' => '6d97a5',
    'purple #9370a8' => '9370a8',
    'red #b8452f' => 'b8452f',
];
foreach ($pairs as $name => $hex) {
    $c = contrast($hex, $bg);
    $aa = $c >= 4.5 ? 'AA ✓' : ($c >= 3 ? 'AA Large ✓' : 'FAIL');
    $aaa = $c >= 7 ? 'AAA ✓' : ($c >= 4.5 ? 'AAA Large ✓' : '—');
    echo "$name on #$bg: $c:1 -> $aa / $aaa\n";
}