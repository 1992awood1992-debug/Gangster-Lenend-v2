@echo off
REM ---------------------------------------------------------------------------
REM Mafia Empire - database restore (Windows / XAMPP).
REM
REM Restores a .sql dump produced by scripts\backup.bat.
REM   scripts\restore.bat backups\mafia_empire_20260101_120000.sql
REM ---------------------------------------------------------------------------
setlocal

if "%~1"=="" (
    echo Usage: %~nx0 ^<backup.sql^>
    exit /b 1
)
if not exist "%~1" (
    echo File not found: %~1
    exit /b 1
)

set "MYSQL=C:\xampp\mysql\bin\mysql.exe"
set "DB_NAME=mafia_empire"
set "DB_USER=root"

echo This will OVERWRITE database %DB_NAME%.
set /p CONFIRM="Type yes to continue: "
if /i not "%CONFIRM%"=="yes" (
    echo Aborted.
    exit /b 1
)

"%MYSQL%" -u %DB_USER% %DB_NAME% < "%~1"
if errorlevel 1 (
    echo Restore FAILED.
    exit /b 1
)
echo Restore complete from: %~1
endlocal
