<?php
$css = file_get_contents('C:\Users\ash\Documents\Default Project\mafia-empire\assets\style.css');
$lines = explode("\n", $css);
$inNavLink = false;
$braceCount = 0;
foreach ($lines as $i => $line) {
    $num = $i + 1;
    if (preg_match('/\.nav-link\s*\{/', $line)) {
        $inNavLink = true;
        $braceCount = substr_count($line, '{') - substr_count($line, '}');
        echo "Line $num: $line\n";
        continue;
    }
    if ($inNavLink) {
        echo "Line $num: $line\n";
        $braceCount += substr_count($line, '{') - substr_count($line, '}');
        if ($braceCount <= 0) {
            $inNavLink = false;
            echo "---\n";
        }
    }
}