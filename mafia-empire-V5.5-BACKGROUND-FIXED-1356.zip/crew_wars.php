<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

finish_expired_wars();

$crew = $u['crew_id'] ? fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]) : null;
$isLeader = $crew && (int) $crew['leader_id'] === $u['id'];
$isBoss = $crew && in_array($u['crew_rank'], ['Leader', 'Underboss'], true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if ($action === 'declare') {
        if (!$crew) {
            flash('Join a crew to wage war.', 'error');
        } elseif (!$isBoss) {
            flash('Only a Leader or Underboss can declare war.', 'error');
        } else {
            $target = fetch('SELECT * FROM crews WHERE id = ?', [(int) ($_POST['target_id'] ?? 0)]);
            $myLevel = crew_level((int) $crew['xp'], (int) $crew['xp_spent']);
            if (!$target) {
                flash('Crew not found.', 'error');
            } elseif ((int) $target['id'] === (int) $crew['id']) {
                flash('You cannot declare war on yourself.', 'error');
            } elseif ($myLevel < 3) {
                flash('Your crew needs level 3 to declare war.', 'error');
            } elseif (crew_relation((int) $crew['id'], (int) $target['id'])) {
                flash('You cannot declare war on an allied crew.', 'error');
            } elseif (active_war_between((int) $crew['id'], (int) $target['id'])) {
                flash('Your crews are already at war.', 'error');
            } elseif ((int) $crew['money'] < 250000) {
                flash('Your crew needs $250,000 to fund a war.', 'error');
            } else {
                q('UPDATE crews SET money = money - 250000 WHERE id = ?', [$crew['id']]);
                insert('crew_wars', [
                    'attacker_id' => $crew['id'],
                    'defender_id' => $target['id'],
                    'status' => 'active',
                    'attacker_score' => 0,
                    'defender_score' => 0,
                    'ends_at' => date('Y-m-d H:i:s', time() + 86400),
                ]);
                add_crew_xp((int) $crew['id'], 75);
                notify_crew((int) $target['id'], e($crew['name']) . ' has declared war on your crew! Kill their members in 24 hours to win.', 'crew_wars.php');
                notify_crew((int) $crew['id'], 'War declared on ' . e($target['name']) . '. Kill their members to score points! (+75 crew XP)', 'crew_wars.php');
                flash('War declared on ' . e($target['name']) . '!', 'success');
            }
        }
    }
    redirect('crew_wars.php');
}

$page_title = 'Crew Wars';
require __DIR__ . '/includes/header.php';

$activeWars = $crew ? fetch_all(
    "SELECT cw.*, cA.name AS aname, cA.tag AS atag, cD.name AS dname, cD.tag AS dtag
     FROM crew_wars cw
     JOIN crews cA ON cA.id = cw.attacker_id
     JOIN crews cD ON cD.id = cw.defender_id
     WHERE cw.status IN ('declared','active') AND (cw.attacker_id = ? OR cw.defender_id = ?)
     ORDER BY cw.started_at DESC", [$crew['id'], $crew['id']]
) : [];

$history = $crew ? fetch_all(
    "SELECT cw.*, cA.name AS aname, cD.name AS dname, cWin.name AS wname
     FROM crew_wars cw
     JOIN crews cA ON cA.id = cw.attacker_id
     JOIN crews cD ON cD.id = cw.defender_id
     LEFT JOIN crews cWin ON cWin.id = cw.winner_id
     WHERE cw.status = 'finished' AND (cw.attacker_id = ? OR cw.defender_id = ?)
     ORDER BY cw.started_at DESC LIMIT 15", [$crew['id'], $crew['id']]
) : [];

$targets = $crew ? fetch_all(
    "SELECT c.id, c.name, c.tag, c.level, COUNT(cm.user_id) AS members
     FROM crews c
     LEFT JOIN crew_members cm ON cm.crew_id = c.id
     WHERE c.id != ?
     GROUP BY c.id
     ORDER BY c.level DESC, members DESC
     LIMIT 25", [$crew['id']]
) : [];
?>
<div class="card">
  <div class="panel-heading">Crew Wars</div>
  <p class="muted small">Declare war, then kill enemy crew members. Every war kill scores +1 for your side. Highest score when the 24-hour clock runs out wins the war and the crew XP.</p>
  <?php if (!$crew): ?>
    <p class="muted">Join a crew to wage war.</p>
  <?php else: ?>
    <div class="grid grid-4" style="margin-bottom:14px">
      <div class="stat"><span>Crew</span><b><?= e($crew['name']) ?></b></div>
      <div class="stat"><span>Level</span><b><?= crew_level((int) $crew['xp'], (int) $crew['xp_spent']) ?></b></div>
      <div class="stat"><span>War Record</span><b><?= (int) $crew['wars_won'] ?>W / <?= (int) $crew['wars_lost'] ?>L</b></div>
      <div class="stat"><span>Crew Bank</span><b><?= money($crew['money']) ?></b></div>
    </div>
  <?php endif; ?>
</div>

<?php if ($crew && $isBoss): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Declare War <span class="tag tag-common">$250,000 · Crew Lv 3+</span></div>
  <form method="post" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="declare">
    <select name="target_id" required style="min-width:240px">
      <option value="">— Select target crew —</option>
      <?php foreach ($targets as $t):
        if (crew_relation((int) $crew['id'], (int) $t['id']) || active_war_between((int) $crew['id'], (int) $t['id'])) continue;
      ?>
        <option value="<?= (int) $t['id'] ?>"><?= e($t['name']) ?> [<?= e($t['tag']) ?>] (Lv <?= (int) $t['level'] ?>, <?= (int) $t['members'] ?> members)</option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-danger" type="submit">Declare War</button>
  </form>
  <p class="muted small" style="margin-top:8px">Allied or NAP crews are excluded. Wars last 24 hours.</p>
</div>
<?php endif; ?>

<?php if ($crew && $activeWars): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Active Wars</div>
  <div class="table-wrap"><table>
    <tr><th>War</th><th>Score</th><th>Time Left</th><th>Your Side</th></tr>
    <?php foreach ($activeWars as $w):
      $mine = (int) $w['attacker_id'] === (int) $crew['id'];
      $enemyName = $mine ? $w['dname'] : $w['aname'];
      $enemyTag = $mine ? $w['dtag'] : $w['atag'];
      $myScore = $mine ? $w['attacker_score'] : $w['defender_score'];
      $enemyScore = $mine ? $w['defender_score'] : $w['attacker_score'];
      $left = max(0, strtotime($w['ends_at']) - time());
      $h = floor($left / 3600); $m = floor(($left % 3600) / 60);
    ?>
      <tr>
        <td><b><?= e($crew['name']) ?></b> vs <b><?= e($enemyName) ?></b> <span class="tag tag-common">[<?= e($enemyTag) ?>]</span></td>
        <td><b class="text-green"><?= $myScore ?></b> : <b class="text-danger"><?= $enemyScore ?></b></td>
        <td><?= $h ?>h <?= $m ?>m</td>
        <td><span class="tag <?= $mine ? 'tag-legendary' : 'tag-common' ?>"><?= $mine ? 'Attacker (You)' : 'Defender' ?></span></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<?php if ($crew && $history): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">War History</div>
  <div class="table-wrap"><table>
    <tr><th>War</th><th>Score</th><th>Result</th><th>Ended</th></tr>
    <?php foreach ($history as $w): ?>
      <tr>
        <td><?= e($w['aname']) ?> vs <?= e($w['dname']) ?></td>
        <td><?= (int) $w['attacker_score'] ?> : <?= (int) $w['defender_score'] ?></td>
        <td><?= $w['winner_id'] ? (e($w['wname']) . ' won') : '<span class="muted">Draw</span>' ?></td>
        <td><?= date('M j, H:i', strtotime($w['ends_at'])) ?></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<?php if (!$crew): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">City Conflicts</div>
  <p class="muted">The newspapers are full of gang bloodshed. Once you join a crew you can follow the conflicts here.</p>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>