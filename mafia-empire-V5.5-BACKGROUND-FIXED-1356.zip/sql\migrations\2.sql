-- Phase 3: Crew Wars & Territory

-- Crews: XP (spendable) + total spent, war record
ALTER TABLE crews
  ADD COLUMN xp INT NOT NULL DEFAULT 0,
  ADD COLUMN xp_spent INT NOT NULL DEFAULT 0,
  ADD COLUMN wars_won INT NOT NULL DEFAULT 0,
  ADD COLUMN wars_lost INT NOT NULL DEFAULT 0;

-- Territory zones (districts split into turf)
CREATE TABLE IF NOT EXISTS zones (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  district_id INT UNSIGNED NOT NULL,
  name VARCHAR(80) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  base_income INT NOT NULL DEFAULT 500,
  min_crew_level INT NOT NULL DEFAULT 1,
  px INT NOT NULL DEFAULT 0,
  py INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_zone_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Which crew controls each zone + upgrade level + collection cooldown
CREATE TABLE IF NOT EXISTS zone_control (
  zone_id INT UNSIGNED NOT NULL,
  crew_id INT UNSIGNED NOT NULL,
  level INT NOT NULL DEFAULT 1,
  captured_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_collect DATETIME NULL,
  PRIMARY KEY (zone_id),
  KEY idx_crew (crew_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crew wars (declared, lasts 24h, scored by war kills)
CREATE TABLE IF NOT EXISTS crew_wars (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  attacker_id INT UNSIGNED NOT NULL,
  defender_id INT UNSIGNED NOT NULL,
  status ENUM('declared','active','finished') NOT NULL DEFAULT 'declared',
  attacker_score INT NOT NULL DEFAULT 0,
  defender_score INT NOT NULL DEFAULT 0,
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ends_at DATETIME NOT NULL,
  winner_id INT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_attacker (attacker_id),
  KEY idx_defender (defender_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crew vault / armory (shared items)
CREATE TABLE IF NOT EXISTS crew_armory (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  crew_id INT UNSIGNED NOT NULL,
  item_id INT UNSIGNED NOT NULL,
  qty INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_crew_item (crew_id, item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crew perks tree (unlocked with crew XP)
CREATE TABLE IF NOT EXISTS crew_perks (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(60) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  cost_xp INT NOT NULL DEFAULT 0,
  requires_code VARCHAR(40) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_perk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crew_unlocked_perks (
  crew_id INT UNSIGNED NOT NULL,
  perk_code VARCHAR(40) NOT NULL,
  unlocked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (crew_id, perk_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Diplomacy: alliance / NAP offers and active pacts
CREATE TABLE IF NOT EXISTS crew_diplomacy (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  crew_a INT UNSIGNED NOT NULL,
  crew_b INT UNSIGNED NOT NULL,
  type ENUM('alliance','nap') NOT NULL,
  status ENUM('pending','active','broken') NOT NULL DEFAULT 'pending',
  declared_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_pair (crew_a, crew_b)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Raid cooldowns (one row per crew + zone attempt)
CREATE TABLE IF NOT EXISTS zone_raids (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  zone_id INT UNSIGNED NOT NULL,
  crew_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_zone_crew (zone_id, crew_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Zone seeds
INSERT INTO zones (district_id, name, description, base_income, min_crew_level, px, py) VALUES
 (1, 'The Corner Market', 'Street stalls and iron shutters - the family\'s bread and butter.', 600, 1, 18, 30),
 (1, 'Speakeasy Row', 'A dozen blind tigers that pour for the right friends.', 750, 1, 42, 22),
 (1, 'Back Alley Garage', 'Where the getaway cars get their getaway.', 900, 1, 66, 40),
 (2, 'Pier 7', 'Cargo comes in at night, and it isn\'t fish.', 1200, 3, 22, 62),
 (2, 'Warehouse District', 'Square miles of crates, tarps, and alibis.', 1400, 3, 48, 70),
 (2, 'The Boathouse', 'Rum-runners drop, we collect. Simple.', 1600, 3, 72, 55),
 (3, 'Cappella Block', 'The chapel is a bank. The bank is a chapel.', 1900, 5, 20, 84),
 (3, 'Olive Oil Terminal', 'Barrels of the stuff. Nobody checks inside.', 2200, 5, 45, 78),
 (3, 'The Piazza', 'Old ladies, old grudges, old money.', 2600, 5, 68, 88),
 (4, 'The Exchange Steps', 'Buy low. Sell high. Threaten medium.', 3200, 8, 24, 46),
 (4, 'Broker\'s Court', 'Suede shoes and loaded accounts.', 3800, 8, 56, 30),
 (4, 'The Mint Yard', 'The city\'s gold, one short truck away.', 4500, 8, 80, 12);

-- Crew perk seeds
INSERT INTO crew_perks (code, name, description, cost_xp, requires_code) VALUES
 ('turf_tycoon', 'Turf Tycoon', '+25% income from all controlled turf.', 1000, NULL),
 ('black_market', 'Black Market Cut', '+10% income from all controlled turf.', 5000, 'turf_tycoon'),
 ('five_points', 'Five Points', '+1 maximum controlled zone.', 1500, NULL),
 ('row_house', 'Row House', '+1 maximum controlled zone.', 3000, 'five_points'),
 ('war_chest', 'War Chest', '+50% crew XP from war victories.', 2000, NULL),
 ('insurance', 'Insurance', 'Halves health lost on failed raids.', 1800, NULL),
 ('mole_network', 'Mole Network', '+15% raid success chance.', 3500, 'insurance'),
 ('recruiter', 'Recruiter', '+4 maximum crew members.', 2500, NULL);