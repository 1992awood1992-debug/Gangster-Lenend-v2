/* ============================================================
   Mafia Empire - service worker v2
   Offline app shell (cache-first static, network-first pages)
   plus Web Push display/click handling, background sync,
   offline action queue with IndexedDB, and native gesture support.
   Scope: the folder this file is served from (the install root).
   ============================================================ */
const VERSION = 'me-v2';
const STATIC_CACHE = VERSION + '-static';
const RUNTIME_CACHE = VERSION + '-runtime';
const OFFLINE_URL = 'offline.html';
const QUEUE_STORE = 'offline_queue';

const PRECACHE = [
  './',
  OFFLINE_URL,
  'manifest.webmanifest',
  'assets/style.css',
  'assets/app.js',
  'assets/img/avatar-default.svg',
  'assets/img/icon-192.png',
  'assets/img/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(STATIC_CACHE);
    // Cache individually so one missing asset can't abort the install.
    await Promise.all(PRECACHE.map(async (u) => {
      try { await cache.add(new Request(u, { cache: 'reload' })); } catch (e) {}
    }));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys.filter((k) => k.indexOf(VERSION) !== 0).map((k) => caches.delete(k))
    );
    // Create IndexedDB for offline queue
    await initQueueDB();
    await self.clients.claim();
  })());
});

const STATIC_RE = /\.(css|js|mjs|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|otf|webmanifest)$/i;

function isBypassed(url) {
  // Never intercept the stateless API, webhooks and Discord endpoints.
  return url.pathname.indexOf('/api/') !== -1
      || url.pathname.indexOf('/discord/') !== -1
      || url.pathname.endsWith('/health.php');
}

/**
 * Initialize IndexedDB for offline action queue
 */
async function initQueueDB() {
  return new Promise((resolve) => {
    const request = indexedDB.open('mafia_empire_offline', 1);
    request.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(QUEUE_STORE)) {
        const store = db.createObjectStore(QUEUE_STORE, { keyPath: 'id', autoIncrement: true });
        store.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => resolve(null);
  });
}

/**
 * Add action to offline queue
 */
async function queueAction(action) {
  const db = await initQueueDB();
  if (!db) return false;
  return new Promise((resolve) => {
    const tx = db.transaction(QUEUE_STORE, 'readwrite');
    tx.objectStore(QUEUE_STORE).add({ ...action, timestamp: Date.now() });
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => resolve(false);
  });
}

/**
 * Process offline queue when back online
 */
async function processQueue() {
  const db = await initQueueDB();
  if (!db) return;
  
  return new Promise((resolve) => {
    const tx = db.transaction(QUEUE_STORE, 'readwrite');
    const store = tx.objectStore(QUEUE_STORE);
    const request = store.getAll();
    
    request.onsuccess = async () => {
      const actions = request.result;
      for (const action of actions) {
        try {
          await fetch(action.url, { method: action.method, headers: action.headers, body: action.body });
          // Remove successful action
          const delTx = db.transaction(QUEUE_STORE, 'readwrite');
          delTx.objectStore(QUEUE_STORE).delete(action.id);
          await new Promise(r => { delTx.oncomplete = r; });
        } catch (e) {
          // Keep failed actions for next retry
        }
      }
      resolve();
    };
    request.onerror = () => resolve();
  });
}

/**
 * Check if online
 */
async function checkOnline() {
  try {
    const resp = await fetch('./', { method: 'HEAD', cache: 'no-cache', signal: AbortSignal.timeout(3000) });
    return resp.ok;
  } catch (e) {
    return false;
  }
}

// Listen for online event
self.addEventListener('online', () => {
  processQueue();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') {
    // POST requests: try network, queue offline
    if (req.method === 'POST') {
      event.respondWith((async () => {
        try {
          const resp = await fetch(req);
          return resp;
        } catch (e) {
          // Queue for background sync
          const clone = req.clone();
          const body = await clone.text();
          await queueAction({
            url: req.url,
            method: req.method,
            headers: Object.fromEntries(clone.headers.entries()),
            body: body,
            timestamp: Date.now()
          });
          // Register for background sync
          if ('sync' in self.registration) {
            await self.registration.sync.register('mafia-sync');
          }
          return new Response(JSON.stringify({ queued: true }), {
            status: 202,
            headers: { 'Content-Type': 'application/json' }
          });
        }
      })());
    }
    return;
  }

  const url = new URL(req.url);
  if (url.origin !== self.location.origin || isBypassed(url)) return;

  // Page navigations: network-first, fall back to cache then offline page.
  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const fresh = await fetch(req);
        const cache = await caches.open(RUNTIME_CACHE);
        cache.put(req, fresh.clone());
        return fresh;
      } catch (e) {
        const cached = await caches.match(req);
        if (cached) return cached;
        const offline = await caches.match(OFFLINE_URL);
        return offline || new Response('Offline', { status: 503, headers: { 'Content-Type': 'text/plain' } });
      }
    })());
    return;
  }

  // Static assets: cache-first, refresh in the background.
  if (STATIC_RE.test(url.pathname)) {
    event.respondWith((async () => {
      const cached = await caches.match(req);
      if (cached) return cached;
      try {
        const fresh = await fetch(req);
        if (fresh && fresh.status === 200 && fresh.type === 'basic') {
          (await caches.open(STATIC_CACHE)).put(req, fresh.clone());
        }
        return fresh;
      } catch (e) {
        return cached || new Response('', { status: 504 });
      }
    })());
    return;
  }

  // Other same-origin GETs: network-first, fall back to runtime cache.
  event.respondWith((async () => {
    try {
      const fresh = await fetch(req);
      if (fresh && fresh.status === 200 && fresh.type === 'basic') {
        (await caches.open(RUNTIME_CACHE)).put(req, fresh.clone());
      }
      return fresh;
    } catch (e) {
      const cached = await caches.match(req);
      return cached || new Response('', { status: 504 });
    }
  })());
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
  if (event.data === 'PROCESS_QUEUE') processQueue();
});

/* ---------------- Background Sync ---------------- */
self.addEventListener('sync', (event) => {
  if (event.tag === 'mafia-sync') {
    event.waitUntil(processQueue());
  }
});

/* ---------------- Web Push ---------------- */
self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (e) {
    data = { title: 'Mafia Empire', body: event.data ? event.data.text() : '' };
  }
  const title = data.title || 'Mafia Empire';
  const options = {
    body: data.body || '',
    icon: data.icon || 'assets/img/icon-192.png',
    badge: 'assets/img/icon-192.png',
    data: { url: data.url || './' },
    tag: data.tag || undefined,
    actions: [
      { action: 'view', title: 'View' },
      { action: 'dismiss', title: 'Dismiss' }
    ]
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || './';
  
  if (event.action === 'dismiss') return;
  
  event.waitUntil((async () => {
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of clients) {
      if ('focus' in c) { try { await c.navigate(target); } catch (e) {} return c.focus(); }
    }
    if (self.clients.openWindow) return self.clients.openWindow(target);
  })());
});

self.addEventListener('notificationclose', (event) => {
  // Track dismissal for analytics
  console.log('Notification closed:', event.notification.tag);
});

/* ---------------- Periodic Background Sync (if supported) ---------------- */
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'mafia-periodic') {
    event.waitUntil((async () => {
      await processQueue();
      // Also refresh critical caches
      const cache = await caches.open(RUNTIME_CACHE);
      const keys = await cache.keys();
      for (const req of keys) {
        if (req.mode === 'navigate') {
          try {
            const fresh = await fetch(req);
            if (fresh.ok) await cache.put(req, fresh);
          } catch (e) {}
        }
      }
    })());
  }
});