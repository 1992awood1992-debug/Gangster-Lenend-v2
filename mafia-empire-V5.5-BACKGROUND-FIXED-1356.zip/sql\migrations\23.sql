-- Stock Market & Pawn Shop (Phase 19) -------------------------------------

-- Stocks table
CREATE TABLE IF NOT EXISTS stocks (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    ticker VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    sector VARCHAR(50) NOT NULL,
    current_price BIGINT UNSIGNED NOT NULL DEFAULT 1000,
    prev_price BIGINT UNSIGNED NOT NULL DEFAULT 1000,
    dividend_yield DECIMAL(4,2) UNSIGNED NOT NULL DEFAULT 0.00,
    volume BIGINT UNSIGNED NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_ticker (ticker),
    KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Player stock holdings
CREATE TABLE IF NOT EXISTS player_stocks (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    stock_id INT UNSIGNED NOT NULL,
    shares BIGINT UNSIGNED NOT NULL DEFAULT 0,
    avg_price BIGINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_user_stock (user_id, stock_id),
    KEY idx_user (user_id),
    FOREIGN KEY (stock_id) REFERENCES stocks(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Stock trade history
CREATE TABLE IF NOT EXISTS stock_history (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    stock_id INT UNSIGNED NOT NULL,
    type ENUM('buy','sell') NOT NULL,
    shares BIGINT UNSIGNED NOT NULL,
    price BIGINT UNSIGNED NOT NULL,
    total BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user (user_id),
    KEY idx_stock (stock_id),
    KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Stock dividends log
CREATE TABLE IF NOT EXISTS stock_dividends (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    stock_id INT UNSIGNED NOT NULL,
    ticker VARCHAR(10) NOT NULL,
    shares BIGINT UNSIGNED NOT NULL,
    per_share BIGINT UNSIGNED NOT NULL,
    amount BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user (user_id),
    KEY idx_stock (stock_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Pawned items
CREATE TABLE IF NOT EXISTS pawned_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    item_id INT UNSIGNED NOT NULL,
    user_item_id INT UNSIGNED NOT NULL,
    loan_amount BIGINT UNSIGNED NOT NULL,
    redeem_cost BIGINT UNSIGNED NOT NULL,
    buyout_price BIGINT UNSIGNED DEFAULT NULL,
    status ENUM('pawned','redeemed','forfeited') NOT NULL DEFAULT 'pawned',
    pawned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    due_at DATETIME NOT NULL,
    redeemed_at DATETIME NULL,
    forfeited_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_user (user_id),
    KEY idx_status (status),
    KEY idx_due (due_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Pawn redemption log
CREATE TABLE IF NOT EXISTS pawn_redeem_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    item_id INT UNSIGNED NOT NULL,
    amount_paid BIGINT UNSIGNED NOT NULL,
    redeemed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Trade Center enhancements
ALTER TABLE trades
    ADD COLUMN IF NOT EXISTS type ENUM('item','currency','mixed') NOT NULL DEFAULT 'item' AFTER status,
    ADD COLUMN IF NOT EXISTS expires_at DATETIME NULL AFTER terms,
    ADD COLUMN IF NOT EXISTS is_counter TINYINT(1) NOT NULL DEFAULT 0 AFTER expires_at,
    ADD COLUMN IF NOT EXISTS counter_to_id BIGINT UNSIGNED NULL AFTER is_counter;

-- Bump schema version
UPDATE settings SET v = '23' WHERE k = 'schema_version';