<?php
require_once __DIR__ . '/includes/init.php';
$u = require_login();

finish_expired_wars();

$crew = $u['crew_id'] ? fetch('SELECT * FROM crews WHERE id = ?', [$u['crew_id']]) : null;
$isLeader = $crew && (int) $crew['leader_id'] === $u['id'];
$isBoss = $crew && in_array($u['crew_rank'], ['Leader', 'Underboss'], true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    if (!$crew) {
        flash('Join a crew for diplomacy.', 'error');
        redirect('diplomacy.php');
    }
    if ($action === 'offer') {
        if (!$isBoss) {
            flash('Only a Leader or Underboss can send pacts.', 'error');
        } else {
            $target = fetch('SELECT * FROM crews WHERE id = ?', [(int) ($_POST['target_id'] ?? 0)]);
            $type = ($_POST['type'] ?? '') === 'alliance' ? 'alliance' : 'nap';
            if (!$target) {
                flash('Crew not found.', 'error');
            } elseif ((int) $target['id'] === (int) $crew['id']) {
                flash('Cannot pact with yourself.', 'error');
            } elseif (crew_relation((int) $crew['id'], (int) $target['id'])) {
                flash('You already have an active pact with that crew.', 'error');
            } elseif (active_war_between((int) $crew['id'], (int) $target['id'])) {
                flash('You are at war with that crew.', 'error');
            } else {
                $exists = fetch('SELECT id, status FROM crew_diplomacy WHERE (crew_a = ? AND crew_b = ?) OR (crew_a = ? AND crew_b = ?)', [$crew['id'], $target['id'], $target['id'], $crew['id']]);
                $cost = $type === 'alliance' ? 50000 : 25000;
                if ($exists && $exists['status'] === 'pending') {
                    flash('A pact offer is already pending with that crew.', 'error');
                } elseif ((int) $crew['money'] < $cost) {
                    flash('Your crew needs ' . money($cost) . ' to send this pact.', 'error');
                } else {
                    q('UPDATE crews SET money = money - ? WHERE id = ?', [$cost, $crew['id']]);
                    if ($exists) {
                        q('UPDATE crew_diplomacy SET type = ?, status = ?, declared_by = ?, created_at = NOW() WHERE id = ?', [$type, 'pending', $u['id'], $exists['id']]);
                    } else {
                        insert('crew_diplomacy', ['crew_a' => $crew['id'], 'crew_b' => $target['id'], 'type' => $type, 'status' => 'pending', 'declared_by' => $u['id']]);
                    }
                    notify_crew((int) $target['id'], e($crew['name']) . ' offers your crew a ' . strtoupper($type) . '.', 'diplomacy.php');
                    flash(($type === 'alliance' ? 'Alliance' : 'Non-Aggression Pact') . ' offer sent to ' . e($target['name']) . '.', 'success');
                }
            }
        }
    } elseif ($action === 'respond') {
        if (!$isBoss) {
            flash('Only a Leader or Underboss can respond.', 'error');
        } else {
            $pact = fetch('SELECT * FROM crew_diplomacy WHERE id = ?', [(int) ($_POST['pact_id'] ?? 0)]);
            $accept = ($_POST['answer'] ?? '') === 'accept';
            if (!$pact || $pact['status'] !== 'pending') {
                flash('Pact not found.', 'error');
            } elseif ((int) $pact['crew_a'] !== (int) $crew['id'] && (int) $pact['crew_b'] !== (int) $crew['id']) {
                flash('This pact does not involve your crew.', 'error');
            } else {
                if ($accept) {
                    q('UPDATE crew_diplomacy SET status = ? WHERE id = ?', ['active', $pact['id']]);
                    add_crew_xp((int) $crew['id'], 60);
                    $other = (int) $pact['crew_a'] === (int) $crew['id'] ? (int) $pact['crew_b'] : (int) $pact['crew_a'];
                    notify_crew($other, e($crew['name']) . ' accepted the ' . strtoupper($pact['type']) . '.', 'diplomacy.php');
                    notify_crew((int) $crew['id'], 'Pact accepted! (+60 crew XP)', 'diplomacy.php');
                    flash('Pact accepted. (+60 crew XP)', 'success');
                } else {
                    q('UPDATE crew_diplomacy SET status = ? WHERE id = ?', ['broken', $pact['id']]);
                    flash('Pact offer declined.', 'success');
                }
            }
        }
    } elseif ($action === 'break') {
        if (!$isBoss) {
            flash('Only a Leader or Underboss can break pacts.', 'error');
        } else {
            $pact = fetch('SELECT * FROM crew_diplomacy WHERE id = ?', [(int) ($_POST['pact_id'] ?? 0)]);
            if (!$pact || $pact['status'] !== 'active') {
                flash('Pact not found.', 'error');
            } elseif ((int) $pact['crew_a'] !== (int) $crew['id'] && (int) $pact['crew_b'] !== (int) $crew['id']) {
                flash('This pact does not involve your crew.', 'error');
            } else {
                q('UPDATE crew_diplomacy SET status = ? WHERE id = ?', ['broken', $pact['id']]);
                $other = (int) $pact['crew_a'] === (int) $crew['id'] ? (int) $pact['crew_b'] : (int) $pact['crew_a'];
                notify_crew($other, e($crew['name']) . ' broke the ' . strtoupper($pact['type']) . '.', 'diplomacy.php');
                flash('Pact broken. Relations are now hostile.', 'success');
            }
        }
    }
    redirect('diplomacy.php');
}

$page_title = 'Diplomacy';
require __DIR__ . '/includes/header.php';

if ($crew) {
    $activePacts = fetch_all(
        "SELECT cd.*, cA.name AS aname, cA.tag AS atag, cB.name AS bname, cB.tag AS btag
         FROM crew_diplomacy cd
         JOIN crews cA ON cA.id = cd.crew_a
         JOIN crews cB ON cB.id = cd.crew_b
         WHERE cd.status = 'active' AND (cd.crew_a = ? OR cd.crew_b = ?)
         ORDER BY cd.created_at DESC", [$crew['id'], $crew['id']]
    );
    $pendingPacts = fetch_all(
        "SELECT cd.*, cA.name AS aname, cA.tag AS atag, cB.name AS bname, cB.tag AS btag
         FROM crew_diplomacy cd
         JOIN crews cA ON cA.id = cd.crew_a
         JOIN crews cB ON cB.id = cd.crew_b
         WHERE cd.status = 'pending' AND (cd.crew_a = ? OR cd.crew_b = ?)
         ORDER BY cd.created_at DESC", [$crew['id'], $crew['id']]
    );
    $targets = fetch_all(
        "SELECT c.id, c.name, c.tag, c.level, COUNT(cm.user_id) AS members
         FROM crews c
         LEFT JOIN crew_members cm ON cm.crew_id = c.id
         WHERE c.id != ?
         GROUP BY c.id
         ORDER BY c.level DESC, members DESC
         LIMIT 25", [$crew['id']]
    );
}
?>
<div class="card">
  <div class="panel-heading">Diplomacy</div>
  <p class="muted small">Forge alliances and non-aggression pacts between families. Allies cannot be attacked or raided. Breaking a pact turns relations hostile.</p>
  <?php if (!$crew): ?>
    <p class="muted">Join a crew for diplomacy.</p>
  <?php else: ?>
    <div class="grid grid-4" style="margin-bottom:14px">
      <div class="stat"><span>Crew</span><b><?= e($crew['name']) ?></b></div>
      <div class="stat"><span>Crew XP</span><b><?= number_format((int) $crew['xp']) ?></b></div>
      <div class="stat"><span>Active Pacts</span><b><?= count($activePacts ?? []) ?></b></div>
      <div class="stat"><span>Pending Offers</span><b><?= count($pendingPacts ?? []) ?></b></div>
    </div>
  <?php endif; ?>
</div>

<?php if ($crew && $isBoss): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Send a Pact</div>
  <form method="post" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="offer">
    <select name="target_id" required style="min-width:220px">
      <option value="">— Select crew —</option>
      <?php foreach ($targets as $t):
        if (crew_relation((int) $crew['id'], (int) $t['id']) || active_war_between((int) $crew['id'], (int) $t['id'])) continue;
      ?>
        <option value="<?= (int) $t['id'] ?>"><?= e($t['name']) ?> [<?= e($t['tag']) ?>] (Lv <?= (int) $t['level'] ?>)</option>
      <?php endforeach; ?>
    </select>
    <select name="type">
      <option value="alliance">Alliance ($50,000)</option>
      <option value="nap">Non-Aggression Pact ($25,000)</option>
    </select>
    <button class="btn btn-gold" type="submit">Send Offer</button>
  </form>
</div>
<?php endif; ?>

<?php if ($crew && !empty($pendingPacts)): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Pending Offers</div>
  <div class="table-wrap"><table>
    <tr><th>Offer</th><th>Crews</th><th></th></tr>
    <?php foreach ($pendingPacts as $p):
      $incoming = (int) $p['crew_b'] === (int) $crew['id'];
      $other = $incoming ? $p['aname'] : $p['bname'];
      $otherTag = $incoming ? $p['atag'] : $p['btag'];
    ?>
      <tr>
        <td><b class="text-<?= $p['type'] === 'alliance' ? 'gold' : 'green' ?>"><?= strtoupper($p['type']) ?></b></td>
        <td><?= e($other) ?> <span class="tag tag-common">[<?= e($otherTag) ?>]</span> <?= $incoming ? '<span class="tag tag-epic">Incoming</span>' : '<span class="tag tag-common">Sent</span>' ?></td>
        <td>
          <?php if ($incoming && $isBoss): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="respond"><input type="hidden" name="pact_id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="answer" value="accept"><button class="btn btn-green btn-sm" type="submit">Accept</button></form>
            <form method="post" style="display:inline;margin-left:4px"><?= csrf_field() ?><input type="hidden" name="action" value="respond"><input type="hidden" name="pact_id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="answer" value="decline"><button class="btn btn-danger btn-sm" type="submit">Decline</button></form>
          <?php else: ?>
            <span class="muted small">Awaiting reply</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<?php if ($crew && !empty($activePacts)): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">Active Pacts</div>
  <div class="table-wrap"><table>
    <tr><th>Pact</th><th>With</th><th>Since</th><th></th></tr>
    <?php foreach ($activePacts as $p):
      $other = (int) $p['crew_a'] === (int) $crew['id'] ? $p['bname'] : $p['aname'];
      $otherTag = (int) $p['crew_a'] === (int) $crew['id'] ? $p['btag'] : $p['atag'];
    ?>
      <tr>
        <td><b class="text-<?= $p['type'] === 'alliance' ? 'gold' : 'green' ?>"><?= strtoupper($p['type']) ?></b></td>
        <td><?= e($other) ?> <span class="tag tag-common">[<?= e($otherTag) ?>]</span></td>
        <td><?= date('M j, Y', strtotime($p['created_at'])) ?></td>
        <td>
          <?php if ($isBoss): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="break"><input type="hidden" name="pact_id" value="<?= (int) $p['id'] ?>"><button class="btn btn-sm" type="submit" data-confirm="Break this pact?">Break</button></form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>

<?php if ($crew && empty($pendingPacts) && empty($activePacts)): ?>
<div class="card" style="margin-top:16px">
  <div class="panel-heading">No Pacts Yet</div>
  <p class="muted">Send an alliance or NAP offer to another crew to open relations.</p>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>