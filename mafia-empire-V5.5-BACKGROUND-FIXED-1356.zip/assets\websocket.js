/**
 * Mafia Empire - WebSocket Client for Real-time Features
 * Connects to the Ratchet WebSocket server for real-time updates
 */

class MafiaWebSocket {
    constructor() {
        this.ws = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;
        this.reconnectDelay = 1000;
        this.messageQueue = [];
        this.eventHandlers = new Map();
        this.tempIdCounter = 0;
        this.pendingMessages = new Map();
        this.channels = new Set();
        this.userId = null;
        this.username = null;
        this.isConnected = false;
        this.isConnecting = false;
        
        // Auto-reconnect on page visibility change
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible' && !this.isConnected) {
                this.connect();
            }
        });
        
        // Heartbeat
        this.heartbeatInterval = null;
    }
    
    connect() {
        if (this.isConnected || this.isConnecting) return;
        
        this.isConnecting = true;
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const host = window.location.hostname;
        const port = window.location.port || (protocol === 'wss:' ? 443 : 80);
        const wsUrl = `${protocol}//${host}:8080`;
        
        try {
            this.ws = new WebSocket(wsUrl);
            this.ws.binaryType = 'arraybuffer';
            
            this.ws.onopen = () => this.onOpen();
            this.ws.onmessage = (event) => this.onMessage(event);
            this.ws.onclose = (event) => this.onClose(event);
            this.ws.onerror = (error) => this.onError(error);
        } catch (e) {
            console.error('WebSocket connection failed:', e);
            this.scheduleReconnect();
        }
    }
    
    onOpen() {
        console.log('WebSocket connected');
        this.isConnected = true;
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        this.emit('connected');
        
        // Start heartbeat
        this.heartbeatInterval = setInterval(() => {
            if (this.isConnected) {
                this.send({ type: 'ping' });
            }
        }, 30000);
        
        // Send queued messages
        this.flushMessageQueue();
        
        // Re-subscribe to channels
        this.channels.forEach(channel => this.subscribe(channel));
    }
    
    onMessage(event) {
        try {
            const data = JSON.parse(event.data);
            this.handleMessage(data);
        } catch (e) {
            console.error('Failed to parse WebSocket message:', e);
        }
    }
    
    handleMessage(data) {
        const type = data.type;
        
        switch (type) {
            case 'auth_success':
                this.userId = data.user.id;
                this.username = data.user.username;
                this.emit('auth_success', data);
                break;
                
            case 'chat_message':
                this.emit('chat_message', data.message);
                break;
                
            case 'message_sent':
                this.handleMessageSent(data);
                break;
                
            case 'typing':
                this.emit('typing', data);
                break;
                
            case 'presence':
                this.emit('presence', data);
                break;
                
            case 'reaction':
                this.emit('reaction', data);
                break;
                
            case 'subscribed':
                this.channels.add(data.channel);
                this.emit('subscribed', data);
                break;
                
            case 'unsubscribed':
                this.channels.delete(data.channel);
                this.emit('unsubscribed', data);
                break;
                
            case 'pong':
                // Heartbeat response
                break;
                
            case 'error':
                console.error('WebSocket error:', data.message);
                this.emit('error', data.message);
                break;
                
            case 'auth_required':
                this.emit('auth_required');
                break;
                
            default:
                this.emit(type, data);
        }
    }
    
    handleMessageSent(data) {
        const pending = this.pendingMessages.get(data.temp_id);
        if (pending) {
            pending.resolve(data.message_id);
            this.pendingMessages.delete(data.temp_id);
        }
    }
    
    onClose(event) {
        console.log('WebSocket closed:', event.code, event.reason);
        this.isConnected = false;
        this.isConnecting = false;
        
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
        
        this.emit('disconnected', { code: event.code, reason: event.reason });
        
        if (event.code !== 1000) { // Not a clean close
            this.scheduleReconnect();
        }
    }
    
    onError(error) {
        console.error('WebSocket error:', error);
        this.emit('error', error);
    }
    
    scheduleReconnect() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.error('Max reconnect attempts reached');
            this.emit('max_reconnect_attempts');
            return;
        }
        
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts);
        this.reconnectAttempts++;
        
        console.log(`Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`);
        
        setTimeout(() => {
            if (!this.isConnected) {
                this.connect();
            }
        }, delay);
    }
    
    // Public API
    auth(token) {
        this.send({
            type: 'auth',
            token: token
        });
    }
    
    subscribe(channel) {
        if (!this.channels.has(channel)) {
            this.channels.add(channel);
        }
        this.send({ type: 'subscribe', channel });
    }
    
    unsubscribe(channel) {
        this.channels.delete(channel);
        this.send({ type: 'unsubscribe', channel });
    }
    
    sendChatMessage(channel, message, replyTo = null) {
        const tempId = ++this.tempIdCounter;
        
        return new Promise((resolve, reject) => {
            this.pendingMessages.set(tempId, { resolve, reject });
            
            this.send({
                type: 'chat_message',
                channel,
                message,
                reply_to: replyTo,
                temp_id: tempId
            });
            
            // Timeout after 10 seconds
            setTimeout(() => {
                if (this.pendingMessages.has(tempId)) {
                    this.pendingMessages.delete(tempId);
                    reject(new Error('Message send timeout'));
                }
            }, 10000);
        });
    }
    
    sendTyping(channel, isTyping) {
        this.send({
            type: isTyping ? 'typing_start' : 'typing_stop',
            channel
        });
    }
    
    setPresence(status) {
        this.send({ type: 'presence', status });
    }
    
    addReaction(channel, messageId, emoji) {
        this.send({
            type: 'reaction',
            channel,
            message_id: messageId,
            emoji
        });
    }
    
    send(payload) {
        if (this.isConnected && this.ws?.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(payload));
            return true;
        } else {
            this.messageQueue.push(payload);
            return false;
        }
    }
    
    flushMessageQueue() {
        while (this.messageQueue.length > 0) {
            const payload = this.messageQueue.shift();
            this.send(payload);
        }
    }
    
    // Event system
    on(event, handler) {
        if (!this.eventHandlers.has(event)) {
            this.eventHandlers.set(event, []);
        }
        this.eventHandlers.get(event).push(handler);
    }
    
    off(event, handler) {
        const handlers = this.eventHandlers.get(event);
        if (handlers) {
            const index = handlers.indexOf(handler);
            if (index !== -1) handlers.splice(index, 1);
        }
    }
    
    emit(event, data) {
        const handlers = this.eventHandlers.get(event) || [];
        handlers.forEach(handler => {
            try {
                handler(data);
            } catch (e) {
                console.error(`Error in ${event} handler:`, e);
            }
        });
    }
    
    disconnect() {
        if (this.ws) {
            this.ws.close(1000, 'Client disconnect');
        }
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
        }
    }
    
    getConnectionState() {
        return {
            connected: this.isConnected,
            connecting: this.isConnecting,
            userId: this.userId,
            username: this.username,
            channels: Array.from(this.channels)
        };
    }
}

// Auto-initialize if token available
document.addEventListener('DOMContentLoaded', () => {
    // Check for auth token in localStorage or meta tag
    const token = localStorage.getItem('ws_token') || 
                  document.querySelector('meta[name="ws-token"]')?.content;
    
    if (token && typeof MafiaWebSocket !== 'undefined') {
        window.mafiaWS = new MafiaWebSocket();
        window.mafiaWS.auth(token);
    }
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MafiaWebSocket;
}